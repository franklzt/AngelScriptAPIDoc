/* Class: AVariantManagerTestActor 
  */ 
 class AVariantManagerTestActor : public AActor
{
public:
// Group: Template

/* Variable: CapturedRotatorProperty 
 Captured FRotator property */
FRotator CapturedRotatorProperty;
/* Variable: EnumWithSecondDefault 
 Captured byte property */
EVariantManagerTestEnum EnumWithSecondDefault;
/* Variable: CapturedByteProperty 
 Captured byte property */
uint8 CapturedByteProperty;
/* Variable: CapturedIntProperty 
 Captured int32 property */
int CapturedIntProperty;
/* Variable: CapturedFloatProperty 
 Captured float property */
float32 CapturedFloatProperty;
/* Variable: bCapturedBoolProperty 
 Captured boolean property */
bool bCapturedBoolProperty;
/* Variable: CapturedObjectProperty 
 Captured UObject property */
UObject CapturedObjectProperty;
/* Variable: CapturedNameProperty 
 Captured FName property */
FName CapturedNameProperty;
/* Variable: CapturedStrProperty 
 Captured FString property */
FString CapturedStrProperty;
/* Variable: CapturedTextProperty 
 Captured FText property */
FText CapturedTextProperty;
/* Variable: EnumWithNoDefault 
 Captured byte property */
EVariantManagerTestEnum EnumWithNoDefault;
/* Variable: CapturedColorProperty 
 Captured FColor property */
FColor CapturedColorProperty;
/* Variable: CapturedLinearColorProperty 
 Captured FLinearColor property */
FLinearColor CapturedLinearColorProperty;
/* Variable: CapturedVectorProperty 
 Captured FVector property */
FVector CapturedVectorProperty;
/* Variable: CapturedQuatProperty 
 Captured FQuat property */
FQuat CapturedQuatProperty;
/* Variable: CapturedVector4Property 
 Captured FVector4 property */
FVector4 CapturedVector4Property;
/* Variable: CapturedVector2DProperty 
 Captured FVector2D property */
FVector2D CapturedVector2DProperty;
/* Variable: CapturedIntPointProperty 
 Captured FIntPoint property */
FIntPoint CapturedIntPointProperty;
/* Variable: CapturedUObjectArrayProperty 
 Captured UObject array property */
TArray<TObjectPtr<UObject>> CapturedUObjectArrayProperty;
/* Variable: CapturedVectorArrayProperty 
 Captured FVector array property */
TArray<FVector> CapturedVectorArrayProperty;
// Group: Static Functions

/* Function: Spawn 
  */
static AVariantManagerTestActor AVariantManagerTestActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVariantManagerTestActor::StaticClass() {}
}
