/* Class: ADocumentationActor 
  */ 
 class ADocumentationActor : public AActor
{
public:
// Group: HelpDocumentation

/* Variable: DocumentLink 
 Link to a help document. */
FString DocumentLink;
// Group: Sprite

/* Variable: Billboard 
  */
UMaterialBillboardComponent Billboard;
// Group: Static Functions

/* Function: Spawn 
  */
static ADocumentationActor ADocumentationActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADocumentationActor::StaticClass() {}
}
