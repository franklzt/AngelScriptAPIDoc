/* Class: AnimExecutionContext 
  */ 
 class AnimExecutionContext
{
public:
// Group: Animation|Utilities

/* Function: IsActive 
 Get whether this branch of the graph is active (i.e. NOT blending out). */
static bool AnimExecutionContext::IsActive(FAnimExecutionContext Context) {}
/* Function: GetAnimInstance 
 Get the anim instance that hosts this context */
static UAnimInstance AnimExecutionContext::GetAnimInstance(FAnimExecutionContext Context) {}
}
