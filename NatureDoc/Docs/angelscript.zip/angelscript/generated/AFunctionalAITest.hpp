/* Class: AFunctionalAITest 
 FuntionalAITest

Functional AI Test using a regular FAITestSpawnSet as a default SpawnSet class type. */ 
 class AFunctionalAITest : public AFunctionalAITestBase
{
public:
// Group: AITest

/* Variable: SpawnSets 
  */
TArray<FAITestSpawnSet> SpawnSets;
// Group: Static Functions

/* Function: Spawn 
  */
static AFunctionalAITest AFunctionalAITest::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AFunctionalAITest::StaticClass() {}
}
