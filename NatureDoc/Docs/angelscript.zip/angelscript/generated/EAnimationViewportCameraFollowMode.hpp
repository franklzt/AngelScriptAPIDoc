/* Class: EAnimationViewportCameraFollowMode 
  */ 
 class EAnimationViewportCameraFollowMode
{
public:
}
/* Enum: EAnimationViewportCameraFollowMode 
 
    None - Enum
    Bounds - Enum
    Bone - Enum
    Root - Enum
    EAnimationViewportCameraFollowMode_MAX - Enum */ 
 enum EAnimationViewportCameraFollowMode { 
None,
Bounds,
Bone,
Root,
EAnimationViewportCameraFollowMode_MAX, 
}