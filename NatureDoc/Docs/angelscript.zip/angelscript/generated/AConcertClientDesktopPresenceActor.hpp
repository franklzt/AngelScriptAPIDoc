/* Class: AConcertClientDesktopPresenceActor 
 A AConcertClientDesktopPresenceActor is a child of AConcertClientPresenceActor that is used to represent users in desktop */ 
 class AConcertClientDesktopPresenceActor : public AConcertClientPresenceActor
{
public:
// Group: Rendering

/* Variable: LaserPointer 
 Spline mesh representing laser */
USplineMeshComponent LaserPointer;
/* Variable: DesktopMeshComponent 
 The camera mesh component to show visually where the camera is placed */
UStaticMeshComponent DesktopMeshComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AConcertClientDesktopPresenceActor AConcertClientDesktopPresenceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AConcertClientDesktopPresenceActor::StaticClass() {}
}
