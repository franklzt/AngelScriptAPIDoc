/* Class: AISMPartitionActor 
 Actor base class for instance containers placed on a grid.
      See UActorPartitionSubsystem. */ 
 class AISMPartitionActor : public APartitionActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AISMPartitionActor AISMPartitionActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AISMPartitionActor::StaticClass() {}
}
