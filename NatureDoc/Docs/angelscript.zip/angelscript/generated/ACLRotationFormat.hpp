/* Class: ACLRotationFormat 
  */ 
 class ACLRotationFormat
{
public:
}
/* Enum: ACLRotationFormat 
 
    ACLRF_Quat_128 - Enum
    ACLRF_QuatDropW_96 - Enum
    ACLRF_QuatDropW_Variable - Enum
    ACLRF_MAX - Enum */ 
 enum ACLRotationFormat { 
ACLRF_Quat_128,
ACLRF_QuatDropW_96,
ACLRF_QuatDropW_Variable,
ACLRF_MAX, 
}