/* Class: AGeometryCollectionActor 
  */ 
 class AGeometryCollectionActor : public AActor
{
public:
// Group: Destruction

/* Variable: GeometryCollectionComponent 
 GeometryCollectionComponent */
UGeometryCollectionComponent GeometryCollectionComponent;
// Group: Physics

/* Function: RaycastSingle 
  */
bool RaycastSingle(FVector Start, FVector End, FHitResult& OutHit) const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AGeometryCollectionActor AGeometryCollectionActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGeometryCollectionActor::StaticClass() {}
}
