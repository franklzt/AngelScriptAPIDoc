/* Class: ALocationVolume 
 A volume representing a location in the world. Used for World Partition loading regions. */ 
 class ALocationVolume : public AVolume
{
public:
// Group: LocationVolume

/* Variable: DebugColor 
  */
FColor DebugColor;
// Group: WorldPartition

/* Function: Load 
 Load this location volume */
void Load() {}
/* Function: Unload 
 Unload this location volume */
void Unload() {}
/* Function: IsLoaded 
 Return if this location volume is loaded */
bool IsLoaded() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALocationVolume ALocationVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALocationVolume::StaticClass() {}
}
