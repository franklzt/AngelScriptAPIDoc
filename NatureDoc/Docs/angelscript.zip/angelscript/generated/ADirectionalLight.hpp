/* Class: ADirectionalLight 
 Implements a directional light actor. */ 
 class ADirectionalLight : public ALight
{
public:
// Group: Light

/* Variable: DirectionalLightComponent 
 EditorOnly reference to the light component to allow it to be displayed in the details panel correctly */
UDirectionalLightComponent DirectionalLightComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ADirectionalLight ADirectionalLight::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADirectionalLight::StaticClass() {}
}
