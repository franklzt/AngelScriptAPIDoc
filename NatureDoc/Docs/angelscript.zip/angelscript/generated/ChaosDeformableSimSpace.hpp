/* Class: ChaosDeformableSimSpace 
  */ 
 class ChaosDeformableSimSpace
{
public:
}
/* Enum: ChaosDeformableSimSpace 
 
    World - Enum
    ComponentXf - Enum
    Bone - Enum
    ChaosDeformableSimSpace_MAX - Enum */ 
 enum ChaosDeformableSimSpace { 
World,
ComponentXf,
Bone,
ChaosDeformableSimSpace_MAX, 
}