/* Class: APlayerStartPIE 
  */ 
 class APlayerStartPIE : public APlayerStart
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static APlayerStartPIE APlayerStartPIE::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APlayerStartPIE::StaticClass() {}
}
