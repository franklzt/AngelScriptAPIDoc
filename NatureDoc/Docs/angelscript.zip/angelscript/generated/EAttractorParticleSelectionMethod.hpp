/* Class: EAttractorParticleSelectionMethod 
  */ 
 class EAttractorParticleSelectionMethod
{
public:
}
/* Enum: EAttractorParticleSelectionMethod 
 
    EAPSM_Random - Enum
    EAPSM_Sequential - Enum
    EAPSM_MAX - Enum */ 
 enum EAttractorParticleSelectionMethod { 
EAPSM_Random,
EAPSM_Sequential,
EAPSM_MAX, 
}