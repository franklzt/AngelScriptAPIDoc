/* Class: EAxis 
  */ 
 class EAxis
{
public:
}
/* Enum: EAxis 
 
    None - Enum
    X - Enum
    Y - Enum
    Z - Enum
    EAxis_MAX - Enum */ 
 enum EAxis { 
None,
X,
Y,
Z,
EAxis_MAX, 
}