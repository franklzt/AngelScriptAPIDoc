/* Class: ATriggerBase 
 An actor used to generate collision events (begin/end overlap) in the level. */ 
 class ATriggerBase : public AActor
{
public:
// Group: TriggerBase

/* Variable: SpriteComponent 
 Billboard used to see the trigger in the editor */
UBillboardComponent SpriteComponent;
/* Variable: CollisionComponent 
 Shape component used for collision */
UShapeComponent CollisionComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ATriggerBase ATriggerBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATriggerBase::StaticClass() {}
}
