/* Class: AInstancedFoliageActor 
  */ 
 class AInstancedFoliageActor : public AISMPartitionActor
{
public:
// Group: Foliage

/* Function: RemoveAllInstances 
  */
static void AInstancedFoliageActor::RemoveAllInstances(UFoliageType InFoliageType) {}
/* Function: AddInstances 
  */
static void AInstancedFoliageActor::AddInstances(UFoliageType InFoliageType, TArray<FTransform> InTransforms) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AInstancedFoliageActor AInstancedFoliageActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AInstancedFoliageActor::StaticClass() {}
}
