/* Class: ALandscapeStreamingProxy 
  */ 
 class ALandscapeStreamingProxy : public ALandscapeProxy
{
public:
// Group: LandscapeProxy

/* Variable: LandscapeActorRef 
  */
TSoftObjectPtr<ALandscape> LandscapeActorRef;
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeStreamingProxy ALandscapeStreamingProxy::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeStreamingProxy::StaticClass() {}
}
