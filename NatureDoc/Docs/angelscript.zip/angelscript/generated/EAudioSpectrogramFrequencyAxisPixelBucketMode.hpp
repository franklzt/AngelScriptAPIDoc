/* Class: EAudioSpectrogramFrequencyAxisPixelBucketMode 
  */ 
 class EAudioSpectrogramFrequencyAxisPixelBucketMode
{
public:
}
/* Enum: EAudioSpectrogramFrequencyAxisPixelBucketMode 
 
    Sample - Enum
    Peak - Enum
    Average - Enum
    EAudioSpectrogramFrequencyAxisPixelBucketMode_MAX - Enum */ 
 enum EAudioSpectrogramFrequencyAxisPixelBucketMode { 
Sample,
Peak,
Average,
EAudioSpectrogramFrequencyAxisPixelBucketMode_MAX, 
}