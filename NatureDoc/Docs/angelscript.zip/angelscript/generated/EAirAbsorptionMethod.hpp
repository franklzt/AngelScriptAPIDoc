/* Class: EAirAbsorptionMethod 
  */ 
 class EAirAbsorptionMethod
{
public:
}
/* Enum: EAirAbsorptionMethod 
 
    Linear - Enum
    CustomCurve - Enum
    EAirAbsorptionMethod_MAX - Enum */ 
 enum EAirAbsorptionMethod { 
Linear,
CustomCurve,
EAirAbsorptionMethod_MAX, 
}