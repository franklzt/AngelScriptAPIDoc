/* Class: AHUD 
 Base class of the heads-up display. This has a canvas and a debug canvas on which primitives can be drawn.
It also contains a list of simple hit boxes that can be used for simple item click detection.
A method of rendering debug text is also included.
Provides some simple methods for rendering text, textures, rectangles and materials which can also be accessed from blueprints.
@see UCanvas
@see FHUDHitBox
@see FDebugTextInfo */ 
 class AHUD : public AActor
{
public:
// Group: HUD

/* Variable: bShowHUD 
 Whether or not the HUD should be drawn. */
bool bShowHUD;
/* Variable: OwningPawn 
 Returns the Pawn for this HUD's player. */
const APawn OwningPawn;
/* Variable: OwningPlayerController 
 Returns the PlayerController for this HUD's player. */
const APlayerController OwningPlayerController;
/* Variable: bLostFocusPaused 
 Tells whether the game was paused due to lost focus */
const bool bLostFocusPaused;
/* Variable: PlayerOwner 
 PlayerController which owns this HUD. */
APlayerController PlayerOwner;
/* Variable: bShowDebugInfo 
 If true, current ViewTarget shows debug information using its DisplayDebug(). */
bool bShowDebugInfo;
/* Variable: bShowHitBoxDebugInfo 
 If true, show hitbox debugging info. */
bool bShowHitBoxDebugInfo;
/* Variable: bShowOverlays 
 If true, render actor overlays. */
bool bShowOverlays;
/* Variable: bEnableDebugTextShadow 
 Put shadow on debug strings */
bool bEnableDebugTextShadow;
// Group: HUD

/* Function: DrawRect 
 Draws a colored untextured quad on the HUD.

Parameters:
    RectColor - Color of the rect. Can be translucent.
    ScreenX - Screen-space X coordinate of upper left corner of the quad.
    ScreenY - Screen-space Y coordinate of upper left corner of the quad.
    ScreenW - Screen-space width of the quad (in pixels).
    ScreenH - Screen-space height of the quad (in pixels). */
void DrawRect(FLinearColor RectColor, float32 ScreenX, float32 ScreenY, float32 ScreenW, float32 ScreenH) {}
/* Function: AddHitBox 
 Add a hitbox to the hud

Parameters:
    Position - Coordinates of the top left of the hit box.
    Size - Size of the hit box.
    bConsumesInput - Whether click processing should continue if this hit box is clicked.
    Priority - The priority of the box used for layering. Larger values are considered first.  Equal values are considered in the order they were added. */
void AddHitBox(FVector2D Position, FVector2D Size, FName InName, bool bConsumesInput, int Priority = 0) {}
/* Function: Deproject 
 Transforms a 2D screen location into a 3D location and direction */
void Deproject(float32 ScreenX, float32 ScreenY, FVector& WorldPosition, FVector& WorldDirection) const {}
/* Function: DrawLine 
 Draws a 2D line on the HUD.

Parameters:
    StartScreenX - Screen-space X coordinate of start of the line.
    StartScreenY - Screen-space Y coordinate of start of the line.
    EndScreenX - Screen-space X coordinate of end of the line.
    EndScreenY - Screen-space Y coordinate of end of the line.
    LineColor - Color to draw line
    LineThickness - Thickness of the line to draw */
void DrawLine(float32 StartScreenX, float32 StartScreenY, float32 EndScreenX, float32 EndScreenY, FLinearColor LineColor, float32 LineThickness = 0.000000) {}
/* Function: DrawMaterial 
 Draws a material-textured quad on the HUD.

Parameters:
    Material - Material to use
    ScreenX - Screen-space X coordinate of upper left corner of the quad.
    ScreenY - Screen-space Y coordinate of upper left corner of the quad.
    ScreenW - Screen-space width of the quad (in pixels).
    ScreenH - Screen-space height of the quad (in pixels).
    MaterialU - Texture-space U coordinate of upper left corner of the quad
    MaterialV - Texture-space V coordinate of upper left corner of the quad.
    MaterialUWidth - Texture-space width of the quad (in normalized UV distance).
    MaterialVHeight - Texture-space height of the quad (in normalized UV distance).
    Scale - Amount to scale the entire texture (horizontally and vertically)
    bScalePosition - Whether the "Scale" parameter should also scale the position of this draw call.
    Rotation - Amount to rotate this quad
    RotPivot - Location (as proportion of quad, 0-1) to rotate about */
void DrawMaterial(UMaterialInterface Material, float32 ScreenX, float32 ScreenY, float32 ScreenW, float32 ScreenH, float32 MaterialU, float32 MaterialV, float32 MaterialUWidth, float32 MaterialVHeight, float32 Scale = 1.000000, bool bScalePosition = false, float32 Rotation = 0.000000, FVector2D RotPivot = FVector2D ( )) {}
/* Function: DrawMaterialSimple 
 Draws a material-textured quad on the HUD.  Assumes UVs such that the entire material is shown.

Parameters:
    Material - Material to use
    ScreenX - Screen-space X coordinate of upper left corner of the quad.
    ScreenY - Screen-space Y coordinate of upper left corner of the quad.
    ScreenW - Screen-space width of the quad (in pixels).
    ScreenH - Screen-space height of the quad (in pixels).
    Scale - Amount to scale the entire texture (horizontally and vertically)
    bScalePosition - Whether the "Scale" parameter should also scale the position of this draw call. */
void DrawMaterialSimple(UMaterialInterface Material, float32 ScreenX, float32 ScreenY, float32 ScreenW, float32 ScreenH, float32 Scale = 1.000000, bool bScalePosition = false) {}
/* Function: DrawMaterialTriangle 
  */
void DrawMaterialTriangle(UMaterialInterface Material, FVector2D V0_Pos, FVector2D V1_Pos, FVector2D V2_Pos, FVector2D V0_UV, FVector2D V1_UV, FVector2D V2_UV, FLinearColor V0_Color = FLinearColor ( 1.000000 , 1.000000 , 1.000000 , 1.000000 ), FLinearColor V1_Color = FLinearColor ( 1.000000 , 1.000000 , 1.000000 , 1.000000 ), FLinearColor V2_Color = FLinearColor ( 1.000000 , 1.000000 , 1.000000 , 1.000000 )) {}
/* Function: Project 
 Transforms a 3D world-space vector into 2D screen coordinates

Parameters:
    Location - The world-space position to transform
    bClampToZeroPlane - If true, 2D screen coordinates behind the viewing plane (-Z) will have Z set to 0 (leaving X and Y alone)

Returns:
    The transformed vector */
FVector Project(FVector Location, bool bClampToZeroPlane = true) const {}
/* Function: DrawText 
 Draws a string on the HUD.

Parameters:
    Text - String to draw
    TextColor - Color to draw string
    ScreenX - Screen-space X coordinate of upper left corner of the string.
    ScreenY - Screen-space Y coordinate of upper left corner of the string.
    Font - Font to draw text.  If NULL, default font is chosen.
    Scale - Scale multiplier to control size of the text.
    bScalePosition - Whether the "Scale" parameter should also scale the position of this draw call. */
void DrawText(FString Text, FLinearColor TextColor, float32 ScreenX, float32 ScreenY, UFont Font = nullptr, float32 Scale = 1.000000, bool bScalePosition = false) {}
/* Function: DrawTexture 
 Draws a textured quad on the HUD.

Parameters:
    Texture - Texture to draw.
    ScreenX - Screen-space X coordinate of upper left corner of the quad.
    ScreenY - Screen-space Y coordinate of upper left corner of the quad.
    ScreenW - Screen-space width of the quad (in pixels).
    ScreenH - Screen-space height of the quad (in pixels).
    TextureU - Texture-space U coordinate of upper left corner of the quad
    TextureV - Texture-space V coordinate of upper left corner of the quad.
    TextureUWidth - Texture-space width of the quad (in normalized UV distance).
    TextureVHeight - Texture-space height of the quad (in normalized UV distance).
    TintColor - Vertex color for the quad.
    BlendMode - Controls how to blend this quad with the scene. Translucent by default.
    Scale - Amount to scale the entire texture (horizontally and vertically)
    bScalePosition - Whether the "Scale" parameter should also scale the position of this draw call.
    Rotation - Amount to rotate this quad
    RotPivot - Location (as proportion of quad, 0-1) to rotate about */
void DrawTexture(UTexture Texture, float32 ScreenX, float32 ScreenY, float32 ScreenW, float32 ScreenH, float32 TextureU, float32 TextureV, float32 TextureUWidth, float32 TextureVHeight, FLinearColor TintColor = FLinearColor ( 1.000000 , 1.000000 , 1.000000 , 1.000000 ), EBlendMode BlendMode = EBlendMode :: BLEND_Translucent, float32 Scale = 1.000000, bool bScalePosition = false, float32 Rotation = 0.000000, FVector2D RotPivot = FVector2D ( )) {}
/* Function: DrawTextureSimple 
 Draws a textured quad on the HUD. Assumes 1:1 texel density.

Parameters:
    Texture - Texture to draw.
    ScreenX - Screen-space X coordinate of upper left corner of the quad.
    ScreenY - Screen-space Y coordinate of upper left corner of the quad.
    Scale - Scale multiplier to control size of the text.
    bScalePosition - Whether the "Scale" parameter should also scale the position of this draw call. */
void DrawTextureSimple(UTexture Texture, float32 ScreenX, float32 ScreenY, float32 Scale = 1.000000, bool bScalePosition = false) {}
/* Function: GetActorsInSelectionRectangle 
 Returns the array of actors inside a selection rectangle, with a class filter.

Sample usage:

      TArray<AStaticMeshActor*> ActorsInSelectionRect;
             Canvas->GetActorsInSelectionRectangle<AStaticMeshActor>(FirstPoint,SecondPoint,ActorsInSelectionRect);

Parameters:
    FirstPoint - The first point, or anchor of the marquee box. Where the dragging of the marquee started in screen space.
    SecondPoint - The second point, where the mouse cursor currently is / the other point of the box selection, in screen space.
    bIncludeNonCollidingComponents - Whether to include even non-colliding components of the actor when determining its bounds
    bActorMustBeFullyEnclosed - The Selection rule: whether the selection box can partially intersect Actor, or must fully enclose the Actor.

Returns:
    OutActors                                    The actors that are within the selection box according to selection rule */
void GetActorsInSelectionRectangle(TSubclassOf<AActor> ClassFilter, FVector2D FirstPoint, FVector2D SecondPoint, TArray<AActor>& OutActors, bool bIncludeNonCollidingComponents = true, bool bActorMustBeFullyEnclosed = false) {}
/* Function: GetOwningPawn 
 Returns the Pawn for this HUD's player. */
APawn GetOwningPawn() const {}
/* Function: GetOwningPlayerController 
 Returns the PlayerController for this HUD's player. */
APlayerController GetOwningPlayerController() const {}
/* Function: GetTextSize 
 Returns the width and height of a string.

Parameters:
    Text - String to draw
    OutWidth - Returns the width in pixels of the string.
    OutHeight - Returns the height in pixels of the string.
    Font - Font to draw text.  If NULL, default font is chosen.
    Scale - Scale multiplier to control size of the text. */
void GetTextSize(FString Text, float32& OutWidth, float32& OutHeight, UFont Font = nullptr, float32 Scale = 1.000000) const {}
// Group: Functions

/* Function: HitBoxClick 
 Called when a hit box is clicked on. Provides the name associated with that box. */
void HitBoxClick(const FName BoxName) {}
/* Function: DrawHUD 
 Hook to allow blueprints to do custom HUD drawing. See: bSuppressNativeHUD to control HUD drawing in base class.
Note:  the canvas resource used for drawing is only valid during this event, it will not be valid if drawing functions are called later (e.g. after a Delay node). */
void DrawHUD(int SizeX, int SizeY) {}
/* Function: HitBoxBeginCursorOver 
 Called when a hit box is moused over. */
void HitBoxBeginCursorOver(const FName BoxName) {}
/* Function: AddDebugText 
 Add debug text for a specific actor to be displayed via DrawDebugTextList().  If the debug text is invalid then it will
attempt to remove any previous entries via RemoveDebugText().

Parameters:
    DebugText - Text to draw
    SrcActor - Actor to which this relates
    Duration - Duration to display the string
    Offset - Initial offset to render text
    DesiredOffset - Desired offset to render text - the text will move to this location over the given duration
    TextColor - Color of text to render
    bSkipOverwriteCheck - skips the check to see if there is already debug text for the given actor
    bAbsoluteLocation - use an absolute world location
    bKeepAttachedToActor - if this is true the text will follow the actor, otherwise it will be drawn at the location when the call was made
    InFont - font to use
    FontScale - scale
    bDrawShadow - Draw shadow on this string */
void AddDebugText(FString DebugText, AActor SrcActor, float32 Duration, FVector Offset, FVector DesiredOffset, FColor TextColor, bool bSkipOverwriteCheck, bool bAbsoluteLocation, bool bKeepAttachedToActor, UFont InFont, float32 FontScale, bool bDrawShadow) {}
/* Function: HitBoxEndCursorOver 
 Called when a hit box no longer has the mouse over it. */
void HitBoxEndCursorOver(const FName BoxName) {}
/* Function: HitBoxRelease 
 Called when a hit box is unclicked. Provides the name associated with that box. */
void HitBoxRelease(const FName BoxName) {}
/* Function: RemoveAllDebugStrings 
 Remove all debug strings added via AddDebugText */
void RemoveAllDebugStrings() {}
/* Function: RemoveDebugText 
 Remove debug strings for the given actor

Parameters:
    SrcActor - Actor whose string you wish to remove
    bLeaveDurationText - when true text that has a finite duration will be removed, otherwise all will be removed for given actor */
void RemoveDebugText(AActor SrcActor, bool bLeaveDurationText) {}
/* Function: GetbLostFocusPaused 
 Tells whether the game was paused due to lost focus */
bool GetbLostFocusPaused() const {}
/* Function: GetbShowHUD 
 Whether or not the HUD should be drawn. */
bool GetbShowHUD() const {}
/* Function: SetbShowHUD 
 Whether or not the HUD should be drawn. */
void SetbShowHUD(bool Value) {}
/* Function: GetbShowDebugInfo 
 If true, current ViewTarget shows debug information using its DisplayDebug(). */
bool GetbShowDebugInfo() const {}
/* Function: SetbShowDebugInfo 
 If true, current ViewTarget shows debug information using its DisplayDebug(). */
void SetbShowDebugInfo(bool Value) {}
/* Function: GetbShowHitBoxDebugInfo 
 If true, show hitbox debugging info. */
bool GetbShowHitBoxDebugInfo() const {}
/* Function: SetbShowHitBoxDebugInfo 
 If true, show hitbox debugging info. */
void SetbShowHitBoxDebugInfo(bool Value) {}
/* Function: GetbShowOverlays 
 If true, render actor overlays. */
bool GetbShowOverlays() const {}
/* Function: SetbShowOverlays 
 If true, render actor overlays. */
void SetbShowOverlays(bool Value) {}
/* Function: GetbEnableDebugTextShadow 
 Put shadow on debug strings */
bool GetbEnableDebugTextShadow() const {}
/* Function: SetbEnableDebugTextShadow 
 Put shadow on debug strings */
void SetbEnableDebugTextShadow(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AHUD AHUD::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AHUD::StaticClass() {}
}
