/* Class: ControlRigSequencer 
  */ 
 class ControlRigSequencer
{
public:
// Group: Static Variables

/* Variable: DefaultParentKey 
  */
static const FRigElementKey ControlRigSequencer::DefaultParentKey;
/* Variable: VisibleControlRigs 
  */
static const TArray<UControlRig> ControlRigSequencer::VisibleControlRigs;
/* Variable: WorldSpaceReferenceKey 
  */
static const FRigElementKey ControlRigSequencer::WorldSpaceReferenceKey;
/* Variable: AnimLayers 
  */
static const TArray<UAnimLayer> ControlRigSequencer::AnimLayers;
// Group: Editor Scripting | Sequencer Tools | Control Rig

/* Function: GetLocalControlRigTransforms 
 Get ControlRig Control's Transform values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Transform control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<FTransform> ControlRigSequencer::GetLocalControlRigTransforms(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: AddConstraint 
 Add a constraint possibly adding to sequencer also if one is open.

Parameters:
    World - The active world
    InType - Type of constraint to create
    InChild - The handle to the transormable to be constrainted
    InParent - The handle to the parent of the constraint
    bMaintainOffset - Whether to maintain offset between child and parent when setting the constraint

Returns:
    Returns the constraint if created all nullptr if not */
static UTickableConstraint ControlRigSequencer::AddConstraint(UWorld World, ETransformConstraintType InType, UTransformableHandle InChild, UTransformableHandle InParent, bool bMaintainOffset) {}
/* Function: BakeConstraint 
 Bake the constraint to keys based on the passed in frames. This will use the open sequencer to bake. See ConstraintsScriptingLibrary to get the list of available constraints

Parameters:
    World - The active world
    Constraint - The Constraint to bake. After baking it will be keyed to be inactive of the range of frames that are baked
    Frames - The frames to bake, if the array is empty it will use the active time ranges of the constraint to determine where it should bake
    TimeUnit - Unit for all frame and time values, either in display rate or tick resolution

Returns:
    Returns True if successful, False otherwise */
static bool ControlRigSequencer::BakeConstraint(UWorld World, UTickableConstraint Constraint, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: BakeConstraints 
 Bake the constraint to keys based on the passed in settings. This will use the open sequencer to bake. See ConstraintsScriptingLibrary to get the list of available constraints

Parameters:
    World - The active world
    InConstraints - The Constraints tobake.  After baking they will be keyed to be inactive of the range of frames that are baked
    InSettings - Settings to use for baking

Returns:
    Returns True if successful, False otherwise */
static bool ControlRigSequencer::BakeConstraints(UWorld World, TArray<UTickableConstraint>& InConstraints, FBakingAnimationKeySettings InSettings) {}
/* Function: BakeControlRigSpace 
 Bake specified Control Rig Controls to a specified Space based upon the current settings

Parameters:
    InSequence - Sequence to bake
    InControlRig - ControlRig to bake
    InControlNames - The name of the Controls to bake
    InSettings - The settings for the bake, e.g, how long to bake, to key reduce etc.
    TimeUnit - Unit for the start and end times in the InSettings parameter. */
static bool ControlRigSequencer::BakeControlRigSpace(ULevelSequence InSequence, UControlRig InControlRig, TArray<FName> InControlNames, FRigSpacePickerBakeSettings InSettings, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: BakeToControlRig 
 Bake the current animation in the binding to a Control Rig track

Parameters:
    World - The active world
    LevelSequence - The LevelSequence we are baking
    ControlRigClass - The class of the Control Rig
    ExportOptions - Export options for creating an animation sequence
    Tolerance - If reducing keys, tolerance about which keys will be removed, smaller tolerance, more keys usually.
    Binding - The binding upon which to bake
    bResetControls - If true will reset all controls to initial value on every frame

Returns:
    returns True if successful, False otherwise */
static bool ControlRigSequencer::BakeToControlRig(UWorld World, ULevelSequence LevelSequence, UClass ControlRigClass, UAnimSeqExportOption ExportOptions, bool bReduceKeys, float32 Tolerance, FMovieSceneBindingProxy Binding, bool bResetControls = true) {}
/* Function: BlendValuesOnSelected 
 Peform specified blend operation based upon selected keys in the curve editor or selected control rig controls

Parameters:
    LevelSequence - The LevelSequence that's loaded in the editor
    BlendValue - The blend value to use, range from -1(blend to previous) to 1(blend to next) */
static bool ControlRigSequencer::BlendValuesOnSelected(ULevelSequence LevelSequence, EAnimToolBlendOperation BlendOperation, float32 BlendValue) {}
/* Function: CollapseControlRigAnimLayers 
 * Collapse and bake all sections and layers on a control rig track to just one section.
*
*

Parameters:
    InSequence - Sequence that has track to collapse *
    InTrack - Track for layers to collapse *
    bKeyReduce - If true do key reduction based upon Tolerance, if false don't *
    Tolerance - If reducing keys, tolerance about which keys will be removed, smaller tolerance, more keys usually. */
static bool ControlRigSequencer::CollapseControlRigAnimLayers(ULevelSequence InSequence, UMovieSceneControlRigParameterTrack InTrack, bool bKeyReduce = false, float32 Tolerance = 0.001000) {}
/* Function: CollapseControlRigAnimLayersWithSettings 
 * Collapse and bake all sections and layers on a control rig track to just one section using passed in settings.
*
*

Parameters:
    InSequence - Sequence that has track to collapse *
    InTrack - Track for layers to collapse *
    InSettings - Settings that determine how to collapse */
static bool ControlRigSequencer::CollapseControlRigAnimLayersWithSettings(ULevelSequence InSequence, UMovieSceneControlRigParameterTrack InTrack, FBakingAnimationKeySettings InSettings) {}
/* Function: Compensate 
 Compensate constraint at the specfied time

Parameters:
    InConstraint - The constraint to compensate
    InTime - Time to compensate
    TimeUnit - Unit for the InTime, either in display rate or tick resolution

Returns:
    Returns true if it can compensate */
static bool ControlRigSequencer::Compensate(UTickableConstraint InConstraint, FFrameNumber InTime, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: CompensateAll 
 Compensate constraint at all keys

Parameters:
    InConstraint - The constraint to compensate

Returns:
    Returns true if it can compensate */
static bool ControlRigSequencer::CompensateAll(UTickableConstraint InConstraint) {}
/* Function: GetWorldSpaceReferenceKey 
 * Get the default world space key, can be used a world space. */
static FRigElementKey ControlRigSequencer::GetWorldSpaceReferenceKey() {}
/* Function: DeleteConstraintKey 
 Delete the Key for the Constraint at the specified time.

Parameters:
    ConstraintSection - Section containing Cosntraint Key
    InTime - Time to delete the constraint.
    TimeUnit - Unit for the InTime, either in display rate or tick resolution

Returns:
    Will return false if function fails,  for example if there is no key at this time it will fail. */
static bool ControlRigSequencer::DeleteConstraintKey(UTickableConstraint Constraint, UMovieSceneSection ConstraintSection, FFrameNumber InTime, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: DeleteControlRigSpace 
 Delete the Control Rig Space Key for the Control at the specified time. This will delete any attached Control Rig keys at this time and will perform any needed compensation to the new space.

Parameters:
    InSequence - Sequence to set the space
    InControlRig - ControlRig with the Control
    InControlName - The name of the Control
    InTime - Time to delete the space.
    TimeUnit - Unit for the InTime, either in display rate or tick resolution

Returns:
    Will return false if function fails,  for example if there is no key at this time it will fail. */
static bool ControlRigSequencer::DeleteControlRigSpace(ULevelSequence InSequence, UControlRig InControlRig, FName InControlName, FFrameNumber InTime, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: HideAllControls 
 Hides all of the controls for the given section */
static void ControlRigSequencer::HideAllControls(UMovieSceneSection InSection) {}
/* Function: SnapControlRig 
 Peform a Snap operation to snap the children to the parent.

Parameters:
    LevelSequence - Active Sequence to snap
    StartFrame - Beginning of the snap
    EndFrame - End of the snap
    ChildrenToSnap - The children objects that snap and get keys set onto. They need to live in an active Sequencer in the level editor
    ParentToSnap - The parent object to snap relative to. If animated, it needs to live in an active Sequencer in the level editor
    SnapSettings - Settings to use
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static bool ControlRigSequencer::SnapControlRig(ULevelSequence LevelSequence, FFrameNumber StartFrame, FFrameNumber EndFrame, FControlRigSnapperSelection ChildrenToSnap, FControlRigSnapperSelection ParentToSnap, const UControlRigSnapSettings SnapSettings, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: FindOrCreateControlRigComponentTrack 
 Find or create a Control Rig Component

Parameters:
    World - The world used to spawn into temporarily if binding is a spawnable
    LevelSequence - The LevelSequence to find or create
    InBinding - The binding (actor or component binding) to find or create the Control Rig tracks

Returns:
    returns Find array of component Control Rigs that were found or created */
static TArray<UMovieSceneTrack> ControlRigSequencer::FindOrCreateControlRigComponentTrack(UWorld World, ULevelSequence LevelSequence, FMovieSceneBindingProxy InBinding) {}
/* Function: FindOrCreateControlRigTrack 
 Find or create a Control Rig track of a specific class based upon the binding

Parameters:
    World - The world used to spawn into temporarily if binding is a spawnable
    LevelSequence - The LevelSequence to find or create
    ControlRigClass - The class of the Control Rig
    InBinding - The binding (actor or component binding) to find or create the Control Rig track

Returns:
    returns Return the found or created track */
static UMovieSceneTrack ControlRigSequencer::FindOrCreateControlRigTrack(UWorld World, ULevelSequence LevelSequence, const UClass ControlRigClass, FMovieSceneBindingProxy InBinding, bool bIsLayeredControlRig = false) {}
/* Function: GetActorWorldTransform 
 Get Actors World Transform at a specific time

Parameters:
    LevelSequence - Active Sequence to get transform for
    Actor - The actor
    Frame - Time to get the transform
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns World Transform */
static FTransform ControlRigSequencer::GetActorWorldTransform(ULevelSequence LevelSequence, AActor Actor, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetActorWorldTransforms 
 Get Actors World Transforms at specific times

Parameters:
    LevelSequence - Active Sequence to get transform for
    Actor - The actor
    Frames - Times to get the transform
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns World Transforms */
static TArray<FTransform> ControlRigSequencer::GetActorWorldTransforms(ULevelSequence LevelSequence, AActor Actor, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SpaceCompensate 
 Perform compensation for any spaces at the specified time for the specified control rig

Parameters:
    InControlRig - Control Rig to compensate
    InTime - The time to look for a space key to compensate
    TimeUnit - Unit for the InTime

Returns:
    Will return false if function fails */
static bool ControlRigSequencer::SpaceCompensate(UControlRig InControlRig, FFrameNumber InTime, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: IsFKControlRig 
 Whether or not the control rig is an FK Control Rig.

Parameters:
    InControlRig - Rig to test to see if FK Control Rig */
static bool ControlRigSequencer::IsFKControlRig(UControlRig InControlRig) {}
/* Function: GetConstraintKeys 
 Get the constraint keys for the specified constraint

Parameters:
    InConstraint - The constraint to get
    ConstraintSection - Section containing Cosntraint Key
    OutBools - Array of whether or not it's active at the specified times
    OutFrames - The Times for the keys
    TimeUnit - Unit for the time params, either in display rate or tick resolution

Returns:
    Returns true if we got the keys from this constraint */
static bool ControlRigSequencer::GetConstraintKeys(UTickableConstraint InConstraint, UMovieSceneSection ConstraintSection, TArray<bool>& OutBools, TArray<FFrameNumber>& OutFrames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetConstraintsForHandle 
 Get all constraints for this object, which is described by a transformable handle

Parameters:
    InChild - The handle to look for constraints controlling it

Returns:
    Returns array of Constraints this handle is constrained to. */
static TArray<UTickableConstraint> ControlRigSequencer::GetConstraintsForHandle(UWorld InWorld, const UTransformableHandle InChild) {}
/* Function: GetControlRigPriorityOrder 
 Get Control Rig prirority order */
static int ControlRigSequencer::GetControlRigPriorityOrder(UMovieSceneTrack InSection) {}
/* Function: GetControlRigs 
 Get all of the control rigs and their bindings in the level sequence

Parameters:
    LevelSequence - The movie scene sequence to look for Control Rigs

Returns:
    returns list of Control Rigs in the level sequence. */
static TArray<FControlRigSequencerBindingProxy> ControlRigSequencer::GetControlRigs(ULevelSequence LevelSequence) {}
/* Function: GetControlRigWorldTransform 
 Get ControlRig Control's World Transform at a specific time

Parameters:
    LevelSequence - Active Sequence to get transform for
    ControlRig - The ControlRig
    ControlName - Name of the Control
    Frame - Time to get the transform
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns World Transform */
static FTransform ControlRigSequencer::GetControlRigWorldTransform(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetControlRigWorldTransforms 
 Get ControlRig Control's World Transforms at specific times

Parameters:
    LevelSequence - Active Sequence to get transform for
    ControlRig - The ControlRig
    ControlName - Name of the Control
    Frames - Times to get the transform
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns World Transforms */
static TArray<FTransform> ControlRigSequencer::GetControlRigWorldTransforms(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetControlsMask 
 Get the controls mask for the given ControlName */
static bool ControlRigSequencer::GetControlsMask(UMovieSceneSection InSection, FName ControlName) {}
/* Function: GetDefaultParentKey 
 * Get the default parent key, can be used a parent space. */
static FRigElementKey ControlRigSequencer::GetDefaultParentKey() {}
/* Function: GetFKControlRigApplyMode 
 Get FKControlRig Apply Mode.

Parameters:
    InControlRig - Rig to test

Returns:
    The EControlRigFKRigExecuteMode mode it is in, either Replace,Additive or Direct */
static EControlRigFKRigExecuteMode ControlRigSequencer::GetFKControlRigApplyMode(UControlRig InControlRig) {}
/* Function: GetLocalControlRigBool 
 Get ControlRig Control's bool value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a bool control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static bool ControlRigSequencer::GetLocalControlRigBool(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigBools 
 Get ControlRig Control's bool values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a bool control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<bool> ControlRigSequencer::GetLocalControlRigBools(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigEulerTransform 
 Get ControlRig Control's EulerTransform value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a EulerTransfom control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static FEulerTransform ControlRigSequencer::GetLocalControlRigEulerTransform(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigEulerTransforms 
 Get ControlRig Control's EulerTransform values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a EulerTransform control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<FEulerTransform> ControlRigSequencer::GetLocalControlRigEulerTransforms(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigFloat 
 Get ControlRig Control's float value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a float control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static float32 ControlRigSequencer::GetLocalControlRigFloat(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigFloats 
 Get ControlRig Control's float values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a float control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<float32> ControlRigSequencer::GetLocalControlRigFloats(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigInt 
 Get ControlRig Control's integer value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a integer control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static int ControlRigSequencer::GetLocalControlRigInt(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigInts 
 Get ControlRig Control's integer values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a intteger control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<int> ControlRigSequencer::GetLocalControlRigInts(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigPosition 
 Get ControlRig Control's Position value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Position control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static FVector ControlRigSequencer::GetLocalControlRigPosition(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigPositions 
 Get ControlRig Control's Position values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Position control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<FVector> ControlRigSequencer::GetLocalControlRigPositions(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigRotator 
 Get ControlRig Control's Rotator value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Rotator control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static FRotator ControlRigSequencer::GetLocalControlRigRotator(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigRotators 
 Get ControlRig Control's Rotator values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Rotator control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<FRotator> ControlRigSequencer::GetLocalControlRigRotators(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigScale 
 Get ControlRig Control's Scale value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Scale control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static FVector ControlRigSequencer::GetLocalControlRigScale(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigScales 
 Get ControlRig Control's Scale values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Scale control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<FVector> ControlRigSequencer::GetLocalControlRigScales(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigTransform 
 Get ControlRig Control's Transform value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Transform control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static FTransform ControlRigSequencer::GetLocalControlRigTransform(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigTransformNoScale 
 Get ControlRig Control's TransformNoScale value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a TransformNoScale control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static FTransformNoScale ControlRigSequencer::GetLocalControlRigTransformNoScale(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigTransformNoScales 
 Get ControlRig Control's TransformNoScale values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a TransformNoScale control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<FTransformNoScale> ControlRigSequencer::GetLocalControlRigTransformNoScales(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigVector2D 
 Set ControlRig Control's Vector2D value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Vector2D control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigVector2D(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FVector2D Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: ShowAllControls 
 Shows all of the controls for the given section */
static void ControlRigSequencer::ShowAllControls(UMovieSceneSection InSection) {}
/* Function: SetLocalControlRigVector2Ds 
 Set ControlRig Control's Vector2D values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Vector2D control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigVector2Ds(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<FVector2D> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigVector2D 
 Get ControlRig Control's Vector2D value at a specific time

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Vector2D control
    Frame - Time to get the value
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Value at that time */
static FVector2D ControlRigSequencer::GetLocalControlRigVector2D(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: GetLocalControlRigVector2Ds 
 Get ControlRig Control's Vector2D values at specific times

Parameters:
    LevelSequence - Active Sequence to get value for
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Vector2D control
    Frames - Times to get the values
    TimeUnit - Unit for frame values, either in display rate or tick resolution

Returns:
    Returns Values at those times */
static TArray<FVector2D> ControlRigSequencer::GetLocalControlRigVector2Ds(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SmartReduce 
 Peform new Smart Reduce filter over the specified control rig section in the current open level sequence. Note existing
functions like LoadAnimSequenceIntoControlRigSection and BakeToControlRig, will still use the old key reduction algorithm,
so if you want to bake and then key reduce with the new function, set the bKeyReduce param as false with those functions,
but then call this function after.

Parameters:
    ReduceParams - Key reduction parameters
    MovieSceneSection - The Control rig section we want to reduce

Returns:
    returns True if successful, False otherwise */
static bool ControlRigSequencer::SmartReduce(FSmartReduceParams& ReduceParams, UMovieSceneSection MovieSceneSection) {}
/* Function: TweenControlRig 
 Peform a Tween operation on the current active sequencer time(must be visible).

Parameters:
    LevelSequence - The LevelSequence that's loaded in the editor
    ControlRig - The Control Rig to tween.
    TweenValue - The tween value to use, range from -1(blend to previous) to 1(blend to next) */
static bool ControlRigSequencer::TweenControlRig(ULevelSequence LevelSequence, UControlRig ControlRig, float32 TweenValue) {}
/* Function: GetSkeletalMeshComponentWorldTransform 
 Get SkeletalMeshComponent World Transform at a specific time

Parameters:
    LevelSequence - Active Sequence to get transform for
    SkeletalMeshComponent - The SkeletalMeshComponent
    Frame - Time to get the transform
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    ReferenceName - Optional name of the referencer

Returns:
    Returns World Transform */
static FTransform ControlRigSequencer::GetSkeletalMeshComponentWorldTransform(ULevelSequence LevelSequence, USkeletalMeshComponent SkeletalMeshComponent, FFrameNumber Frame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, FName ReferenceName = NAME_None) {}
/* Function: GetSkeletalMeshComponentWorldTransforms 
 Get SkeletalMeshComponents World Transforms at specific times

Parameters:
    LevelSequence - Active Sequence to get transform for
    SkeletalMeshComponent - The SkeletalMeshComponent
    Frames - Times to get the transform
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    ReferenceName - Optional name of the referencer

Returns:
    Returns World Transforms */
static TArray<FTransform> ControlRigSequencer::GetSkeletalMeshComponentWorldTransforms(ULevelSequence LevelSequence, USkeletalMeshComponent SkeletalMeshComponent, TArray<FFrameNumber> Frames, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, FName ReferenceName = NAME_None) {}
/* Function: IsLayeredControlRig 
 Whether or not the control rig is an Layered Control Rig.

Parameters:
    InControlRig - Rig to test to see if Layered Control Rig */
static bool ControlRigSequencer::IsLayeredControlRig(UControlRig InControlRig) {}
/* Function: LoadAnimSequenceIntoControlRigSection 
 Load anim sequence into this control rig section

Parameters:
    MovieSceneSection - The MovieSceneSectionto load into
    AnimSequence - The Sequence to load
    InStartFrame - Frame to insert the animation
    TimeUnit - Unit for all frame and time values, either in display rate or tick resolution
    bKeyReduce - If true do key reduction based upon Tolerance, if false don't
    Tolerance - If reducing keys, tolerance about which keys will be removed, smaller tolerance, more keys usually.
    Interpolation - The key interpolation type to set the keys, defaults to EMovieSceneKeyInterpolation::SmartAuto
    bResetControls - If true will reset all controls to initial value on every frame

Returns:
    returns True if successful, False otherwise */
static bool ControlRigSequencer::LoadAnimSequenceIntoControlRigSection(UMovieSceneSection MovieSceneSection, UAnimSequence AnimSequence, USkeletalMeshComponent SkelMeshComp, FFrameNumber InStartFrame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bKeyReduce = false, float32 Tolerance = 0.001000, EMovieSceneKeyInterpolation Interpolation = EMovieSceneKeyInterpolation :: SmartAuto, bool bResetControls = true) {}
/* Function: GetVisibleControlRigs 
 Get all of the visible control rigs in the level

Returns:
    returns list of visible Control Rigs */
static TArray<UControlRig> ControlRigSequencer::GetVisibleControlRigs() {}
/* Function: MoveConstraintKey 
 Move the constraint active key in the current open Sequencer

Parameters:
    ConstraintSection - Section containing Cosntraint Key
    InTime - Original time of the constraint key
    InNewTime - New time for the constraint key
    TimeUnit - Unit for the time params, either in display rate or tick resolution

Returns:
    Will return false if function fails, for example if there is no key at this time it will fail, or if the new time is invalid it could fail also */
static bool ControlRigSequencer::MoveConstraintKey(UTickableConstraint Constraint, UMovieSceneSection ConstraintSection, FFrameNumber InTime, FFrameNumber InNewTime, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: MoveControlRigSpace 
 Move the Control Rig Space Key for the Control at the specified time to the new time. This will also move any Control Rig keys at this space switch boundary.

Parameters:
    InSequence - Sequence to set the space
    InControlRig - ControlRig with the Control
    InControlName - The name of the Control
    InTime - Original time of the space key
    InNewTime - New time for the space key
    TimeUnit - Unit for the time params, either in display rate or tick resolution

Returns:
    Will return false if function fails, for example if there is no key at this time it will fail, or if the new time is invalid it could fail also */
static bool ControlRigSequencer::MoveControlRigSpace(ULevelSequence InSequence, UControlRig InControlRig, FName InControlName, FFrameNumber InTime, FFrameNumber InNewTime, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: RenameControlRigControlChannels 
 Rename the Control Rig Channels in Sequencer to the specified new control names, which should be present on the Control Rig

Parameters:
    InSequence - Sequence to rename controls
    InControlRig - ControlRig to rename controls
    InOldControlNames - The name of the old Control Rig Control Channels to change. Will be replaced by the corresponding name in the InNewControlNames array
    InNewControlNames - The name of the new Control Rig Channels

Returns:
    Return true if the function succeeds, false if it doesn't which can happen if the name arrays don't match in size or any of the new Control Names aren't valid */
static bool ControlRigSequencer::RenameControlRigControlChannels(ULevelSequence InSequence, UControlRig InControlRig, TArray<FName> InOldControlNames, TArray<FName> InNewControlNames) {}
/* Function: SetConstraintActiveKey 
 Set the constraint active key in the current open Sequencer

Parameters:
    InConstraint - The constraint to set the key
    bActive - Whether or not it's active
    TimeUnit - Unit for the time params, either in display rate or tick resolution

Returns:
    Returns true if we set the constraint to be the passed in value, false if not. We may not do so if the value is the same. */
static bool ControlRigSequencer::SetConstraintActiveKey(UTickableConstraint InConstraint, bool bActive, FFrameNumber InFrame, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetControlRigApplyMode 
 Set the FK Control Rig to apply mode

Parameters:
    InControlRig - Rig to set
    InApplyMode - Set the EControlRigFKRigExecuteMode mode (Replace,Addtiive or Direct)

Returns:
    returns True if the mode was set, may not be set if the Control Rig doesn't support these modes currently only FKControlRig's do. */
static bool ControlRigSequencer::SetControlRigApplyMode(UControlRig InControlRig, EControlRigFKRigExecuteMode InApplyMode) {}
/* Function: SetControlRigLayeredMode 
 * Convert the control rig track into absolute or layered rig
*
*

Parameters:
    InTrack - Control rig track to convert *
    bSetIsLayered - Convert to layered rig if true, or absolute if false */
static bool ControlRigSequencer::SetControlRigLayeredMode(UMovieSceneControlRigParameterTrack InTrack, bool bSetIsLayered) {}
/* Function: SetControlRigPriorityOrder 
 Set Control Rig priority order */
static void ControlRigSequencer::SetControlRigPriorityOrder(UMovieSceneTrack InSection, int PriorityOrder) {}
/* Function: SetControlRigSpace 
 * Set the a key for the Control Rig Space for the Control at the specified time. If space is the same as the current no key witll be set.
*
*

Parameters:
    InSequence - Sequence to set the space *
    InControlRig - ControlRig with the Control *
    InControlName - The name of the Control *
    InSpaceKey - The new space for the Control *
    InTime - Time to change the space. *
    TimeUnit - Unit for the InTime, either in display rate or tick resolution */
static bool ControlRigSequencer::SetControlRigSpace(ULevelSequence InSequence, UControlRig InControlRig, FName InControlName, FRigElementKey InSpaceKey, FFrameNumber InTime, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetControlRigWorldTransform 
 Set ControlRig Control's World Transform at a specific time

Parameters:
    LevelSequence - Active Sequence to set transforms for. Must be loaded in Level Editor.
    ControlRig - The ControlRig
    ControlName - Name of the Control
    Frame - Time to set the transform
    WorldTransform - World Transform to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - Whether or not to set a key. */
static void ControlRigSequencer::SetControlRigWorldTransform(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FTransform WorldTransform, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetControlRigWorldTransforms 
 Set ControlRig Control's World Transforms at a specific times.

Parameters:
    LevelSequence - Active Sequence to set transforms for. Must be loaded in Level Editor.
    ControlRig - The ControlRig
    ControlName - Name of the Control
    Frames - Times to set the transform
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetControlRigWorldTransforms(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, TArray<FTransform> WorldTransforms, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetControlsMask 
 Set the controls mask for the given ControlNames */
static void ControlRigSequencer::SetControlsMask(UMovieSceneSection InSection, TArray<FName> ControlNames, bool bVisible) {}
/* Function: SetLocalControlRigBool 
 Set ControlRig Control's bool value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a bool control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigBool(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, bool Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigBools 
 Set ControlRig Control's bool values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a bool control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigBools(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<bool> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigEulerTransform 
 Set ControlRig Control's EulerTransform value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a EulerTransform control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigEulerTransform(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FEulerTransform Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigEulerTransforms 
 Set ControlRig Control's EulerTransform values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a EulerTransform control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigEulerTransforms(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<FEulerTransform> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigFloat 
 Set ControlRig Control's float value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a float control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigFloat(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, float32 Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigFloats 
 Set ControlRig Control's float values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a float control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigFloats(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<float32> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigInt 
 Set ControlRig Control's int value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a int control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigInt(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, int Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigInts 
 Set ControlRig Control's int values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a int control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigInts(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<int> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigPosition 
 Set ControlRig Control's Position value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Position control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigPosition(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FVector Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigPositions 
 Set ControlRig Control's Position values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Position control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigPositions(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<FVector> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigRotator 
 Set ControlRig Control's Rotator value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Rotator control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigRotator(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FRotator Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigRotators 
 Set ControlRig Control's Rotator values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Rotator control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigRotators(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<FRotator> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigScale 
 Set ControlRig Control's Scale value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Scale control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigScale(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FVector Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigScales 
 Set ControlRig Control's Scale values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Scale control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigScales(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<FVector> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigTransform 
 Set ControlRig Control's Transform value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Transform control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigTransform(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FTransform Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigTransformNoScale 
 Set ControlRig Control's TransformNoScale value at specific time

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a TransformNoScale control
    Frame - Time to set the value
    Value - The value to set
    TimeUnit - Unit for frame values, either in display rate or tick resolution
    bSetKey - If True set a key, if not just set the value */
static void ControlRigSequencer::SetLocalControlRigTransformNoScale(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, FFrameNumber Frame, FTransformNoScale Value, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate, bool bSetKey = true) {}
/* Function: SetLocalControlRigTransformNoScales 
 Set ControlRig Control's TransformNoScale values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a TransformNoScale control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigTransformNoScales(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<FTransformNoScale> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
/* Function: SetLocalControlRigTransforms 
 Set ControlRig Control's Transform values at specific times

Parameters:
    LevelSequence - Active Sequence to set value on
    ControlRig - The ControlRig
    ControlName - Name of the Control, should be a Transform control
    Frames - Times to set the values
    Values - The values to set at those times
    TimeUnit - Unit for frame values, either in display rate or tick resolution */
static void ControlRigSequencer::SetLocalControlRigTransforms(ULevelSequence LevelSequence, UControlRig ControlRig, FName ControlName, TArray<FFrameNumber> Frames, const TArray<FTransform> Values, EMovieSceneTimeUnit TimeUnit = EMovieSceneTimeUnit :: DisplayRate) {}
// Group: Editor Scripting | Sequencer Tools | Control Rig | Animation Layers

/* Function: GetAnimLayerIndex 
 Helper function to get the index in the anim layer array from the anim layer

Returns:
    Returns index for the anim layer or INDEX_NONE(-1) if it doesn't exist */
static int ControlRigSequencer::GetAnimLayerIndex(UAnimLayer AnimLayer) {}
/* Function: GetAnimLayers 
 Get the animation layer objects

Returns:
    Returns array of anim layer objects if they exist on active Sequencer */
static TArray<UAnimLayer> ControlRigSequencer::GetAnimLayers() {}
/* Function: MergeAnimLayers 
 Merge specified anim layers into one layer. Will merge onto the anim layer with the lowest index

Parameters:
    Indices - The indices to merge

Returns:
    Returns true if successful, false otherwise */
static bool ControlRigSequencer::MergeAnimLayers(TArray<int> Indices) {}
/* Function: AddAnimLayerFromSelection 
 Add anim layer from objects selected in Sequencer

Returns:
    Returns Index of created anim layer */
static int ControlRigSequencer::AddAnimLayerFromSelection() {}
/* Function: DeleteAnimLayer 
 Delete anim layer at specified index

Parameters:
    Index - The index where the anim layer exists

Returns:
    Returns true if successful, false otherwise */
static bool ControlRigSequencer::DeleteAnimLayer(int Index) {}
/* Function: DuplicateAnimLayer 
 Duplicate anim layer at specified index

Parameters:
    Index - The index where the anim layer exists

Returns:
    Returns index of new layer, -1 if none created */
static int ControlRigSequencer::DuplicateAnimLayer(int Index) {}
// Group: Editor Scripting | Sequencer Tools | FBX

/* Function: ExportFBXFromControlRigSection 
 Exports an FBX from the given control rig section. */
static bool ControlRigSequencer::ExportFBXFromControlRigSection(ULevelSequence Sequence, const UMovieSceneControlRigParameterSection Section, const UMovieSceneUserExportFBXControlRigSettings ExportFBXControlRigSettings) {}
/* Function: ImportFBXToControlRigTrack 
 * Import FBX onto a control rig with the specified track and section
*
*

Parameters:
    InSequence - Sequence to import *
    InTrack - Track to import onto *
    InSection - Section to import onto, may be null in which case we use the track's section to key *
    SelectedControlRigNames - List of selected control rig names. Will use them if  ImportFBXControlRigSettings->bImportOntoSelectedControls is true *
    ImportFBXControlRigSettings - Settings to control import. * */
static bool ControlRigSequencer::ImportFBXToControlRigTrack(UWorld World, ULevelSequence InSequence, UMovieSceneControlRigParameterTrack InTrack, UMovieSceneControlRigParameterSection InSection, TArray<FString> SelectedControlRigNames, UMovieSceneUserImportFBXControlRigSettings ImportFBXControlRigSettings, FString ImportFilename) {}
}
