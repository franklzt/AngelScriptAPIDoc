/* Class: AnimationCompressionFormat 
  */ 
 class AnimationCompressionFormat
{
public:
}
/* Enum: AnimationCompressionFormat 
 
    ACF_None - Enum
    ACF_Float96NoW - Enum
    ACF_Fixed48NoW - Enum
    ACF_IntervalFixed32NoW - Enum
    ACF_Fixed32NoW - Enum
    ACF_Float32NoW - Enum
    ACF_Identity - Enum
    ACF_MAX - Enum */ 
 enum AnimationCompressionFormat { 
ACF_None,
ACF_Float96NoW,
ACF_Fixed48NoW,
ACF_IntervalFixed32NoW,
ACF_Fixed32NoW,
ACF_Float32NoW,
ACF_Identity,
ACF_MAX, 
}