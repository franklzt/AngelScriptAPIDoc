/* Class: ASphereReflectionCapture 
 Actor used to capture the scene for reflection in a sphere shape.
@see https://docs.unrealengine.com/latest/INT/Resources/ContentExamples/Reflections/1_4 */ 
 class ASphereReflectionCapture : public AReflectionCapture
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ASphereReflectionCapture ASphereReflectionCapture::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASphereReflectionCapture::StaticClass() {}
}
