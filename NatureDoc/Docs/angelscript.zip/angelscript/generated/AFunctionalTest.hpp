/* Class: AFunctionalTest 
  */ 
 class AFunctionalTest : public AActor
{
public:
// Group: Functional Testing

/* Variable: RandomNumbersStream 
 A random number stream that you can use during testing.  This number stream will be consistent
every time the test is run. */
FRandomStream RandomNumbersStream;
/* Variable: Author 
 The owner is the group or person responsible for the test. Generally you should use a group name
like 'Editor' or 'Rendering'. When a test fails it may not be obvious who should investigate
so this provides a associate responsible groups with tests. */
FString Author;
/* Variable: Description 
 A description of the test, like what is this test trying to determine. */
FString Description;
/* Variable: TestTags 
 Tags describing this test separated by square brackets, such as '[dog]' or '[cat]' or '[Graphics][prio0][unstable]'.
Tags can be used to run subsets of tests, or to categorize data in test reports. */
FString TestTags;
/* Variable: LogErrorHandling 
 Determines how LogErrors are handled during this test. */
EFunctionalTestLogHandling LogErrorHandling;
/* Variable: LogWarningHandling 
 Determines how LogWarnings are handled during this test. */
EFunctionalTestLogHandling LogWarningHandling;
/* Variable: ObservationPoint 
 Allows you to specify another actor to view the test from.  Usually this is a camera you place
in the map to observe the test.  Not useful when running on a build farm, but provides a handy
way to observe the test from a different location than you place the functional test actor. */
AActor ObservationPoint;
/* Variable: TotalTime 
  */
float32 TotalTime;
/* Variable: Result 
  */
EFunctionalTestResult Result;
/* Variable: TestLabel 
  */
FString TestLabel;
/* Variable: bIsEnabled 
 Allows a test to be disabled.  If a test is disabled, it will not appear in the set of
runnable tests (after saving the map). */
bool bIsEnabled;
/* Variable: bShouldDelayGarbageCollection 
 Allows for garbage collection to be delayed. If delayed, garbage collection will be triggered at the end of a test run */
bool bShouldDelayGarbageCollection;
/* Variable: CurrentRerunReason 
 Returns the current re-run reason if we're in a named re-run. */
const FName CurrentRerunReason;
// Group: Timeout

/* Variable: TimesUpResult 
 If test is limited by time this is the result that will be returned when time runs out */
EFunctionalTestResult TimesUpResult;
/* Variable: PreparationTimeLimit 
 The Test's time limit for preparation, this is the time it has to return true when checking IsReady(). '0' means no limit. */
float32 PreparationTimeLimit;
/* Variable: TimesUpMessage 
  */
FText TimesUpMessage;
/* Variable: TimeLimit 
 Test's time limit. '0' means no limit */
const float32 TimeLimit;
// Group: Variables

/* Variable: OnTestPrepare 
 Called when the test is ready to prepare */
FFunctionalTestEventSignature OnTestPrepare;
/* Variable: OnTestStart 
 Called when the test is started */
FFunctionalTestEventSignature OnTestStart;
/* Variable: OnTestFinished 
 Called when the test is finished. Use it to clean up */
FFunctionalTestEventSignature OnTestFinished;
// Group: Asserts

/* Function: AssertNotEqual_Vector 
 Assert that two vectors are (memberwise) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Vector(FVector Actual, FVector NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Vector2D 
 Assert that two two-component vectors are (memberwise) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Vector2D(FVector2D Actual, FVector2D NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Quat 
 Assert that two quats are (memberwise) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Quat(FQuat Actual, FQuat NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Rotator 
 Assert that the component angles of two rotators are all not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Rotator(FRotator Actual, FRotator NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Bool 
 Assert that two bools are equal

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be Equal To {Expected} for context '') */
bool AssertEqual_Bool(bool Actual, bool Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Box2D 
 Assert that two two-component boxes are (memberwise) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Box2D(FBox2D Actual, FBox2D Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Double 
 Assert that two double are equal within tolerance between two doubles.

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be Equal To {Expected} within Tolerance for context '') */
bool AssertEqual_Double(float Actual, float Expected, FString What, float Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Float 
 Assert that two floats are equal within tolerance between two floats.

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be Equal To {Expected} within Tolerance for context '') */
bool AssertEqual_Float(float32 Actual, float32 Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Int 
 Assert that two ints are equal

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be Equal To {Expected} for context '') */
bool AssertEqual_Int(int Actual, int Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Matrix 
 Assert that two 4x4 matrices are (memberwise) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Matrix(FMatrix Actual, FMatrix Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Name 
 Assert that two FNames are equal

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be Equal To {Expected} for context '') */
bool AssertEqual_Name(FName Actual, FName Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Object 
 Assert that two Objects are equal

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be Equal To {Expected} for context '') */
bool AssertEqual_Object(UObject Actual, UObject Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Plane 
 Assert that two planes are (memberwise) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Plane(FPlane Actual, FPlane Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Quat 
 Assert that two quats are (memberwise) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Quat(FQuat Actual, FQuat Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Rotator 
 Assert that the component angles of two rotators are all equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Rotator(FRotator Actual, FRotator Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_RotatorOrientation 
 Assert that the orientation of two rotators is the same within a small tolerance. Robust to quaternion singularities where angles can differ despite having an identical orientation.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_RotatorOrientation(FRotator Actual, FRotator Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_String 
 Assert that two Strings are equal.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_String(FString Actual, FString Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_TraceQueryResults 
 Assert that two TraceQueryResults are equal.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_TraceQueryResults(const UTraceQueryTestResults Actual, const UTraceQueryTestResults Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Transform 
 Assert that two transforms are (components memberwise - translation, rotation, scale) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Transform(FTransform Actual, FTransform Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Vector 
 Assert that two vectors are (memberwise) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Vector(FVector Actual, FVector Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Vector2D 
 Assert that two two-component vectors are (memberwise) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Vector2D(FVector2D Actual, FVector2D Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertEqual_Vector4 
 Assert that two four-component vectors are (memberwise) equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' to be {Expected} but it was {Actual} for context ''") */
bool AssertEqual_Vector4(FVector4 Actual, FVector4 Expected, FString What, float32 Tolerance = 0.000100, const UObject ContextObject = nullptr) {}
/* Function: AssertFalse 
 Assert that a boolean value is false.

Parameters:
    Message - The message to display if the assert fails ("Assertion Failed: 'Message' for context ''") */
bool AssertFalse(bool Condition, FString Message, const UObject ContextObject = nullptr) {}
/* Function: AssertIsValid 
 Assert that a UObject is valid

Parameters:
    Message - The message to display if the object is invalid ("Invalid object: 'Message' for context ''") */
bool AssertIsValid(UObject Object, FString Message, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Box2D 
 Assert that two two-component boxes are (memberwise) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Box2D(FBox2D Actual, FBox2D NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Matrix 
 Assert that two 4x4 matrices are (memberwise) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Matrix(FMatrix Actual, FMatrix NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Plane 
 Assert that two planes are (memberwise) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Plane(FPlane Actual, FPlane NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertValue_Int 
 Assert on a relationship between two integers.

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be <ShouldBe> {Expected} for context '') */
bool AssertValue_Int(int Actual, EComparisonMethod ShouldBe, int Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_String 
 Assert that two Strings are not equal.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_String(FString Actual, FString NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Transform 
 Assert that two transforms are (components memberwise - translation, rotation, scale) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Transform(FTransform Actual, FTransform NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertValue_Double 
 Assert on a relationship between two doubles.

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be <ShouldBe> {Expected} for context '') */
bool AssertValue_Double(float Actual, EComparisonMethod ShouldBe, float Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertValue_Float 
 Assert on a relationship between two floats.

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be <ShouldBe> {Expected} for context '') */
bool AssertValue_Float(float32 Actual, EComparisonMethod ShouldBe, float32 Expected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertNotEqual_Vector4 
 Assert that two four-component vectors are (memberwise) not equal within a small tolerance.

Parameters:
    What - A name to use in the message if the assert fails ("Expected 'What' not to be {Expected} but it was {Actual} for context ''") */
bool AssertNotEqual_Vector4(FVector4 Actual, FVector4 NotExpected, FString What, const UObject ContextObject = nullptr) {}
/* Function: AssertTrue 
 Assert that a boolean value is true.

Parameters:
    Message - The message to display if the assert fails ("Assertion Failed: 'Message' for context ''") */
bool AssertTrue(bool Condition, FString Message, const UObject ContextObject = nullptr) {}
/* Function: AssertValue_DateTime 
 Assert on a relationship between two DateTimes.

Parameters:
    What - A name to use in the message if the assert fails (What: expected {Actual} to be <ShouldBe> {Expected} for context '') */
bool AssertValue_DateTime(FDateTime Actual, EComparisonMethod ShouldBe, FDateTime Expected, FString What, const UObject ContextObject = nullptr) {}
// Group: Development

/* Function: RegisterAutoDestroyActor 
 Actors registered this way will be automatically destroyed (by limiting their lifespan)
    on test finish */
void RegisterAutoDestroyActor(AActor ActorToAutoDestroy) {}
// Group: Functional Testing

/* Function: AddRerun 
 Causes the test to be rerun for a specific named reason. */
void AddRerun(FName Reason) {}
/* Function: FinishTest 
  */
void FinishTest(EFunctionalTestResult TestResult, FString Message) {}
/* Function: LogMessage 
  */
void LogMessage(FString Message) {}
/* Function: DebugGatherRelevantActors 
 Used by debug drawing to gather actors this test is using and point at them on the level to better understand test's setup */
TArray<AActor> DebugGatherRelevantActors() const {}
/* Function: SetConsoleVariableFromFloat 
 Sets the CVar from the given input. Variable gets reset after the test. */
void SetConsoleVariableFromFloat(FString Name, float32 InValue) {}
/* Function: GetCurrentRerunReason 
 Returns the current re-run reason if we're in a named re-run. */
FName GetCurrentRerunReason() const {}
/* Function: IsEnabled 
  */
bool IsEnabled() const {}
/* Function: IsReady 
 IsReady() is called once per frame after a test is run, until it returns true.  You should use this function to
delay Start being called on the test until preconditions are met. */
bool IsReady() {}
/* Function: IsRunning 
 AActor interface end */
bool IsRunning() const {}
/* Function: OnAdditionalTestFinishedMessageRequest 
  */
FString OnAdditionalTestFinishedMessageRequest(EFunctionalTestResult TestResult) const {}
/* Function: OnWantsReRunCheck 
 retrieves information whether test wants to have another run just after finishing */
bool OnWantsReRunCheck() const {}
/* Function: SetTimeLimit 
  */
void SetTimeLimit(float32 NewTimeLimit, EFunctionalTestResult ResultWhenTimeRunsOut) {}
/* Function: SetConsoleVariableFromInteger 
 Sets the CVar from the given input. Variable gets reset after the test. */
void SetConsoleVariableFromInteger(FString Name, int InValue) {}
/* Function: SetConsoleVariable 
 Sets the CVar from the given input. Variable gets reset after the test. */
void SetConsoleVariable(FString Name, FString InValue) {}
/* Function: SetConsoleVariableFromBoolean 
 Sets the CVar from the given input. Variable gets reset after the test. */
void SetConsoleVariableFromBoolean(FString Name, bool InValue) {}
// Group: Reporting

/* Function: AddWarning 
  */
void AddWarning(FString Message) {}
/* Function: AddError 
  */
void AddError(FString Message) {}
/* Function: AddInfo 
  */
void AddInfo(FString Message) {}
// Group: Functions

/* Function: GetbShouldDelayGarbageCollection 
 Allows for garbage collection to be delayed. If delayed, garbage collection will be triggered at the end of a test run */
bool GetbShouldDelayGarbageCollection() const {}
/* Function: PrepareTest 
 Prepare Test is fired once the test starts up, before the test IsReady() and thus before Start Test is called.
So if there's some initial conditions or setup that you might need for your IsReady() check, you might want
to do that here. */
void PrepareTest() {}
/* Function: GetbIsEnabled 
 Allows a test to be disabled.  If a test is disabled, it will not appear in the set of
runnable tests (after saving the map). */
bool GetbIsEnabled() const {}
/* Function: SetbIsEnabled 
 Allows a test to be disabled.  If a test is disabled, it will not appear in the set of
runnable tests (after saving the map). */
void SetbIsEnabled(bool Value) {}
/* Function: StartTest 
 Called once the IsReady() check for the test returns true.  After that happens the test has Officially started,
and it will begin receiving Ticks in the blueprint. */
void StartTest() {}
/* Function: SetbShouldDelayGarbageCollection 
 Allows for garbage collection to be delayed. If delayed, garbage collection will be triggered at the end of a test run */
void SetbShouldDelayGarbageCollection(bool Value) {}
/* Function: GetTimeLimit 
 Test's time limit. '0' means no limit */
const float32& GetTimeLimit() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AFunctionalTest AFunctionalTest::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AFunctionalTest::StaticClass() {}
}
