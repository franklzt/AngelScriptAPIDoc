/* Class: EAlignObjectsAlignTypes 
  */ 
 class EAlignObjectsAlignTypes
{
public:
}
/* Enum: EAlignObjectsAlignTypes 
 
    Pivots - Enum
    BoundingBoxes - Enum
    EAlignObjectsAlignTypes_MAX - Enum */ 
 enum EAlignObjectsAlignTypes { 
Pivots,
BoundingBoxes,
EAlignObjectsAlignTypes_MAX, 
}