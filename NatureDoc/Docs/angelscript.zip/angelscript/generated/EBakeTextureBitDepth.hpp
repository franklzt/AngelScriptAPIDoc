/* Class: EBakeTextureBitDepth 
  */ 
 class EBakeTextureBitDepth
{
public:
}
/* Enum: EBakeTextureBitDepth 
 
    ChannelBits8 - Enum
    ChannelBits16 - Enum
    EBakeTextureBitDepth_MAX - Enum */ 
 enum EBakeTextureBitDepth { 
ChannelBits8,
ChannelBits16,
EBakeTextureBitDepth_MAX, 
}