/* Class: AServerStreamingLevelsVisibility 
 Actor used to replicate server's visible level streaming */ 
 class AServerStreamingLevelsVisibility : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AServerStreamingLevelsVisibility AServerStreamingLevelsVisibility::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AServerStreamingLevelsVisibility::StaticClass() {}
}
