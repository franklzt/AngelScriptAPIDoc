/* Class: CachedAnimData 
  */ 
 class CachedAnimData
{
public:
// Group: Utilities|Animation|StateMachine

/* Function: StateMachine_GetRelevantAnimTimeRemaining 
 Gets the time to the end of the asset, in seconds, of the most relevant asset player in the specified state (specified in the provided FCachedAnimRelevancyData) */
static float32 CachedAnimData::StateMachine_GetRelevantAnimTimeRemaining(UAnimInstance InAnimInstance, FCachedAnimRelevancyData CachedAnimRelevancyData) {}
/* Function: StateMachine_GetAssetPlayerTimeRatio 
 Gets the accumulated time, as a fraction, of the asset player in the specified state. Assumes only one player in the state (specified in the provided FCachedAnimAssetPlayerData) */
static float32 CachedAnimData::StateMachine_GetAssetPlayerTimeRatio(UAnimInstance InAnimInstance, FCachedAnimAssetPlayerData CachedAnimAssetPlayerData) {}
/* Function: StateMachine_GetCrossfadeDuration 
 CachedAnimTransitionData **// Gets the crossfade duration of the transition between the two input states. If multiple transition rules exist, the first will be returned (specified in the provided FCachedAnimTransitionData) */
static float32 CachedAnimData::StateMachine_GetCrossfadeDuration(UAnimInstance InAnimInstance, FCachedAnimTransitionData CachedAnimTransitionData) {}
/* Function: StateMachine_GetGlobalWeight 
 Returns the weight of a state, relative to the graph (specified in the provided FCachedAnimStateData) */
static float32 CachedAnimData::StateMachine_GetGlobalWeight(UAnimInstance InAnimInstance, FCachedAnimStateData CachedAnimStateData) {}
/* Function: StateMachine_GetLocalWeight 
 Returns the weight of a state, relative to its state machine (specified in the provided FCachedAnimStateData) */
static float32 CachedAnimData::StateMachine_GetLocalWeight(UAnimInstance InAnimInstance, FCachedAnimStateData CachedAnimStateData) {}
/* Function: StateMachine_GetRelevantAnimTime 
 CachedAnimRelevancyData **// Gets the accumulated time, in seconds, of the most relevant asset player in the specified state (specified in the provided FCachedAnimRelevancyData) */
static float32 CachedAnimData::StateMachine_GetRelevantAnimTime(UAnimInstance InAnimInstance, FCachedAnimRelevancyData CachedAnimRelevancyData) {}
/* Function: StateMachine_GetAssetPlayerTime 
 CachedAnimAssetPlayerData **// Gets the accumulated time, in seconds, of the asset player in the specified state. Assumes only one player in the state (specified in the provided FCachedAnimAssetPlayerData) */
static float32 CachedAnimData::StateMachine_GetAssetPlayerTime(UAnimInstance InAnimInstance, FCachedAnimAssetPlayerData CachedAnimAssetPlayerData) {}
/* Function: StateMachine_GetRelevantAnimTimeRemainingFraction 
 Gets the time to the end of the asset, as a fraction, of the most relevant asset player in the specified state (specified in the provided FCachedAnimRelevancyData) */
static float32 CachedAnimData::StateMachine_GetRelevantAnimTimeRemainingFraction(UAnimInstance InAnimInstance, FCachedAnimRelevancyData CachedAnimRelevancyData) {}
/* Function: StateMachine_GetTotalWeight 
 CachedAnimStateArray **// Returns the summed weight of a state or states, relative to their state machine (specified in the provided FCachedAnimStateArray) */
static float32 CachedAnimData::StateMachine_GetTotalWeight(UAnimInstance InAnimInstance, FCachedAnimStateArray CachedAnimStateArray) {}
/* Function: StateMachine_IsFullWeight 
 Returns true when the weight of the input state (or summed weight for multiple input states) is 1.0 of greater (specified in the provided FCachedAnimStateArray) */
static bool CachedAnimData::StateMachine_IsFullWeight(UAnimInstance InAnimInstance, FCachedAnimStateArray CachedAnimStateArray) {}
/* Function: StateMachine_IsRelevant 
 Returns true when the input state, or states, have any weight (specified in the provided FCachedAnimStateArray) */
static bool CachedAnimData::StateMachine_IsRelevant(UAnimInstance InAnimInstance, FCachedAnimStateArray CachedAnimStateArray) {}
/* Function: StateMachine_IsStateRelevant 
 CachedAnimStateData **// Returns whether a state is relevant (specified in the provided FCachedAnimStateData) */
static bool CachedAnimData::StateMachine_IsStateRelevant(UAnimInstance InAnimInstance, FCachedAnimStateData CachedAnimStateData) {}
}
