/* Class: EBlendListTransitionType 
  */ 
 class EBlendListTransitionType
{
public:
}
/* Enum: EBlendListTransitionType 
 
    StandardBlend - Enum
    Inertialization - Enum
    EBlendListTransitionType_MAX - Enum */ 
 enum EBlendListTransitionType { 
StandardBlend,
Inertialization,
EBlendListTransitionType_MAX, 
}