/* Class: EBeaconConnectionState 
  */ 
 class EBeaconConnectionState
{
public:
}
/* Enum: EBeaconConnectionState 
 
    Invalid - Enum
    Closed - Enum
    Pending - Enum
    Open - Enum
    EBeaconConnectionState_MAX - Enum */ 
 enum EBeaconConnectionState { 
Invalid,
Closed,
Pending,
Open,
EBeaconConnectionState_MAX, 
}