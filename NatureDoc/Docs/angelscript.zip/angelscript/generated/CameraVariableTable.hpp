/* Class: CameraVariableTable 
  */ 
 class CameraVariableTable
{
public:
// Group: Camera

/* Function: SetBooleanCameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetBooleanCameraVariable(FBlueprintCameraVariableTable VariableTable, UBooleanCameraVariable Variable, bool Value) {}
/* Function: GetDoubleCameraVariable 
 Gets a camera variable's value from the given table. */
static float CameraVariableTable::GetDoubleCameraVariable(FBlueprintCameraVariableTable VariableTable, UDoubleCameraVariable Variable) {}
/* Function: GetFloatCameraVariable 
 Gets a camera variable's value from the given table. */
static float32 CameraVariableTable::GetFloatCameraVariable(FBlueprintCameraVariableTable VariableTable, UFloatCameraVariable Variable) {}
/* Function: GetInteger32CameraVariable 
 Gets a camera variable's value from the given table. */
static int CameraVariableTable::GetInteger32CameraVariable(FBlueprintCameraVariableTable VariableTable, UInteger32CameraVariable Variable) {}
/* Function: GetRotatorCameraVariable 
 Gets a camera variable's value from the given table. */
static FRotator CameraVariableTable::GetRotatorCameraVariable(FBlueprintCameraVariableTable VariableTable, URotator3dCameraVariable Variable) {}
/* Function: GetTransformCameraVariable 
 Gets a camera variable's value from the given table. */
static FTransform CameraVariableTable::GetTransformCameraVariable(FBlueprintCameraVariableTable VariableTable, UTransform3dCameraVariable Variable) {}
/* Function: GetVector2CameraVariable 
 Gets a camera variable's value from the given table. */
static FVector2D CameraVariableTable::GetVector2CameraVariable(FBlueprintCameraVariableTable VariableTable, UVector2dCameraVariable Variable) {}
/* Function: GetVector3CameraVariable 
 Gets a camera variable's value from the given table. */
static FVector CameraVariableTable::GetVector3CameraVariable(FBlueprintCameraVariableTable VariableTable, UVector3dCameraVariable Variable) {}
/* Function: GetVector4CameraVariable 
 Gets a camera variable's value from the given table. */
static FVector4 CameraVariableTable::GetVector4CameraVariable(FBlueprintCameraVariableTable VariableTable, UVector4dCameraVariable Variable) {}
/* Function: GetBooleanCameraVariable 
 Gets a camera variable's value from the given table. */
static bool CameraVariableTable::GetBooleanCameraVariable(FBlueprintCameraVariableTable VariableTable, UBooleanCameraVariable Variable) {}
/* Function: SetDoubleCameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetDoubleCameraVariable(FBlueprintCameraVariableTable VariableTable, UDoubleCameraVariable Variable, float Value) {}
/* Function: SetFloatCameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetFloatCameraVariable(FBlueprintCameraVariableTable VariableTable, UFloatCameraVariable Variable, float32 Value) {}
/* Function: SetInteger32CameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetInteger32CameraVariable(FBlueprintCameraVariableTable VariableTable, UInteger32CameraVariable Variable, int Value) {}
/* Function: SetRotatorCameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetRotatorCameraVariable(FBlueprintCameraVariableTable VariableTable, URotator3dCameraVariable Variable, FRotator Value) {}
/* Function: SetTransformCameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetTransformCameraVariable(FBlueprintCameraVariableTable VariableTable, UTransform3dCameraVariable Variable, FTransform Value) {}
/* Function: SetVector2CameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetVector2CameraVariable(FBlueprintCameraVariableTable VariableTable, UVector2dCameraVariable Variable, FVector2D Value) {}
/* Function: SetVector3CameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetVector3CameraVariable(FBlueprintCameraVariableTable VariableTable, UVector3dCameraVariable Variable, FVector Value) {}
/* Function: SetVector4CameraVariable 
 Sets a camera variable's value in the given table. */
static void CameraVariableTable::SetVector4CameraVariable(FBlueprintCameraVariableTable VariableTable, UVector4dCameraVariable Variable, FVector4 Value) {}
}
