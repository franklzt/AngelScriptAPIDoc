/* Class: ANiagaraPreviewGrid 
  */ 
 class ANiagaraPreviewGrid : public AActor
{
public:
// Group: Preview

/* Variable: ResetMode 
  */
ENiagaraPreviewGridResetMode ResetMode;
/* Variable: PreviewAxisX 
 Object controlling behavior varying on the X axis. */
UNiagaraPreviewAxis PreviewAxisX;
/* Variable: PreviewAxisY 
 Object controlling behavior varying on the Y axis. */
UNiagaraPreviewAxis PreviewAxisY;
/* Variable: PreviewClass 
 Class used to for previews in this grid. */
TSubclassOf<ANiagaraPreviewBase> PreviewClass;
/* Variable: SpacingX 
 The default spacing between previews in X if the axis does not override it. */
float32 SpacingX;
/* Variable: SpacingY 
 The default spacing between previews if the axis does not override it. */
float32 SpacingY;
/* Variable: System 
  */
UNiagaraSystem System;
// Group: Preview

/* Function: DeactivatePreviews 
  */
void DeactivatePreviews() {}
/* Function: GetPreviews 
  */
void GetPreviews(TArray<UNiagaraComponent>& OutPreviews) {}
/* Function: SetPaused 
  */
void SetPaused(bool bPaused) {}
/* Function: ActivatePreviews 
 AActor Interface End */
void ActivatePreviews(bool bReset) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANiagaraPreviewGrid ANiagaraPreviewGrid::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANiagaraPreviewGrid::StaticClass() {}
}
