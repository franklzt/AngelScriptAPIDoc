/* Class: EAlignObjectsBoxPoint 
  */ 
 class EAlignObjectsBoxPoint
{
public:
}
/* Enum: EAlignObjectsBoxPoint 
 
    Center - Enum
    Bottom - Enum
    Top - Enum
    Left - Enum
    Right - Enum
    Front - Enum
    Back - Enum
    Min - Enum
    Max - Enum
    EAlignObjectsBoxPoint_MAX - Enum */ 
 enum EAlignObjectsBoxPoint { 
Center,
Bottom,
Top,
Left,
Right,
Front,
Back,
Min,
Max,
EAlignObjectsBoxPoint_MAX, 
}