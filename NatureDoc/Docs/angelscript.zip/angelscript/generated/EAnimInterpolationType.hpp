/* Class: EAnimInterpolationType 
  */ 
 class EAnimInterpolationType
{
public:
}
/* Enum: EAnimInterpolationType 
 
    Linear - Enum
    Step - Enum
    EAnimInterpolationType_MAX - Enum */ 
 enum EAnimInterpolationType { 
Linear,
Step,
EAnimInterpolationType_MAX, 
}