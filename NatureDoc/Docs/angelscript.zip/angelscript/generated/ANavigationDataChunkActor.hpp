/* Class: ANavigationDataChunkActor 
  */ 
 class ANavigationDataChunkActor : public APartitionActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ANavigationDataChunkActor ANavigationDataChunkActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavigationDataChunkActor::StaticClass() {}
}
