/* Class: EBlueprintPinStyleType 
  */ 
 class EBlueprintPinStyleType
{
public:
}
/* Enum: EBlueprintPinStyleType 
 
    BPST_Original - Enum
    BPST_VariantA - Enum
    BPST_MAX - Enum */ 
 enum EBlueprintPinStyleType { 
BPST_Original,
BPST_VariantA,
BPST_MAX, 
}