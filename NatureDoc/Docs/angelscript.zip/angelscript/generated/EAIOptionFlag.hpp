/* Class: EAIOptionFlag 
  */ 
 class EAIOptionFlag
{
public:
}
/* Enum: EAIOptionFlag 
 
    Default - Enum
    Enable - Enum
    Disable - Enum
    MAX - Enum */ 
 enum EAIOptionFlag { 
Default,
Enable,
Disable,
MAX, 
}