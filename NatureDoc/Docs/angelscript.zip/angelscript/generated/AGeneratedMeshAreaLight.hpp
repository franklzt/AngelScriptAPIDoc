/* Class: AGeneratedMeshAreaLight 
 Implements a light that is created after a lighting build with Lightmass and handles mesh area light influence on dynamic objects. */ 
 class AGeneratedMeshAreaLight : public ASpotLight
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AGeneratedMeshAreaLight AGeneratedMeshAreaLight::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGeneratedMeshAreaLight::StaticClass() {}
}
