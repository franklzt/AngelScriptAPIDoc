/* Class: ADefaultPawn 
 DefaultPawn implements a simple Pawn with spherical collision and built-in flying movement.
@see UFloatingPawnMovement */ 
 class ADefaultPawn : public APawn
{
public:
// Group: Pawn

/* Variable: BaseLookUpRate 
 Base lookup rate, in deg/sec. Other scaling may affect final lookup rate. */
float32 BaseLookUpRate;
/* Variable: CollisionComponent 
 DefaultPawn collision component */
USphereComponent CollisionComponent;
/* Variable: MeshComponent 
 The mesh associated with this Pawn. */
UStaticMeshComponent MeshComponent;
/* Variable: bAddDefaultMovementBindings 
 If true, adds default input bindings for movement and camera look. */
bool bAddDefaultMovementBindings;
/* Variable: BaseTurnRate 
 Base turn rate, in deg/sec. Other scaling may affect final turn rate. */
float32 BaseTurnRate;
// Group: Pawn

/* Function: MoveForward 
 Input callback to move forward in local space (or backward if Val is negative).

Parameters:
    Val - Amount of movement in the forward direction (or backward if negative). */
void MoveForward(float32 Val) {}
/* Function: MoveRight 
 Input callback to strafe right in local space (or left if Val is negative).

Parameters:
    Val - Amount of movement in the right direction (or left if negative). */
void MoveRight(float32 Val) {}
/* Function: MoveUp_World 
 Input callback to move up in world space (or down if Val is negative).

Parameters:
    Val - Amount of movement in the world up direction (or down if negative). */
void MoveUp_World(float32 Val) {}
/* Function: TurnAtRate 
 Called via input to turn at a given rate.

Parameters:
    Rate - This is a normalized rate, i.e. 1.0 means 100% of desired turn rate */
void TurnAtRate(float32 Rate) {}
/* Function: LookUpAtRate 
 Called via input to look up at a given rate (or down if Rate is negative).

Parameters:
    Rate - This is a normalized rate, i.e. 1.0 means 100% of desired turn rate */
void LookUpAtRate(float32 Rate) {}
// Group: Functions

/* Function: SetMovementComponent 
 DefaultPawn movement component */
void SetMovementComponent(UPawnMovementComponent Value) {}
/* Function: GetbAddDefaultMovementBindings 
 If true, adds default input bindings for movement and camera look. */
bool GetbAddDefaultMovementBindings() const {}
/* Function: SetbAddDefaultMovementBindings 
 If true, adds default input bindings for movement and camera look. */
void SetbAddDefaultMovementBindings(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ADefaultPawn ADefaultPawn::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADefaultPawn::StaticClass() {}
}
