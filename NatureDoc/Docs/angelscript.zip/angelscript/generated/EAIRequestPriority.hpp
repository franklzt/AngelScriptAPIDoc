/* Class: EAIRequestPriority 
  */ 
 class EAIRequestPriority
{
public:
}
/* Enum: EAIRequestPriority 
 
    SoftScript - Enum
    Logic - Enum
    HardScript - Enum
    Reaction - Enum
    Ultimate - Enum
    MAX - Enum */ 
 enum EAIRequestPriority { 
SoftScript,
Logic,
HardScript,
Reaction,
Ultimate,
MAX, 
}