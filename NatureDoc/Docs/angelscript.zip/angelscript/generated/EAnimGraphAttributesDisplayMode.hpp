/* Class: EAnimGraphAttributesDisplayMode 
  */ 
 class EAnimGraphAttributesDisplayMode
{
public:
}
/* Enum: EAnimGraphAttributesDisplayMode 
 
    HideOnPins - Enum
    ShowOnPins - Enum
    Automatic - Enum
    EAnimGraphAttributesDisplayMode_MAX - Enum */ 
 enum EAnimGraphAttributesDisplayMode { 
HideOnPins,
ShowOnPins,
Automatic,
EAnimGraphAttributesDisplayMode_MAX, 
}