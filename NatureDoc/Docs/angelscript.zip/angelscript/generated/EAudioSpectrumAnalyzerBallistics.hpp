/* Class: EAudioSpectrumAnalyzerBallistics 
  */ 
 class EAudioSpectrumAnalyzerBallistics
{
public:
}
/* Enum: EAudioSpectrumAnalyzerBallistics 
 
    Analog - Enum
    Digital - Enum
    EAudioSpectrumAnalyzerBallistics_MAX - Enum */ 
 enum EAudioSpectrumAnalyzerBallistics { 
Analog,
Digital,
EAudioSpectrumAnalyzerBallistics_MAX, 
}