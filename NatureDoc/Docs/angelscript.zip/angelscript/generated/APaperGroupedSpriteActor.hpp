/* Class: APaperGroupedSpriteActor 
 A group of sprites that will be rendered and culled as a single unit

This actor is created when you Merge several sprite components together.
it is just a thin wrapper around a UPaperGroupedSpriteComponent. */ 
 class APaperGroupedSpriteActor : public AActor
{
public:
// Group: Sprite

/* Variable: RenderComponent 
  */
UPaperGroupedSpriteComponent RenderComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static APaperGroupedSpriteActor APaperGroupedSpriteActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APaperGroupedSpriteActor::StaticClass() {}
}
