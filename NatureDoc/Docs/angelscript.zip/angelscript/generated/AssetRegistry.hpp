/* Class: AssetRegistry 
  */ 
 class AssetRegistry
{
public:
// Group: Static Functions

/* Function: GetAssetByObjectPath 
  */
static FAssetData AssetRegistry::GetAssetByObjectPath(FSoftObjectPath ObjectPath, bool bIncludeOnlyOnDiskAssets = false) {}
/* Function: HasAssets 
  */
static bool AssetRegistry::HasAssets(const FName PackagePath, bool bRecursive = false) {}
/* Function: GetAssetsByPackageName 
  */
static bool AssetRegistry::GetAssetsByPackageName(FName PackageName, TArray<FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets = false) {}
/* Function: GetAssetsByPath 
  */
static bool AssetRegistry::GetAssetsByPath(FName PackagePath, TArray<FAssetData>& OutAssetData, bool bRecursive = false, bool bIncludeOnlyOnDiskAssets = false) {}
/* Function: GetAssetsByClass 
  */
static bool AssetRegistry::GetAssetsByClass(FTopLevelAssetPath ClassPath, TArray<FAssetData>& OutAssetData, bool bSearchSubClasses = false) {}
/* Function: GetBlueprintCDOsByParentClass 
  */
static void AssetRegistry::GetBlueprintCDOsByParentClass(UClass Class, TArray<UObject>& OutAssets) {}
/* Function: GetWidgetBlueprintCDOsByParentClass 
  */
static void AssetRegistry::GetWidgetBlueprintCDOsByParentClass(UClass Class, TArray<UObject>& OutAssets) {}
/* Function: GetAssetsByTags 
  */
static bool AssetRegistry::GetAssetsByTags(TArray<FName> AssetTags, TArray<FAssetData>& OutAssetData) {}
/* Function: IsLoadingAssets 
  */
static bool AssetRegistry::IsLoadingAssets() {}
/* Function: GetAllAssets 
  */
static bool AssetRegistry::GetAllAssets(TArray<FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets = false) {}
/* Function: GetAssets 
  */
static bool AssetRegistry::GetAssets(FARFilter Filter, TArray<FAssetData>& OutAssetData, bool bSkipARFilteredAssets = true) {}
/* Function: GetDependencies 
  */
static bool AssetRegistry::GetDependencies(FName PackageName, FAssetRegistryDependencyOptions DependencyOptions, TArray<FName>& OutDependencies) {}
/* Function: GetReferencers 
  */
static bool AssetRegistry::GetReferencers(FName PackageName, FAssetRegistryDependencyOptions ReferenceOptions, TArray<FName>& OutReferencers) {}
/* Function: GetDerivedClassNames 
  */
static void AssetRegistry::GetDerivedClassNames(TArray<FTopLevelAssetPath> ClassNames, TSet<FTopLevelAssetPath> ExcludedClassNames, TSet<FTopLevelAssetPath>& OutDerivedClassNames) {}
/* Function: GetGeneratedClassName 
  */
static bool AssetRegistry::GetGeneratedClassName(FAssetData AssetData, FTopLevelAssetPath& OutGeneratedClassName) {}
/* Function: AssetCreated 
  */
static void AssetRegistry::AssetCreated(UObject NewAsset) {}
/* Function: LoadAllBlueprintsUnderPath 
  */
static void AssetRegistry::LoadAllBlueprintsUnderPath(FName PathToLoadFrom, FString OptionalFileIncludeRegex = "") {}
}
