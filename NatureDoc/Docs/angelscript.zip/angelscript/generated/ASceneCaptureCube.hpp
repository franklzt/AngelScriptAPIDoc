/* Class: ASceneCaptureCube 
  */ 
 class ASceneCaptureCube : public ASceneCapture
{
public:
// Group: DecalActor

/* Variable: CaptureComponentCube 
 Scene capture component. */
USceneCaptureComponentCube CaptureComponentCube;
// Group: Rendering

/* Function: OnInterpToggle 
  */
void OnInterpToggle(bool bEnable) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ASceneCaptureCube ASceneCaptureCube::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASceneCaptureCube::StaticClass() {}
}
