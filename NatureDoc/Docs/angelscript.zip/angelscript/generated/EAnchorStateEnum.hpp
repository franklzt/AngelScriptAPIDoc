/* Class: EAnchorStateEnum 
  */ 
 class EAnchorStateEnum
{
public:
}
/* Enum: EAnchorStateEnum 
 
    Dataflow_AnchorState_Anchored - Enum
    Dataflow_AnchorState_NotAnchored - Enum
    Dataflow_Max - Enum
    Dataflow_MAX - Enum */ 
 enum EAnchorStateEnum { 
Dataflow_AnchorState_Anchored,
Dataflow_AnchorState_NotAnchored,
Dataflow_Max,
Dataflow_MAX, 
}