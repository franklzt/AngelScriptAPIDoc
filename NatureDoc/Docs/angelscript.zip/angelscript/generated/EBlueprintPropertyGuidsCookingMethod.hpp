/* Class: EBlueprintPropertyGuidsCookingMethod 
  */ 
 class EBlueprintPropertyGuidsCookingMethod
{
public:
}
/* Enum: EBlueprintPropertyGuidsCookingMethod 
 
    Disabled - Enum
    AllBlueprints - Enum
    EnabledBlueprintsOnly - Enum
    EBlueprintPropertyGuidsCookingMethod_MAX - Enum */ 
 enum EBlueprintPropertyGuidsCookingMethod { 
Disabled,
AllBlueprints,
EnabledBlueprintsOnly,
EBlueprintPropertyGuidsCookingMethod_MAX, 
}