/* Class: AWorldPartitionReplay 
 Actor used to record world partition replay data (streaming sources for now) */ 
 class AWorldPartitionReplay : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AWorldPartitionReplay AWorldPartitionReplay::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AWorldPartitionReplay::StaticClass() {}
}
