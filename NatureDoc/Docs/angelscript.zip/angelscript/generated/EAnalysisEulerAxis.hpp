/* Class: EAnalysisEulerAxis 
  */ 
 class EAnalysisEulerAxis
{
public:
}
/* Enum: EAnalysisEulerAxis 
 
    Roll - Enum
    Pitch - Enum
    Yaw - Enum
    EAnalysisEulerAxis_MAX - Enum */ 
 enum EAnalysisEulerAxis { 
Roll,
Pitch,
Yaw,
EAnalysisEulerAxis_MAX, 
}