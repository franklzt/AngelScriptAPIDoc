/* Class: AExponentialHeightFog 
 Implements an Actor for exponential height fog. */ 
 class AExponentialHeightFog : public AInfo
{
public:
// Group: ExponentialHeightFog

/* Variable: Component 
 @todo document */
UExponentialHeightFogComponent Component;
// Group: Static Functions

/* Function: Spawn 
  */
static AExponentialHeightFog AExponentialHeightFog::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AExponentialHeightFog::StaticClass() {}
}
