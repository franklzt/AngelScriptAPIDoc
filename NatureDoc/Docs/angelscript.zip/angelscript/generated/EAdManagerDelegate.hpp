/* Class: EAdManagerDelegate 
  */ 
 class EAdManagerDelegate
{
public:
}
/* Enum: EAdManagerDelegate 
 
    AMD_ClickedBanner - Enum
    AMD_UserClosedAd - Enum
    AMD_MAX - Enum */ 
 enum EAdManagerDelegate { 
AMD_ClickedBanner,
AMD_UserClosedAd,
AMD_MAX, 
}