/* Class: EAudioDeviceChangedState 
  */ 
 class EAudioDeviceChangedState
{
public:
}
/* Enum: EAudioDeviceChangedState 
 
    Invalid - Enum
    Active - Enum
    Disabled - Enum
    NotPresent - Enum
    Unplugged - Enum
    Count - Enum
    EAudioDeviceChangedState_MAX - Enum */ 
 enum EAudioDeviceChangedState { 
Invalid,
Active,
Disabled,
NotPresent,
Unplugged,
Count,
EAudioDeviceChangedState_MAX, 
}