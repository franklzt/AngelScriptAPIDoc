/* Class: ANavMeshBoundsVolume 
  */ 
 class ANavMeshBoundsVolume : public AVolume
{
public:
// Group: Navigation

/* Variable: SupportedAgents 
  */
FNavAgentSelector SupportedAgents;
// Group: Static Functions

/* Function: Spawn 
  */
static ANavMeshBoundsVolume ANavMeshBoundsVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavMeshBoundsVolume::StaticClass() {}
}
