/* Class: ADynamicMeshActor 
 ADynamicMeshActor is an Actor that has a USimpleDynamicMeshComponent as it's RootObject. */ 
 class ADynamicMeshActor : public AActor
{
public:
// Group: DynamicMeshActor

/* Variable: ComputeMeshPool 
 Access the compute mesh pool */
const UDynamicMeshPool ComputeMeshPool;
/* Variable: DynamicMeshComponent 
  */
UDynamicMeshComponent DynamicMeshComponent;
// Group: DynamicMeshActor|Advanced

/* Variable: bEnableComputeMeshPool 
 Control whether the DynamicMeshPool will be created when requested via GetComputeMeshPool() */
bool bEnableComputeMeshPool;
// Group: DynamicMeshActor

/* Function: ReleaseAllComputeMeshes 
 Release all compute meshes that the Pool has allocated */
void ReleaseAllComputeMeshes() {}
/* Function: FreeAllComputeMeshes 
 Release all compute meshes that the Pool has allocated, and then release them from the Pool, so that they will be garbage-collected */
void FreeAllComputeMeshes() {}
/* Function: GetComputeMeshPool 
 Access the compute mesh pool */
UDynamicMeshPool GetComputeMeshPool() {}
/* Function: GetDynamicMeshComponent 
  */
UDynamicMeshComponent GetDynamicMeshComponent() const {}
/* Function: AllocateComputeMesh 
 Request a compute mesh from the Pool, which will return a previously-allocated mesh or add and return a new one. If the Pool is disabled, a new UDynamicMesh will be allocated and returned. */
UDynamicMesh AllocateComputeMesh() {}
/* Function: ReleaseComputeMesh 
 Release a compute mesh back to the Pool */
bool ReleaseComputeMesh(UDynamicMesh Mesh) {}
// Group: Functions

/* Function: SetDynamicMeshComponent 
  */
void SetDynamicMeshComponent(UDynamicMeshComponent Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ADynamicMeshActor ADynamicMeshActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADynamicMeshActor::StaticClass() {}
}
