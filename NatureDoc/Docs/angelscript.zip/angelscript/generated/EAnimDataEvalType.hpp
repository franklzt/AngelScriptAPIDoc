/* Class: EAnimDataEvalType 
  */ 
 class EAnimDataEvalType
{
public:
}
/* Enum: EAnimDataEvalType 
 
    Source - Enum
    Raw - Enum
    Compressed - Enum
    EAnimDataEvalType_MAX - Enum */ 
 enum EAnimDataEvalType { 
Source,
Raw,
Compressed,
EAnimDataEvalType_MAX, 
}