/* Class: AServerStatReplicator 
 Class used to replicate server "stat net" data over. For server only values, the client data is
is overwritten when bUpdateStatNet == true. For data that both the client and server set, the server
data will only overwrite if bUpdateStatNet == true && bOverwriteClientStats == true. */ 
 class AServerStatReplicator : public AInfo
{
public:
// Group: ServerStats

/* Variable: bOverwriteClientStats 
 Whether to overwrite client data stat net with data from the server or not */
bool bOverwriteClientStats;
/* Variable: bUpdateStatNet 
 Whether to update stat net with data from the server or not */
bool bUpdateStatNet;
// Group: Static Functions

/* Function: Spawn 
  */
static AServerStatReplicator AServerStatReplicator::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AServerStatReplicator::StaticClass() {}
}
