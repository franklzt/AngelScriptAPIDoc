/* Class: EAnimPoseSpaces 
  */ 
 class EAnimPoseSpaces
{
public:
}
/* Enum: EAnimPoseSpaces 
 
    Local - Enum
    World - Enum
    EAnimPoseSpaces_MAX - Enum */ 
 enum EAnimPoseSpaces { 
Local,
World,
EAnimPoseSpaces_MAX, 
}