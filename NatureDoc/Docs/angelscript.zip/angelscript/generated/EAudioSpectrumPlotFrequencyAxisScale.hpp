/* Class: EAudioSpectrumPlotFrequencyAxisScale 
  */ 
 class EAudioSpectrumPlotFrequencyAxisScale
{
public:
}
/* Enum: EAudioSpectrumPlotFrequencyAxisScale 
 
    Linear - Enum
    Logarithmic - Enum
    EAudioSpectrumPlotFrequencyAxisScale_MAX - Enum */ 
 enum EAudioSpectrumPlotFrequencyAxisScale { 
Linear,
Logarithmic,
EAudioSpectrumPlotFrequencyAxisScale_MAX, 
}