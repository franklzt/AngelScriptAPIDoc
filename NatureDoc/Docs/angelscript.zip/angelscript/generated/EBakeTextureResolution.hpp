/* Class: EBakeTextureResolution 
  */ 
 class EBakeTextureResolution
{
public:
}
/* Enum: EBakeTextureResolution 
 
    Resolution16 - Enum
    Resolution32 - Enum
    Resolution64 - Enum
    Resolution128 - Enum
    Resolution256 - Enum
    Resolution512 - Enum
    Resolution1024 - Enum
    Resolution2048 - Enum
    Resolution4096 - Enum
    Resolution8192 - Enum
    EBakeTextureResolution_MAX - Enum */ 
 enum EBakeTextureResolution { 
Resolution16,
Resolution32,
Resolution64,
Resolution128,
Resolution256,
Resolution512,
Resolution1024,
Resolution2048,
Resolution4096,
Resolution8192,
EBakeTextureResolution_MAX, 
}