/* Class: ControlRig 
  */ 
 class ControlRig
{
public:
// Group: Static Variables

/* Variable: AvailableRigUnits 
  */
static const TArray<UStruct> ControlRig::AvailableRigUnits;
/* Variable: CurrentlyOpenRigBlueprints 
  */
static const TArray<UControlRigBlueprint> ControlRig::CurrentlyOpenRigBlueprints;
/* Variable: AvailableRigModules 
  */
static const TArray<FRigModuleDescription> ControlRig::AvailableRigModules;
// Group: Control Rig Blueprint

/* Function: GetHierarchyController 
  */
static URigHierarchyController ControlRig::GetHierarchyController(UControlRigBlueprint InRigBlueprint) {}
/* Function: GetAvailableRigModules 
  */
static TArray<FRigModuleDescription> ControlRig::GetAvailableRigModules() {}
/* Function: GetAvailableRigUnits 
  */
static TArray<UStruct> ControlRig::GetAvailableRigUnits() {}
/* Function: GetCurrentlyOpenRigBlueprints 
  */
static TArray<UControlRigBlueprint> ControlRig::GetCurrentlyOpenRigBlueprints() {}
/* Function: GetHierarchy 
  */
static URigHierarchy ControlRig::GetHierarchy(UControlRigBlueprint InRigBlueprint) {}
/* Function: CastToControlRigBlueprint 
  */
static void ControlRig::CastToControlRigBlueprint(UObject Object, ECastToControlRigBlueprintCases& Branches, UControlRigBlueprint& AsControlRigBlueprint) {}
/* Function: GetPreviewMesh 
  */
static USkeletalMesh ControlRig::GetPreviewMesh(UControlRigBlueprint InRigBlueprint) {}
/* Function: RequestControlRigInit 
  */
static void ControlRig::RequestControlRigInit(UControlRigBlueprint InRigBlueprint) {}
/* Function: SetPreviewMesh 
  */
static void ControlRig::SetPreviewMesh(UControlRigBlueprint InRigBlueprint, USkeletalMesh PreviewMesh, bool bMarkAsDirty = true) {}
/* Function: SetupAllEditorMenus 
  */
static void ControlRig::SetupAllEditorMenus() {}
}
