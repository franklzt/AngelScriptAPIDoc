/* Class: DistributionParamMode 
  */ 
 class DistributionParamMode
{
public:
}
/* Enum: DistributionParamMode 
 
    DPM_Normal - Enum
    DPM_Abs - Enum
    DPM_Direct - Enum
    DPM_MAX - Enum */ 
 enum DistributionParamMode { 
DPM_Normal,
DPM_Abs,
DPM_Direct,
DPM_MAX, 
}