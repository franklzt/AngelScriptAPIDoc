/* Class: APlayerState 
 A PlayerState is created for every player on a server (or in a standalone game).
PlayerStates are replicated to all clients, and contain network game relevant information about the player, such as playername, score, etc. */ 
 class APlayerState : public AInfo
{
public:
// Group: Events

/* Variable: OnPawnSet 
 Broadcast whenever this player's possessed pawn is set */
FOnPlayerStatePawnSet OnPawnSet;
// Group: PlayerState

/* Variable: PawnPrivate 
 The pawn that is controlled by by this player state. */
APawn PawnPrivate;
/* Variable: PlayerController 
 Return the player controller that created this player state, or null for remote clients */
const APlayerController PlayerController;
/* Variable: CompressedPing 
 Replicated compressed ping for this player (holds ping in msec divided by 4) */
const uint8 CompressedPing;
/* Variable: Pawn 
 Return the pawn controlled by this Player State. */
const APawn Pawn;
/* Variable: PingInMilliseconds 
 Returns the ping (in milliseconds)

Returns ExactPing if available (local players or when running on the server), and
the replicated CompressedPing (converted back to milliseconds) otherwise.

Note that replication of CompressedPing is controlled by bShouldUpdateReplicatedPing,
and if disabled then this will return 0 or a stale value on clients for player states
that aren't related to local players */
const float32 PingInMilliseconds;
/* Variable: PlayerId 
 Unique net id number. Actual value varies based on current online subsystem, use it only as a guaranteed unique number per player. */
const int PlayerId;
/* Variable: PlayerName 
 returns current player name */
const FString PlayerName;
/* Variable: Score 
 Player's current score. */
const float32 Score;
/* Variable: bIsSpectator 
 Whether this player is currently a spectator */
const bool bIsSpectator;
/* Variable: bIsABot 
 True if this PlayerState is associated with an AIController */
const bool bIsABot;
// Group: Variables

/* Variable: UniqueId 
 The id used by the network to uniquely identify a player.
NOTE: the internals of this property should *never* be exposed to the player as it's transient
and opaque in meaning (ie it might mean date/time followed by something else).
It is OK to use and pass around this property, though. */
const FUniqueNetIdRepl UniqueId;
// Group: PlayerState

/* Function: IsOnlyASpectator 
 Gets the literal value of bOnlySpectator. */
bool IsOnlyASpectator() const {}
/* Function: GetUniqueId 
 Gets the online unique id for a player. If a player is logged in this will be consistent across all clients and servers. */
FUniqueNetIdRepl GetUniqueId() const {}
/* Function: GetPawn 
 Return the pawn controlled by this Player State. */
APawn GetPawn() const {}
/* Function: GetPingInMilliseconds 
 Returns the ping (in milliseconds)

Returns ExactPing if available (local players or when running on the server), and
the replicated CompressedPing (converted back to milliseconds) otherwise.

Note that replication of CompressedPing is controlled by bShouldUpdateReplicatedPing,
and if disabled then this will return 0 or a stale value on clients for player states
that aren't related to local players */
float32 GetPingInMilliseconds() const {}
/* Function: GetPlayerController 
 Return the player controller that created this player state, or null for remote clients */
APlayerController GetPlayerController() const {}
/* Function: CopyProperties 
 * Can be implemented in Blueprint Child to move more properties from old to new PlayerState when traveling to a new level
*
*

Parameters:
    NewPlayerState - New PlayerState, which we fill with the current properties */
void CopyProperties(APlayerState NewPlayerState) {}
/* Function: GetPlayerName 
 returns current player name */
FString GetPlayerName() const {}
/* Function: OverrideWith 
 * Can be implemented in Blueprint Child to move more properties from old to new PlayerState when reconnecting
*
*

Parameters:
    OldPlayerState - Old PlayerState, which we use to fill the new one with */
void OverrideWith(APlayerState OldPlayerState) {}
// Group: Functions

/* Function: GetbIsSpectator 
 Whether this player is currently a spectator */
bool GetbIsSpectator() const {}
/* Function: GetCompressedPing 
 Gets the literal value of the compressed Ping value (Ping = PingInMS / 4). */
uint8 GetCompressedPing() const {}
/* Function: IsSpectator 
 Gets the literal value of bIsSpectator. */
bool IsSpectator() const {}
/* Function: GetPlayerId 
 Gets the literal value of PlayerId. */
int GetPlayerId() const {}
/* Function: GetScore 
 Gets the literal value of Score. */
float32 GetScore() const {}
/* Function: IsABot 
 Gets the literal value of bIsABot. */
bool IsABot() const {}
/* Function: GetbIsABot 
 True if this PlayerState is associated with an AIController */
bool GetbIsABot() const {}
/* Function: SetbShouldUpdateReplicatedPing 
 Whether or not this player's replicated CompressedPing value is updated automatically.
Since player states are always relevant by default, in cases where there are many players replicating,
replicating the ping value can cause additional unnecessary overhead on servers if the value isn't
needed on clients. */
void SetbShouldUpdateReplicatedPing(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static APlayerState APlayerState::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APlayerState::StaticClass() {}
}
