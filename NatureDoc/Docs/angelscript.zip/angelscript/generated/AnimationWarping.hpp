/* Class: AnimationWarping 
  */ 
 class AnimationWarping
{
public:
// Group: Animation

/* Function: GetCurveValueFromAnimation 
 Helper function to extract the value of a curve in an animation at a given time */
static bool AnimationWarping::GetCurveValueFromAnimation(const UAnimSequenceBase Animation, FName CurveName, float32 Time, float32& OutValue) {}
// Group: Animation|BlendStack

/* Function: GetOffsetRootTransform 
 Get the current world space transform from the offset root bone animgraph node */
static FTransform AnimationWarping::GetOffsetRootTransform(FAnimNodeReference Node) {}
}
