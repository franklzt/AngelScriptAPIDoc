/* Class: AOnlineBeaconHostObject 
 Base class for any unique beacon connectivity, paired with an AOnlineBeaconClient implementation

By defining a beacon type and implementing the ability to spawn unique AOnlineBeaconClients, any two instances of the engine
can communicate with each other without officially connecting through normal Unreal networking */ 
 class AOnlineBeaconHostObject : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AOnlineBeaconHostObject AOnlineBeaconHostObject::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AOnlineBeaconHostObject::StaticClass() {}
}
