/* Class: EAttributeBasedRootMotionMode 
  */ 
 class EAttributeBasedRootMotionMode
{
public:
}
/* Enum: EAttributeBasedRootMotionMode 
 
    ApplyDelta - Enum
    ApplyVelocity - Enum
    EAttributeBasedRootMotionMode_MAX - Enum */ 
 enum EAttributeBasedRootMotionMode { 
ApplyDelta,
ApplyVelocity,
EAttributeBasedRootMotionMode_MAX, 
}