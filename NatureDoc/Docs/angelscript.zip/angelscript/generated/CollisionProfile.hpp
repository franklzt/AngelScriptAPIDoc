/* Class: CollisionProfile 
  */ 
 class CollisionProfile
{
public:
// Group: Static Variables

/* Variable: CharacterMesh 
  */
static const FName CollisionProfile::CharacterMesh;
/* Variable: BlockAll 
  */
static const FName CollisionProfile::BlockAll;
/* Variable: OverlapAll 
  */
static const FName CollisionProfile::OverlapAll;
/* Variable: BlockAllDynamic 
  */
static const FName CollisionProfile::BlockAllDynamic;
/* Variable: OverlapAllDynamic 
  */
static const FName CollisionProfile::OverlapAllDynamic;
/* Variable: IgnoreOnlyPawn 
  */
static const FName CollisionProfile::IgnoreOnlyPawn;
/* Variable: OverlapOnlyPawn 
  */
static const FName CollisionProfile::OverlapOnlyPawn;
/* Variable: Pawn 
  */
static const FName CollisionProfile::Pawn;
/* Variable: Spectator 
  */
static const FName CollisionProfile::Spectator;
/* Variable: NoCollision 
  */
static const FName CollisionProfile::NoCollision;
/* Variable: PhysicsActor 
  */
static const FName CollisionProfile::PhysicsActor;
/* Variable: Destructible 
  */
static const FName CollisionProfile::Destructible;
/* Variable: InvisibleWall 
  */
static const FName CollisionProfile::InvisibleWall;
/* Variable: InvisibleWallDynamic 
  */
static const FName CollisionProfile::InvisibleWallDynamic;
/* Variable: Trigger 
  */
static const FName CollisionProfile::Trigger;
/* Variable: Ragdoll 
  */
static const FName CollisionProfile::Ragdoll;
/* Variable: Vehicle 
  */
static const FName CollisionProfile::Vehicle;
/* Variable: UI 
  */
static const FName CollisionProfile::UI;
}
