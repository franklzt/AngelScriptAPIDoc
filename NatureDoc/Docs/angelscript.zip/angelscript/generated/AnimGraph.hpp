/* Class: AnimGraph 
  */ 
 class AnimGraph
{
public:
// Group: Animation|Utilities

/* Function: EndProfilingTimer 
 This function ends measuring a profiling bracket and optionally logs the result

Parameters:
    bLog - If set to true the result is logged to the OutputLog
    LogPrefix - A prefix to use for the log */
static float32 AnimGraph::EndProfilingTimer(bool bLog = true, FString LogPrefix = "") {}
/* Function: CalculateVelocityFromPositionHistory 
 This function calculates the velocity of a position changing over time.
You need to hook up a valid PositionHistory variable to this for storage.

Parameters:
    DeltaSeconds - The time passed in seconds
    Position - The position to track over time.
    History - The history to use for storage.
    NumberOfSamples - The number of samples to use for the history. The higher the number of samples - the smoother the velocity changes.
    VelocityMin - The minimum velocity to use for normalization (if both min and max are set to 0, normalization is turned off)
    VelocityMax - The maximum velocity to use for normalization (if both min and max are set to 0, normalization is turned off) */
static float32 AnimGraph::CalculateVelocityFromPositionHistory(float32 DeltaSeconds, FVector Position, FPositionHistory& History, int NumberOfSamples, float32 VelocityMin, float32 VelocityMax) {}
/* Function: CalculateVelocityFromSockets 
 This function calculates the velocity of an offset position on a bone / socket over time.
The bone's / socket's motion can be expressed within a reference frame (another bone / socket).
You need to hook up a valid PositionHistory variable to this for storage.

Parameters:
    DeltaSeconds - The time passed in seconds
    Component - The skeletal component to look for the bones / sockets
    SocketOrBoneName - The name of the bone / socket to track.
    ReferenceSocketOrBone - The name of the bone / socket to use as a frame of reference (or None if no frame of reference == world space).
    SocketSpace - The space to use for the two sockets / bones
    OffsetInBoneSpace - The relative position in the space of the bone / socket to track over time.
    History - The history to use for storage.
    NumberOfSamples - The number of samples to use for the history. The higher the number of samples - the smoother the velocity changes.
    VelocityMin - The minimum velocity to use for normalization (if both min and max are set to 0, normalization is turned off)
    VelocityMax - The maximum velocity to use for normalization (if both min and max are set to 0, normalization is turned off)
    EasingType - The easing function to use
    CustomCurve - The curve to use if the easing type is "Custom" */
static float32 AnimGraph::CalculateVelocityFromSockets(float32 DeltaSeconds, USkeletalMeshComponent Component, const FName SocketOrBoneName, const FName ReferenceSocketOrBone, ERelativeTransformSpace SocketSpace, FVector OffsetInBoneSpace, FPositionHistory& History, int NumberOfSamples, float32 VelocityMin, float32 VelocityMax, EEasingFuncType EasingType, FRuntimeFloatCurve CustomCurve) {}
/* Function: DirectionBetweenSockets 
 Computes the direction between two bones / sockets.

Parameters:
    Component - The skeletal component to look for the sockets / bones within
    SocketOrBoneNameFrom - The name of the first socket / bone
    SocketOrBoneNameTo - The name of the second socket / bone */
static FVector AnimGraph::DirectionBetweenSockets(const USkeletalMeshComponent Component, const FName SocketOrBoneNameFrom, const FName SocketOrBoneNameTo) {}
/* Function: DistanceBetweenSockets 
 Computes the distance between two bones / sockets and can remap the range.

Parameters:
    Component - The skeletal component to look for the sockets / bones within
    SocketOrBoneNameA - The name of the first socket / bone
    SocketSpaceA - The space for the first socket / bone
    SocketOrBoneNameB - The name of the second socket / bone
    SocketSpaceB - The space for the second socket / bone
    bRemapRange - If set to true, the distance will be remapped using the range parameters
    InRangeMin - The minimum for the input range (commonly == 0.0)
    InRangeMax - The maximum for the input range (the max expected distance)
    OutRangeMin - The minimum for the output range (commonly == 0.0)
    OutRangeMax - The maximum for the output range (commonly == 1.0) */
static float32 AnimGraph::DistanceBetweenSockets(const USkeletalMeshComponent Component, const FName SocketOrBoneNameA, ERelativeTransformSpace SocketSpaceA, const FName SocketOrBoneNameB, ERelativeTransformSpace SocketSpaceB, bool bRemapRange, float32 InRangeMin, float32 InRangeMax, float32 OutRangeMin, float32 OutRangeMax) {}
/* Function: CalculateDirection 
 Returns degree of the angle between Velocity and Rotation forward vector
The range of return will be from [-180, 180]. Useful for feeding directional blendspaces.

Parameters:
    Velocity - The velocity to use as direction relative to BaseRotation
    BaseRotation - The base rotation, e.g. of a pawn */
static float32 AnimGraph::CalculateDirection(FVector Velocity, FRotator BaseRotation) {}
/* Function: LookAt 
 Computes the transform which is "looking" at target position with a local axis.

Parameters:
    CurrentTransform - The input transform to modify
    TargetPosition - The position this transform should look at
    LookAtVector - The local vector to align with the target
    bUseUpVector - If set to true the lookat will also perform a twist rotation
    UpVector - The position to use for the upvector target (only used is bUseUpVector is turned on)
    ClampConeInDegree - A limit for only allowing the lookat to rotate as much as defined by the float value */
static FTransform AnimGraph::LookAt(FTransform CurrentTransform, FVector TargetPosition, FVector LookAtVector, bool bUseUpVector, FVector UpVector, float32 ClampConeInDegree) {}
/* Function: MakeFloatFromPerlinNoise 
 This function creates perlin noise for a single float and then range map to RangeOut

Parameters:
    Value - The input value for the noise function
    RangeOutMin - The minimum for the output range
    RangeOutMax - The maximum for the output range */
static float32 AnimGraph::MakeFloatFromPerlinNoise(float32 Value, float32 RangeOutMin, float32 RangeOutMax) {}
/* Function: MakeVectorFromPerlinNoise 
 This function creates perlin noise from input X, Y, Z, and then range map to RangeOut, and out put to OutX, OutY, OutZ

Parameters:
    X - The x component for the input position of the noise
    Y - The y component for the input position of the noise
    Z - The z component for the input position of the noise
    RangeOutMinX - The minimum for the output range for the x component
    RangeOutMaxX - The maximum for the output range for the x component
    RangeOutMinY - The minimum for the output range for the y component
    RangeOutMaxY - The maximum for the output range for the y component
    RangeOutMinZ - The minimum for the output range for the z component
    RangeOutMaxZ - The maximum for the output range for the z component */
static FVector AnimGraph::MakeVectorFromPerlinNoise(float32 X, float32 Y, float32 Z, float32 RangeOutMinX, float32 RangeOutMaxX, float32 RangeOutMinY, float32 RangeOutMaxY, float32 RangeOutMinZ, float32 RangeOutMaxZ) {}
/* Function: StartProfilingTimer 
 This function starts measuring the time for a profiling bracket */
static void AnimGraph::StartProfilingTimer() {}
/* Function: TwoBoneIK 
 Computes the transform for two bones using inverse kinematics.

Parameters:
    RootPos - The input root position of the two bone chain
    JointPos - The input center (elbow) position of the two bone chain
    EndPos - The input end (wrist) position of the two bone chain
    JointTarget - The IK target for the write to reach
    Effector - The position of the target effector for the IK Chain.
    OutJointPos - The resulting position for the center (elbow)
    OutEndPos - The resulting position for the end (wrist)
    bAllowStretching - If set to true the bones are allowed to stretch
    StartStretchRatio - The ratio at which the bones should start to stretch. The higher the value, the later the stretching wil start.
    MaxStretchScale - The maximum multiplier for the stretch to reach. */
static void AnimGraph::TwoBoneIK(FVector RootPos, FVector JointPos, FVector EndPos, FVector JointTarget, FVector Effector, FVector& OutJointPos, FVector& OutEndPos, bool bAllowStretching, float32 StartStretchRatio, float32 MaxStretchScale) {}
}
