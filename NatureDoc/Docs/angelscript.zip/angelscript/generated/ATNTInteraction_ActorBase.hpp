/* Class: ATNTInteraction_ActorBase 
  */ 
 class ATNTInteraction_ActorBase : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ATNTInteraction_ActorBase ATNTInteraction_ActorBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATNTInteraction_ActorBase::StaticClass() {}
}
