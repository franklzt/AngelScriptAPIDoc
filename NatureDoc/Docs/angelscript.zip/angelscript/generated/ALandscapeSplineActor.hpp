/* Class: ALandscapeSplineActor 
  */ 
 class ALandscapeSplineActor : public AActor
{
public:
// Group: Target Landscape

/* Variable: LandscapeActor 
 Landscape * */
ALandscape LandscapeActor;
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeSplineActor ALandscapeSplineActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeSplineActor::StaticClass() {}
}
