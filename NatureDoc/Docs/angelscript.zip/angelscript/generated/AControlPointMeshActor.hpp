/* Class: AControlPointMeshActor 
 ControlPointMeshActor is an actor with a ControlPointMeshComponent.

@see UControlPointMeshComponent */ 
 class AControlPointMeshActor : public AActor
{
public:
// Group: ControlPointMeshActor

/* Variable: ControlPointMeshComponent 
  */
UControlPointMeshComponent ControlPointMeshComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AControlPointMeshActor AControlPointMeshActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AControlPointMeshActor::StaticClass() {}
}
