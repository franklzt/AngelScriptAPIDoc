/* Class: ALightmassPortal 
  */ 
 class ALightmassPortal : public AActor
{
public:
// Group: Portal

/* Variable: PortalComponent 
  */
ULightmassPortalComponent PortalComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ALightmassPortal ALightmassPortal::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALightmassPortal::StaticClass() {}
}
