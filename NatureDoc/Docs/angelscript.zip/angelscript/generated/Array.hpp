/* Class: Array 
  */ 
 class Array
{
public:
// Group: Utilities|Array

/* Function: FilterArray 
 *Filter an array based on a Class derived from Actor.
*
*

Parameters:
    TargetArray - The array to filter from *
    FilterClass - The Actor sub-class type that acts as the filter, only objects derived from it will be returned. *

Returns:
    An array containing only those objects which are derived from the class specified. */
static void Array::FilterArray(TArray<AActor> TargetArray, TSubclassOf<AActor> FilterClass, TArray<AActor>& FilteredArray) {}
// Group: Utilities|Array|Sort

/* Function: SortFloatArray 
 Sorts an array of doubles.

Parameters:
    TargetArray - The array to sort.
    bStableSort - If a stable sort should be used. This preserves the order of identical elements, but is slower.
    SortOrder - If the array should be sorted in ascending or descending order. */
static void Array::SortFloatArray(TArray<float>& TargetArray, bool bStableSort = false, EArraySortOrder SortOrder = EArraySortOrder :: Ascending) {}
/* Function: SortInt64Array 
 Sorts an array of 64-bit integers.

Parameters:
    TargetArray - The array to sort.
    bStableSort - If a stable sort should be used. This preserves the order of identical elements, but is slower.
    SortOrder - If the array should be sorted in ascending or descending order. */
static void Array::SortInt64Array(TArray<int64>& TargetArray, bool bStableSort = false, EArraySortOrder SortOrder = EArraySortOrder :: Ascending) {}
/* Function: SortIntArray 
 Sorts an array of integers.

Parameters:
    TargetArray - The array to sort.
    bStableSort - If a stable sort should be used. This preserves the order of identical elements, but is slower.
    SortOrder - If the array should be sorted in ascending or descending order. */
static void Array::SortIntArray(TArray<int>& TargetArray, bool bStableSort = false, EArraySortOrder SortOrder = EArraySortOrder :: Ascending) {}
/* Function: SortNameArray 
 Sorts an array of FNames.

Parameters:
    TargetArray - The array to sort.
    bStableSort - If a stable sort should be used. This preserves the order of identical elements, but is slower.
    bLexicalSort - If the names should be sorted based on the string value of the name rather than the comparison index. This is slower when enabled.
    SortOrder - If the array should be sorted in ascending or descending order. */
static void Array::SortNameArray(TArray<FName>& TargetArray, bool bStableSort = false, bool bLexicalSort = true, EArraySortOrder SortOrder = EArraySortOrder :: Ascending) {}
/* Function: SortStringArray 
 Sorts an array of strings alphabetically.

Parameters:
    TargetArray - The array to sort.
    bStableSort - If a stable sort should be used. This preserves the order of identical elements, but is slower.
    SortOrder - If the array should be sorted in ascending or descending order. */
static void Array::SortStringArray(TArray<FString>& TargetArray, bool bStableSort = false, EArraySortOrder SortOrder = EArraySortOrder :: Ascending) {}
/* Function: SortByteArray 
 Sorts an array of bytes.

Parameters:
    TargetArray - The array to sort.
    bStableSort - If a stable sort should be used. This preserves the order of identical elements, but is slower.
    SortOrder - If the array should be sorted in ascending or descending order. */
static void Array::SortByteArray(TArray<uint8>& TargetArray, bool bStableSort = false, EArraySortOrder SortOrder = EArraySortOrder :: Ascending) {}
}
