/* Class: EAnimAssetCurveFlags 
  */ 
 class EAnimAssetCurveFlags
{
public:
}
/* Enum: EAnimAssetCurveFlags 
 
    AACF_NONE - Enum
    AACF_DriveMorphTarget_DEPRECATED - Enum
    AACF_DriveAttribute_DEPRECATED - Enum
    AACF_Editable - Enum
    AACF_DriveMaterial_DEPRECATED - Enum
    AACF_Metadata - Enum
    AACF_DriveTrack - Enum
    AACF_Disabled - Enum
    AACF_MAX - Enum */ 
 enum EAnimAssetCurveFlags { 
AACF_NONE,
AACF_DriveMorphTarget_DEPRECATED,
AACF_DriveAttribute_DEPRECATED,
AACF_Editable,
AACF_DriveMaterial_DEPRECATED,
AACF_Metadata,
AACF_DriveTrack,
AACF_Disabled,
AACF_MAX, 
}