/* Class: ALevelInstanceEditorInstanceActor 
 Editor Only Actor that is spawned inside every LevelInstance Instance Level so that we can update its Actor Transforms through the ILevelInstanceInterface's (ULevelInstanceComponent)
@see ULevelInstanceComponent */ 
 class ALevelInstanceEditorInstanceActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ALevelInstanceEditorInstanceActor ALevelInstanceEditorInstanceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALevelInstanceEditorInstanceActor::StaticClass() {}
}
