/* Class: ASequencerKeyActor 
  */ 
 class ASequencerKeyActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ASequencerKeyActor ASequencerKeyActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASequencerKeyActor::StaticClass() {}
}
