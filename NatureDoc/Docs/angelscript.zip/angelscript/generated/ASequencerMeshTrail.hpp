/* Class: ASequencerMeshTrail 
  */ 
 class ASequencerMeshTrail : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ASequencerMeshTrail ASequencerMeshTrail::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASequencerMeshTrail::StaticClass() {}
}
