/* Class: EActivationFunction 
  */ 
 class EActivationFunction
{
public:
}
/* Enum: EActivationFunction 
 
    Linear - Enum
    ReLU - Enum
    LeakyReLU - Enum
    Tanh - Enum
    Sigmoid - Enum
    EActivationFunction_MAX - Enum */ 
 enum EActivationFunction { 
Linear,
ReLU,
LeakyReLU,
Tanh,
Sigmoid,
EActivationFunction_MAX, 
}