/* Class: DEPRECATED_EditorStaticMesh 
  */ 
 class DEPRECATED_EditorStaticMesh
{
public:
// Group: Editor Scripting | StaticMesh

/* Function: GetSimpleCollisionCount 
  */
static int DEPRECATED_EditorStaticMesh::GetSimpleCollisionCount(UStaticMesh StaticMesh) {}
/* Function: AddSimpleCollisionsWithNotification 
  */
static int DEPRECATED_EditorStaticMesh::AddSimpleCollisionsWithNotification(UStaticMesh StaticMesh, EScriptCollisionShapeType ShapeType, bool bApplyChanges) {}
/* Function: AddUVChannel 
  */
static bool DEPRECATED_EditorStaticMesh::AddUVChannel(UStaticMesh StaticMesh, int LODIndex) {}
/* Function: BulkSetConvexDecompositionCollisions 
  */
static bool DEPRECATED_EditorStaticMesh::BulkSetConvexDecompositionCollisions(TArray<UStaticMesh> StaticMeshes, int HullCount, int MaxHullVerts, int HullPrecision) {}
/* Function: BulkSetConvexDecompositionCollisionsWithNotification 
  */
static bool DEPRECATED_EditorStaticMesh::BulkSetConvexDecompositionCollisionsWithNotification(TArray<UStaticMesh> StaticMeshes, int HullCount, int MaxHullVerts, int HullPrecision, bool bApplyChanges) {}
/* Function: EnableSectionCastShadow 
  */
static void DEPRECATED_EditorStaticMesh::EnableSectionCastShadow(UStaticMesh StaticMesh, bool bCastShadow, int LODIndex, int SectionIndex) {}
/* Function: EnableSectionCollision 
  */
static void DEPRECATED_EditorStaticMesh::EnableSectionCollision(UStaticMesh StaticMesh, bool bCollisionEnabled, int LODIndex, int SectionIndex) {}
/* Function: GenerateBoxUVChannel 
  */
static bool DEPRECATED_EditorStaticMesh::GenerateBoxUVChannel(UStaticMesh StaticMesh, int LODIndex, int UVChannelIndex, FVector Position, FRotator Orientation, FVector Size) {}
/* Function: GenerateCylindricalUVChannel 
  */
static bool DEPRECATED_EditorStaticMesh::GenerateCylindricalUVChannel(UStaticMesh StaticMesh, int LODIndex, int UVChannelIndex, FVector Position, FRotator Orientation, FVector2D Tiling) {}
/* Function: GeneratePlanarUVChannel 
  */
static bool DEPRECATED_EditorStaticMesh::GeneratePlanarUVChannel(UStaticMesh StaticMesh, int LODIndex, int UVChannelIndex, FVector Position, FRotator Orientation, FVector2D Tiling) {}
/* Function: GetCollisionComplexity 
  */
static ECollisionTraceFlag DEPRECATED_EditorStaticMesh::GetCollisionComplexity(UStaticMesh StaticMesh) {}
/* Function: GetConvexCollisionCount 
  */
static int DEPRECATED_EditorStaticMesh::GetConvexCollisionCount(UStaticMesh StaticMesh) {}
/* Function: GetLodBuildSettings 
  */
static void DEPRECATED_EditorStaticMesh::GetLodBuildSettings(const UStaticMesh StaticMesh, int LodIndex, FMeshBuildSettings& OutBuildOptions) {}
/* Function: GetLodCount 
  */
static int DEPRECATED_EditorStaticMesh::GetLodCount(UStaticMesh StaticMesh) {}
/* Function: GetLodReductionSettings 
  */
static void DEPRECATED_EditorStaticMesh::GetLodReductionSettings(const UStaticMesh StaticMesh, int LodIndex, FMeshReductionSettings& OutReductionOptions) {}
/* Function: GetLodScreenSizes 
  */
static TArray<float32> DEPRECATED_EditorStaticMesh::GetLodScreenSizes(UStaticMesh StaticMesh) {}
/* Function: GetNumberMaterials 
  */
static int DEPRECATED_EditorStaticMesh::GetNumberMaterials(UStaticMesh StaticMesh) {}
/* Function: GetNumberVerts 
  */
static int DEPRECATED_EditorStaticMesh::GetNumberVerts(UStaticMesh StaticMesh, int LODIndex) {}
/* Function: GetNumUVChannels 
  */
static int DEPRECATED_EditorStaticMesh::GetNumUVChannels(UStaticMesh StaticMesh, int LODIndex) {}
/* Function: AddSimpleCollisions 
  */
static int DEPRECATED_EditorStaticMesh::AddSimpleCollisions(UStaticMesh StaticMesh, EScriptCollisionShapeType ShapeType) {}
/* Function: HasInstanceVertexColors 
  */
static bool DEPRECATED_EditorStaticMesh::HasInstanceVertexColors(UStaticMeshComponent StaticMeshComponent) {}
/* Function: HasVertexColors 
  */
static bool DEPRECATED_EditorStaticMesh::HasVertexColors(UStaticMesh StaticMesh) {}
/* Function: ImportLOD 
  */
static int DEPRECATED_EditorStaticMesh::ImportLOD(UStaticMesh BaseStaticMesh, int LODIndex, FString SourceFilename) {}
/* Function: InsertUVChannel 
  */
static bool DEPRECATED_EditorStaticMesh::InsertUVChannel(UStaticMesh StaticMesh, int LODIndex, int UVChannelIndex) {}
/* Function: IsSectionCollisionEnabled 
  */
static bool DEPRECATED_EditorStaticMesh::IsSectionCollisionEnabled(UStaticMesh StaticMesh, int LODIndex, int SectionIndex) {}
/* Function: ReimportAllCustomLODs 
  */
static bool DEPRECATED_EditorStaticMesh::ReimportAllCustomLODs(UStaticMesh StaticMesh) {}
/* Function: RemoveCollisions 
  */
static bool DEPRECATED_EditorStaticMesh::RemoveCollisions(UStaticMesh StaticMesh) {}
/* Function: RemoveCollisionsWithNotification 
  */
static bool DEPRECATED_EditorStaticMesh::RemoveCollisionsWithNotification(UStaticMesh StaticMesh, bool bApplyChanges) {}
/* Function: RemoveLods 
  */
static bool DEPRECATED_EditorStaticMesh::RemoveLods(UStaticMesh StaticMesh) {}
/* Function: RemoveUVChannel 
  */
static bool DEPRECATED_EditorStaticMesh::RemoveUVChannel(UStaticMesh StaticMesh, int LODIndex, int UVChannelIndex) {}
/* Function: SetAllowCPUAccess 
  */
static void DEPRECATED_EditorStaticMesh::SetAllowCPUAccess(UStaticMesh StaticMesh, bool bAllowCPUAccess) {}
/* Function: SetConvexDecompositionCollisions 
  */
static bool DEPRECATED_EditorStaticMesh::SetConvexDecompositionCollisions(UStaticMesh StaticMesh, int HullCount, int MaxHullVerts, int HullPrecision) {}
/* Function: SetConvexDecompositionCollisionsWithNotification 
  */
static bool DEPRECATED_EditorStaticMesh::SetConvexDecompositionCollisionsWithNotification(UStaticMesh StaticMesh, int HullCount, int MaxHullVerts, int HullPrecision, bool bApplyChanges) {}
/* Function: SetGenerateLightmapUv 
  */
static bool DEPRECATED_EditorStaticMesh::SetGenerateLightmapUv(UStaticMesh StaticMesh, bool bGenerateLightmapUVs) {}
/* Function: SetLodBuildSettings 
  */
static void DEPRECATED_EditorStaticMesh::SetLodBuildSettings(UStaticMesh StaticMesh, int LodIndex, FMeshBuildSettings BuildOptions) {}
/* Function: SetLodFromStaticMesh 
  */
static int DEPRECATED_EditorStaticMesh::SetLodFromStaticMesh(UStaticMesh DestinationStaticMesh, int DestinationLodIndex, UStaticMesh SourceStaticMesh, int SourceLodIndex, bool bReuseExistingMaterialSlots) {}
/* Function: SetLodReductionSettings 
  */
static void DEPRECATED_EditorStaticMesh::SetLodReductionSettings(UStaticMesh StaticMesh, int LodIndex, FMeshReductionSettings ReductionOptions) {}
/* Function: SetLods 
  */
static int DEPRECATED_EditorStaticMesh::SetLods(UStaticMesh StaticMesh, FStaticMeshReductionOptions ReductionOptions) {}
/* Function: SetLodsWithNotification 
  */
static int DEPRECATED_EditorStaticMesh::SetLodsWithNotification(UStaticMesh StaticMesh, FStaticMeshReductionOptions ReductionOptions, bool bApplyChanges) {}
}
