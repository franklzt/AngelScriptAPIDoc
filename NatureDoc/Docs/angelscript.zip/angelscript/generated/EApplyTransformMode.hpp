/* Class: EApplyTransformMode 
  */ 
 class EApplyTransformMode
{
public:
}
/* Enum: EApplyTransformMode 
 
    Override - Enum
    Additive - Enum
    Max - Enum
    EApplyTransformMode_MAX - Enum */ 
 enum EApplyTransformMode { 
Override,
Additive,
Max,
EApplyTransformMode_MAX, 
}