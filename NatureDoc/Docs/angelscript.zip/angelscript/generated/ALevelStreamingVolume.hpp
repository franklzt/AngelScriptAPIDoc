/* Class: ALevelStreamingVolume 
  */ 
 class ALevelStreamingVolume : public AVolume
{
public:
// Group: LevelStreamingVolume

/* Variable: StreamingUsage 
 Determines what this volume is used for, e.g. whether to control loading, loading and visibility or just visibilty (blocking on load) */
EStreamingVolumeUsage StreamingUsage;
/* Variable: bEditorPreVisOnly 
 If true, this streaming volume should only be used for editor streaming level previs. */
bool bEditorPreVisOnly;
/* Variable: bDisabled 
 If true, this streaming volume is ignored by the streaming volume code.  Used to either
disable a level streaming volume without disassociating it from the level, or to toggle
the control of a level's streaming between Kismet and volume streaming. */
bool bDisabled;
/* Variable: StreamingLevelNames 
 Levels names affected by this level streaming volume. */
TArray<FName> StreamingLevelNames;
// Group: Functions

/* Function: SetbEditorPreVisOnly 
 If true, this streaming volume should only be used for editor streaming level previs. */
void SetbEditorPreVisOnly(bool Value) {}
/* Function: GetbDisabled 
 If true, this streaming volume is ignored by the streaming volume code.  Used to either
disable a level streaming volume without disassociating it from the level, or to toggle
the control of a level's streaming between Kismet and volume streaming. */
bool GetbDisabled() const {}
/* Function: SetbDisabled 
 If true, this streaming volume is ignored by the streaming volume code.  Used to either
disable a level streaming volume without disassociating it from the level, or to toggle
the control of a level's streaming between Kismet and volume streaming. */
void SetbDisabled(bool Value) {}
/* Function: GetbEditorPreVisOnly 
 If true, this streaming volume should only be used for editor streaming level previs. */
bool GetbEditorPreVisOnly() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALevelStreamingVolume ALevelStreamingVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALevelStreamingVolume::StaticClass() {}
}
