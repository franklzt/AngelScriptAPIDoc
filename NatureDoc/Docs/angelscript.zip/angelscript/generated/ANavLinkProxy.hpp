/* Class: ANavLinkProxy 
 ANavLinkProxy connects areas of Navmesh that don't have a direct navigation path.
It directly supports Simple Links (see PointLinks array). There can be multiple Simple links per ANavLinkProxy instance.
Simple links are designed to statically link areas of Navmesh and are associated with a particular area class that the link provides.
Smart Link functionality is provided via UNavLinkCustomComponent, see SmartLinkComp. They are designed to be able to be dynamically toggled
between enabled and disabled and provide different area classes for both cases. The area classes can be dynamically modified
without navmesh rebuilds.
There can only be at most one smart link per ANavLinkProxy instance.
Both simple and smart links on a single ANavLinkProxy instance, can be set / enabled at once, as well as either or neither of them. */ 
 class ANavLinkProxy : public AActor
{
public:
// Group: SimpleLink

/* Variable: PointLinks 
 Navigation links (point to point) added to navigation data */
TArray<FNavigationLink> PointLinks;
// Group: SmartLink

/* Variable: bSmartLinkIsRelevant 
 Smart link: toggle relevancy */
bool bSmartLinkIsRelevant;
/* Variable: SmartLinkComp 
 Smart link: can affect path following */
UNavLinkCustomComponent SmartLinkComp;
// Group: Variables

/* Variable: OnSmartLinkReached 
  */
FSmartLinkReachedSignature OnSmartLinkReached;
// Group: AI|Navigation

/* Function: IsSmartLinkEnabled 
 check if smart link is enabled */
bool IsSmartLinkEnabled() const {}
/* Function: SetSmartLinkEnabled 
 change state of smart link */
void SetSmartLinkEnabled(bool bEnabled) {}
/* Function: ResumePathFollowing 
 resume normal path following */
void ResumePathFollowing(AActor Agent) {}
/* Function: HasMovingAgents 
 check if any agent is moving through smart link right now */
bool HasMovingAgents() const {}
// Group: Functions

/* Function: SmartLinkReached 
 called when agent reaches smart link during path following, use ResumePathFollowing() to give control back */
void SmartLinkReached(AActor Agent, FVector Destination) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANavLinkProxy ANavLinkProxy::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavLinkProxy::StaticClass() {}
}
