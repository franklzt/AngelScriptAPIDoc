/* Class: EAudioDeviceChangedRole 
  */ 
 class EAudioDeviceChangedRole
{
public:
}
/* Enum: EAudioDeviceChangedRole 
 
    Invalid - Enum
    Console - Enum
    Multimedia - Enum
    Communications - Enum
    Count - Enum
    EAudioDeviceChangedRole_MAX - Enum */ 
 enum EAudioDeviceChangedRole { 
Invalid,
Console,
Multimedia,
Communications,
Count,
EAudioDeviceChangedRole_MAX, 
}