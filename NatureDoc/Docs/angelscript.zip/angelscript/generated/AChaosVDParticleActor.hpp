/* Class: AChaosVDParticleActor 
 Actor used to represent a Chaos Particle in the Visual Debugger's world */ 
 class AChaosVDParticleActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AChaosVDParticleActor AChaosVDParticleActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AChaosVDParticleActor::StaticClass() {}
}
