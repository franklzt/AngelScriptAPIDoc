/* Class: EAutomationState 
  */ 
 class EAutomationState
{
public:
}
/* Enum: EAutomationState 
 
    NotRun - Enum
    InProcess - Enum
    Fail - Enum
    Success - Enum
    Skipped - Enum
    EAutomationState_MAX - Enum */ 
 enum EAutomationState { 
NotRun,
InProcess,
Fail,
Success,
Skipped,
EAutomationState_MAX, 
}