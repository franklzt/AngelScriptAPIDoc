/* Class: EBakeMapType 
  */ 
 class EBakeMapType
{
public:
}
/* Enum: EBakeMapType 
 
    None - Enum
    TangentSpaceNormal - Enum
    ObjectSpaceNormal - Enum
    FaceNormal - Enum
    BentNormal - Enum
    Position - Enum
    Curvature - Enum
    AmbientOcclusion - Enum
    Texture - Enum
    MultiTexture - Enum
    VertexColor - Enum
    MaterialID - Enum
    PolyGroupID - Enum
    One - Enum
    Zero - Enum
    UVShell - Enum
    All - Enum
    EBakeMapType_MAX - Enum */ 
 enum EBakeMapType { 
None,
TangentSpaceNormal,
ObjectSpaceNormal,
FaceNormal,
BentNormal,
Position,
Curvature,
AmbientOcclusion,
Texture,
MultiTexture,
VertexColor,
MaterialID,
PolyGroupID,
One,
Zero,
UVShell,
All,
EBakeMapType_MAX, 
}