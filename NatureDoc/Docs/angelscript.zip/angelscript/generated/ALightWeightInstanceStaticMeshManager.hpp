/* Class: ALightWeightInstanceStaticMeshManager 
  */ 
 class ALightWeightInstanceStaticMeshManager : public ALightWeightInstanceManager
{
public:
// Group: Debug

/* Variable: ISMComponent 
  */
UInstancedStaticMeshComponent ISMComponent;
/* Variable: StaticMesh 
  */
TSoftObjectPtr<UStaticMesh> StaticMesh;
// Group: Static Functions

/* Function: Spawn 
  */
static ALightWeightInstanceStaticMeshManager ALightWeightInstanceStaticMeshManager::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALightWeightInstanceStaticMeshManager::StaticClass() {}
}
