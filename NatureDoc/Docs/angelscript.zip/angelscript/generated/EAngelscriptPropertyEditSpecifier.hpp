/* Class: EAngelscriptPropertyEditSpecifier 
  */ 
 class EAngelscriptPropertyEditSpecifier
{
public:
}
/* Enum: EAngelscriptPropertyEditSpecifier 
 
    EditAnywhere - Enum
    EditInstanceOnly - Enum
    EditDefaultsOnly - Enum
    NotEditable - Enum
    EAngelscriptPropertyEditSpecifier_MAX - Enum */ 
 enum EAngelscriptPropertyEditSpecifier { 
EditAnywhere,
EditInstanceOnly,
EditDefaultsOnly,
NotEditable,
EAngelscriptPropertyEditSpecifier_MAX, 
}