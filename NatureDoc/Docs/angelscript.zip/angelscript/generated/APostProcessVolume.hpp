/* Class: APostProcessVolume 
 for FPostprocessSettings */ 
 class APostProcessVolume : public AVolume
{
public:
// Group: PostProcessVolumeSettings

/* Variable: Priority 
 Priority of this volume. In the case of overlapping volumes the one with the highest priority
overrides the lower priority ones. The order is undefined if two or more overlapping volumes have the same priority. */
float32 Priority;
/* Variable: BlendRadius 
 World space radius around the volume that is used for blending (only if not unbound). */
float32 BlendRadius;
/* Variable: BlendWeight 
 0:no effect, 1:full effect */
float32 BlendWeight;
/* Variable: bEnabled 
 Whether this volume is enabled or not. */
bool bEnabled;
/* Variable: bUnbound 
 Whether this volume covers the whole world, or just the area inside its bounds. */
bool bUnbound;
/* Variable: Settings 
 Post process settings to use for this volume. */
FPostProcessSettings Settings;
// Group: Functions

/* Function: SetbEnabled 
 Whether this volume is enabled or not. */
void SetbEnabled(bool Value) {}
/* Function: GetbUnbound 
 Whether this volume covers the whole world, or just the area inside its bounds. */
bool GetbUnbound() const {}
/* Function: SetbUnbound 
 Whether this volume covers the whole world, or just the area inside its bounds. */
void SetbUnbound(bool Value) {}
/* Function: GetbEnabled 
 Whether this volume is enabled or not. */
bool GetbEnabled() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static APostProcessVolume APostProcessVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APostProcessVolume::StaticClass() {}
}
