/* Class: AnimCharacterMovement 
  */ 
 class AnimCharacterMovement
{
public:
// Group: Animation Character Movement

/* Function: PredictGroundMovementStopLocation 
 Predict where the character will stop based on its current movement properties and parameters from the movement component.
This uses prediction logic that is heavily tied to the UCharacterMovementComponent.
Each parameter corresponds to a value from the UCharacterMovementComponent with the same name.
Because this is a thread safe function, it's recommended to populate these fields via the Property Access system.

Returns:
    The predicted stop position in local space to the character. The size of this vector will be the distance to the stop location. */
static FVector AnimCharacterMovement::PredictGroundMovementStopLocation(FVector Velocity, bool bUseSeparateBrakingFriction, float32 BrakingFriction, float32 GroundFriction, float32 BrakingFrictionFactor, float32 BrakingDecelerationWalking) {}
/* Function: PredictGroundMovementPivotLocation 
 Predict where the character will change direction during a pivot based on its current movement properties and parameters from the movement component.
This uses prediction logic that is heavily tied to the UCharacterMovementComponent.
Each parameter corresponds to a value from the UCharacterMovementComponent with the same name.
Because this is a thread safe function, it's recommended to populate these fields via the Property Access system.

Returns:
    The predicted pivot position in local space to the character. The size of this vector will be the distance to the pivot. */
static FVector AnimCharacterMovement::PredictGroundMovementPivotLocation(FVector Acceleration, FVector Velocity, float32 GroundFriction) {}
}
