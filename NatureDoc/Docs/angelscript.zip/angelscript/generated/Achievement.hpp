/* Class: Achievement 
  */ 
 class Achievement
{
public:
// Group: Online|Achievements

/* Function: GetCachedAchievementProgress 
 out */
static void Achievement::GetCachedAchievementProgress(APlayerController PlayerController, FName AchievementID, bool& bFoundID, float32& Progress) {}
/* Function: GetCachedAchievementDescription 
 out */
static void Achievement::GetCachedAchievementDescription(APlayerController PlayerController, FName AchievementID, bool& bFoundID, FText& Title, FText& LockedDescription, FText& UnlockedDescription, bool& bHidden) {}
}
