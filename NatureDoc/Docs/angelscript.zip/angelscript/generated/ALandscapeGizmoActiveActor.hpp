/* Class: ALandscapeGizmoActiveActor 
  */ 
 class ALandscapeGizmoActiveActor : public ALandscapeGizmoActor
{
public:
// Group: Variables

/* Variable: FrustumVerts 
  */
FVector FrustumVerts;
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeGizmoActiveActor ALandscapeGizmoActiveActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeGizmoActiveActor::StaticClass() {}
}
