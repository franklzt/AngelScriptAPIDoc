/* Class: ARectLight 
  */ 
 class ARectLight : public ALight
{
public:
// Group: Light

/* Variable: RectLightComponent 
  */
URectLightComponent RectLightComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ARectLight ARectLight::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ARectLight::StaticClass() {}
}
