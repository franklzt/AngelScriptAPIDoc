/* Class: AnimPhysCollisionType 
  */ 
 class AnimPhysCollisionType
{
public:
}
/* Enum: AnimPhysCollisionType 
 
    CoM - Enum
    CustomSphere - Enum
    InnerSphere - Enum
    OuterSphere - Enum
    AnimPhysCollisionType_MAX - Enum */ 
 enum AnimPhysCollisionType { 
CoM,
CustomSphere,
InnerSphere,
OuterSphere,
AnimPhysCollisionType_MAX, 
}