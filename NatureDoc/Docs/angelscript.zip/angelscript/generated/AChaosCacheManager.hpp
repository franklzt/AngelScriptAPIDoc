/* Class: AChaosCacheManager 
  */ 
 class AChaosCacheManager : public AActor
{
public:
// Group: Caching

/* Variable: StartMode 
 How to trigger the cache record or playback, timed will start counting at BeginPlay, Triggered will begin
counting from when the owning cache manager is requested to trigger the cache action
@see AChaosCacheManager::TriggerObservedComponent */
EStartMode StartMode;
/* Variable: StartTime 
 Defines the (random access) time that represents the rest pose of the components managed by this cache.
When in Play mode, the components are set to the state provided by the caches at this evaluated time. */
float32 StartTime;
/* Variable: ObservedComponents 
 List of observed objects and their caches */
TArray<FObservedComponent> ObservedComponents;
/* Variable: CacheMode 
 How to use the cache - playback or record */
ECacheMode CacheMode;
// Group: Caching

/* Function: SetCurrentTime 
  */
void SetCurrentTime(float32 CurrentTime) {}
/* Function: EnablePlaybackByCache 
 Enable playback for a specific component using its cache name */
void EnablePlaybackByCache(FName InCacheName, bool bEnable) {}
/* Function: ResetAllComponentTransforms 
 Resets all components back to the world space transform they had when the cache for them was originally recorded
if one is available */
void ResetAllComponentTransforms() {}
/* Function: ResetSingleTransform 
 Resets the component at the specified index in the observed list back to the world space transform it had when the
cache for it was originally recorded if one is available

Parameters:
    InIndex - Index of the component to reset */
void ResetSingleTransform(int InIndex) {}
/* Function: SetCacheCollection 
 change the cache collection for this player
if the cache is playing or recording this will have no effect */
void SetCacheCollection(UChaosCacheCollection InCacheCollection) {}
/* Function: EnablePlayback 
 Enable playback for a specific component using its index in the list of observed component */
void EnablePlayback(int Index, bool bEnable) {}
/* Function: TriggerAll 
 Triggers the recording or playback of all observed components */
void TriggerAll() {}
/* Function: TriggerComponent 
 Triggers a component to play or record.
If the cache manager has an observed component entry for InComponent and it is a triggered entry
this will begin the playback or record for that component, otherwise no action is taken.

Parameters:
    InComponent - Component to trigger */
void TriggerComponent(UPrimitiveComponent InComponent) {}
/* Function: TriggerComponentByCache 
 Triggers a component to play or record.
Searches the observed component list for an entry matching InCacheName and triggers the
playback or recording of the linked observed component

Parameters:
    InCacheName - Cache name to trigger */
void TriggerComponentByCache(FName InCacheName) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AChaosCacheManager AChaosCacheManager::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AChaosCacheManager::StaticClass() {}
}
