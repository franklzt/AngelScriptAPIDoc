/* Class: AOnlineBeaconClient 
 Base class for any unique beacon connectivity, paired with an AOnlineBeaconHostObject implementation

This is the actual actor that replicates across client/server and where all RPCs occur
On the host, the life cycle is managed by an AOnlineBeaconHostObject
On the client, the life cycle is managed by the game */ 
 class AOnlineBeaconClient : public AOnlineBeacon
{
public:
// Group: Functions

/* Function: ClientOnConnected 
 Called on the server side to open up the actor channel that will allow RPCs to occur
(DO NOT OVERLOAD, implement OnConnected() instead) */
void ClientOnConnected() {}
// Group: Static Functions

/* Function: Spawn 
  */
static AOnlineBeaconClient AOnlineBeaconClient::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AOnlineBeaconClient::StaticClass() {}
}
