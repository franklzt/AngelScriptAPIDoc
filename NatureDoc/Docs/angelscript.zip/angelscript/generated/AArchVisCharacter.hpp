/* Class: AArchVisCharacter 
  */ 
 class AArchVisCharacter : public ACharacter
{
public:
// Group: ArchVis Controls

/* Variable: LookUpAtRateAxisName 
 Axis name for rate-based look up/down inputs (e.g. joystick). This should match an Axis Binding in your input settings */
FString LookUpAtRateAxisName;
/* Variable: TurnAxisName 
 Axis name for direct turn left/right inputs (e.g. mouse). This should match an Axis Binding in your input settings */
FString TurnAxisName;
/* Variable: TurnAtRateAxisName 
 Axis name for rate-based turn left/right inputs (e.g. joystick). This should match an Axis Binding in your input settings */
FString TurnAtRateAxisName;
/* Variable: MoveForwardAxisName 
 Axis name for "move forward/back" control. This should match an Axis Binding in your input settings */
FString MoveForwardAxisName;
/* Variable: MoveRightAxisName 
 Axis name for "move left/right" control. This should match an Axis Binding in your input settings */
FString MoveRightAxisName;
/* Variable: MouseSensitivityScale_Pitch 
 Controls how aggressively mouse motion translates to character rotation in the pitch axis. */
float32 MouseSensitivityScale_Pitch;
/* Variable: MouseSensitivityScale_Yaw 
 Controls how aggressively mouse motion translates to character rotation in the yaw axis. */
float32 MouseSensitivityScale_Yaw;
/* Variable: LookUpAxisName 
 Axis name for direct look up/down inputs (e.g. mouse). This should match an Axis Binding in your input settings */
FString LookUpAxisName;
// Group: Static Functions

/* Function: Spawn 
  */
static AArchVisCharacter AArchVisCharacter::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AArchVisCharacter::StaticClass() {}
}
