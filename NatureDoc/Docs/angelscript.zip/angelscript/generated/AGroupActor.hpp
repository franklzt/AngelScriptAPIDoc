/* Class: AGroupActor 
  */ 
 class AGroupActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AGroupActor AGroupActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGroupActor::StaticClass() {}
}
