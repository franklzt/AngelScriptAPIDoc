/* Class: EBakeTextureSamplesPerPixel 
  */ 
 class EBakeTextureSamplesPerPixel
{
public:
}
/* Enum: EBakeTextureSamplesPerPixel 
 
    Sample1 - Enum
    Sample4 - Enum
    Sample16 - Enum
    Sample64 - Enum
    Sample256 - Enum
    EBakeTextureSamplesPerPixel_MAX - Enum */ 
 enum EBakeTextureSamplesPerPixel { 
Sample1,
Sample4,
Sample16,
Sample64,
Sample256,
EBakeTextureSamplesPerPixel_MAX, 
}