/* Class: EAutoSaveMethod 
  */ 
 class EAutoSaveMethod
{
public:
}
/* Enum: EAutoSaveMethod 
 
    BackupAndRestore - Enum
    BackupAndOverwrite - Enum
    EAutoSaveMethod_MAX - Enum */ 
 enum EAutoSaveMethod { 
BackupAndRestore,
BackupAndOverwrite,
EAutoSaveMethod_MAX, 
}