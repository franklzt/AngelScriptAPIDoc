/* Class: AVREditorFloatingUI 
 Represents an interactive floating UI panel in the VR Editor */ 
 class AVREditorFloatingUI : public AVREditorBaseActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AVREditorFloatingUI AVREditorFloatingUI::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVREditorFloatingUI::StaticClass() {}
}
