/* Class: EBakeNormalSpace 
  */ 
 class EBakeNormalSpace
{
public:
}
/* Enum: EBakeNormalSpace 
 
    Tangent - Enum
    Object - Enum
    EBakeNormalSpace_MAX - Enum */ 
 enum EBakeNormalSpace { 
Tangent,
Object,
EBakeNormalSpace_MAX, 
}