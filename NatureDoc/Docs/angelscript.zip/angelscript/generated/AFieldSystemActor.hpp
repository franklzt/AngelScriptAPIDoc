/* Class: AFieldSystemActor 
  */ 
 class AFieldSystemActor : public AActor
{
public:
// Group: Field

/* Variable: FieldSystemComponent 
 FieldSystemComponent */
UFieldSystemComponent FieldSystemComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AFieldSystemActor AFieldSystemActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AFieldSystemActor::StaticClass() {}
}
