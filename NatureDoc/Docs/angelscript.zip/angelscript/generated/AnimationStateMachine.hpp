/* Class: AnimationStateMachine 
  */ 
 class AnimationStateMachine
{
public:
// Group: State Machine

/* Function: ConvertToAnimationStateMachinePure 
 Get an anim state machine from an anim node reference (pure) */
static void AnimationStateMachine::ConvertToAnimationStateMachinePure(FAnimNodeReference Node, FAnimationStateMachineReference& AnimationState, bool& Result) {}
/* Function: ConvertToAnimationStateResult 
 Get an anim state reference from an anim node reference */
static void AnimationStateMachine::ConvertToAnimationStateResult(FAnimNodeReference Node, FAnimationStateResultReference& AnimationState, EAnimNodeReferenceConversionResult& Result) {}
/* Function: ConvertToAnimationStateResultPure 
 Get an anim state reference from an anim node reference (pure) */
static void AnimationStateMachine::ConvertToAnimationStateResultPure(FAnimNodeReference Node, FAnimationStateResultReference& AnimationState, bool& Result) {}
/* Function: ConvertToAnimationStateMachine 
 Get an anim state machine from an anim node reference */
static void AnimationStateMachine::ConvertToAnimationStateMachine(FAnimNodeReference Node, FAnimationStateMachineReference& AnimationState, EAnimNodeReferenceConversionResult& Result) {}
}
