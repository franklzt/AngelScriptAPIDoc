/* Class: AEmitter 
  */ 
 class AEmitter : public AActor
{
public:
// Group: Emitter

/* Variable: bPostUpdateTickGroup 
  */
bool bPostUpdateTickGroup;
/* Variable: ParticleSystemComponent 
  */
UParticleSystemComponent ParticleSystemComponent;
// Group: Variables

/* Variable: OnParticleDeath 
  */
FParticleDeathSignature OnParticleDeath;
/* Variable: OnParticleCollide 
  */
FParticleCollisionSignature OnParticleCollide;
/* Variable: OnParticleBurst 
  */
FParticleBurstSignature OnParticleBurst;
/* Variable: OnParticleSpawn 
  */
FParticleSpawnSignature OnParticleSpawn;
// Group: Particles

/* Function: SetTemplate 
  */
void SetTemplate(UParticleSystem NewTemplate) {}
/* Function: Deactivate 
  */
void Deactivate() {}
/* Function: IsActive 
  */
bool IsActive() const {}
/* Function: Activate 
 BEGIN DEPRECATED (use component functions now in level script) */
void Activate() {}
/* Function: ToggleActive 
  */
void ToggleActive() {}
// Group: Particles|Parameters

/* Function: SetMaterialParameter 
  */
void SetMaterialParameter(FName ParameterName, UMaterialInterface Param) {}
/* Function: SetFloatParameter 
  */
void SetFloatParameter(FName ParameterName, float32 Param) {}
/* Function: SetActorParameter 
  */
void SetActorParameter(FName ParameterName, AActor Param) {}
/* Function: SetColorParameter 
  */
void SetColorParameter(FName ParameterName, FLinearColor Param) {}
/* Function: SetVectorParameter 
  */
void SetVectorParameter(FName ParameterName, FVector Param) {}
// Group: Functions

/* Function: SetbPostUpdateTickGroup 
  */
void SetbPostUpdateTickGroup(bool Value) {}
/* Function: GetbPostUpdateTickGroup 
  */
bool GetbPostUpdateTickGroup() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AEmitter AEmitter::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AEmitter::StaticClass() {}
}
