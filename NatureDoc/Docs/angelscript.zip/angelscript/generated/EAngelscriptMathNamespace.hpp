/* Class: EAngelscriptMathNamespace 
  */ 
 class EAngelscriptMathNamespace
{
public:
}
/* Enum: EAngelscriptMathNamespace 
 
    Math - Enum
    FMath - Enum
    EAngelscriptMathNamespace_MAX - Enum */ 
 enum EAngelscriptMathNamespace { 
Math,
FMath,
EAngelscriptMathNamespace_MAX, 
}