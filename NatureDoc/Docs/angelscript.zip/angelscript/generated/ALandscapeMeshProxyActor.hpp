/* Class: ALandscapeMeshProxyActor 
  */ 
 class ALandscapeMeshProxyActor : public AActor
{
public:
// Group: LandscapeMeshProxyActor

/* Variable: LandscapeMeshProxyComponent 
  */
ULandscapeMeshProxyComponent LandscapeMeshProxyComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeMeshProxyActor ALandscapeMeshProxyActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeMeshProxyActor::StaticClass() {}
}
