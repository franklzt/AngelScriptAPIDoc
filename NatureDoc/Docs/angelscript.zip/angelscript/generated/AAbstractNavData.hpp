/* Class: AAbstractNavData 
  */ 
 class AAbstractNavData : public ANavigationData
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AAbstractNavData AAbstractNavData::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AAbstractNavData::StaticClass() {}
}
