/* Class: ALevelVariantSetsActor 
  */ 
 class ALevelVariantSetsActor : public AActor
{
public:
// Group: LevelVariantSets

/* Function: SetLevelVariantSets 
  */
void SetLevelVariantSets(ULevelVariantSets InVariantSets) {}
/* Function: SwitchOnVariantByIndex 
  */
bool SwitchOnVariantByIndex(int VariantSetIndex, int VariantIndex) {}
/* Function: SwitchOnVariantByName 
  */
bool SwitchOnVariantByName(FString VariantSetName, FString VariantName) {}
/* Function: GetLevelVariantSets 
 Returns the LevelVariantSets asset, optionally loading it if necessary */
ULevelVariantSets GetLevelVariantSets(bool bLoad = false) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALevelVariantSetsActor ALevelVariantSetsActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALevelVariantSetsActor::StaticClass() {}
}
