/* Class: Automation 
  */ 
 class Automation
{
public:
// Group: Automation

/* Function: GetDefaultScreenshotOptionsForRendering 
  */
static FAutomationScreenshotOptions Automation::GetDefaultScreenshotOptionsForRendering(EComparisonTolerance Tolerance = EComparisonTolerance :: Low, float32 Delay = 0.200000) {}
/* Function: AddExpectedLogMessage 
 Expect a specific log message to match a pattern during an automated test regardless of its verbosity. Treat the pattern as regex by default. */
static void Automation::AddExpectedLogMessage(FString ExpectedPatternString, int Occurrences = 1, bool ExactMatch = false, bool IsRegex = true) {}
/* Function: AddExpectedPlainLogError 
 Mute the report of log error and warning matching a plain string during an automated test */
static void Automation::AddExpectedPlainLogError(FString ExpectedString, int Occurrences = 1, bool ExactMatch = false) {}
/* Function: AddExpectedPlainLogMessage 
 Expect a specific log message to match a plain string during an automated test regardless of its verbosity */
static void Automation::AddExpectedPlainLogMessage(FString ExpectedString, int Occurrences = 1, bool ExactMatch = false) {}
/* Function: AddTestError 
 Add error to currently running automated test. */
static void Automation::AddTestError(FString InLogItem) {}
/* Function: AddTestInfo 
 Add info to currently running automated test. */
static void Automation::AddTestInfo(FString InLogItem) {}
/* Function: AddTestTelemetryData 
 Add Telemetry data to currently running automated test. */
static void Automation::AddTestTelemetryData(FString DataPoint, float32 Measurement, FString Context = "") {}
/* Function: AddTestWarning 
 Add warning to currently running automated test. */
static void Automation::AddTestWarning(FString InLogItem) {}
/* Function: AreAutomatedTestsRunning 
 Lets you know if any automated tests are running, or are about to run and the automation system is spinning up tests. */
static bool Automation::AreAutomatedTestsRunning() {}
/* Function: AutomationWaitForLoading 
  */
static void Automation::AutomationWaitForLoading(UObject WorldContextObject, FLatentActionInfo LatentInfo, FAutomationWaitForLoadingOptions Options) {}
/* Function: CompareImageAgainstReference 
 request image comparison.

Parameters:
    ImageFilePath - Absolute path to the image location. All 8bit RGBA channels supported formats by the engine are accepted.
    ComparisonName - Optional name for the comparison, by default the basename of ImageFilePath is used

Returns:
    True if comparison was successfully enqueued */
static bool Automation::CompareImageAgainstReference(FString ImageFilePath, FString ComparisonName = "", EComparisonTolerance ComparisonTolerance = EComparisonTolerance :: Low, FString ComparisonNotes = "", UObject WorldContextObject = nullptr) {}
/* Function: DisableStatGroup 
  */
static void Automation::DisableStatGroup(UObject WorldContextObject, FName GroupName) {}
/* Function: EnableStatGroup 
  */
static void Automation::EnableStatGroup(UObject WorldContextObject, FName GroupName) {}
/* Function: FinishLoadingBeforeScreenshot 
  */
static void Automation::FinishLoadingBeforeScreenshot() {}
/* Function: GetDefaultScreenshotOptionsForGameplay 
  */
static FAutomationScreenshotOptions Automation::GetDefaultScreenshotOptionsForGameplay(EComparisonTolerance Tolerance = EComparisonTolerance :: Low, float32 Delay = 0.200000) {}
/* Function: AddExpectedLogError 
 Mute the report of log error and warning matching a pattern during an automated test. Treat the pattern as regex by default.

Parameters:
    ExpectedPatternString - Expects a Regex pattern. */
static void Automation::AddExpectedLogError(FString ExpectedPatternString, int Occurrences = 1, bool ExactMatch = false, bool IsRegex = true) {}
/* Function: GetStatCallCount 
  */
static float32 Automation::GetStatCallCount(FName StatName) {}
/* Function: GetStatExcAverage 
  */
static float32 Automation::GetStatExcAverage(FName StatName) {}
/* Function: GetStatExcMax 
  */
static float32 Automation::GetStatExcMax(FName StatName) {}
/* Function: GetStatIncAverage 
  */
static float32 Automation::GetStatIncAverage(FName StatName) {}
/* Function: GetStatIncMax 
  */
static float32 Automation::GetStatIncMax(FName StatName) {}
/* Function: SetEditorViewportViewMode 
 Sets all viewports of the first found level editor to have the given ViewMode (Lit/Unlit/etc.) * */
static void Automation::SetEditorViewportViewMode(EViewModeIndex Index) {}
/* Function: SetEditorViewportVisualizeBuffer 
 Sets all viewports of the first found level editor to have the VisualizeBuffer ViewMode and also display a given buffer (BaseColor/Metallic/Roughness/etc.) * */
static void Automation::SetEditorViewportVisualizeBuffer(FName BufferName) {}
/* Function: SetScalabilityQualityLevelRelativeToMax 
 Sets all other settings based on an overall value

Parameters:
    Value - 0:Cinematic, 1:Epic...etc. */
static void Automation::SetScalabilityQualityLevelRelativeToMax(UObject WorldContextObject, int Value = 1) {}
/* Function: SetScalabilityQualityToEpic 
  */
static void Automation::SetScalabilityQualityToEpic(UObject WorldContextObject) {}
/* Function: SetScalabilityQualityToLow 
  */
static void Automation::SetScalabilityQualityToLow(UObject WorldContextObject) {}
/* Function: SetTestTelemetryStorage 
 Set Telemetry data storage name of currently running automated test. */
static void Automation::SetTestTelemetryStorage(FString StorageName) {}
/* Function: TakeAutomationScreenshot 
 Takes a screenshot of the game's viewport.  Does not capture any UI. */
static void Automation::TakeAutomationScreenshot(UObject WorldContextObject, FLatentActionInfo LatentInfo, FString Name, FString Notes, FAutomationScreenshotOptions Options) {}
/* Function: TakeAutomationScreenshotAtCamera 
 Takes a screenshot of the game's viewport, from a particular camera actors POV.  Does not capture any UI. */
static void Automation::TakeAutomationScreenshotAtCamera(UObject WorldContextObject, FLatentActionInfo LatentInfo, ACameraActor Camera, FString NameOverride, FString Notes, FAutomationScreenshotOptions Options) {}
/* Function: TakeAutomationScreenshotOfUI 
  */
static void Automation::TakeAutomationScreenshotOfUI(UObject WorldContextObject, FLatentActionInfo LatentInfo, FString Name, FAutomationScreenshotOptions Options) {}
/* Function: TakeHighResScreenshot 
 take high res screenshot in editor. */
static UAutomationEditorTask Automation::TakeHighResScreenshot(int ResX, int ResY, FString Filename, ACameraActor Camera = nullptr, bool bMaskEnabled = false, bool bCaptureHDR = false, EComparisonTolerance ComparisonTolerance = EComparisonTolerance :: Low, FString ComparisonNotes = "", float32 Delay = 0.000000, bool bForceGameView = true) {}
}
