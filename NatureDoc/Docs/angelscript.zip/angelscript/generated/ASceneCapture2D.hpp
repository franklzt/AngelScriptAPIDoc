/* Class: ASceneCapture2D 
  */ 
 class ASceneCapture2D : public ASceneCapture
{
public:
// Group: DecalActor

/* Variable: CaptureComponent2D 
 Scene capture component. */
USceneCaptureComponent2D CaptureComponent2D;
// Group: Rendering

/* Function: OnInterpToggle 
  */
void OnInterpToggle(bool bEnable) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ASceneCapture2D ASceneCapture2D::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASceneCapture2D::StaticClass() {}
}
