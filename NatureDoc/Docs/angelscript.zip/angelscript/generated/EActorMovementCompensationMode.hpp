/* Class: EActorMovementCompensationMode 
  */ 
 class EActorMovementCompensationMode
{
public:
}
/* Enum: EActorMovementCompensationMode 
 
    ComponentSpace - Enum
    WorldSpace - Enum
    SuddenMotionOnly - Enum
    EActorMovementCompensationMode_MAX - Enum */ 
 enum EActorMovementCompensationMode { 
ComponentSpace,
WorldSpace,
SuddenMotionOnly,
EActorMovementCompensationMode_MAX, 
}