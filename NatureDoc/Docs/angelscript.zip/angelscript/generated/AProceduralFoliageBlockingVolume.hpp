/* Class: AProceduralFoliageBlockingVolume 
 An invisible volume used to block ProceduralFoliage instances from being spawned. */ 
 class AProceduralFoliageBlockingVolume : public AVolume
{
public:
// Group: ProceduralFoliage

/* Variable: DensityFalloff 
  */
FFoliageDensityFalloff DensityFalloff;
/* Variable: ProceduralFoliageVolume 
  */
AProceduralFoliageVolume ProceduralFoliageVolume;
// Group: Static Functions

/* Function: Spawn 
  */
static AProceduralFoliageBlockingVolume AProceduralFoliageBlockingVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AProceduralFoliageBlockingVolume::StaticClass() {}
}
