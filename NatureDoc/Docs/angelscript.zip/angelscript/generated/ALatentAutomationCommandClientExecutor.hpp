/* Class: ALatentAutomationCommandClientExecutor 
 ALatentAutomationCommandClientExecutor

Executes a ULatentAutomationCommand on client.

This Actor replicates. The provided ULatentAutomationCommand will be replicated.
When ticking, this Actor will inject a component into the player controller to be
able to synchronize execution between client and server.
This Actor executes the test on client.

The executor will use the different replicated properties to communicate the
different phases of execution from server to client. */ 
 class ALatentAutomationCommandClientExecutor : public AActor
{
public:
// Group: Automation Command Client Executor

/* Function: AssertTrue 
  */
void AssertTrue(bool bExpression, FString Message) {}
/* Function: AssertNotNull 
  */
void AssertNotNull(const UObject Object, FString Message) {}
/* Function: AssertNotSame 
  */
void AssertNotSame(const UObject Expected, const UObject Actual, FString Message) {}
/* Function: AssertNull 
  */
void AssertNull(const UObject Object, FString Message) {}
/* Function: AssertSame 
  */
void AssertSame(const UObject Expected, const UObject Actual, FString Message) {}
/* Function: AssertFalse 
  */
void AssertFalse(bool bExpression, FString Message) {}
/* Function: Fail 
 Client functions */
void Fail(FString Message) {}
// Group: Functions

/* Function: ServerAssertNotNull 
  */
void ServerAssertNotNull(const UObject Object, FString Message) {}
/* Function: ServerAssertNotSame 
  */
void ServerAssertNotSame(const UObject Expected, const UObject Actual, FString Message) {}
/* Function: ServerAssertFalse 
  */
void ServerAssertFalse(bool bExpression, FString Message) {}
/* Function: ServerAssertNull 
  */
void ServerAssertNull(const UObject Object, FString Message) {}
/* Function: ServerAssertSame 
  */
void ServerAssertSame(const UObject Expected, const UObject Actual, FString Message) {}
/* Function: ServerAssertTrue 
  */
void ServerAssertTrue(bool bExpression, FString Message) {}
/* Function: ServerFail 
  */
void ServerFail(FString Message) {}
/* Function: ServerLatentCommandClientChecked 
  */
void ServerLatentCommandClientChecked() {}
/* Function: ServerLatentCommandClientDone 
  */
void ServerLatentCommandClientDone() {}
/* Function: ServerLatentCommandClientReady 
  */
void ServerLatentCommandClientReady() {}
/* Function: ServerLatentCommandDescribeOnClient 
  */
void ServerLatentCommandDescribeOnClient(FString NewDescription) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALatentAutomationCommandClientExecutor ALatentAutomationCommandClientExecutor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALatentAutomationCommandClientExecutor::StaticClass() {}
}
