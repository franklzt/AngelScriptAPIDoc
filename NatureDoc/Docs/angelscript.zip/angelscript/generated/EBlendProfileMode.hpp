/* Class: EBlendProfileMode 
  */ 
 class EBlendProfileMode
{
public:
}
/* Enum: EBlendProfileMode 
 
    TimeFactor - Enum
    WeightFactor - Enum
    BlendMask - Enum
    EBlendProfileMode_MAX - Enum */ 
 enum EBlendProfileMode { 
TimeFactor,
WeightFactor,
BlendMask,
EBlendProfileMode_MAX, 
}