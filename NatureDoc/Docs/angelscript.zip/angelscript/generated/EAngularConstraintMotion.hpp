/* Class: EAngularConstraintMotion 
  */ 
 class EAngularConstraintMotion
{
public:
}
/* Enum: EAngularConstraintMotion 
 
    ACM_Free - Enum
    ACM_Limited - Enum
    ACM_Locked - Enum
    ACM_MAX - Enum */ 
 enum EAngularConstraintMotion { 
ACM_Free,
ACM_Limited,
ACM_Locked,
ACM_MAX, 
}