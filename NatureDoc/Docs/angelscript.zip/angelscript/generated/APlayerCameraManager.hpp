/* Class: APlayerCameraManager 
 A PlayerCameraManager is responsible for managing the camera for a particular
player. It defines the final view properties used by other systems (e.g. the renderer),
meaning you can think of it as your virtual eyeball in the world. It can compute the
final camera properties directly, or it can arbitrate/blend between other objects or
actors that influence the camera (e.g. blending from one CameraActor to another).

The PlayerCameraManagers primary external responsibility is to reliably respond to
various Get*() functions, such as GetCameraViewPoint. Most everything else is
implementation detail and overrideable by user projects.

By default, a PlayerCameraManager maintains a "view target", which is the primary actor
the camera is associated with. It can also apply various "post" effects to the final
view state, such as camera animations, shakes, post-process effects or special
effects such as dirt on the lens.

@see https://docs.unrealengine.com/latest/INT/Gameplay/Framework/Camera/ */ 
 class APlayerCameraManager : public AActor
{
public:
// Group: Camera

/* Variable: CameraLocation 
 Returns camera's current location. */
const FVector CameraLocation;
/* Variable: FOVAngle 
 Returns the camera's current full FOV angle, in degrees. */
const float32 FOVAngle;
/* Variable: CameraRotation 
 Returns camera's current rotation. */
const FRotator CameraRotation;
// Group: CameraModifier

/* Variable: DefaultModifiers 
 List of modifiers to create by default for this camera */
TArray<TSubclassOf<UCameraModifier>> DefaultModifiers;
// Group: Debug

/* Variable: FreeCamDistance 
 Distance to place free camera from view target (used in certain CameraStyles) */
float32 FreeCamDistance;
/* Variable: FreeCamOffset 
 Offset to Z free camera position (used in certain CameraStyles) */
FVector FreeCamOffset;
/* Variable: ViewTargetOffset 
 Offset to view target (used in certain CameraStyles) */
FVector ViewTargetOffset;
// Group: Game|Player

/* Variable: OwningPlayerController 
 Returns the PlayerController that owns this camera. */
const APlayerController OwningPlayerController;
// Group: PlayerCameraManager

/* Variable: ViewYawMin 
 Minimum view yaw, in degrees. */
float32 ViewYawMin;
/* Variable: DefaultOrthoWidth 
 The default desired width (in world units) of the orthographic view (ignored in Perspective mode) */
float32 DefaultOrthoWidth;
/* Variable: ViewPitchMin 
 Minimum view pitch, in degrees. */
float32 ViewPitchMin;
/* Variable: ViewPitchMax 
 Maximum view pitch, in degrees. */
float32 ViewPitchMax;
/* Variable: DefaultAspectRatio 
 Default aspect ratio. Most of the time the value from a camera component will be used instead. */
float32 DefaultAspectRatio;
/* Variable: ViewYawMax 
 Maximum view yaw, in degrees. */
float32 ViewYawMax;
/* Variable: TransformComponent 
 Dummy component we can use to attach things to the camera. */
USceneComponent TransformComponent;
/* Variable: ViewRollMax 
 Maximum view roll, in degrees. */
float32 ViewRollMax;
/* Variable: DefaultFOV 
 FOV to use by default. */
float32 DefaultFOV;
/* Variable: AutoPlaneShift 
 Manually adjusts the planes of this camera, maintaining the distance between them. Positive moves out to the farplane, negative towards the near plane */
float32 AutoPlaneShift;
/* Variable: ViewRollMin 
 Minimum view roll, in degrees. */
float32 ViewRollMin;
/* Variable: bUseCameraHeightAsViewTarget 
 If UpdateOrthoPlanes is enabled, this setting will use the cameras current height to compensate the distance to the general view (as a pseudo distance to view target when one isn't present) */
bool bUseCameraHeightAsViewTarget;
/* Variable: bIsOrthographic 
 True when this camera should use an orthographic perspective instead of FOV */
bool bIsOrthographic;
/* Variable: bAutoCalculateOrthoPlanes 
 True when this camera should automatically calculated the Near+Far planes */
bool bAutoCalculateOrthoPlanes;
/* Variable: bUpdateOrthoPlanes 
 Adjusts the near/far planes and the view origin of the current camera automatically to avoid clipping and light artefacting */
bool bUpdateOrthoPlanes;
/* Variable: bDefaultConstrainAspectRatio 
 True if black bars should be added if the destination view has a different aspect ratio (only used when a view target doesn't specify whether or not to constrain the aspect ratio; most of the time the value from a camera component is used instead) */
bool bDefaultConstrainAspectRatio;
/* Variable: bClientSimulatingViewTarget 
 True if clients are handling setting their own viewtarget and the server should not replicate it. */
bool bClientSimulatingViewTarget;
/* Variable: bUseClientSideCameraUpdates 
 True if server will use camera positions replicated from the client instead of calculating them locally. */
bool bUseClientSideCameraUpdates;
/* Variable: bGameCameraCutThisFrame 
 True if we did a camera cut this frame. Automatically reset to false every frame.
This flag affects various things in the renderer (such as whether to use the occlusion queries from last frame, and motion blur). */
const bool bGameCameraCutThisFrame;
// Group: Variables

/* Variable: OnAudioFadeChangeEvent 
 If bound, broadcast on fade start (with fade time) instead of manually altering audio device's primary volume directly */
FOnAudioFadeChangeSignature OnAudioFadeChangeEvent;
// Group: Camera

/* Function: GetFOVAngle 
 Returns the camera's current full FOV angle, in degrees. */
float32 GetFOVAngle() const {}
/* Function: ClearCameraLensEffects 
 Removes all camera lens effects. */
void ClearCameraLensEffects() {}
/* Function: GetCameraRotation 
 Returns camera's current rotation. */
FRotator GetCameraRotation() const {}
/* Function: GetCameraLocation 
 Returns camera's current location. */
FVector GetCameraLocation() const {}
/* Function: SetGameCameraCutThisFrame 
 Sets the bGameCameraCutThisFrame flag to true (indicating we did a camera cut this frame; useful for game code to call, e.g., when performing a teleport that should be seamless) */
void SetGameCameraCutThisFrame() {}
// Group: Camera Fades

/* Function: StartCameraFade 
 Does a camera fade to/from a solid color.  Animates automatically.

Parameters:
    FromAlpha - Alpha at which to begin the fade. Range [0..1], where 0 is fully transparent and 1 is fully opaque solid color.
    ToAlpha - Alpha at which to finish the fade.
    Duration - How long the fade should take, in seconds.
    Color - Color to fade to/from.
    bShouldFadeAudio - True to fade audio volume along with the alpha of the solid color.
    bHoldWhenFinished - True for fade to hold at the ToAlpha until explicitly stopped (e.g. with StopCameraFade) */
void StartCameraFade(float32 FromAlpha, float32 ToAlpha, float32 Duration, FLinearColor Color, bool bShouldFadeAudio = false, bool bHoldWhenFinished = false) {}
/* Function: SetManualCameraFade 
 Turns on camera fading at the given opacity. Does not auto-animate, allowing user to animate themselves.
Call StopCameraFade to turn fading back off. */
void SetManualCameraFade(float32 InFadeAmount, FLinearColor Color, bool bInFadeAudio) {}
/* Function: StopCameraFade 
 Stops camera fading. */
void StopCameraFade() {}
// Group: Camera Shakes

/* Function: StopAllInstancesOfCameraShake 
 Stops playing all shakes of the given class. */
void StopAllInstancesOfCameraShake(TSubclassOf<UCameraShakeBase> Shake, bool bImmediately = true) {}
/* Function: StartCameraShake 
 Plays a camera shake on this camera.

Parameters:
    Scale - Scalar defining how "intense" to play the shake. 1.0 is normal (as authored).
    PlaySpace - Which coordinate system to play the shake in (affects oscillations and camera anims)
    UserPlaySpaceRot - Coordinate system to play shake when PlaySpace == CAPS_UserDefined. */
UCameraShakeBase StartCameraShake(TSubclassOf<UCameraShakeBase> ShakeClass, float32 Scale = 1.000000, ECameraShakePlaySpace PlaySpace = ECameraShakePlaySpace :: CameraLocal, FRotator UserPlaySpaceRot = FRotator ( )) {}
/* Function: StopAllInstancesOfCameraShakeFromSource 
 Stops playing all shakes of the given class originating from the given source. */
void StopAllInstancesOfCameraShakeFromSource(TSubclassOf<UCameraShakeBase> Shake, UCameraShakeSourceComponent SourceComponent, bool bImmediately = true) {}
/* Function: StopAllCameraShakesFromSource 
 Stops playing all shakes originating from the given source. */
void StopAllCameraShakesFromSource(UCameraShakeSourceComponent SourceComponent, bool bImmediately = true) {}
/* Function: StopCameraShake 
 Immediately stops the given shake instance and invalidates it. */
void StopCameraShake(UCameraShakeBase ShakeInstance, bool bImmediately = true) {}
/* Function: StopAllCameraShakes 
 Stops all active camera shakes on this camera. */
void StopAllCameraShakes(bool bImmediately = true) {}
/* Function: StartCameraShakeFromSource 
 Plays a camera shake on this camera.

Parameters:
    SourceComponent - The source from which the camera shake originates.
    Scale - Applies an additional constant scale on top of the dynamic scale computed with the distance to the source
    PlaySpace - Which coordinate system to play the shake in (affects oscillations and camera anims)
    UserPlaySpaceRot - Coordinate system to play shake when PlaySpace == CAPS_UserDefined. */
UCameraShakeBase StartCameraShakeFromSource(TSubclassOf<UCameraShakeBase> ShakeClass, UCameraShakeSourceComponent SourceComponent, float32 Scale = 1.000000, ECameraShakePlaySpace PlaySpace = ECameraShakePlaySpace :: CameraLocal, FRotator UserPlaySpaceRot = FRotator ( )) {}
// Group: Game|Player

/* Function: GetOwningPlayerController 
 Returns the PlayerController that owns this camera. */
APlayerController GetOwningPlayerController() const {}
/* Function: RemoveCameraModifier 
 Removes the given camera modifier from this camera (if it's on the camera in the first place) and discards it.

Returns:
    True if successfully removed, false otherwise. */
bool RemoveCameraModifier(UCameraModifier ModifierToRemove) {}
/* Function: FindCameraModifierByClass 
 Returns camera modifier for this camera of the given class, if it exists.
Exact class match only. If there are multiple modifiers of the same class, the first one is returned. */
UCameraModifier FindCameraModifierByClass(TSubclassOf<UCameraModifier> ModifierClass) {}
/* Function: AddNewCameraModifier 
 Creates and initializes a new camera modifier of the specified class.

Parameters:
    ModifierClass - The class of camera modifier to create.

Returns:
    Returns the newly created camera modifier. */
UCameraModifier AddNewCameraModifier(TSubclassOf<UCameraModifier> ModifierClass) {}
// Group: Photography

/* Function: PhotographyCameraModify 
 Implementable blueprint hook to allow a PlayerCameraManager subclass to
constrain or otherwise modify the camera during free-camera photography.
For example, a blueprint may wish to limit the distance from the camera's
original point, or forbid the camera from passing through walls.
NewCameraLocation contains the proposed new camera location.
PreviousCameraLocation contains the camera location in the previous frame.
OriginalCameraLocation contains the camera location before the game was put
into photography mode.
Return ResultCameraLocation as modified according to your constraints. */
void PhotographyCameraModify(const FVector NewCameraLocation, const FVector PreviousCameraLocation, const FVector OriginalCameraLocation, FVector& ResultCameraLocation) {}
/* Function: OnPhotographyMultiPartCaptureEnd 
 Event triggered upon the end of a multi-part photograph capture, when manual
free-roaming photographic camera control is about to be returned to the user.
Here you may re-enable whatever was turned off within
OnPhotographyMultiPartCaptureStart. */
void OnPhotographyMultiPartCaptureEnd() {}
/* Function: OnPhotographySessionStart 
 Event triggered upon entering Photography mode (before pausing, if
r.Photography.AutoPause is 1). */
void OnPhotographySessionStart() {}
/* Function: OnPhotographySessionEnd 
 Event triggered upon leaving Photography mode (after unpausing, if
r.Photography.AutoPause is 1). */
void OnPhotographySessionEnd() {}
/* Function: OnPhotographyMultiPartCaptureStart 
 Event triggered upon the start of a multi-part photograph capture (i.e. a
stereoscopic or 360-degree shot).  This is an ideal time to turn off
rendering effects that tile badly (UI, subtitles, vignette, very aggressive
bloom, etc; most of these are automatically disabled when
r.Photography.AutoPostprocess is 1). */
void OnPhotographyMultiPartCaptureStart() {}
// Group: Functions

/* Function: BlueprintUpdateCamera 
 Blueprint hook to allow blueprints to override existing camera behavior or implement custom cameras.
If this function returns true, we will use the given returned values and skip further calculations to determine
final camera POV. */
bool BlueprintUpdateCamera(AActor CameraTarget, FVector& NewCameraLocation, FRotator& NewCameraRotation, float32& NewCameraFOV) {}
/* Function: GetbIsOrthographic 
 True when this camera should use an orthographic perspective instead of FOV */
bool GetbIsOrthographic() const {}
/* Function: SetbIsOrthographic 
 True when this camera should use an orthographic perspective instead of FOV */
void SetbIsOrthographic(bool Value) {}
/* Function: GetbAutoCalculateOrthoPlanes 
 True when this camera should automatically calculated the Near+Far planes */
bool GetbAutoCalculateOrthoPlanes() const {}
/* Function: SetbAutoCalculateOrthoPlanes 
 True when this camera should automatically calculated the Near+Far planes */
void SetbAutoCalculateOrthoPlanes(bool Value) {}
/* Function: GetbUpdateOrthoPlanes 
 Adjusts the near/far planes and the view origin of the current camera automatically to avoid clipping and light artefacting */
bool GetbUpdateOrthoPlanes() const {}
/* Function: SetbUpdateOrthoPlanes 
 Adjusts the near/far planes and the view origin of the current camera automatically to avoid clipping and light artefacting */
void SetbUpdateOrthoPlanes(bool Value) {}
/* Function: GetbUseCameraHeightAsViewTarget 
 If UpdateOrthoPlanes is enabled, this setting will use the cameras current height to compensate the distance to the general view (as a pseudo distance to view target when one isn't present) */
bool GetbUseCameraHeightAsViewTarget() const {}
/* Function: SetbUseCameraHeightAsViewTarget 
 If UpdateOrthoPlanes is enabled, this setting will use the cameras current height to compensate the distance to the general view (as a pseudo distance to view target when one isn't present) */
void SetbUseCameraHeightAsViewTarget(bool Value) {}
/* Function: GetbDefaultConstrainAspectRatio 
 True if black bars should be added if the destination view has a different aspect ratio (only used when a view target doesn't specify whether or not to constrain the aspect ratio; most of the time the value from a camera component is used instead) */
bool GetbDefaultConstrainAspectRatio() const {}
/* Function: SetbDefaultConstrainAspectRatio 
 True if black bars should be added if the destination view has a different aspect ratio (only used when a view target doesn't specify whether or not to constrain the aspect ratio; most of the time the value from a camera component is used instead) */
void SetbDefaultConstrainAspectRatio(bool Value) {}
/* Function: GetbClientSimulatingViewTarget 
 True if clients are handling setting their own viewtarget and the server should not replicate it. */
bool GetbClientSimulatingViewTarget() const {}
/* Function: SetbClientSimulatingViewTarget 
 True if clients are handling setting their own viewtarget and the server should not replicate it. */
void SetbClientSimulatingViewTarget(bool Value) {}
/* Function: GetbUseClientSideCameraUpdates 
 True if server will use camera positions replicated from the client instead of calculating them locally. */
bool GetbUseClientSideCameraUpdates() const {}
/* Function: SetbUseClientSideCameraUpdates 
 True if server will use camera positions replicated from the client instead of calculating them locally. */
void SetbUseClientSideCameraUpdates(bool Value) {}
/* Function: GetbGameCameraCutThisFrame 
 True if we did a camera cut this frame. Automatically reset to false every frame.
This flag affects various things in the renderer (such as whether to use the occlusion queries from last frame, and motion blur). */
bool GetbGameCameraCutThisFrame() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static APlayerCameraManager APlayerCameraManager::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APlayerCameraManager::StaticClass() {}
}
