/* Class: EBakingKeySettings 
  */ 
 class EBakingKeySettings
{
public:
}
/* Enum: EBakingKeySettings 
 
    KeysOnly - Enum
    AllFrames - Enum
    EBakingKeySettings_MAX - Enum */ 
 enum EBakingKeySettings { 
KeysOnly,
AllFrames,
EBakingKeySettings_MAX, 
}