/* Class: ASpectatorBeaconHost 
 A beacon host used for taking reservations for an existing game session */ 
 class ASpectatorBeaconHost : public AOnlineBeaconHostObject
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ASpectatorBeaconHost ASpectatorBeaconHost::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASpectatorBeaconHost::StaticClass() {}
}
