/* Class: AVolumetricCloud 
 A placeable actor that represents a participating media material around a planet, e.g. clouds.
@see TODO address to the documentation. */ 
 class AVolumetricCloud : public AInfo
{
public:
// Group: Atmosphere

/* Variable: VolumetricCloudComponent 
  */
UVolumetricCloudComponent VolumetricCloudComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AVolumetricCloud AVolumetricCloud::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVolumetricCloud::StaticClass() {}
}
