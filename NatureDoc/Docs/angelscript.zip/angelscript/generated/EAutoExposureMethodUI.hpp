/* Class: EAutoExposureMethodUI 
  */ 
 class EAutoExposureMethodUI
{
public:
}
/* Enum: EAutoExposureMethodUI 
 
    AEM_Histogram - Enum
    AEM_Basic - Enum
    AEM_Manual - Enum
    AEM_MAX - Enum */ 
 enum EAutoExposureMethodUI { 
AEM_Histogram,
AEM_Basic,
AEM_Manual,
AEM_MAX, 
}