/* Class: EAsyncTraceType 
  */ 
 class EAsyncTraceType
{
public:
}
/* Enum: EAsyncTraceType 
 
    Test - Enum
    Single - Enum
    Multi - Enum */ 
 enum EAsyncTraceType { 
Test,
Single,
Multi, 
}