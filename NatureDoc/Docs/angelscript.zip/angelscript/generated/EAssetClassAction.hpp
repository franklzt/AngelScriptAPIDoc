/* Class: EAssetClassAction 
  */ 
 class EAssetClassAction
{
public:
}
/* Enum: EAssetClassAction 
 
    CreateAsset - Enum
    ViewAsset - Enum
    ImportAsset - Enum
    ExportAsset - Enum
    AllAssetActions - Enum
    EAssetClassAction_MAX - Enum */ 
 enum EAssetClassAction { 
CreateAsset,
ViewAsset,
ImportAsset,
ExportAsset,
AllAssetActions,
EAssetClassAction_MAX, 
}