/* Class: EAuditionPageMode 
  */ 
 class EAuditionPageMode
{
public:
}
/* Enum: EAuditionPageMode 
 
    Focused - Enum
    User - Enum
    EAuditionPageMode_MAX - Enum */ 
 enum EAuditionPageMode { 
Focused,
User,
EAuditionPageMode_MAX, 
}