/* Class: EAssetRegistrySortOrder 
  */ 
 class EAssetRegistrySortOrder
{
public:
}
/* Enum: EAssetRegistrySortOrder 
 
    Ascending - Enum
    Descending - Enum
    EAssetRegistrySortOrder_MAX - Enum */ 
 enum EAssetRegistrySortOrder { 
Ascending,
Descending,
EAssetRegistrySortOrder_MAX, 
}