/* Class: EBlueprintComponentDataCookingMethod 
  */ 
 class EBlueprintComponentDataCookingMethod
{
public:
}
/* Enum: EBlueprintComponentDataCookingMethod 
 
    Disabled - Enum
    AllBlueprints - Enum
    EnabledBlueprintsOnly - Enum
    EBlueprintComponentDataCookingMethod_MAX - Enum */ 
 enum EBlueprintComponentDataCookingMethod { 
Disabled,
AllBlueprints,
EnabledBlueprintsOnly,
EBlueprintComponentDataCookingMethod_MAX, 
}