/* Class: ALocalFogVolume 
 Actor used to position a local fog volume in the scene.
@see https://docs.unrealengine.com/??? */ 
 class ALocalFogVolume : public AInfo
{
public:
// Group: Fog

/* Variable: LocalFogVolumeVolume 
 Object used to visualize the local fog volume */
ULocalFogVolumeComponent LocalFogVolumeVolume;
// Group: Static Functions

/* Function: Spawn 
  */
static ALocalFogVolume ALocalFogVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALocalFogVolume::StaticClass() {}
}
