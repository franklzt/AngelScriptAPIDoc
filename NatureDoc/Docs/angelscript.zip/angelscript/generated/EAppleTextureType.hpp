/* Class: EAppleTextureType 
  */ 
 class EAppleTextureType
{
public:
}
/* Enum: EAppleTextureType 
 
    Unknown - Enum
    Image - Enum
    PixelBuffer - Enum
    Surface - Enum
    MetalTexture - Enum
    EAppleTextureType_MAX - Enum */ 
 enum EAppleTextureType { 
Unknown,
Image,
PixelBuffer,
Surface,
MetalTexture,
EAppleTextureType_MAX, 
}