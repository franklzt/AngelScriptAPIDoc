/* Class: ALevelSequenceActor 
 Actor responsible for controlling a specific level sequence in the world. */ 
 class ALevelSequenceActor : public AActor
{
public:
// Group: Cameras

/* Variable: CameraSettings 
  */
FLevelSequenceCameraSettings CameraSettings;
// Group: General

/* Variable: LevelSequenceAsset 
  */
ULevelSequence LevelSequenceAsset;
/* Variable: DefaultInstanceData 
 Instance data that can be used to dynamically control sequence evaluation at runtime */
UObject DefaultInstanceData;
/* Variable: BurnInOptions 
  */
ULevelSequenceBurnInOptions BurnInOptions;
/* Variable: BindingOverrides 
 Mapping of actors to override the sequence bindings with */
UMovieSceneBindingOverrides BindingOverrides;
/* Variable: bOverrideInstanceData 
 Enable specification of dynamic instance data to be supplied to the sequence during playback */
bool bOverrideInstanceData;
// Group: Playback

/* Variable: SequencePlayer 
  */
ULevelSequencePlayer SequencePlayer;
/* Variable: PlaybackSettings 
  */
FMovieSceneSequencePlaybackSettings PlaybackSettings;
// Group: Replication

/* Variable: bReplicatePlayback 
 If true, playback of this level sequence on the server will be synchronized across other clients */
bool bReplicatePlayback;
// Group: Sequencer|Player

/* Variable: Sequence 
 Get the level sequence being played by this actor. */
ULevelSequence Sequence;
// Group: Sequencer|Player

/* Function: HideBurnin 
 Hide burnin */
void HideBurnin() {}
/* Function: ShowBurnin 
 Show burnin */
void ShowBurnin() {}
/* Function: GetSequence 
 Get the level sequence being played by this actor.

Returns:
    Level sequence, or nullptr if not assigned or if it cannot be loaded. */
ULevelSequence GetSequence() const {}
/* Function: SetSequence 
 Set the level sequence being played by this actor.

Parameters:
    InSequence - The sequence object to set. */
void SetSequence(ULevelSequence InSequence) {}
// Group: Sequencer|Player|Bindings

/* Function: FindNamedBindings 
 Retrieve all the bindings that have been tagged with the specified name

Parameters:
    Tag - The unique tag name to lookup bindings with. Object Bindings can be tagged within the sequence UI by RMB -> Tags... on the object binding in the tree.

Returns:
    An array containing all the bindings that are tagged with this name, potentially empty. */
const TArray<FMovieSceneObjectBindingID>& FindNamedBindings(FName Tag) const {}
/* Function: FindNamedBinding 
 Retrieve the first object binding that has been tagged with the specified name */
FMovieSceneObjectBindingID FindNamedBinding(FName Tag) const {}
/* Function: RemoveBinding 
 Removes the specified actor from the specified binding's actor array */
void RemoveBinding(FMovieSceneObjectBindingID Binding, AActor Actor) {}
/* Function: AddBindingByTag 
 Binds an actor to all the bindings tagged with the specified name in this sequence. Does not remove any exising bindings that have been set up through this API. Object Bindings can be tagged within the sequence UI by RMB -> Tags... on the object binding in the tree.

Parameters:
    BindingTag - The unique tag name to lookup bindings with
    Actor - The actor to assign to all the tagged bindings
    bAllowBindingsFromAsset - If false the new bindings being supplied here will replace the bindings set in the level sequence asset, meaning the original object animated by Sequencer will no longer be animated. Bindings set to spawnables will not spawn if false. If true, new bindings will be in addition to ones set set in Sequencer UI. This function will not modify the original asset. */
void AddBindingByTag(FName BindingTag, AActor Actor, bool bAllowBindingsFromAsset = false) {}
/* Function: RemoveBindingByTag 
 Removes the specified actor from the specified binding's actor array */
void RemoveBindingByTag(FName Tag, AActor Actor) {}
/* Function: ResetBinding 
 Resets the specified binding back to the defaults defined by the Level Sequence asset */
void ResetBinding(FMovieSceneObjectBindingID Binding) {}
/* Function: ResetBindings 
 Resets all overridden bindings back to the defaults defined by the Level Sequence asset */
void ResetBindings() {}
/* Function: AddBinding 
 Adds the specified actor to the overridden bindings for the specified binding ID, optionally still allowing the bindings defined in the Level Sequence asset

Parameters:
    Binding - Binding to modify
    Actor - Actor to bind
    bAllowBindingsFromAsset - If false the new bindings being supplied here will replace the bindings set in the level sequence asset, meaning the original object animated by Sequencer will no longer be animated. Bindings set to spawnables will not spawn if false. If true, new bindings will be in addition to ones set set in Sequencer UI. This function will not modify the original asset. */
void AddBinding(FMovieSceneObjectBindingID Binding, AActor Actor, bool bAllowBindingsFromAsset = false) {}
/* Function: SetBindingByTag 
 Assigns an set of actors to all the bindings tagged with the specified name in this sequence. Object Bindings can be tagged within the sequence UI by RMB -> Tags... on the object binding in the tree.

Parameters:
    BindingTag - The unique tag name to lookup bindings with
    Actors - The actors to assign to all the tagged bindings
    bAllowBindingsFromAsset - If false the new bindings being supplied here will replace the bindings set in the level sequence asset, meaning the original object animated by Sequencer will no longer be animated. Bindings set to spawnables will not spawn if false. If true, new bindings will be in addition to ones set set in Sequencer UI. This function will not modify the original asset. */
void SetBindingByTag(FName BindingTag, TArray<AActor> Actors, bool bAllowBindingsFromAsset = false) {}
/* Function: SetBinding 
 Overrides the specified binding with the specified actors, optionally still allowing the bindings defined in the Level Sequence asset

Parameters:
    Binding - Binding to modify
    Actors - Actors to bind
    bAllowBindingsFromAsset - If false the new bindings being supplied here will replace the bindings set in the level sequence asset, meaning the original object animated by Sequencer will no longer be animated. Bindings set to spawnables will not spawn if false. If true, new bindings will be in addition to ones set set in Sequencer UI. This function will not modify the original asset. */
void SetBinding(FMovieSceneObjectBindingID Binding, TArray<AActor> Actors, bool bAllowBindingsFromAsset = false) {}
// Group: Functions

/* Function: GetbOverrideInstanceData 
 Enable specification of dynamic instance data to be supplied to the sequence during playback */
bool GetbOverrideInstanceData() const {}
/* Function: GetSequencePlayer 
 Access this actor's sequence player, or None if it is not yet initialized */
ULevelSequencePlayer GetSequencePlayer() const {}
/* Function: SetbReplicatePlayback 
 If true, playback of this level sequence on the server will be synchronized across other clients */
void SetbReplicatePlayback(bool ReplicatePlayback) {}
/* Function: SetSequencePlayer 
  */
void SetSequencePlayer(ULevelSequencePlayer Value) {}
/* Function: SetReplicatePlayback 
 Set whether or not to replicate playback for this actor */
void SetReplicatePlayback(bool ReplicatePlayback) {}
/* Function: SetbOverrideInstanceData 
 Enable specification of dynamic instance data to be supplied to the sequence during playback */
void SetbOverrideInstanceData(bool Value) {}
/* Function: GetbReplicatePlayback 
 If true, playback of this level sequence on the server will be synchronized across other clients */
bool GetbReplicatePlayback() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALevelSequenceActor ALevelSequenceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALevelSequenceActor::StaticClass() {}
}
