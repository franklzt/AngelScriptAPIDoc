/* Class: AMeshMergeCullingVolume 
 A volume that can be added a level in order to remove triangles from source meshes before generating HLOD or merged meshes */ 
 class AMeshMergeCullingVolume : public AVolume
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AMeshMergeCullingVolume AMeshMergeCullingVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AMeshMergeCullingVolume::StaticClass() {}
}
