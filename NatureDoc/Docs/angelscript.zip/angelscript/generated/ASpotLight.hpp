/* Class: ASpotLight 
  */ 
 class ASpotLight : public ALight
{
public:
// Group: Light

/* Variable: SpotLightComponent 
  */
USpotLightComponent SpotLightComponent;
// Group: Rendering|Lighting

/* Function: SetOuterConeAngle 
  */
void SetOuterConeAngle(float32 NewOuterConeAngle) {}
/* Function: SetInnerConeAngle 
 BEGIN DEPRECATED (use component functions now in level script) */
void SetInnerConeAngle(float32 NewInnerConeAngle) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ASpotLight ASpotLight::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASpotLight::StaticClass() {}
}
