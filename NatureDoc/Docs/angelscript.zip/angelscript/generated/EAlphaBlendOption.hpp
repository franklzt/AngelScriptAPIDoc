/* Class: EAlphaBlendOption 
  */ 
 class EAlphaBlendOption
{
public:
}
/* Enum: EAlphaBlendOption 
 
    Linear - Enum
    Cubic - Enum
    HermiteCubic - Enum
    Sinusoidal - Enum
    QuadraticInOut - Enum
    CubicInOut - Enum
    QuarticInOut - Enum
    QuinticInOut - Enum
    CircularIn - Enum
    CircularOut - Enum
    CircularInOut - Enum
    ExpIn - Enum
    ExpOut - Enum
    ExpInOut - Enum
    Custom - Enum
    EAlphaBlendOption_MAX - Enum */ 
 enum EAlphaBlendOption { 
Linear,
Cubic,
HermiteCubic,
Sinusoidal,
QuadraticInOut,
CubicInOut,
QuarticInOut,
QuinticInOut,
CircularIn,
CircularOut,
CircularInOut,
ExpIn,
ExpOut,
ExpInOut,
Custom,
EAlphaBlendOption_MAX, 
}