/* Class: AVolume 
 An editable 3D volume placed in a level. Different types of volumes perform different functions
@see https://docs.unrealengine.com/latest/INT/Engine/Actors/Volumes */ 
 class AVolume : public ABrush
{
public:
// Group: Variables

/* Variable: Bounds 
  */
const FBoxSphereBounds Bounds;
// Group: Functions

/* Function: EncompassesPoint 
  */
bool EncompassesPoint(FVector Point, float32 SphereRadius = 0.f) const {}
/* Function: EncompassesPoint 
  */
bool EncompassesPoint(FVector Point, float32 SphereRadius, float32& OutDistanceToPoint) const {}
/* Function: SetBrushColor 
  */
void SetBrushColor(FLinearColor InBrushColor) {}
/* Function: GetBounds 
  */
FBoxSphereBounds GetBounds() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AVolume AVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVolume::StaticClass() {}
}
