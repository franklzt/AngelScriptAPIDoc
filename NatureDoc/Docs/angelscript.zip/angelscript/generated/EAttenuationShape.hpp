/* Class: EAttenuationShape 
  */ 
 class EAttenuationShape
{
public:
}
/* Enum: EAttenuationShape 
 
    Sphere - Enum
    Capsule - Enum
    Box - Enum
    Cone - Enum
    EAttenuationShape_MAX - Enum */ 
 enum EAttenuationShape { 
Sphere,
Capsule,
Box,
Cone,
EAttenuationShape_MAX, 
}