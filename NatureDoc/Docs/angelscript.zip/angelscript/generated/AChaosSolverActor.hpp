/* Class: AChaosSolverActor 
  */ 
 class AChaosSolverActor : public AActor
{
public:
// Group: Chaos

/* Variable: Properties 
  */
FChaosSolverConfiguration Properties;
// Group: ChaosPhysics|Debug

/* Variable: ChaosDebugSubstepControl 
 * Control to pause/step/substep the solver to the next synchronization point. */
FChaosDebugSubstepControl ChaosDebugSubstepControl;
// Group: Physics

/* Variable: SimulationAsset 
 Solver dataflow asset used to advance in time */
FDataflowSimulationAsset SimulationAsset;
// Group: Settings

/* Variable: FloorHeight 
  */
float32 FloorHeight;
/* Variable: bHasFloor 
 End deprecated properties */
bool bHasFloor;
// Group: ChaosPhysics

/* Function: SetSolverActive 
 Controls whether the solver is able to simulate particles it controls */
void SetSolverActive(bool bActive) {}
/* Function: SetAsCurrentWorldSolver 
 Makes this solver the current world solver. Dynamically spawned objects will have their physics state created in this solver. */
void SetAsCurrentWorldSolver() {}
// Group: Static Functions

/* Function: Spawn 
  */
static AChaosSolverActor AChaosSolverActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AChaosSolverActor::StaticClass() {}
}
