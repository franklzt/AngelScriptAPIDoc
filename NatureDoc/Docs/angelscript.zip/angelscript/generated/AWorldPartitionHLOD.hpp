/* Class: AWorldPartitionHLOD 
  */ 
 class AWorldPartitionHLOD : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AWorldPartitionHLOD AWorldPartitionHLOD::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AWorldPartitionHLOD::StaticClass() {}
}
