/* Class: ASkeletalMeshActor 
 SkeletalMeshActor is an instance of a USkeletalMesh in the world.
Skeletal meshes are deformable meshes that can be animated and change their geometry at run-time.
Skeletal meshes dragged into the level from the Content Browser are automatically converted to StaticMeshActors.

@see https://docs.unrealengine.com/latest/INT/Engine/Content/Types/SkeletalMeshes/
@see USkeletalMesh */ 
 class ASkeletalMeshActor : public AActor
{
public:
// Group: Animation

/* Variable: bShouldDoAnimNotifies 
 Whether or not this actor should respond to anim notifies - CURRENTLY ONLY AFFECTS PlayParticleEffect NOTIFIES* */
bool bShouldDoAnimNotifies;
// Group: SkeletalMeshActor

/* Variable: SkeletalMeshComponent 
  */
USkeletalMeshComponent SkeletalMeshComponent;
// Group: Functions

/* Function: SetbShouldDoAnimNotifies 
 Whether or not this actor should respond to anim notifies - CURRENTLY ONLY AFFECTS PlayParticleEffect NOTIFIES* */
void SetbShouldDoAnimNotifies(bool Value) {}
/* Function: GetbShouldDoAnimNotifies 
 Whether or not this actor should respond to anim notifies - CURRENTLY ONLY AFFECTS PlayParticleEffect NOTIFIES* */
bool GetbShouldDoAnimNotifies() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ASkeletalMeshActor ASkeletalMeshActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASkeletalMeshActor::StaticClass() {}
}
