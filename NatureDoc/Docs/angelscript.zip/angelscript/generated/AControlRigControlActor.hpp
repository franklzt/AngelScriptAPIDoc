/* Class: AControlRigControlActor 
  */ 
 class AControlRigControlActor : public AActor
{
public:
// Group: Control Actor

/* Variable: ControlRigClass 
  */
TSubclassOf<UControlRig> ControlRigClass;
/* Variable: bRefreshOnTick 
  */
bool bRefreshOnTick;
/* Variable: bIsSelectable 
  */
bool bIsSelectable;
/* Variable: ActorToTrack 
  */
AActor ActorToTrack;
// Group: Materials

/* Variable: ColorParameter 
  */
FString ColorParameter;
/* Variable: bCastShadows 
  */
bool bCastShadows;
/* Variable: MaterialOverride 
  */
UMaterialInterface MaterialOverride;
// Group: Control Actor

/* Function: Refresh 
  */
void Refresh() {}
/* Function: ResetControlActor 
  */
void ResetControlActor() {}
/* Function: Clear 
  */
void Clear() {}
// Group: Static Functions

/* Function: Spawn 
  */
static AControlRigControlActor AControlRigControlActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AControlRigControlActor::StaticClass() {}
}
