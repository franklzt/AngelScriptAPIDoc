/* Class: ASpectatorBeaconClient 
 A beacon client used for making reservations with an existing game session */ 
 class ASpectatorBeaconClient : public AOnlineBeaconClient
{
public:
// Group: Functions

/* Function: ClientReservationResponse 
 Response from the host session after making a reservation request

Parameters:
    ReservationResponse - response from server */
void ClientReservationResponse(ESpectatorReservationResult ReservationResponse) {}
/* Function: ClientSendReservationFull 
 Response from the host session that the reservation is full */
void ClientSendReservationFull() {}
/* Function: ClientSendReservationUpdates 
 Response from the host session that the reservation count has changed

Parameters:
    NumRemainingReservations - number of slots remaining until a full session */
void ClientSendReservationUpdates(int NumRemainingReservations) {}
/* Function: ServerCancelReservationRequest 
 Tell the server to cancel a pending or existing reservation

Parameters:
    Spectator - id of the spectator for the reservation to cancel */
void ServerCancelReservationRequest(FUniqueNetIdRepl Spectator) {}
/* Function: ClientCancelReservationResponse 
 Response from the host session after making a cancellation request

Parameters:
    ReservationResponse - response from server */
void ClientCancelReservationResponse(ESpectatorReservationResult ReservationResponse) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ASpectatorBeaconClient ASpectatorBeaconClient::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASpectatorBeaconClient::StaticClass() {}
}
