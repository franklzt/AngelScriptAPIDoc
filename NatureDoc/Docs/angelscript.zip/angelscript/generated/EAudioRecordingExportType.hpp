/* Class: EAudioRecordingExportType 
  */ 
 class EAudioRecordingExportType
{
public:
}
/* Enum: EAudioRecordingExportType 
 
    SoundWave - Enum
    WavFile - Enum
    EAudioRecordingExportType_MAX - Enum */ 
 enum EAudioRecordingExportType { 
SoundWave,
WavFile,
EAudioRecordingExportType_MAX, 
}