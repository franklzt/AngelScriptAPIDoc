/* Class: AGameSession 
 Acts as a game-specific wrapper around the session interface. The game code makes calls to this when it needs to interact with the session interface.
A game session exists only the server, while running an online game. */ 
 class AGameSession : public AInfo
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AGameSession AGameSession::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameSession::StaticClass() {}
}
