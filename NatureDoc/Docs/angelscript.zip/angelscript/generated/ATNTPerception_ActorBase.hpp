/* Class: ATNTPerception_ActorBase 
  */ 
 class ATNTPerception_ActorBase : public AActor
{
public:
// Group: Perception

/* Function: OnPerception 
  */
void OnPerception(bool& Find, FVector& Location, FVector& LastLocation, FVector& FirstImpactNormal) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ATNTPerception_ActorBase ATNTPerception_ActorBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATNTPerception_ActorBase::StaticClass() {}
}
