/* Class: EAudioSpectrumType 
  */ 
 class EAudioSpectrumType
{
public:
}
/* Enum: EAudioSpectrumType 
 
    MagnitudeSpectrum - Enum
    PowerSpectrum - Enum
    Decibel - Enum
    EAudioSpectrumType_MAX - Enum */ 
 enum EAudioSpectrumType { 
MagnitudeSpectrum,
PowerSpectrum,
Decibel,
EAudioSpectrumType_MAX, 
}