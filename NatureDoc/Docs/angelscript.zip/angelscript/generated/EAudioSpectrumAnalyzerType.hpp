/* Class: EAudioSpectrumAnalyzerType 
  */ 
 class EAudioSpectrumAnalyzerType
{
public:
}
/* Enum: EAudioSpectrumAnalyzerType 
 
    FFT - Enum
    CQT - Enum
    EAudioSpectrumAnalyzerType_MAX - Enum */ 
 enum EAudioSpectrumAnalyzerType { 
FFT,
CQT,
EAudioSpectrumAnalyzerType_MAX, 
}