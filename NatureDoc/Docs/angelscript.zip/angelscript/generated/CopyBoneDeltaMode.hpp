/* Class: CopyBoneDeltaMode 
  */ 
 class CopyBoneDeltaMode
{
public:
}
/* Enum: CopyBoneDeltaMode 
 
    Accumulate - Enum
    Copy - Enum
    CopyBoneDeltaMode_MAX - Enum */ 
 enum CopyBoneDeltaMode { 
Accumulate,
Copy,
CopyBoneDeltaMode_MAX, 
}