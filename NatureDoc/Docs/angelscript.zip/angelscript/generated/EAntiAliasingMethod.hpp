/* Class: EAntiAliasingMethod 
  */ 
 class EAntiAliasingMethod
{
public:
}
/* Enum: EAntiAliasingMethod 
 
    AAM_None - Enum
    AAM_FXAA - Enum
    AAM_TemporalAA - Enum
    AAM_MSAA - Enum
    AAM_TSR - Enum
    AAM_MAX - Enum */ 
 enum EAntiAliasingMethod { 
AAM_None,
AAM_FXAA,
AAM_TemporalAA,
AAM_MSAA,
AAM_TSR,
AAM_MAX, 
}