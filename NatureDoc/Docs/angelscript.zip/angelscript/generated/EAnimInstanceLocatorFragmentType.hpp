/* Class: EAnimInstanceLocatorFragmentType 
  */ 
 class EAnimInstanceLocatorFragmentType
{
public:
}
/* Enum: EAnimInstanceLocatorFragmentType 
 
    AnimInstance - Enum
    PostProcessAnimInstance - Enum
    EAnimInstanceLocatorFragmentType_MAX - Enum */ 
 enum EAnimInstanceLocatorFragmentType { 
AnimInstance,
PostProcessAnimInstance,
EAnimInstanceLocatorFragmentType_MAX, 
}