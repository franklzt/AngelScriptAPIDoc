/* Class: AMaterialInstanceActor 
  */ 
 class AMaterialInstanceActor : public AActor
{
public:
// Group: MaterialInstanceActor

/* Variable: TargetActors 
 Pointer to actors that we want to control paramters of using Matinee. */
TArray<TObjectPtr<AActor>> TargetActors;
// Group: Static Functions

/* Function: Spawn 
  */
static AMaterialInstanceActor AMaterialInstanceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AMaterialInstanceActor::StaticClass() {}
}
