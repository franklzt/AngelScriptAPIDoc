/* Class: EBasicKeyOperation 
  */ 
 class EBasicKeyOperation
{
public:
}
/* Enum: EBasicKeyOperation 
 
    Set - Enum
    NotSet - Enum
    EBasicKeyOperation_MAX - Enum */ 
 enum EBasicKeyOperation { 
Set,
NotSet,
EBasicKeyOperation_MAX, 
}