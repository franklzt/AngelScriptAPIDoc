/* Class: ASequenceRecorderGroup 
  */ 
 class ASequenceRecorderGroup : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ASequenceRecorderGroup ASequenceRecorderGroup::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASequenceRecorderGroup::StaticClass() {}
}
