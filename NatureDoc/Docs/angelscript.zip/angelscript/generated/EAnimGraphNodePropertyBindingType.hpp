/* Class: EAnimGraphNodePropertyBindingType 
  */ 
 class EAnimGraphNodePropertyBindingType
{
public:
}
/* Enum: EAnimGraphNodePropertyBindingType 
 
    None - Enum
    Property - Enum
    Function - Enum
    EAnimGraphNodePropertyBindingType_MAX - Enum */ 
 enum EAnimGraphNodePropertyBindingType { 
None,
Property,
Function,
EAnimGraphNodePropertyBindingType_MAX, 
}