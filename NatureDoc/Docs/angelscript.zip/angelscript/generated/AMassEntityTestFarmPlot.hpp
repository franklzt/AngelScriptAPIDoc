/* Class: AMassEntityTestFarmPlot 
  */ 
 class AMassEntityTestFarmPlot : public AActor
{
public:
// Group: Farm

/* Variable: TestDataCropIndicies 
 Indices into VisualDataTable for crops */
TArray<uint16> TestDataCropIndicies;
/* Variable: GridCellHeight 
  */
float32 GridCellHeight;
/* Variable: HarvestIconScale 
  */
float32 HarvestIconScale;
/* Variable: VisualDataTable 
  */
TArray<FFarmVisualDataRow> VisualDataTable;
/* Variable: TestDataFlowerIndicies 
 Indices into VisualDataTable for flowers */
TArray<uint16> TestDataFlowerIndicies;
/* Variable: GridCellWidth 
  */
float32 GridCellWidth;
/* Variable: VisualNearCullDistance 
  */
uint VisualNearCullDistance;
/* Variable: VisualFarCullDistance 
  */
uint VisualFarCullDistance;
/* Variable: IconNearCullDistance 
  */
uint IconNearCullDistance;
/* Variable: IconFarCullDistance 
  */
uint IconFarCullDistance;
/* Variable: HarvestIconISMC 
  */
UHierarchicalInstancedStaticMeshComponent HarvestIconISMC;
// Group: Static Functions

/* Function: Spawn 
  */
static AMassEntityTestFarmPlot AMassEntityTestFarmPlot::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AMassEntityTestFarmPlot::StaticClass() {}
}
