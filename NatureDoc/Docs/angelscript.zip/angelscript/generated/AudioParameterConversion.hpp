/* Class: AudioParameterConversion 
  */ 
 class AudioParameterConversion
{
public:
// Group: Audio|Parameter

/* Function: IntegerToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::IntegerToAudioParameter(FName Name, int Integer) {}
/* Function: BooleanToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::BooleanToAudioParameter(FName Name, bool Bool) {}
/* Function: FloatArrayToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::FloatArrayToAudioParameter(FName Name, TArray<float32> Floats) {}
/* Function: FloatToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::FloatToAudioParameter(FName Name, float32 Float) {}
/* Function: IntegerArrayToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::IntegerArrayToAudioParameter(FName Name, TArray<int> Integers) {}
/* Function: BooleanArrayToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::BooleanArrayToAudioParameter(FName Name, TArray<bool> Bools) {}
/* Function: ObjectArrayToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::ObjectArrayToAudioParameter(FName Name, TArray<UObject> Objects) {}
/* Function: ObjectToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::ObjectToAudioParameter(FName Name, UObject Object) {}
/* Function: StringArrayToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::StringArrayToAudioParameter(FName Name, TArray<FString> Strings) {}
/* Function: StringToAudioParameter 
  */
static FAudioParameter AudioParameterConversion::StringToAudioParameter(FName Name, FString String) {}
}
