/* Class: EAudioMixerChannelType 
  */ 
 class EAudioMixerChannelType
{
public:
}
/* Enum: EAudioMixerChannelType 
 
    FrontLeft - Enum
    FrontRight - Enum
    FrontCenter - Enum
    LowFrequency - Enum
    BackLeft - Enum
    BackRight - Enum
    FrontLeftOfCenter - Enum
    FrontRightOfCenter - Enum
    BackCenter - Enum
    SideLeft - Enum
    SideRight - Enum
    TopCenter - Enum
    TopFrontLeft - Enum
    TopFrontCenter - Enum
    TopFrontRight - Enum
    TopBackLeft - Enum
    TopBackCenter - Enum
    TopBackRight - Enum
    Unknown - Enum
    ChannelTypeCount - Enum
    DefaultChannel - Enum
    EAudioMixerChannelType_MAX - Enum */ 
 enum EAudioMixerChannelType { 
FrontLeft,
FrontRight,
FrontCenter,
LowFrequency,
BackLeft,
BackRight,
FrontLeftOfCenter,
FrontRightOfCenter,
BackCenter,
SideLeft,
SideRight,
TopCenter,
TopFrontLeft,
TopFrontCenter,
TopFrontRight,
TopBackLeft,
TopBackCenter,
TopBackRight,
Unknown,
ChannelTypeCount,
DefaultChannel,
EAudioMixerChannelType_MAX, 
}