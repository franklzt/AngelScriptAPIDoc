/* Class: ADEPRECATED_WorldPartitionVolume 
  */ 
 class ADEPRECATED_WorldPartitionVolume : public AVolume
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ADEPRECATED_WorldPartitionVolume ADEPRECATED_WorldPartitionVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADEPRECATED_WorldPartitionVolume::StaticClass() {}
}
