/* Class: ATestTerminator 
 ATestTerminator

This actor will execute an Exit command in the world where it is spawned
when this object is destroyed.

Replication is configured so the actor is replicated on client worlds.

Destruction is handled by the integration test system. */ 
 class ATestTerminator : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ATestTerminator ATestTerminator::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATestTerminator::StaticClass() {}
}
