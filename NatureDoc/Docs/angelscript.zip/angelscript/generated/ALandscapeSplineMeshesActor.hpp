/* Class: ALandscapeSplineMeshesActor 
 This class is only intended to be used by UWorldPartitionLandscapeSplineMeshesBuilder which extracts and clones
landscape spline and control point static meshes into partitioned actors

This serves as an optimization as these actors will be streamed at runtime */ 
 class ALandscapeSplineMeshesActor : public APartitionActor
{
public:
// Group: PartitionSplineMeshActor

/* Variable: StaticMeshComponents 
  */
TArray<TObjectPtr<UStaticMeshComponent>> StaticMeshComponents;
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeSplineMeshesActor ALandscapeSplineMeshesActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeSplineMeshesActor::StaticClass() {}
}
