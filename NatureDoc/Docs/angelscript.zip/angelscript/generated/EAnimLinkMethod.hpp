/* Class: EAnimLinkMethod 
  */ 
 class EAnimLinkMethod
{
public:
}
/* Enum: EAnimLinkMethod 
 
    Absolute - Enum
    Relative - Enum
    Proportional - Enum
    EAnimLinkMethod_MAX - Enum */ 
 enum EAnimLinkMethod { 
Absolute,
Relative,
Proportional,
EAnimLinkMethod_MAX, 
}