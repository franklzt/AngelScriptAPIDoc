/* Class: EAnimGroupRole 
  */ 
 class EAnimGroupRole
{
public:
}
/* Enum: EAnimGroupRole 
 
    CanBeLeader - Enum
    AlwaysFollower - Enum
    AlwaysLeader - Enum
    TransitionLeader - Enum
    TransitionFollower - Enum
    ExclusiveAlwaysLeader - Enum
    EAnimGroupRole_MAX - Enum */ 
 enum EAnimGroupRole { 
CanBeLeader,
AlwaysFollower,
AlwaysLeader,
TransitionLeader,
TransitionFollower,
ExclusiveAlwaysLeader,
EAnimGroupRole_MAX, 
}