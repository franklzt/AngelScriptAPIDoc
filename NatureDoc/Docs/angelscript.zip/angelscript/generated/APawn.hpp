/* Class: APawn 
 Pawn is the base class of all actors that can be possessed by players or AI.
They are the physical representations of players and creatures in a level.

@see https://docs.unrealengine.com/latest/INT/Gameplay/Framework/Pawn/ */ 
 class APawn : public AActor
{
public:
// Group: Camera

/* Variable: BaseEyeHeight 
 Base eye height above collision center. */
float32 BaseEyeHeight;
// Group: Pawn

/* Variable: AutoPossessAI 
 Determines when the Pawn creates and is possessed by an AI Controller (on level start, when spawned, etc).
Only possible if AIControllerClassRef is set, and ignored if AutoPossessPlayer is enabled.
@see AutoPossessPlayer */
EAutoPossessAI AutoPossessAI;
/* Variable: AIControllerClass 
 Default class to use when pawn is controlled by AI. */
TSubclassOf<AController> AIControllerClass;
/* Variable: PlayerState 
 If Pawn is possessed by a player, points to its Player State.  Needed for network play as controllers are not replicated to clients. */
APlayerState PlayerState;
/* Variable: AutoPossessPlayer 
 Determines which PlayerController, if any, should automatically possess the pawn when the level starts or when the pawn is spawned.
@see AutoPossessAI */
EAutoReceiveInput AutoPossessPlayer;
/* Variable: LastHitBy 
 Controller of the last Actor that caused us damage. */
AController LastHitBy;
/* Variable: ReceiveControllerChangedDelegate 
 Event called after a pawn's controller has changed, on the server and owning client. This will happen at the same time as the delegate on GameInstance */
FPawnControllerChangedSignature ReceiveControllerChangedDelegate;
/* Variable: ReceiveRestartedDelegate 
 Event called after a pawn has been restarted, usually by a possession change. This is called on the server for all pawns and the owning client for player pawns */
FPawnRestartedSignature ReceiveRestartedDelegate;
/* Variable: BaseAimRotation 
 Return the aim rotation for the Pawn.
If we have a controller, by default we aim at the player's 'eyes' direction
that is by default the Pawn rotation for AI, and camera (crosshair) rotation for human players. */
const FRotator BaseAimRotation;
/* Variable: bCanAffectNavigationGeneration 
 If set to false (default) given pawn instance will never affect navigation generation (but components could).
Setting it to true will result in using regular AActor's navigation relevancy
calculation to check if this pawn instance should affect navigation generation.
@note Use SetCanAffectNavigationGeneration() to change this value at runtime.
@note Modifying this value at runtime will result in any navigation change only if runtime navigation generation is enabled.
@note Override UpdateNavigationRelevance() to propagate the flag to the desired components.
@see SetCanAffectNavigationGeneration(), UpdateNavigationRelevance() */
bool bCanAffectNavigationGeneration;
/* Variable: bUseControllerRotationRoll 
 If true, this Pawn's roll will be updated to match the Controller's ControlRotation roll, if controlled by a PlayerController. */
bool bUseControllerRotationRoll;
/* Variable: ControlRotation 
 Get the rotation of the Controller, often the 'view' rotation of this Pawn. */
const FRotator ControlRotation;
/* Variable: LocalViewingPlayerController 
 Returns local Player Controller viewing this pawn, whether it is controlling or spectating */
const APlayerController LocalViewingPlayerController;
/* Variable: MovementComponent 
 Return our PawnMovementComponent, if we have one. */
const UPawnMovementComponent MovementComponent;
/* Variable: NavAgentLocation 
 Basically retrieved pawn's location on navmesh */
const FVector NavAgentLocation;
/* Variable: bUseControllerRotationPitch 
 If true, this Pawn's pitch will be updated to match the Controller's ControlRotation pitch, if controlled by a PlayerController. */
bool bUseControllerRotationPitch;
/* Variable: PlatformUserId 
 Returns the Platform User ID of the PlayerController that is controlling this character.

Returns an invalid Platform User ID if this character is not controlled by a local player. */
const FPlatformUserId PlatformUserId;
/* Variable: bUseControllerRotationYaw 
 If true, this Pawn's yaw will be updated to match the Controller's ControlRotation yaw, if controlled by a PlayerController. */
bool bUseControllerRotationYaw;
// Group: Pawn|Input

/* Variable: PendingMovementInputVector 
 Return the pending input vector in world space. This is the most up-to-date value of the input vector, pending ConsumeMovementInputVector() which clears it,
Usually only a PawnMovementComponent will want to read this value, or the Pawn itself if it is responsible for movement. */
const FVector PendingMovementInputVector;
/* Variable: OverrideInputComponentClass 
 If set, then this InputComponent class will be used instead of the Input Settings' DefaultInputComponentClass */
TSubclassOf<UInputComponent> OverrideInputComponentClass;
/* Variable: LastMovementInputVector 
 Return the last input vector in world space that was processed by ConsumeMovementInputVector(), which is usually done by the Pawn or PawnMovementComponent.
Any user that needs to know about the input that last affected movement should use this function.
For example an animation update would want to use this, since by default the order of updates in a frame is:
PlayerController (device input) -> MovementComponent -> Pawn -> Mesh (animations) */
const FVector LastMovementInputVector;
// Group: Variables

/* Variable: Controller 
 Controller currently possessing this Actor */
const AController Controller;
// Group: AI

/* Function: PawnMakeNoise 
 Inform AIControllers that you've made a noise they might hear (they are sent a HearNoise message if they have bHearNoises==true)
The instigator of this sound is the pawn which is used to call MakeNoise.

Parameters:
    Loudness - is the relative loudness of this noise (range 0.0 to 1.0).  Directly affects the hearing range specified by the AI's HearingThreshold.
    NoiseLocation - Position of noise source.  If zero vector, use the actor's location.
    bUseNoiseMakerLocation - If true, use the location of the NoiseMaker rather than NoiseLocation.  If false, use NoiseLocation.
    NoiseMaker - Which actor is the source of the noise.  Not to be confused with the Noise Instigator, which is responsible for the noise (and is the pawn on which this function is called).  If not specified, the pawn instigating the noise will be used as the NoiseMaker */
void PawnMakeNoise(float32 Loudness, FVector NoiseLocation, bool bUseNoiseMakerLocation = true, AActor NoiseMaker = nullptr) {}
// Group: AI|Navigation

/* Function: SetCanAffectNavigationGeneration 
 Use SetCanAffectNavigationGeneration to change this value at runtime.
Note that calling this function at runtime will result in any navigation change only if runtime navigation generation is enabled. */
void SetCanAffectNavigationGeneration(bool bNewValue, bool bForceUpdate = false) {}
// Group: Pawn

/* Function: IsPawnControlled 
 Check if this actor is currently being controlled at all (the actor has a valid Controller, which will be false for remote clients) */
bool IsPawnControlled() const {}
/* Function: IsPlayerControlled 
 Returns true if controlled by a human player (possessed by a PlayerController).        This returns true for players controlled by remote clients */
bool IsPlayerControlled() const {}
/* Function: SpawnDefaultController 
 Spawn default controller for this Pawn, and get possessed by it. */
void SpawnDefaultController() {}
/* Function: DetachFromControllerPendingDestroy 
 Call this function to detach safely pawn from its controller, knowing that we will be destroyed soon. */
void DetachFromControllerPendingDestroy() {}
/* Function: GetBaseAimRotation 
 Return the aim rotation for the Pawn.
If we have a controller, by default we aim at the player's 'eyes' direction
that is by default the Pawn rotation for AI, and camera (crosshair) rotation for human players. */
FRotator GetBaseAimRotation() const {}
/* Function: GetController 
 Returns controller for this actor. */
AController GetController() const {}
/* Function: GetControlRotation 
 Get the rotation of the Controller, often the 'view' rotation of this Pawn. */
FRotator GetControlRotation() const {}
/* Function: IsBotControlled 
 Returns true if controlled by a bot. */
bool IsBotControlled() const {}
/* Function: GetLocalViewingPlayerController 
 Returns local Player Controller viewing this pawn, whether it is controlling or spectating */
APlayerController GetLocalViewingPlayerController() const {}
/* Function: GetMovementComponent 
 Return our PawnMovementComponent, if we have one. */
UPawnMovementComponent GetMovementComponent() const {}
/* Function: GetNavAgentLocation 
 Basically retrieved pawn's location on navmesh */
FVector GetNavAgentLocation() const {}
/* Function: IsLocallyControlled 
 Returns true if controlled by a local (not network) Controller. */
bool IsLocallyControlled() const {}
/* Function: GetMovementBaseActor 
 Gets the owning actor of the Movement Base Component on which the pawn is standing. */
static AActor APawn::GetMovementBaseActor(const APawn Pawn) {}
/* Function: GetPlatformUserId 
 Returns the Platform User ID of the PlayerController that is controlling this character.

Returns an invalid Platform User ID if this character is not controlled by a local player. */
FPlatformUserId GetPlatformUserId() const {}
/* Function: IsControlled 
  */
bool IsControlled() const {}
/* Function: IsLocallyViewed 
 Is this pawn the ViewTarget of a local PlayerController?  Helpful for determining whether the pawn is
visible/critical for any VFX.  NOTE: Technically there may be some cases where locally controlled pawns return
false for this, such as if you are using a remote camera view of some sort.  But generally it will be true for
locally controlled pawns, and it will always be true for pawns that are being spectated in-game or in Replays. */
bool IsLocallyViewed() const {}
// Group: Pawn|Input

/* Function: ConsumeMovementInputVector 
 Returns the pending input vector and resets it to zero.
This should be used during a movement update (by the Pawn or PawnMovementComponent) to prevent accumulation of control input between frames.
Copies the pending input vector to the saved input vector (GetLastMovementInputVector()).

Returns:
    The pending input vector. */
FVector ConsumeMovementInputVector() {}
/* Function: IsMoveInputIgnored 
 Helper to see if move input is ignored. If our controller is a PlayerController, checks Controller->IsMoveInputIgnored(). */
bool IsMoveInputIgnored() const {}
/* Function: AddControllerPitchInput 
 Add input (affecting Pitch) to the Controller's ControlRotation, if it is a local PlayerController.
This value is multiplied by the PlayerController's InputPitchScale value.

Parameters:
    Val - Amount to add to Pitch. This value is multiplied by the PlayerController's InputPitchScale value. */
void AddControllerPitchInput(float32 Val) {}
/* Function: AddMovementInput 
 Add movement input along the given world direction vector (usually normalized) scaled by 'ScaleValue'. If ScaleValue < 0, movement will be in the opposite direction.
Base Pawn classes won't automatically apply movement, it's up to the user to do so in a Tick event. Subclasses such as Character and DefaultPawn automatically handle this input and move.

Parameters:
    WorldDirection - Direction in world space to apply input
    ScaleValue - Scale to apply to input. This can be used for analog input, ie a value of 0.5 applies half the normal value, while -1.0 would reverse the direction.
    bForce - If true always add the input, ignoring the result of IsMoveInputIgnored(). */
void AddMovementInput(FVector WorldDirection, float32 ScaleValue = 1.000000, bool bForce = false) {}
/* Function: GetOverrideInputComponentClass 
  */
TSubclassOf<UInputComponent> GetOverrideInputComponentClass() const {}
/* Function: GetLastMovementInputVector 
 Return the last input vector in world space that was processed by ConsumeMovementInputVector(), which is usually done by the Pawn or PawnMovementComponent.
Any user that needs to know about the input that last affected movement should use this function.
For example an animation update would want to use this, since by default the order of updates in a frame is:
PlayerController (device input) -> MovementComponent -> Pawn -> Mesh (animations)

Returns:
    The last input vector in world space that was processed by ConsumeMovementInputVector(). */
FVector GetLastMovementInputVector() const {}
/* Function: GetPendingMovementInputVector 
 Return the pending input vector in world space. This is the most up-to-date value of the input vector, pending ConsumeMovementInputVector() which clears it,
Usually only a PawnMovementComponent will want to read this value, or the Pawn itself if it is responsible for movement.

Returns:
    The pending input vector in world space. */
FVector GetPendingMovementInputVector() const {}
/* Function: AddControllerYawInput 
 Add input (affecting Yaw) to the Controller's ControlRotation, if it is a local PlayerController.
This value is multiplied by the PlayerController's InputYawScale value.

Parameters:
    Val - Amount to add to Yaw. This value is multiplied by the PlayerController's InputYawScale value. */
void AddControllerYawInput(float32 Val) {}
/* Function: AddControllerRollInput 
 Add input (affecting Roll) to the Controller's ControlRotation, if it is a local PlayerController.
This value is multiplied by the PlayerController's InputRollScale value.

Parameters:
    Val - Amount to add to Roll. This value is multiplied by the PlayerController's InputRollScale value. */
void AddControllerRollInput(float32 Val) {}
// Group: Functions

/* Function: Unpossessed 
 Event called when the Pawn is no longer possessed by a Controller. Only called on the server (or in standalone) */
void Unpossessed(AController OldController) {}
/* Function: GetbUseControllerRotationRoll 
 If true, this Pawn's roll will be updated to match the Controller's ControlRotation roll, if controlled by a PlayerController. */
bool GetbUseControllerRotationRoll() const {}
/* Function: Possessed 
 Event called when the Pawn is possessed by a Controller. Only called on the server (or in standalone) */
void Possessed(AController NewController) {}
/* Function: GetbUseControllerRotationPitch 
 If true, this Pawn's pitch will be updated to match the Controller's ControlRotation pitch, if controlled by a PlayerController. */
bool GetbUseControllerRotationPitch() const {}
/* Function: SetbUseControllerRotationPitch 
 If true, this Pawn's pitch will be updated to match the Controller's ControlRotation pitch, if controlled by a PlayerController. */
void SetbUseControllerRotationPitch(bool Value) {}
/* Function: GetbUseControllerRotationYaw 
 If true, this Pawn's yaw will be updated to match the Controller's ControlRotation yaw, if controlled by a PlayerController. */
bool GetbUseControllerRotationYaw() const {}
/* Function: SetbUseControllerRotationYaw 
 If true, this Pawn's yaw will be updated to match the Controller's ControlRotation yaw, if controlled by a PlayerController. */
void SetbUseControllerRotationYaw(bool Value) {}
/* Function: Restarted 
 Event called after a pawn has been restarted, usually by a possession change. This is called on the server for all pawns and the owning client for player pawns */
void Restarted() {}
/* Function: SetbUseControllerRotationRoll 
 If true, this Pawn's roll will be updated to match the Controller's ControlRotation roll, if controlled by a PlayerController. */
void SetbUseControllerRotationRoll(bool Value) {}
/* Function: GetbCanAffectNavigationGeneration 
 If set to false (default) given pawn instance will never affect navigation generation (but components could).
Setting it to true will result in using regular AActor's navigation relevancy
calculation to check if this pawn instance should affect navigation generation.
Note: Use SetCanAffectNavigationGeneration() to change this value at runtime.
Note: Modifying this value at runtime will result in any navigation change only if runtime navigation generation is enabled.
Note: Override UpdateNavigationRelevance() to propagate the flag to the desired components.
See: SetCanAffectNavigationGeneration(), UpdateNavigationRelevance() */
bool GetbCanAffectNavigationGeneration() const {}
/* Function: SetbCanAffectNavigationGeneration 
 If set to false (default) given pawn instance will never affect navigation generation (but components could).
Setting it to true will result in using regular AActor's navigation relevancy
calculation to check if this pawn instance should affect navigation generation.
Note: Use SetCanAffectNavigationGeneration() to change this value at runtime.
Note: Modifying this value at runtime will result in any navigation change only if runtime navigation generation is enabled.
Note: Override UpdateNavigationRelevance() to propagate the flag to the desired components.
See: SetCanAffectNavigationGeneration(), UpdateNavigationRelevance() */
void SetbCanAffectNavigationGeneration(bool Value) {}
/* Function: SetOverrideInputComponentClass 
 If set, then this InputComponent class will be used instead of the Input Settings' DefaultInputComponentClass */
void SetOverrideInputComponentClass(TSubclassOf<UInputComponent> Value) {}
/* Function: ControllerChanged 
 Event called after a pawn's controller has changed, on the server and owning client. This will happen at the same time as the delegate on GameInstance */
void ControllerChanged(AController OldController, AController NewController) {}
// Group: Static Functions

/* Function: Spawn 
  */
static APawn APawn::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APawn::StaticClass() {}
}
