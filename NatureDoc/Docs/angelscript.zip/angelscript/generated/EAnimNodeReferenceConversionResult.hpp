/* Class: EAnimNodeReferenceConversionResult 
  */ 
 class EAnimNodeReferenceConversionResult
{
public:
}
/* Enum: EAnimNodeReferenceConversionResult 
 
    Succeeded - Enum
    Failed - Enum
    EAnimNodeReferenceConversionResult_MAX - Enum */ 
 enum EAnimNodeReferenceConversionResult { 
Succeeded,
Failed,
EAnimNodeReferenceConversionResult_MAX, 
}