/* Class: EBindingKind 
  */ 
 class EBindingKind
{
public:
}
/* Enum: EBindingKind 
 
    Function - Enum
    Property - Enum
    EBindingKind_MAX - Enum */ 
 enum EBindingKind { 
Function,
Property,
EBindingKind_MAX, 
}