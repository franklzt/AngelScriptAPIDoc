/* Class: ADecalActor 
 DecalActor contains a DecalComponent which can be used to render material modifications on top of existing geometry.

@see https://docs.unrealengine.com/latest/INT/Engine/Actors/DecalActor
@see UDecalComponent */ 
 class ADecalActor : public AActor
{
public:
// Group: Decal

/* Variable: Decal 
 The decal component for this decal actor */
UDecalComponent Decal;
// Group: Rendering|Components|Decal

/* Variable: DecalMaterial 
  */
UMaterialInterface DecalMaterial;
// Group: Rendering|Components|Decal

/* Function: GetDecalMaterial 
  */
UMaterialInterface GetDecalMaterial() const {}
/* Function: SetDecalMaterial 
 BEGIN DEPRECATED (use component functions now in level script) */
void SetDecalMaterial(UMaterialInterface NewDecalMaterial) {}
/* Function: CreateDynamicMaterialInstance 
  */
UMaterialInstanceDynamic CreateDynamicMaterialInstance() {}
// Group: Static Functions

/* Function: Spawn 
  */
static ADecalActor ADecalActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADecalActor::StaticClass() {}
}
