/* Class: AAudioVolume 
  */ 
 class AAudioVolume : public AVolume
{
public:
// Group: AmbientZone

/* Variable: AmbientZoneSettings 
 Impacts sounds that have "Apply Ambient Volumes" set to true in their Sound Class, based on whether the sound sources and the player are inside or outside the audio volume */
FInteriorSettings AmbientZoneSettings;
// Group: AudioVolume

/* Variable: Priority 
 Priority of this volume. In the case of overlapping volumes, the one with the highest priority
is chosen. The order is undefined if two or more overlapping volumes have the same priority. */
float32 Priority;
/* Variable: bEnabled 
 Whether this volume is currently enabled and able to affect sounds */
bool bEnabled;
// Group: Reverb

/* Variable: Settings 
 Reverb settings to use for this volume. */
FReverbSettings Settings;
// Group: Submixes

/* Variable: SubmixOverrideSettings 
 Submix effect chain override settings. Will override the effect chains on the given submixes when the conditions are met. */
TArray<FAudioVolumeSubmixOverrideSettings> SubmixOverrideSettings;
/* Variable: SubmixSendSettings 
 Submix send settings to use for this volume. Allows audio to dynamically send to submixes based on source and listener locations relative to this volume. */
TArray<FAudioVolumeSubmixSendSettings> SubmixSendSettings;
// Group: AudioVolume

/* Function: SetInteriorSettings 
  */
void SetInteriorSettings(FInteriorSettings NewInteriorSettings) {}
/* Function: SetPriority 
  */
void SetPriority(float32 NewPriority) {}
/* Function: SetReverbSettings 
  */
void SetReverbSettings(FReverbSettings NewReverbSettings) {}
/* Function: SetSubmixOverrideSettings 
  */
void SetSubmixOverrideSettings(TArray<FAudioVolumeSubmixOverrideSettings> NewSubmixOverrideSettings) {}
/* Function: SetSubmixSendSettings 
  */
void SetSubmixSendSettings(TArray<FAudioVolumeSubmixSendSettings> NewSubmixSendSettings) {}
/* Function: SetEnabled 
  */
void SetEnabled(bool bNewEnabled) {}
// Group: Functions

/* Function: GetPriority 
 Priority of this volume. In the case of overlapping volumes, the one with the highest priority
is chosen. The order is undefined if two or more overlapping volumes have the same priority. */
const float32& GetPriority() const {}
/* Function: GetbEnabled 
 Whether this volume is currently enabled and able to affect sounds */
bool GetbEnabled() const {}
/* Function: SetbEnabled 
 Whether this volume is currently enabled and able to affect sounds */
void SetbEnabled(bool Value) {}
/* Function: GetSubmixSendSettings 
 Submix send settings to use for this volume. Allows audio to dynamically send to submixes based on source and listener locations relative to this volume. */
const TArray<FAudioVolumeSubmixSendSettings>& GetSubmixSendSettings() const {}
/* Function: GetSubmixOverrideSettings 
 Submix effect chain override settings. Will override the effect chains on the given submixes when the conditions are met. */
const TArray<FAudioVolumeSubmixOverrideSettings>& GetSubmixOverrideSettings() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AAudioVolume AAudioVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AAudioVolume::StaticClass() {}
}
