/* Class: ABoxReflectionCapture 
 Actor used to capture the scene for reflection in a box shape
@see https://docs.unrealengine.com/latest/INT/Resources/ContentExamples/Reflections/1_3/index.html */ 
 class ABoxReflectionCapture : public AReflectionCapture
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ABoxReflectionCapture ABoxReflectionCapture::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ABoxReflectionCapture::StaticClass() {}
}
