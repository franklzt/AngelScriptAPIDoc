/* Class: ANavModifierVolume 
 Allows applying selected AreaClass to navmesh, using Volume's shape */ 
 class ANavModifierVolume : public AVolume
{
public:
// Group: Default

/* Variable: NavMeshResolution 
 Experimental: When not set to None, the navmesh tiles touched by the navigation modifier volume will be built
using the highest resolution found. */
ENavigationDataResolution NavMeshResolution;
/* Variable: AreaClass 
 NavArea to apply inside the defined volume. */
TSubclassOf<UNavArea> AreaClass;
/* Variable: AreaClassToReplace 
 When setting this value, the modifier volume behavior changes : it will now replace any surface marked by AreaClassToReplace in the volume and replace it with AreaClass. */
TSubclassOf<UNavArea> AreaClassToReplace;
/* Variable: bMaskFillCollisionUnderneathForNavmesh 
 Experimental: if set, the 2D space occupied by the volume box will ignore FillCollisionUnderneathForNavmesh */
bool bMaskFillCollisionUnderneathForNavmesh;
// Group: AI|Navigation

/* Function: SetAreaClassToReplace 
  */
void SetAreaClassToReplace(TSubclassOf<UNavArea> NewAreaClassToReplace = nullptr) {}
/* Function: SetAreaClass 
  */
void SetAreaClass(TSubclassOf<UNavArea> NewAreaClass = nullptr) {}
// Group: Functions

/* Function: GetAreaClassToReplace 
 When setting this value, the modifier volume behavior changes : it will now replace any surface marked by AreaClassToReplace in the volume and replace it with AreaClass. */
const TSubclassOf<UNavArea>& GetAreaClassToReplace() const {}
/* Function: GetAreaClass 
 NavArea to apply inside the defined volume. */
const TSubclassOf<UNavArea>& GetAreaClass() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANavModifierVolume ANavModifierVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavModifierVolume::StaticClass() {}
}
