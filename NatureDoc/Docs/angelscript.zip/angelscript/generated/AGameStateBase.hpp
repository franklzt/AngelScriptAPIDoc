/* Class: AGameStateBase 
 GameStateBase is a class that manages the game's global state, and is spawned by GameModeBase.
It exists on both the client and the server and is fully replicated. */ 
 class AGameStateBase : public AInfo
{
public:
// Group: GameState

/* Variable: AuthorityGameMode 
 Instance of the current game mode, exists only on the server. For non-authority clients, this will be NULL. */
AGameModeBase AuthorityGameMode;
/* Variable: SpectatorClass 
 Class used by spectators, assigned by GameModeBase. */
TSubclassOf<ASpectatorPawn> SpectatorClass;
/* Variable: PlayerArray 
 Array of all PlayerStates, maintained on both server and clients (PlayerStates are always relevant) */
TArray<TObjectPtr<APlayerState>> PlayerArray;
/* Variable: ServerWorldTimeSecondsUpdateFrequency 
 Frequency that the server updates the replicated TimeSeconds from the world. Set to zero to disable periodic updates. */
float32 ServerWorldTimeSecondsUpdateFrequency;
/* Variable: ServerWorldTimeSeconds 
 Returns the simulated TimeSeconds on the server, will be synchronized on client and server */
const float ServerWorldTimeSeconds;
/* Variable: GameModeClass 
 Class of the server's game mode, assigned by GameModeBase. */
TSubclassOf<AGameModeBase> GameModeClass;
// Group: Game

/* Function: HasMatchEnded 
 Returns true if the match can be considered ended. Defaults to false. */
bool HasMatchEnded() const {}
// Group: GameState

/* Function: GetServerWorldTimeSeconds 
 Returns the simulated TimeSeconds on the server, will be synchronized on client and server */
float GetServerWorldTimeSeconds() const {}
/* Function: HasBegunPlay 
 Returns true if the world has started play (called BeginPlay on actors) */
bool HasBegunPlay() const {}
/* Function: GetPlayerStartTime 
 Returns the time that should be used as when a player started */
float32 GetPlayerStartTime(AController Controller) const {}
/* Function: HasMatchStarted 
 Returns true if the world has started match (called MatchStarted callbacks) */
bool HasMatchStarted() const {}
/* Function: GetPlayerRespawnDelay 
 Returns how much time needs to be spent before a player can respawn */
float32 GetPlayerRespawnDelay(AController Controller) const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AGameStateBase AGameStateBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameStateBase::StaticClass() {}
}
