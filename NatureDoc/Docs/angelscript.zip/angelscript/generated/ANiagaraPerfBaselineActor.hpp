/* Class: ANiagaraPerfBaselineActor 
 Actor that controls how the baseline system behaves and also controls stats gathering for. */ 
 class ANiagaraPerfBaselineActor : public AActor
{
public:
// Group: Baseline

/* Variable: Label 
  */
UTextRenderComponent Label;
/* Variable: Controller 
  */
UNiagaraBaselineController Controller;
// Group: Static Functions

/* Function: Spawn 
  */
static ANiagaraPerfBaselineActor ANiagaraPerfBaselineActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANiagaraPerfBaselineActor::StaticClass() {}
}
