/* Class: EBeamTaperMethod 
  */ 
 class EBeamTaperMethod
{
public:
}
/* Enum: EBeamTaperMethod 
 
    PEBTM_None - Enum
    PEBTM_Full - Enum
    PEBTM_Partial - Enum
    PEBTM_MAX - Enum */ 
 enum EBeamTaperMethod { 
PEBTM_None,
PEBTM_Full,
PEBTM_Partial,
PEBTM_MAX, 
}