/* Class: AGroomActor 
 An actor that renders a simulated hair */ 
 class AGroomActor : public AActor
{
public:
// Group: StrandHair

/* Variable: GroomComponent 
 Strand hair component that performs simulation and rendering */
UGroomComponent GroomComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AGroomActor AGroomActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGroomActor::StaticClass() {}
}
