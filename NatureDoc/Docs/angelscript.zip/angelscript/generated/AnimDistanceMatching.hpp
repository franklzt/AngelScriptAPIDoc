/* Class: AnimDistanceMatching 
  */ 
 class AnimDistanceMatching
{
public:
// Group: Distance Matching

/* Function: SetPlayrateToMatchSpeed 
 Set the play rate of the sequence player so that the speed of the animation matches in-game movement speed.
While distance matching is commonly used for transition animations, cycle animations (walk, jog, etc) typically just adjust their play rate to match
the in-game movement speed.
This function assumes that the animation has a constant speed.

Parameters:
    SequencePlayer - The sequence player node to operate on.
    SpeedToMatch - The in-game movement speed to match. This is usually the current speed of the movement component.
    PlayRateClamp - A clamp on how much the animation's play rate can change to match the in-game movement speed. Set to (0,0) for no clamping. */
static FSequencePlayerReference AnimDistanceMatching::SetPlayrateToMatchSpeed(FSequencePlayerReference SequencePlayer, float32 SpeedToMatch, FVector2D PlayRateClamp = FVector2D ( 0.750000 , 1.250000 )) {}
/* Function: DistanceMatchToTarget 
 Set the time of the sequence evaluator to the point in the animation where the distance curve matches the DistanceToTarget input.
A common use case is to achieve stops without foot sliding by, each frame, selecting the point in the animation that matches the distance the character has remaining until it stops.
Note that because this technique sets the time of the animation by distance remaining, it doesn't respect phase of any previous animation (e.g. from a jog cycle).

Parameters:
    SequenceEvaluator - The sequence evaluator node to operate on.
    DistanceToTarget - The distance remaining to a target (e.g. a stop or pivot point).
    DistanceCurveName - Name of the curve we want to match */
static FSequenceEvaluatorReference AnimDistanceMatching::DistanceMatchToTarget(FSequenceEvaluatorReference SequenceEvaluator, float32 DistanceToTarget, FName DistanceCurveName) {}
}
