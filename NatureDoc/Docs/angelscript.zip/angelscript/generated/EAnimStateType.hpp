/* Class: EAnimStateType 
  */ 
 class EAnimStateType
{
public:
}
/* Enum: EAnimStateType 
 
    AST_SingleAnimation - Enum
    AST_BlendGraph - Enum
    AST_MAX - Enum */ 
 enum EAnimStateType { 
AST_SingleAnimation,
AST_BlendGraph,
AST_MAX, 
}