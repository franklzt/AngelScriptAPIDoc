/* Class: APartitionActor 
 Actor base class for instance containers placed on a grid.
See UActorPartitionSubsystem. */ 
 class APartitionActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static APartitionActor APartitionActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APartitionActor::StaticClass() {}
}
