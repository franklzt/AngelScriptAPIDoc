/* Class: APointLight 
  */ 
 class APointLight : public ALight
{
public:
// Group: Light

/* Variable: PointLightComponent 
  */
UPointLightComponent PointLightComponent;
// Group: Rendering|Lighting

/* Function: SetRadius 
 BEGIN DEPRECATED (use component functions now in level script) */
void SetRadius(float32 NewRadius) {}
/* Function: SetLightFalloffExponent 
  */
void SetLightFalloffExponent(float32 NewLightFalloffExponent) {}
// Group: Static Functions

/* Function: Spawn 
  */
static APointLight APointLight::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APointLight::StaticClass() {}
}
