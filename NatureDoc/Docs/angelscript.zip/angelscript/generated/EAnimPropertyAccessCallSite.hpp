/* Class: EAnimPropertyAccessCallSite 
  */ 
 class EAnimPropertyAccessCallSite
{
public:
}
/* Enum: EAnimPropertyAccessCallSite 
 
    WorkerThread_Unbatched - Enum
    WorkerThread_Batched_PreEventGraph - Enum
    WorkerThread_Batched_PostEventGraph - Enum
    GameThread_Batched_PreEventGraph - Enum
    GameThread_Batched_PostEventGraph - Enum
    EAnimPropertyAccessCallSite_MAX - Enum */ 
 enum EAnimPropertyAccessCallSite { 
WorkerThread_Unbatched,
WorkerThread_Batched_PreEventGraph,
WorkerThread_Batched_PostEventGraph,
GameThread_Batched_PreEventGraph,
GameThread_Batched_PostEventGraph,
EAnimPropertyAccessCallSite_MAX, 
}