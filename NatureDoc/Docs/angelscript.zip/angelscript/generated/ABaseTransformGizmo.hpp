/* Class: ABaseTransformGizmo 
 Base class for transform gizmo */ 
 class ABaseTransformGizmo : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ABaseTransformGizmo ABaseTransformGizmo::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ABaseTransformGizmo::StaticClass() {}
}
