/* Class: EAllowEditsMode 
  */ 
 class EAllowEditsMode
{
public:
}
/* Enum: EAllowEditsMode 
 
    AllEdits - Enum
    AllowSequencerEditsOnly - Enum
    AllowLevelEditsOnly - Enum
    EAllowEditsMode_MAX - Enum */ 
 enum EAllowEditsMode { 
AllEdits,
AllowSequencerEditsOnly,
AllowLevelEditsOnly,
EAllowEditsMode_MAX, 
}