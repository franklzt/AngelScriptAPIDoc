/* Class: EAutomaticRadius 
  */ 
 class EAutomaticRadius
{
public:
}
/* Enum: EAutomaticRadius 
 
    On - Enum
    Off - Enum
    EAutomaticRadius_MAX - Enum */ 
 enum EAutomaticRadius { 
On,
Off,
EAutomaticRadius_MAX, 
}