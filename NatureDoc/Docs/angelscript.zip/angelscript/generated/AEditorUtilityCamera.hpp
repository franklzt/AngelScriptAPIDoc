/* Class: AEditorUtilityCamera 
  */ 
 class AEditorUtilityCamera : public ACameraActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AEditorUtilityCamera AEditorUtilityCamera::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AEditorUtilityCamera::StaticClass() {}
}
