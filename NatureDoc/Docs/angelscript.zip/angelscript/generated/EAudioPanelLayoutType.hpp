/* Class: EAudioPanelLayoutType 
  */ 
 class EAudioPanelLayoutType
{
public:
}
/* Enum: EAudioPanelLayoutType 
 
    Basic - Enum
    Advanced - Enum
    EAudioPanelLayoutType_MAX - Enum */ 
 enum EAudioPanelLayoutType { 
Basic,
Advanced,
EAudioPanelLayoutType_MAX, 
}