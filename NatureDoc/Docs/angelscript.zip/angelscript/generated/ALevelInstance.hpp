/* Class: ALevelInstance 
  */ 
 class ALevelInstance : public AActor
{
public:
// Group: Default

/* Variable: LevelInstanceComponent 
  */
ULevelInstanceComponent LevelInstanceComponent;
// Group: Level

/* Variable: DesiredRuntimeBehavior 
  */
ELevelInstanceRuntimeBehavior DesiredRuntimeBehavior;
/* Variable: WorldAsset 
 Level LevelInstance */
TSoftObjectPtr<UWorld> WorldAsset;
// Group: Static Functions

/* Function: Spawn 
  */
static ALevelInstance ALevelInstance::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALevelInstance::StaticClass() {}
}
