/* Class: ALightWeightInstanceManager 
  */ 
 class ALightWeightInstanceManager : public AActor
{
public:
// Group: LightWeightInstance

/* Variable: InstanceTransforms 
 Current per instance transforms */
TArray<FTransform> InstanceTransforms;
/* Variable: RepresentedClass 
  */
TSubclassOf<AActor> RepresentedClass;
// Group: Static Functions

/* Function: Spawn 
  */
static ALightWeightInstanceManager ALightWeightInstanceManager::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALightWeightInstanceManager::StaticClass() {}
}
