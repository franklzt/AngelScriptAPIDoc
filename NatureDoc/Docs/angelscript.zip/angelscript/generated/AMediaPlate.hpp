/* Class: AMediaPlate 
 MediaPlate is an actor that can play and show media in the world. */ 
 class AMediaPlate : public AActor
{
public:
// Group: MediaPlate

/* Variable: StaticMeshComponent 
 Holds the mesh. */
UStaticMeshComponent StaticMeshComponent;
/* Variable: MediaPlateComponent 
  */
UMediaPlateComponent MediaPlateComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AMediaPlate AMediaPlate::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AMediaPlate::StaticClass() {}
}
