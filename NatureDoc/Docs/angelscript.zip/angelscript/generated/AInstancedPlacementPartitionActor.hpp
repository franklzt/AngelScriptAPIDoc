/* Class: AInstancedPlacementPartitionActor 
 The base class used by any editor placement of instanced objects, which holds any relevant runtime data for the placed instances. */ 
 class AInstancedPlacementPartitionActor : public AISMPartitionActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AInstancedPlacementPartitionActor AInstancedPlacementPartitionActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AInstancedPlacementPartitionActor::StaticClass() {}
}
