/* Class: EAnimSyncGroupScope 
  */ 
 class EAnimSyncGroupScope
{
public:
}
/* Enum: EAnimSyncGroupScope 
 
    Local - Enum
    Component - Enum
    EAnimSyncGroupScope_MAX - Enum */ 
 enum EAnimSyncGroupScope { 
Local,
Component,
EAnimSyncGroupScope_MAX, 
}