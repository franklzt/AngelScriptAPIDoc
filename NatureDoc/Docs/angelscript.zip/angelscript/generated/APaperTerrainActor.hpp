/* Class: APaperTerrainActor 
 An instance of a piece of 2D terrain in the level */ 
 class APaperTerrainActor : public AActor
{
public:
// Group: Sprite

/* Variable: RenderComponent 
  */
UPaperTerrainComponent RenderComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static APaperTerrainActor APaperTerrainActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APaperTerrainActor::StaticClass() {}
}
