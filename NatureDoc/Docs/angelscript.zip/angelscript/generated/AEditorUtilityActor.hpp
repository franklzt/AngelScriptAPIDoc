/* Class: AEditorUtilityActor 
  */ 
 class AEditorUtilityActor : public AActor
{
public:
// Group: Input|Editor

/* Variable: ReceivesEditorInput 
  */
bool ReceivesEditorInput;
/* Variable: bReceivesEditorInput 
 If set to true, then this actor will be able to recieve input delegate callbacks when in the editor. */
bool bReceivesEditorInput;
// Group: Variables

/* Variable: InputComponent 
 Component that handles input for this actor, if input is enabled. */
const UInputComponent InputComponent;
// Group: Editor

/* Function: Run 
 Standard function to execute */
void Run() {}
// Group: Input|Editor

/* Function: GetReceivesEditorInput 
  */
bool GetReceivesEditorInput() const {}
/* Function: SetReceivesEditorInput 
  */
void SetReceivesEditorInput(bool bInValue) {}
/* Function: GetInputComponent 
 Returns the current InputComponent on this utility actor. This will be NULL unless bReceivesEditorInput is set to true. */
UInputComponent GetInputComponent() const {}
// Group: Functions

/* Function: SetbReceivesEditorInput 
 If set to true, then this actor will be able to recieve input delegate callbacks when in the editor. */
void SetbReceivesEditorInput(bool bInValue) {}
/* Function: GetbReceivesEditorInput 
 If set to true, then this actor will be able to recieve input delegate callbacks when in the editor. */
bool GetbReceivesEditorInput() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AEditorUtilityActor AEditorUtilityActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AEditorUtilityActor::StaticClass() {}
}
