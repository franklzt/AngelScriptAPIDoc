/* Class: EActorBrowsingFolderDoubleClickMethod 
  */ 
 class EActorBrowsingFolderDoubleClickMethod
{
public:
}
/* Enum: EActorBrowsingFolderDoubleClickMethod 
 
    ToggleExpansion - Enum
    ToggleCurrentFolder - Enum
    EActorBrowsingFolderDoubleClickMethod_MAX - Enum */ 
 enum EActorBrowsingFolderDoubleClickMethod { 
ToggleExpansion,
ToggleCurrentFolder,
EActorBrowsingFolderDoubleClickMethod_MAX, 
}