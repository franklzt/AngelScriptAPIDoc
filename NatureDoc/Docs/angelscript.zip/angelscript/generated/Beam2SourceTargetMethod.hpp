/* Class: Beam2SourceTargetMethod 
  */ 
 class Beam2SourceTargetMethod
{
public:
}
/* Enum: Beam2SourceTargetMethod 
 
    PEB2STM_Default - Enum
    PEB2STM_UserSet - Enum
    PEB2STM_Emitter - Enum
    PEB2STM_Particle - Enum
    PEB2STM_Actor - Enum
    PEB2STM_MAX - Enum */ 
 enum Beam2SourceTargetMethod { 
PEB2STM_Default,
PEB2STM_UserSet,
PEB2STM_Emitter,
PEB2STM_Particle,
PEB2STM_Actor,
PEB2STM_MAX, 
}