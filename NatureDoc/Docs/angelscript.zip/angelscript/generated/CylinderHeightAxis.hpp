/* Class: CylinderHeightAxis 
  */ 
 class CylinderHeightAxis
{
public:
}
/* Enum: CylinderHeightAxis 
 
    PMLPC_HEIGHTAXIS_X - Enum
    PMLPC_HEIGHTAXIS_Y - Enum
    PMLPC_HEIGHTAXIS_Z - Enum
    PMLPC_HEIGHTAXIS_MAX - Enum */ 
 enum CylinderHeightAxis { 
PMLPC_HEIGHTAXIS_X,
PMLPC_HEIGHTAXIS_Y,
PMLPC_HEIGHTAXIS_Z,
PMLPC_HEIGHTAXIS_MAX, 
}