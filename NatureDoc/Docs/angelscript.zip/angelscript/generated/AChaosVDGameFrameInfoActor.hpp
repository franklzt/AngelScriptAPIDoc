/* Class: AChaosVDGameFrameInfoActor 
 Actor that contains game frame related data */ 
 class AChaosVDGameFrameInfoActor : public AChaosVDDataContainerBaseActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AChaosVDGameFrameInfoActor AChaosVDGameFrameInfoActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AChaosVDGameFrameInfoActor::StaticClass() {}
}
