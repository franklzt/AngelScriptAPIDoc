/* Class: ALandscapeProxy 
  */ 
 class ALandscapeProxy : public APartitionActor
{
public:
// Group: Collision

/* Variable: BodyInstance 
 Collision profile settings for this landscape */
FBodyInstance BodyInstance;
/* Variable: CollisionMipLevel 
 Landscape LOD to use for collision tests. Higher numbers use less memory and process faster, but are much less accurate */
int CollisionMipLevel;
/* Variable: bGenerateOverlapEvents 
 If true, Landscape will generate overlap events when other components are overlapping it (eg Begin Overlap).
Both the Landscape and the other component must have this flag enabled for overlap events to occur.

@see [Overlap Events](https://docs.unrealengine.com/InteractiveExperiences/Physics/Collision/Overview#overlapandgenerateoverlapevents)
@see UpdateOverlaps(), BeginComponentOverlap(), EndComponentOverlap() */
bool bGenerateOverlapEvents;
/* Variable: SimpleCollisionMipLevel 
 If set higher than the "Collision Mip Level", this specifies the Landscape LOD to use for "simple collision" tests, otherwise the "Collision Mip Level" is used for both simple and complex collision.
Does not work with an XY offset map (mesh collision) */
int SimpleCollisionMipLevel;
// Group: HLOD

/* Variable: HLODMeshSourceLOD 
 Specify which LOD to use for the HLOD mesh if HLODMeshSourceLODPolicy is set to SpecificLOD. */
int HLODMeshSourceLOD;
/* Variable: HLODMaterialOverride 
 Specify a custom HLOD material to apply to the HLOD mesh. Specifying an HLOD Material Override will result in no texture being baked for the HLOD mesh. */
UMaterialInterface HLODMaterialOverride;
/* Variable: HLODMeshSourceLODPolicy 
 Specify how to choose the LOD used as input for the HLOD mesh. */
ELandscapeHLODMeshSourceLODPolicy HLODMeshSourceLODPolicy;
/* Variable: bUseLandscapeForCullingInvisibleHLODVertices 
 Flag whether or not this Landscape's surface can be used for culling hidden triangles * */
bool bUseLandscapeForCullingInvisibleHLODVertices;
/* Variable: HLODTextureSize 
 Specify the texture size to use for the HLOD mesh if HLODTextureSizePolicy is set to SpecificSize. Specifying an HLOD Material Override will disable this option as no texture will be baked. */
int HLODTextureSize;
/* Variable: HLODTextureSizePolicy 
 Specify how to choose the texture size of the resulting HLOD mesh. Specifying an HLOD Material Override will disable this option as no texture will be baked. */
ELandscapeHLODTextureSizePolicy HLODTextureSizePolicy;
// Group: Landscape

/* Variable: bStripGrassWhenCookedServer 
 Strip Grass data when cooked for server */
bool bStripGrassWhenCookedServer;
/* Variable: bUseDynamicMaterialInstance 
 When set to true it will generate MaterialInstanceDynamic for each components, so material can be changed at runtime */
bool bUseDynamicMaterialInstance;
/* Variable: bStripPhysicsWhenCookedClient 
 Strip Physics/collision components when cooked for client */
bool bStripPhysicsWhenCookedClient;
/* Variable: bStripGrassWhenCookedClient 
 Strip Grass data when cooked for client */
bool bStripGrassWhenCookedClient;
/* Variable: MaxPaintedLayersPerComponent 
  */
int MaxPaintedLayersPerComponent;
/* Variable: bUseCompressedHeightmapStorage 
 Enable compressed heightmap texture storage. */
bool bUseCompressedHeightmapStorage;
/* Variable: bStripPhysicsWhenCookedServer 
 Strip Physics/collision components when cooked for server */
bool bStripPhysicsWhenCookedServer;
/* Variable: PerLODOverrideMaterials 
  */
TArray<FLandscapePerLODMaterialOverride> PerLODOverrideMaterials;
/* Variable: LandscapeMaterial 
 Combined material used to render the landscape */
UMaterialInterface LandscapeMaterial;
/* Variable: DefaultPhysMaterial 
 Default physical material, used when no per-layer values physical materials */
UPhysicalMaterial DefaultPhysMaterial;
/* Variable: StreamingDistanceMultiplier 
 Allows artists to adjust the distance where textures using UV 0 are streamed in/out.
1.0 is the default, whereas a higher value increases the streamed-in resolution.
Value can be < 0 (from legcay content, or code changes) */
float32 StreamingDistanceMultiplier;
/* Variable: LandscapeHoleMaterial 
 Material used to render landscape components with holes. If not set, LandscapeMaterial will be used (blend mode will be overridden to Masked if it is set to Opaque) */
UMaterialInterface LandscapeHoleMaterial;
/* Variable: PositiveZBoundsExtension 
 Allows overriding the landscape bounds. This is useful if you distort the landscape with world-position-offset, for example
Extension value in the positive Z axis, positive value increases bound size
Note that this can also be overridden per-component when the component is selected with the component select tool */
float32 PositiveZBoundsExtension;
/* Variable: NegativeZBoundsExtension 
 Allows overriding the landscape bounds. This is useful if you distort the landscape with world-position-offset, for example
Extension value in the negative Z axis, positive value increases bound size
Note that this can also be overridden per-component when the component is selected with the component select tool */
float32 NegativeZBoundsExtension;
// Group: Landscape|Runtime

/* Variable: LandscapeActor 
  */
const ALandscape LandscapeActor;
// Group: Lighting

/* Variable: bCastShadowAsTwoSided 
 Whether this primitive should cast dynamic shadows as if it were a two sided material.  This flag is only used if CastShadow is true. */
bool bCastShadowAsTwoSided;
/* Variable: bAffectDynamicIndirectLighting 
 Controls whether the primitive should influence indirect lighting. */
bool bAffectDynamicIndirectLighting;
/* Variable: bAffectDistanceFieldLighting 
 Controls whether the primitive should affect dynamic distance field lighting methods.  This flag is only used if CastShadow is true. * */
bool bAffectDistanceFieldLighting;
/* Variable: StaticLightingResolution 
 The resolution to cache lighting at, in texels/quad in one axis
Total resolution would be changed by StaticLightingResolution*StaticLightingResolution
Automatically calculate proper value for removing seams */
float32 StaticLightingResolution;
/* Variable: bAffectIndirectLightingWhileHidden 
 Controls whether the primitive should affect indirect lighting when hidden. This flag is only used if bAffectDynamicIndirectLighting is true. */
bool bAffectIndirectLightingWhileHidden;
/* Variable: ShadowCacheInvalidationBehavior 
 Control shadow invalidation behavior, in particular with respect to Virtual Shadow Maps and material effects like World Position Offset. */
EShadowCacheInvalidationBehavior ShadowCacheInvalidationBehavior;
/* Variable: bCastFarShadow 
 When enabled, the component will be rendering into the far shadow cascades(only for directional lights).  This flag is only used if CastShadow is true. */
bool bCastFarShadow;
/* Variable: NonNaniteVirtualShadowMapConstantDepthBias 
 Constant bias to handle the worst artifacts of the continuous LOD morphing when rendering to VSM.
Only applies when using non-Nanite landscape and VSM. */
float32 NonNaniteVirtualShadowMapConstantDepthBias;
/* Variable: NonNaniteVirtualShadowMapInvalidationHeightErrorThreshold 
 For non-Nanite landscape, cached VSM pages need to be invalidated when continuous LOD morphing introduces a height difference that is too large between the current landscape component's profile and the one that was used when the shadow was shadow was last cached.
This height threshold (in Unreal units) controls this invalidation rate (a smaller threshold will reduce the likeliness of shadow artifacts, but will make the invalidations occur more frequently, which is not desirable in terms of performance.
Disabled if 0.0.
Only applies when using non-Nanite landscape and VSM. */
float32 NonNaniteVirtualShadowMapInvalidationHeightErrorThreshold;
/* Variable: NonNaniteVirtualShadowMapInvalidationScreenSizeLimit 
 Screen size under which VSM invalidation stops occurring.
As the height difference between 2 mip levels increases when the LOD level increases (because of undersampling), VSM pages tend to be invalidated more frequently even though it's getting less and less relevant to do so, since this will mean that the screen size of the landscape section decreases, thus the artifacts actually become less noticeable.
We therefore artificially attenuate the VSM invalidation rate as the screen size decreases, to avoid invalidating VSM pages too often, as it becomes less and less impactful.
A higher value will accentuate this attenuation (better performance but more artifacts) and vice versa.
If 0.0, the attenuation of the VSM invalidation rate will be disabled entirely.
Only applies when using non-Nanite landscape and VSM. */
float32 NonNaniteVirtualShadowMapInvalidationScreenSizeLimit;
/* Variable: StaticLightingLOD 
 LOD level to use when running lightmass (increase to 1 or 2 for large landscapes to stop lightmass crashing) */
int StaticLightingLOD;
/* Variable: LightingChannels 
 Channels that this Landscape should be in.  Lights with matching channels will affect the Landscape.
These channels only apply to opaque materials, direct lighting, and dynamic lighting and shadowing. */
FLightingChannels LightingChannels;
/* Variable: bCastDynamicShadow 
 Controls whether the primitive should cast shadows in the case of non precomputed shadowing.  This flag is only used if CastShadow is true. * */
bool bCastDynamicShadow;
/* Variable: bCastContactShadow 
 Whether the object should cast contact shadows. This flag is only used if CastShadow is true. */
bool bCastContactShadow;
/* Variable: bCastStaticShadow 
 Whether the object should cast a static shadow from shadow casting lights.  This flag is only used if CastShadow is true. */
bool bCastStaticShadow;
/* Variable: CastShadow 
 Controls whether the primitive component should cast a shadow or not. */
bool CastShadow;
/* Variable: bCastHiddenShadow 
 If true, the primitive will cast shadows even if bHidden is true.  Controls whether the primitive should cast shadows when hidden.  This flag is only used if CastShadow is true. */
bool bCastHiddenShadow;
// Group: Lightmass

/* Variable: LightmassSettings 
 The Lightmass settings for this object. */
FLightmassPrimitiveSettings LightmassSettings;
// Group: LOD

/* Variable: ExportLOD 
 LOD level to use when exporting the landscape to obj or FBX */
int ExportLOD;
/* Variable: LODGroupKey 
 Specifies the LOD Group (Zero is No Group). All landscapes in the same group calculate their LOD together, allowing matching border LODs to fix geometry seams. */
uint LODGroupKey;
/* Variable: MaxLODLevel 
 Max LOD level to use when rendering, -1 means the max available */
int MaxLODLevel;
// Group: LOD Distribution

/* Variable: ScalableLOD0ScreenSize 
 Scalable (per-quality) version of 'LOD 0 Screen Size'. */
FPerQualityLevelFloat ScalableLOD0ScreenSize;
/* Variable: LODDistributionSetting 
 The distribution setting used to change the LOD generation, 3 is the normal distribution, small number mean you want your last LODs to take more screen space and big number mean you want your first LODs to take more screen space. */
float32 LODDistributionSetting;
/* Variable: LOD0DistributionSetting 
 The distribution setting used to change the LOD 0 generation, 1.25 is the normal distribution, numbers influence directly the LOD0 proportion on screen. */
float32 LOD0DistributionSetting;
/* Variable: LODBlendRange 
 This controls the area that blends LOD between neighboring sections. At 1.0 it blends across the entire section, and lower numbers reduce the blend region to be closer to the boundary. */
float32 LODBlendRange;
/* Variable: bUseScalableLODSettings 
 Allows to specify LOD distribution settings per quality level. Using this will ignore the r.LandscapeLOD0DistributionScale CVar. */
bool bUseScalableLODSettings;
/* Variable: ScalableLOD0DistributionSetting 
 Scalable (per-quality) version of 'LOD 0'. */
FPerQualityLevelFloat ScalableLOD0DistributionSetting;
/* Variable: LOD0ScreenSize 
 This is the starting screen size used to calculate the distribution. You can increase the value if you want less LOD0 component, and you use very large landscape component. */
float32 LOD0ScreenSize;
/* Variable: ScalableLODDistributionSetting 
 Scalable (per-quality) version of 'Other LODs'. */
FPerQualityLevelFloat ScalableLODDistributionSetting;
// Group: Nanite

/* Variable: NaniteSkirtDepth 
  */
float32 NaniteSkirtDepth;
/* Variable: bNaniteSkirtEnabled 
  */
bool bNaniteSkirtEnabled;
/* Variable: NaniteLODIndex 
 LOD level of the landscape when generating the Nanite mesh. Mostly there for debug reasons, since Nanite is meant to allow high density meshes, we want to use 0 most of the times. */
int NaniteLODIndex;
/* Variable: NaniteMaxEdgeLengthFactor 
  */
float32 NaniteMaxEdgeLengthFactor;
/* Variable: NanitePositionPrecision 
  */
int NanitePositionPrecision;
/* Variable: bEnableNanite 
 Use Nanite to render landscape as a mesh on supported platforms. */
bool bEnableNanite;
// Group: Navigation

/* Variable: NavigationGeometryGatheringMode 
  */
ENavDataGatheringMode NavigationGeometryGatheringMode;
// Group: Rendering

/* Variable: CustomDepthStencilWriteMask 
 Mask used for stencil buffer writes. */
ERendererStencilMask CustomDepthStencilWriteMask;
/* Variable: LDMaxDrawDistance 
 Max draw distance exposed to LDs. The real max draw distance is the min (disregarding 0) of this and volumes affecting this object. */
float32 LDMaxDrawDistance;
/* Variable: CustomDepthStencilValue 
 Optionally write this 0-255 value to the stencil buffer in CustomDepth pass (Requires project setting or r.CustomDepth == 3) */
int CustomDepthStencilValue;
/* Variable: bHoldout 
 If this is True, this primitive will render black with an alpha of 0, but all secondary effects (shadows, reflections, indirect lighting) remain. This feature requires the project settings "Alpha Output" and "Support Primitive Alpha Holdout". */
bool bHoldout;
/* Variable: bRenderCustomDepth 
 If true, the Landscape will be rendered in the CustomDepth pass (usually used for outlines) */
bool bRenderCustomDepth;
// Group: VirtualTexture

/* Variable: bVirtualTextureRenderWithQuadHQ 
 Use highest quality heightmap interpolation when using a single quad to render this landscape to runtime virtual texture pages.
This also requires the project setting: r.VT.RVT.HighQualityPerPixelHeight. */
bool bVirtualTextureRenderWithQuadHQ;
/* Variable: bVirtualTextureRenderWithQuad 
 Use a single quad to render this landscape to runtime virtual texture pages.
This is the fastest path but it only gives correct results if the runtime virtual texture orientation is aligned with the landscape.
If the two are unaligned we need to render to the virtual texture using LODs with sufficient density. */
bool bVirtualTextureRenderWithQuad;
/* Variable: VirtualTextureNumLods 
 Number of mesh levels to use when rendering landscape into runtime virtual texture.
Lower values reduce vertex count when rendering to the runtime virtual texture but decrease accuracy when using values that require vertex interpolation. */
int VirtualTextureNumLods;
/* Variable: VirtualTextureLodBias 
 Bias to the LOD selected for rendering to runtime virtual textures.
Higher values reduce vertex count when rendering to the runtime virtual texture. */
int VirtualTextureLodBias;
/* Variable: RuntimeVirtualTextures 
 Array of runtime virtual textures into which we draw this landscape.
The material also needs to be set up to output to a virtual texture. */
TArray<TObjectPtr<URuntimeVirtualTexture>> RuntimeVirtualTextures;
/* Variable: VirtualTextureRenderPassType 
 Controls if this component draws in the main pass as well as in the virtual texture. */
ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType;
// Group: Landscape

/* Function: DeleteUnusedLayers 
 Delete all unused layers in components. Warning: any update of the component could re-introduce them. */
void DeleteUnusedLayers() {}
// Group: Landscape|Editor

/* Function: EditorApplySpline 
 Deform landscape using a given spline

Parameters:
    InSplineComponent - The component containing the spline data
    StartWidth - Width of the spline at the start node, in Spline Component local space
    EndWidth - Width of the spline at the end node, in Spline Component local space
    StartSideFalloff - Width of the falloff at either side of the spline at the start node, in Spline Component local space
    EndSideFalloff - Width of the falloff at either side of the spline at the end node, in Spline Component local space
    StartRoll - Roll applied to the spline at the start node, in degrees. 0 is flat
    EndRoll - Roll applied to the spline at the end node, in degrees. 0 is flat
    NumSubdivisions - Number of triangles to place along the spline when applying it to the landscape. Higher numbers give better results, but setting it too high will be slow and may cause artifacts
    bRaiseHeights - Allow the landscape to be raised up to the level of the spline. If both bRaiseHeights and bLowerHeights are false, no height modification of the landscape will be performed
    bLowerHeights - Allow the landscape to be lowered down to the level of the spline. If both bRaiseHeights and bLowerHeights are false, no height modification of the landscape will be performed
    PaintLayer - LayerInfo to paint, or none to skip painting. The landscape must be configured with the same layer info in one of its layers or this will do nothing!
    EditLayerName - Name of the landscape edit layer to affect (in Edit Layers mode) */
void EditorApplySpline(USplineComponent InSplineComponent, float32 StartWidth = 200.000000, float32 EndWidth = 200.000000, float32 StartSideFalloff = 200.000000, float32 EndSideFalloff = 200.000000, float32 StartRoll = 0.000000, float32 EndRoll = 0.000000, int NumSubdivisions = 20, bool bRaiseHeights = true, bool bLowerHeights = true, ULandscapeLayerInfoObject PaintLayer = nullptr, FName EditLayerName = NAME_None) {}
// Group: Landscape|Runtime

/* Function: GetLandscapeActor 
  */
ALandscape GetLandscapeActor() {}
// Group: Landscape|Runtime|Material

/* Function: SetLandscapeMaterialVectorParameterValue 
 Set an MID vector parameter value for all landscape components. */
void SetLandscapeMaterialVectorParameterValue(FName ParameterName, FLinearColor Value) {}
/* Function: SetLandscapeMaterialTextureParameterValue 
 Set an MID texture parameter value for all landscape components. */
void SetLandscapeMaterialTextureParameterValue(FName ParameterName, UTexture Value) {}
/* Function: SetLandscapeMaterialScalarParameterValue 
 Set a MID scalar (float) parameter value for all landscape components. */
void SetLandscapeMaterialScalarParameterValue(FName ParameterName, float32 Value) {}
// Group: Rendering

/* Function: LandscapeExportHeightmapToRenderTarget 
 Output a landscape heightmap to a render target

Parameters:
    InRenderTarget - Valid render target with a format of RTF_RGBA16f, RTF_RGBA32f or RTF_RGBA8
    InExportHeightIntoRGChannel - Tell us if we should export the height that is internally stored as R & G (for 16 bits) to a single R channel of the render target (the format need to be RTF_RGBA16f or RTF_RGBA32f) Note that using RTF_RGBA16f with InExportHeightIntoRGChannel == false, could have precision loss.
    InExportLandscapeProxies - Option to also export components of all proxies of Landscape actor (if LandscapeProxy is the Landscape Actor) */
bool LandscapeExportHeightmapToRenderTarget(UTextureRenderTarget2D InRenderTarget, bool InExportHeightIntoRGChannel = false, bool InExportLandscapeProxies = true) {}
/* Function: ChangeLODDistanceFactor 
 Change the Level of Detail distance factor */
void ChangeLODDistanceFactor(float32 InLODDistanceFactor) {}
/* Function: LandscapeImportHeightmapFromRenderTarget 
 Overwrites a landscape heightmap with render target data

Parameters:
    InRenderTarget - Valid render target with a format of RTF_RGBA16f, RTF_RGBA32f or RTF_RGBA8
    InImportHeightFromRGChannel - Only relevant when using format RTF_RGBA16f or RTF_RGBA32f, and will tell us if we should import the height data from the R channel only of the Render target or from R & G. Note that using RTF_RGBA16f with InImportHeightFromRGChannel == false, could have precision loss Only works in the editor */
bool LandscapeImportHeightmapFromRenderTarget(UTextureRenderTarget2D InRenderTarget, bool InImportHeightFromRGChannel = false) {}
/* Function: LandscapeImportWeightmapFromRenderTarget 
 Overwrites a landscape weightmap with render target data
Only works in the editor */
bool LandscapeImportWeightmapFromRenderTarget(UTextureRenderTarget2D InRenderTarget, FName InLayerName) {}
/* Function: ChangeComponentScreenSizeToUseSubSections 
 Change ComponentScreenSizeToUseSubSections value on the render proxy. */
void ChangeComponentScreenSizeToUseSubSections(float32 InComponentScreenSizeToUseSubSections) {}
/* Function: LandscapeExportWeightmapToRenderTarget 
 Output a landscape weightmap to a render target
Only works in the editor */
bool LandscapeExportWeightmapToRenderTarget(UTextureRenderTarget2D InRenderTarget, FName InLayerName) {}
// Group: Functions

/* Function: EditorSetLandscapeMaterial 
 Setter for LandscapeMaterial. Has no effect outside the editor. */
void EditorSetLandscapeMaterial(UMaterialInterface NewLandscapeMaterial) {}
/* Function: SetbCastContactShadow 
 Whether the object should cast contact shadows. This flag is only used if CastShadow is true. */
void SetbCastContactShadow(bool Value) {}
/* Function: SetVirtualTextureRenderPassType 
  */
void SetVirtualTextureRenderPassType(ERuntimeVirtualTextureMainPassType InType) {}
/* Function: SetLandscapeMaterial 
 Combined material used to render the landscape */
void SetLandscapeMaterial(UMaterialInterface NewLandscapeMaterial) {}
/* Function: GetLandscapeMaterial 
 Combined material used to render the landscape */
UMaterialInterface GetLandscapeMaterial() const {}
/* Function: GetVirtualTextureRenderPassType 
 Controls if this component draws in the main pass as well as in the virtual texture. */
const ERuntimeVirtualTextureMainPassType& GetVirtualTextureRenderPassType() const {}
/* Function: GetCastShadow 
 Controls whether the primitive component should cast a shadow or not. */
bool GetCastShadow() const {}
/* Function: SetCastShadow 
 Controls whether the primitive component should cast a shadow or not. */
void SetCastShadow(bool Value) {}
/* Function: GetbCastDynamicShadow 
 Controls whether the primitive should cast shadows in the case of non precomputed shadowing.  This flag is only used if CastShadow is true. * */
bool GetbCastDynamicShadow() const {}
/* Function: SetbCastDynamicShadow 
 Controls whether the primitive should cast shadows in the case of non precomputed shadowing.  This flag is only used if CastShadow is true. * */
void SetbCastDynamicShadow(bool Value) {}
/* Function: GetbCastStaticShadow 
 Whether the object should cast a static shadow from shadow casting lights.  This flag is only used if CastShadow is true. */
bool GetbCastStaticShadow() const {}
/* Function: SetbCastStaticShadow 
 Whether the object should cast a static shadow from shadow casting lights.  This flag is only used if CastShadow is true. */
void SetbCastStaticShadow(bool Value) {}
/* Function: GetbCastContactShadow 
 Whether the object should cast contact shadows. This flag is only used if CastShadow is true. */
bool GetbCastContactShadow() const {}
/* Function: GetHeightAtLocation 
  */
bool GetHeightAtLocation(FVector Location, float32& OutHeight) const {}
/* Function: GetbCastFarShadow 
 When enabled, the component will be rendering into the far shadow cascades(only for directional lights).  This flag is only used if CastShadow is true. */
bool GetbCastFarShadow() const {}
/* Function: SetbCastFarShadow 
 When enabled, the component will be rendering into the far shadow cascades(only for directional lights).  This flag is only used if CastShadow is true. */
void SetbCastFarShadow(bool Value) {}
/* Function: GetbCastHiddenShadow 
 If true, the primitive will cast shadows even if bHidden is true.  Controls whether the primitive should cast shadows when hidden.  This flag is only used if CastShadow is true. */
bool GetbCastHiddenShadow() const {}
/* Function: SetbCastHiddenShadow 
 If true, the primitive will cast shadows even if bHidden is true.  Controls whether the primitive should cast shadows when hidden.  This flag is only used if CastShadow is true. */
void SetbCastHiddenShadow(bool Value) {}
/* Function: GetbCastShadowAsTwoSided 
 Whether this primitive should cast dynamic shadows as if it were a two sided material.  This flag is only used if CastShadow is true. */
bool GetbCastShadowAsTwoSided() const {}
/* Function: SetbCastShadowAsTwoSided 
 Whether this primitive should cast dynamic shadows as if it were a two sided material.  This flag is only used if CastShadow is true. */
void SetbCastShadowAsTwoSided(bool Value) {}
/* Function: GetbAffectDistanceFieldLighting 
 Controls whether the primitive should affect dynamic distance field lighting methods.  This flag is only used if CastShadow is true. * */
bool GetbAffectDistanceFieldLighting() const {}
/* Function: SetbAffectDistanceFieldLighting 
 Controls whether the primitive should affect dynamic distance field lighting methods.  This flag is only used if CastShadow is true. * */
void SetbAffectDistanceFieldLighting(bool Value) {}
/* Function: GetbAffectDynamicIndirectLighting 
 Controls whether the primitive should influence indirect lighting. */
bool GetbAffectDynamicIndirectLighting() const {}
/* Function: SetbAffectDynamicIndirectLighting 
 Controls whether the primitive should influence indirect lighting. */
void SetbAffectDynamicIndirectLighting(bool Value) {}
/* Function: GetbAffectIndirectLightingWhileHidden 
 Controls whether the primitive should affect indirect lighting when hidden. This flag is only used if bAffectDynamicIndirectLighting is true. */
bool GetbAffectIndirectLightingWhileHidden() const {}
/* Function: SetbAffectIndirectLightingWhileHidden 
 Controls whether the primitive should affect indirect lighting when hidden. This flag is only used if bAffectDynamicIndirectLighting is true. */
void SetbAffectIndirectLightingWhileHidden(bool Value) {}
/* Function: SetbUseMaterialPositionOffsetInStaticLighting 
 Whether to use the landscape material's vertical world position offset when calculating static lighting.
Note: Only z (vertical) offset is supported. XY offsets are ignored.
Does not work correctly with an XY offset map (mesh collision) */
void SetbUseMaterialPositionOffsetInStaticLighting(bool Value) {}
/* Function: GetbHoldout 
 If this is True, this primitive will render black with an alpha of 0, but all secondary effects (shadows, reflections, indirect lighting) remain. This feature requires the project settings "Alpha Output" and "Support Primitive Alpha Holdout". */
bool GetbHoldout() const {}
/* Function: SetbHoldout 
 If this is True, this primitive will render black with an alpha of 0, but all secondary effects (shadows, reflections, indirect lighting) remain. This feature requires the project settings "Alpha Output" and "Support Primitive Alpha Holdout". */
void SetbHoldout(bool Value) {}
/* Function: GetbRenderCustomDepth 
 If true, the Landscape will be rendered in the CustomDepth pass (usually used for outlines) */
bool GetbRenderCustomDepth() const {}
/* Function: SetbRenderCustomDepth 
 If true, the Landscape will be rendered in the CustomDepth pass (usually used for outlines) */
void SetbRenderCustomDepth(bool Value) {}
/* Function: GetbGenerateOverlapEvents 
 If true, Landscape will generate overlap events when other components are overlapping it (eg Begin Overlap).
Both the Landscape and the other component must have this flag enabled for overlap events to occur.

See: [Overlap Events](https://docs.unrealengine.com/InteractiveExperiences/Physics/Collision/Overview#overlapandgenerateoverlapevents)
See: UpdateOverlaps(), BeginComponentOverlap(), EndComponentOverlap() */
bool GetbGenerateOverlapEvents() const {}
/* Function: SetbGenerateOverlapEvents 
 If true, Landscape will generate overlap events when other components are overlapping it (eg Begin Overlap).
Both the Landscape and the other component must have this flag enabled for overlap events to occur.

See: [Overlap Events](https://docs.unrealengine.com/InteractiveExperiences/Physics/Collision/Overview#overlapandgenerateoverlapevents)
See: UpdateOverlaps(), BeginComponentOverlap(), EndComponentOverlap() */
void SetbGenerateOverlapEvents(bool Value) {}
/* Function: SetbBakeMaterialPositionOffsetIntoCollision 
 Whether to bake the landscape material's vertical world position offset into the collision heightfield.
              Note: Only z (vertical) offset is supported. XY offsets are ignored.
              Does not work with an XY offset map (mesh collision) */
void SetbBakeMaterialPositionOffsetIntoCollision(bool Value) {}
/* Function: SetbUsedForNavigation 
 Hints navigation system whether this landscape will ever be navigated on. true by default, but make sure to set it to false for faraway, background landscapes */
void SetbUsedForNavigation(bool Value) {}
/* Function: SetbFillCollisionUnderLandscapeForNavmesh 
 Set to true to prevent navmesh generation under the terrain geometry */
void SetbFillCollisionUnderLandscapeForNavmesh(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeProxy ALandscapeProxy::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeProxy::StaticClass() {}
}
