/* Class: AWorldDataLayers 
 Actor containing data layers instances within a world. */ 
 class AWorldDataLayers : public AInfo
{
public:
// Group: Functions

/* Function: OnDataLayerRuntimeStateChanged 
  */
void OnDataLayerRuntimeStateChanged(const UDataLayerInstance InDataLayer, EDataLayerRuntimeState InState) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AWorldDataLayers AWorldDataLayers::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AWorldDataLayers::StaticClass() {}
}
