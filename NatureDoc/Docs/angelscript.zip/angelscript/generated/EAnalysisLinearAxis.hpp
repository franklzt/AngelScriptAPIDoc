/* Class: EAnalysisLinearAxis 
  */ 
 class EAnalysisLinearAxis
{
public:
}
/* Enum: EAnalysisLinearAxis 
 
    PlusX - Enum
    PlusY - Enum
    PlusZ - Enum
    MinusX - Enum
    MinusY - Enum
    MinusZ - Enum
    EAnalysisLinearAxis_MAX - Enum */ 
 enum EAnalysisLinearAxis { 
PlusX,
PlusY,
PlusZ,
MinusX,
MinusY,
MinusZ,
EAnalysisLinearAxis_MAX, 
}