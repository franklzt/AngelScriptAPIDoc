/* Class: ANiagaraActor 
  */ 
 class ANiagaraActor : public AActor
{
public:
// Group: NiagaraActor

/* Variable: DestroyOnSystemFinish 
 Returns true if the system will destroy on finish */
bool DestroyOnSystemFinish;
/* Variable: NiagaraComponent 
 Pointer to System component */
UNiagaraComponent NiagaraComponent;
// Group: NiagaraActor

/* Function: SetDestroyOnSystemFinish 
 Set true for this actor to self-destruct when the Niagara system finishes, false otherwise */
void SetDestroyOnSystemFinish(bool bShouldDestroyOnSystemFinish) {}
/* Function: GetDestroyOnSystemFinish 
 Returns true if the system will destroy on finish */
bool GetDestroyOnSystemFinish() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANiagaraActor ANiagaraActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANiagaraActor::StaticClass() {}
}
