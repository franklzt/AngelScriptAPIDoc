/* Class: EActorSequenceObjectReferenceType 
  */ 
 class EActorSequenceObjectReferenceType
{
public:
}
/* Enum: EActorSequenceObjectReferenceType 
 
    ContextActor - Enum
    ExternalActor - Enum
    Component - Enum
    EActorSequenceObjectReferenceType_MAX - Enum */ 
 enum EActorSequenceObjectReferenceType { 
ContextActor,
ExternalActor,
Component,
EActorSequenceObjectReferenceType_MAX, 
}