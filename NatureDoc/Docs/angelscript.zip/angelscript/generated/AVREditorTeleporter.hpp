/* Class: AVREditorTeleporter 
 VR Editor teleport manager and the visual representation of the teleport */ 
 class AVREditorTeleporter : public AActor
{
public:
// Group: Variables

/* Variable: VRMode 
 The owning VR mode */
const UVREditorMode VRMode;
/* Variable: InteractorTryingTeleport 
 The interactor that started aiming to teleport */
const UViewportInteractor InteractorTryingTeleport;
// Group: Teleporter

/* Function: SetVisibility 
 Hide or show the teleporter visuals */
void SetVisibility(bool bVisible) {}
/* Function: GetInteractorTryingTeleport 
 Get the actor we're currently trying to teleport with.
Valid during aiming and teleporting. */
UViewportInteractor GetInteractorTryingTeleport() const {}
/* Function: GetSlideDelta 
 Get slide delta to push/pull or scale the teleporter */
float32 GetSlideDelta(UVREditorInteractor Interactor, bool Axis) {}
/* Function: GetVRMode 
  */
UVREditorMode GetVRMode() const {}
/* Function: Init 
 Initializes the teleporter */
void Init(UVREditorMode InMode) {}
/* Function: IsAiming 
 Whether we are currently aiming to teleport. */
bool IsAiming() const {}
/* Function: IsTeleporting 
  */
bool IsTeleporting() const {}
/* Function: SetColor 
 Sets the color for the teleporter visuals */
void SetColor(FLinearColor Color) {}
/* Function: DoTeleport 
 Do and finalize teleport. */
void DoTeleport() {}
/* Function: Shutdown 
 Shuts down the teleporter */
void Shutdown() {}
/* Function: StartAiming 
 Functions we call to handle teleporting in navigation mode */
void StartAiming(UViewportInteractor Interactor) {}
/* Function: StartTeleport 
 Start teleporting, does a ray trace with the hand passed and calculates the locations for lerp movement in Teleport */
void StartTeleport() {}
/* Function: StopAiming 
 Cancel teleport aiming mode without doing the teleport */
void StopAiming() {}
/* Function: TeleportDone 
 Called when teleport is done for cleanup */
void TeleportDone() {}
// Group: Static Functions

/* Function: Spawn 
  */
static AVREditorTeleporter AVREditorTeleporter::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVREditorTeleporter::StaticClass() {}
}
