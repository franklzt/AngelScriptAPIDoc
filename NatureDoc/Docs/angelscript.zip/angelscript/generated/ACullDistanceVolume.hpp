/* Class: ACullDistanceVolume 
  */ 
 class ACullDistanceVolume : public AVolume
{
public:
// Group: CullDistanceVolume

/* Variable: bEnabled 
 Whether the volume is currently enabled or not. */
bool bEnabled;
/* Variable: CullDistances 
 Array of size and cull distance pairs. The code will calculate the sphere diameter of a primitive's BB and look for a best
fit in this array to determine which cull distance to use. */
TArray<FCullDistanceSizePair> CullDistances;
// Group: Functions

/* Function: SetbEnabled 
 Whether the volume is currently enabled or not. */
void SetbEnabled(bool Value) {}
/* Function: GetbEnabled 
 Whether the volume is currently enabled or not. */
bool GetbEnabled() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ACullDistanceVolume ACullDistanceVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACullDistanceVolume::StaticClass() {}
}
