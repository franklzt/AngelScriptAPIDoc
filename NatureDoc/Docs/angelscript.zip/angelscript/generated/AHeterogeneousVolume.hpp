/* Class: AHeterogeneousVolume 
 A placeable actor that represents a heterogeneous volume. */ 
 class AHeterogeneousVolume : public AInfo
{
public:
// Group: Volume

/* Variable: HeterogeneousVolumeComponent 
  */
UHeterogeneousVolumeComponent HeterogeneousVolumeComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AHeterogeneousVolume AHeterogeneousVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AHeterogeneousVolume::StaticClass() {}
}
