/* Class: AWindDirectionalSource 
 Actor that provides a directional wind source. Only affects SpeedTree assets. */ 
 class AWindDirectionalSource : public AInfo
{
public:
// Group: WindDirectionalSource

/* Variable: Component 
  */
UWindDirectionalSourceComponent Component;
// Group: Static Functions

/* Function: Spawn 
  */
static AWindDirectionalSource AWindDirectionalSource::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AWindDirectionalSource::StaticClass() {}
}
