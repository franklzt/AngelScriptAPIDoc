/* Class: EBakeCurvatureTypeMode 
  */ 
 class EBakeCurvatureTypeMode
{
public:
}
/* Enum: EBakeCurvatureTypeMode 
 
    MeanAverage - Enum
    Max - Enum
    Min - Enum
    Gaussian - Enum
    EBakeCurvatureTypeMode_MAX - Enum */ 
 enum EBakeCurvatureTypeMode { 
MeanAverage,
Max,
Min,
Gaussian,
EBakeCurvatureTypeMode_MAX, 
}