/* Class: EAILockSource 
  */ 
 class EAILockSource
{
public:
}
/* Enum: EAILockSource 
 
    Animation - Enum
    Logic - Enum
    Script - Enum
    Gameplay - Enum
    MAX - Enum */ 
 enum EAILockSource { 
Animation,
Logic,
Script,
Gameplay,
MAX, 
}