/* Class: EAimMode 
  */ 
 class EAimMode
{
public:
}
/* Enum: EAimMode 
 
    AimAtTarget - Enum
    OrientToTarget - Enum
    MAX - Enum */ 
 enum EAimMode { 
AimAtTarget,
OrientToTarget,
MAX, 
}