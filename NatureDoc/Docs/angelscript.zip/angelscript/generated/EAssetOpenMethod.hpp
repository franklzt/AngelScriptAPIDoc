/* Class: EAssetOpenMethod 
  */ 
 class EAssetOpenMethod
{
public:
}
/* Enum: EAssetOpenMethod 
 
    Edit - Enum
    View - Enum
    EAssetOpenMethod_MAX - Enum */ 
 enum EAssetOpenMethod { 
Edit,
View,
EAssetOpenMethod_MAX, 
}