/* Class: ATriggerBox 
 A box shaped trigger, used to generate overlap events in the level */ 
 class ATriggerBox : public ATriggerBase
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ATriggerBox ATriggerBox::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATriggerBox::StaticClass() {}
}
