/* Class: EAIParamType 
  */ 
 class EAIParamType
{
public:
}
/* Enum: EAIParamType 
 
    Float - Enum
    Int - Enum
    Bool - Enum
    MAX - Enum */ 
 enum EAIParamType { 
Float,
Int,
Bool,
MAX, 
}