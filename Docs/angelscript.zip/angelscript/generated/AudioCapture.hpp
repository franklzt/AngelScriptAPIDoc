/* Class: AudioCapture 
  */ 
 class AudioCapture
{
public:
// Group: Audio

/* Function: Conv_AudioInputDeviceInfoToString 
 Returns the device info in a human readable format

Parameters:
    info - The audio device data to print

Returns:
    The data in a string format */
static FString AudioCapture::Conv_AudioInputDeviceInfoToString(FAudioInputDeviceInfo info) {}
/* Function: GetAvailableAudioInputDevices 
 Gets information about all audio output devices available in the system

Parameters:
    OnObtainDevicesEvent - the event to fire when the audio endpoint devices have been retrieved */
static void AudioCapture::GetAvailableAudioInputDevices(FOnAudioInputDevicesObtained OnObtainDevicesEvent = FOnAudioInputDevicesObtained ( )) {}
// Group: Audio Capture

/* Function: CreateAudioCapture 
  */
static UAudioCapture AudioCapture::CreateAudioCapture() {}
}
