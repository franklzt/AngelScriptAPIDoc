/* Class: EAssetEditorOpenLocation 
  */ 
 class EAssetEditorOpenLocation
{
public:
}
/* Enum: EAssetEditorOpenLocation 
 
    Default - Enum
    NewWindow - Enum
    MainWindow - Enum
    ContentBrowser - Enum
    LastDockedWindowOrNewWindow - Enum
    LastDockedWindowOrMainWindow - Enum
    LastDockedWindowOrContentBrowser - Enum
    EAssetEditorOpenLocation_MAX - Enum */ 
 enum EAssetEditorOpenLocation { 
Default,
NewWindow,
MainWindow,
ContentBrowser,
LastDockedWindowOrNewWindow,
LastDockedWindowOrMainWindow,
LastDockedWindowOrContentBrowser,
EAssetEditorOpenLocation_MAX, 
}