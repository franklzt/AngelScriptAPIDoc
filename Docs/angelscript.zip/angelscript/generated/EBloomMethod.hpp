/* Class: EBloomMethod 
  */ 
 class EBloomMethod
{
public:
}
/* Enum: EBloomMethod 
 
    BM_SOG - Enum
    BM_FFT - Enum
    BM_MAX - Enum */ 
 enum EBloomMethod { 
BM_SOG,
BM_FFT,
BM_MAX, 
}