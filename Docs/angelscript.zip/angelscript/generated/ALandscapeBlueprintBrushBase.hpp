/* Class: ALandscapeBlueprintBrushBase 
  */ 
 class ALandscapeBlueprintBrushBase : public AActor
{
public:
// Group: Settings

/* Variable: AffectHeightmap 
  */
bool AffectHeightmap;
/* Variable: AffectWeightmap 
  */
bool AffectWeightmap;
/* Variable: AffectVisibilityLayer 
  */
bool AffectVisibilityLayer;
/* Variable: AffectedWeightmapLayers 
  */
TArray<FName> AffectedWeightmapLayers;
/* Variable: UpdateOnPropertyChange 
  */
bool UpdateOnPropertyChange;
// Group: Landscape

/* Function: RequestLandscapeUpdate 
  */
void RequestLandscapeUpdate(bool bInUserTriggered = false) {}
// Group: Functions

/* Function: RenderLayer 
  */
UTextureRenderTarget2D RenderLayer(FLandscapeBrushParameters InParameters) {}
/* Function: Initialize 
  */
void Initialize(FTransform InLandscapeTransform, FIntPoint InLandscapeSize, FIntPoint InLandscapeRenderTargetSize) {}
/* Function: GetBlueprintRenderDependencies 
  */
void GetBlueprintRenderDependencies(TArray<UObject>& OutStreamableAssets) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeBlueprintBrushBase ALandscapeBlueprintBrushBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeBlueprintBrushBase::StaticClass() {}
}
