/* Class: APhasedAutomationActorBase 
  */ 
 class APhasedAutomationActorBase : public AActor
{
public:
// Group: Automation

/* Function: OnFunctionalTestingComplete 
  */
void OnFunctionalTestingComplete() {}
/* Function: OnFunctionalTestingBegin 
  */
void OnFunctionalTestingBegin() {}
// Group: Static Functions

/* Function: Spawn 
  */
static APhasedAutomationActorBase APhasedAutomationActorBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APhasedAutomationActorBase::StaticClass() {}
}
