/* Class: EBlendMode 
  */ 
 class EBlendMode
{
public:
}
/* Enum: EBlendMode 
 
    BLEND_Opaque - Enum
    BLEND_Masked - Enum
    BLEND_Translucent - Enum
    BLEND_Additive - Enum
    BLEND_Modulate - Enum
    BLEND_AlphaComposite - Enum
    BLEND_AlphaHoldout - Enum
    BLEND_TranslucentColoredTransmittance - Enum
    BLEND_MAX - Enum
    BLEND_TranslucentGreyTransmittance - Enum
    BLEND_ColoredTransmittanceOnly - Enum */ 
 enum EBlendMode { 
BLEND_Opaque,
BLEND_Masked,
BLEND_Translucent,
BLEND_Additive,
BLEND_Modulate,
BLEND_AlphaComposite,
BLEND_AlphaHoldout,
BLEND_TranslucentColoredTransmittance,
BLEND_MAX,
BLEND_TranslucentGreyTransmittance,
BLEND_ColoredTransmittanceOnly, 
}