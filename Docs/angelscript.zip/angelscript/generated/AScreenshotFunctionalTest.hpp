/* Class: AScreenshotFunctionalTest 
 No UI */ 
 class AScreenshotFunctionalTest : public AScreenshotFunctionalTestBase
{
public:
// Group: Camera

/* Variable: bCameraCutOnScreenshotPrep 
 Tests not relying on temporal effects can force a camera cut to flush stale data */
bool bCameraCutOnScreenshotPrep;
// Group: Static Functions

/* Function: Spawn 
  */
static AScreenshotFunctionalTest AScreenshotFunctionalTest::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AScreenshotFunctionalTest::StaticClass() {}
}
