/* Class: EAlphaChannelMode 
  */ 
 class EAlphaChannelMode
{
public:
}
/* Enum: EAlphaChannelMode 
 
    Disabled - Enum
    Enabled - Enum
    LinearColorSpaceOnly - Enum
    AllowThroughTonemapper - Enum
    EAlphaChannelMode_MAX - Enum */ 
 enum EAlphaChannelMode { 
Disabled,
Enabled,
LinearColorSpaceOnly,
AllowThroughTonemapper,
EAlphaChannelMode_MAX, 
}