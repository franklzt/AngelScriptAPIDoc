/* Class: AChaosVDGeometryContainer 
 Actor that contains Static Mesh Components used to visualize the geometry we generated from the recorded data */ 
 class AChaosVDGeometryContainer : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AChaosVDGeometryContainer AChaosVDGeometryContainer::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AChaosVDGeometryContainer::StaticClass() {}
}
