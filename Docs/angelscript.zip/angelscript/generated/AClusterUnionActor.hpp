/* Class: AClusterUnionActor 
 A lightweight actor that can be used to own a cluster union component. */ 
 class AClusterUnionActor : public AActor
{
public:
// Group: Cluster Union

/* Variable: ClusterUnion 
 The pivot used while building. */
UClusterUnionComponent ClusterUnion;
// Group: Static Functions

/* Function: Spawn 
  */
static AClusterUnionActor AClusterUnionActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AClusterUnionActor::StaticClass() {}
}
