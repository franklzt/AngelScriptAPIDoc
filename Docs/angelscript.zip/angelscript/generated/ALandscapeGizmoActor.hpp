/* Class: ALandscapeGizmoActor 
  */ 
 class ALandscapeGizmoActor : public AActor
{
public:
// Group: Gizmo

/* Variable: Height 
  */
float32 Height;
/* Variable: LengthZ 
  */
float32 LengthZ;
/* Variable: MarginZ 
  */
float32 MarginZ;
/* Variable: MinRelativeZ 
  */
float32 MinRelativeZ;
/* Variable: RelativeScaleZ 
  */
float32 RelativeScaleZ;
/* Variable: TargetLandscapeInfo 
  */
ULandscapeInfo TargetLandscapeInfo;
/* Variable: Width 
  */
float32 Width;
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscapeGizmoActor ALandscapeGizmoActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscapeGizmoActor::StaticClass() {}
}
