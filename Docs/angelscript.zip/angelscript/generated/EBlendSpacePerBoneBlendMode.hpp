/* Class: EBlendSpacePerBoneBlendMode 
  */ 
 class EBlendSpacePerBoneBlendMode
{
public:
}
/* Enum: EBlendSpacePerBoneBlendMode 
 
    ManualPerBoneOverride - Enum
    BlendProfile - Enum
    EBlendSpacePerBoneBlendMode_MAX - Enum */ 
 enum EBlendSpacePerBoneBlendMode { 
ManualPerBoneOverride,
BlendProfile,
EBlendSpacePerBoneBlendMode_MAX, 
}