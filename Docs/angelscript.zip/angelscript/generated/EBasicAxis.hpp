/* Class: EBasicAxis 
  */ 
 class EBasicAxis
{
public:
}
/* Enum: EBasicAxis 
 
    X - Enum
    Y - Enum
    Z - Enum
    NegX - Enum
    NegY - Enum
    NegZ - Enum
    EBasicAxis_MAX - Enum */ 
 enum EBasicAxis { 
X,
Y,
Z,
NegX,
NegY,
NegZ,
EBasicAxis_MAX, 
}