/* Class: EAttachLocation 
  */ 
 class EAttachLocation
{
public:
}
/* Enum: EAttachLocation 
 
    KeepRelativeOffset - Enum
    KeepWorldPosition - Enum
    SnapToTarget - Enum
    SnapToTargetIncludingScale - Enum
    EAttachLocation_MAX - Enum */ 
 enum EAttachLocation { 
KeepRelativeOffset,
KeepWorldPosition,
SnapToTarget,
SnapToTargetIncludingScale,
EAttachLocation_MAX, 
}