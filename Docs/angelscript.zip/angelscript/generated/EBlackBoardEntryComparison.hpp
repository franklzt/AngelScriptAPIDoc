/* Class: EBlackBoardEntryComparison 
  */ 
 class EBlackBoardEntryComparison
{
public:
}
/* Enum: EBlackBoardEntryComparison 
 
    Equal - Enum
    NotEqual - Enum
    EBlackBoardEntryComparison_MAX - Enum */ 
 enum EBlackBoardEntryComparison { 
Equal,
NotEqual,
EBlackBoardEntryComparison_MAX, 
}