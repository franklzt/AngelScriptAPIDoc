/* Class: AAIController 
 AIController is the base class of controllers for AI-controlled Pawns.

Controllers are non-physical actors that can be attached to a pawn to control its actions.
AIControllers manage the artificial intelligence for the pawns they control.
In networked games, they only exist on the server.

@see https://docs.unrealengine.com/latest/INT/Gameplay/Framework/Controller/ */ 
 class AAIController : public AController
{
public:
// Group: AI

/* Variable: FocalPoint 
 Retrieve the final position that controller should be looking at. */
FVector FocalPoint;
/* Variable: PerceptionComponent 
  */
UAIPerceptionComponent PerceptionComponent;
/* Variable: Blackboard 
 blackboard */
UBlackboardComponent Blackboard;
/* Variable: DefaultNavigationFilterClass 
  */
TSubclassOf<UNavigationQueryFilter> DefaultNavigationFilterClass;
/* Variable: bSetControlRotationFromPawnOrientation 
 Copy Pawn rotation to ControlRotation, if there is no focus point. */
bool bSetControlRotationFromPawnOrientation;
/* Variable: bWantsPlayerState 
 Specifies if this AI wants its own PlayerState. */
bool bWantsPlayerState;
/* Variable: bAllowStrafe 
 Is strafing allowed during movement? */
bool bAllowStrafe;
/* Variable: bSkipExtraLOSChecks 
 Skip extra line of sight traces to extremities of target being checked. */
bool bSkipExtraLOSChecks;
/* Variable: FocusActor 
 Get the focused actor. */
const AActor FocusActor;
/* Variable: BrainComponent 
 Component responsible for behaviors. */
UBrainComponent BrainComponent;
/* Variable: PathFollowingComponent 
 Component used for moving along a path. */
UPathFollowingComponent PathFollowingComponent;
/* Variable: ActionsComp 
  */
UDEPRECATED_PawnActionsComponent ActionsComp;
/* Variable: bStartAILogicOnPossess 
 By default AI's logic does not start when controlled Pawn is possessed. Setting this flag to true
    will make AI logic start when pawn is possessed */
bool bStartAILogicOnPossess;
/* Variable: bStopAILogicOnUnposses 
 By default AI's logic gets stopped when controlled Pawn is unpossessed. Setting this flag to false
    will make AI logic persist past losing control over a pawn */
bool bStopAILogicOnUnposses;
// Group: AI|Navigation

/* Variable: MoveStatus 
 Returns status of path following */
const EPathFollowingStatus MoveStatus;
/* Variable: ImmediateMoveDestination 
 Returns position of current path segment's end. */
const FVector ImmediateMoveDestination;
// Group: AI|Perception

/* Variable: AIPerceptionComponent 
  */
const UAIPerceptionComponent AIPerceptionComponent;
// Group: Variables

/* Variable: ReceiveMoveCompleted 
 Blueprint notification that we've completed the current movement request */
FAIMoveCompletedSignature ReceiveMoveCompleted;
/* Variable: DeprecatedActionsComponent 
  */
const UDEPRECATED_PawnActionsComponent DeprecatedActionsComponent;
// Group: AI

/* Function: GetFocusActor 
 Get the focused actor. */
AActor GetFocusActor() const {}
/* Function: UseBlackboard 
 Makes AI use the specified Blackboard asset & creates a Blackboard Component if one does not already exist.

Parameters:
    BlackboardAsset - The Blackboard asset to use.
    BlackboardComponent - The Blackboard component that was used or created to work with the passed-in Blackboard Asset.

Returns:
    true if we successfully linked the blackboard asset to the blackboard component. */
bool UseBlackboard(UBlackboardData BlackboardAsset, UBlackboardComponent& BlackboardComponent) {}
/* Function: RunBehaviorTree 
 Starts executing behavior tree. */
bool RunBehaviorTree(UBehaviorTree BTAsset) {}
/* Function: GetFocalPoint 
 Retrieve the final position that controller should be looking at. */
FVector GetFocalPoint() const {}
/* Function: GetFocalPointOnActor 
 Retrieve the focal point this controller should focus to on given actor. */
FVector GetFocalPointOnActor(const AActor Actor) const {}
/* Function: SetFocalPoint 
 Set the position that controller should be looking at. */
void SetFocalPoint(FVector FP) {}
/* Function: SetFocus 
 Set Focus for actor, will set FocalPoint as a result. */
void SetFocus(AActor NewFocus) {}
/* Function: ClearFocus 
 Clears Focus, will also clear FocalPoint as a result */
void ClearFocus() {}
// Group: AI|Navigation

/* Function: HasPartialPath 
 Returns true if the current PathFollowingComponent's path is partial (does not reach desired destination). */
bool HasPartialPath() const {}
/* Function: GetPathFollowingComponent 
 Returns PathFollowingComponent subobject * */
UPathFollowingComponent GetPathFollowingComponent() const {}
/* Function: GetMoveStatus 
 Returns status of path following */
EPathFollowingStatus GetMoveStatus() const {}
/* Function: GetImmediateMoveDestination 
 Returns position of current path segment's end. */
FVector GetImmediateMoveDestination() const {}
/* Function: SetPathFollowingComponent 
 Note that this function does not do any pathfollowing state transfer.
    Intended to be called as part of initialization/setup process */
void SetPathFollowingComponent(UPathFollowingComponent NewPFComponent) {}
/* Function: MoveToActor 
 Makes AI go toward specified Goal actor (destination will be continuously updated), aborts any active path following

Parameters:
    AcceptanceRadius - finish move if pawn gets close enough
    bStopOnOverlap - add pawn's radius to AcceptanceRadius
    bUsePathfinding - use navigation data to calculate path (otherwise it will go in straight line)
    bCanStrafe - set focus related flag: bAllowStrafe
    FilterClass - navigation filter for pathfinding adjustments. If none specified DefaultNavigationFilterClass will be used
    bAllowPartialPath - use incomplete path when goal can't be reached */
EPathFollowingRequestResult MoveToActor(AActor Goal, float32 AcceptanceRadius = - 1.000000, bool bStopOnOverlap = true, bool bUsePathfinding = true, bool bCanStrafe = true, TSubclassOf<UNavigationQueryFilter> FilterClass = nullptr, bool bAllowPartialPath = true) {}
/* Function: MoveToLocation 
 Makes AI go toward specified Dest location, aborts any active path following

Parameters:
    AcceptanceRadius - finish move if pawn gets close enough
    bStopOnOverlap - add pawn's radius to AcceptanceRadius
    bUsePathfinding - use navigation data to calculate path (otherwise it will go in straight line)
    bProjectDestinationToNavigation - project location on navigation data before using it
    bCanStrafe - set focus related flag: bAllowStrafe
    FilterClass - navigation filter for pathfinding adjustments. If none specified DefaultNavigationFilterClass will be used
    bAllowPartialPath - use incomplete path when goal can't be reached */
EPathFollowingRequestResult MoveToLocation(FVector Dest, float32 AcceptanceRadius = - 1.000000, bool bStopOnOverlap = true, bool bUsePathfinding = true, bool bProjectDestinationToNavigation = false, bool bCanStrafe = true, TSubclassOf<UNavigationQueryFilter> FilterClass = nullptr, bool bAllowPartialPath = true) {}
/* Function: SetMoveBlockDetection 
 Updates state of movement block detection. */
void SetMoveBlockDetection(bool bEnable) {}
// Group: AI|Perception

/* Function: GetAIPerceptionComponent 
  */
UAIPerceptionComponent GetAIPerceptionComponent() {}
// Group: AI|Tasks

/* Function: ClaimTaskResource 
  */
void ClaimTaskResource(TSubclassOf<UGameplayTaskResource> ResourceClass) {}
/* Function: UnclaimTaskResource 
  */
void UnclaimTaskResource(TSubclassOf<UGameplayTaskResource> ResourceClass) {}
// Group: Functions

/* Function: GetDeprecatedActionsComponent 
  */
UDEPRECATED_PawnActionsComponent GetDeprecatedActionsComponent() const {}
/* Function: GetbSkipExtraLOSChecks 
 Skip extra line of sight traces to extremities of target being checked. */
bool GetbSkipExtraLOSChecks() const {}
/* Function: GetActionsComp 
  */
UDEPRECATED_PawnActionsComponent GetActionsComp() const {}
/* Function: GetbStartAILogicOnPossess 
 By default AI's logic does not start when controlled Pawn is possessed. Setting this flag to true
    will make AI logic start when pawn is possessed */
bool GetbStartAILogicOnPossess() const {}
/* Function: SetbStartAILogicOnPossess 
 By default AI's logic does not start when controlled Pawn is possessed. Setting this flag to true
    will make AI logic start when pawn is possessed */
void SetbStartAILogicOnPossess(bool Value) {}
/* Function: GetbStopAILogicOnUnposses 
 By default AI's logic gets stopped when controlled Pawn is unpossessed. Setting this flag to false
    will make AI logic persist past losing control over a pawn */
bool GetbStopAILogicOnUnposses() const {}
/* Function: SetbStopAILogicOnUnposses 
 By default AI's logic gets stopped when controlled Pawn is unpossessed. Setting this flag to false
    will make AI logic persist past losing control over a pawn */
void SetbStopAILogicOnUnposses(bool Value) {}
/* Function: OnUsingBlackBoard 
  */
void OnUsingBlackBoard(UBlackboardComponent BlackboardComp, UBlackboardData BlackboardAsset) {}
/* Function: SetbSkipExtraLOSChecks 
 Skip extra line of sight traces to extremities of target being checked. */
void SetbSkipExtraLOSChecks(bool Value) {}
/* Function: GetbAllowStrafe 
 Is strafing allowed during movement? */
bool GetbAllowStrafe() const {}
/* Function: SetbAllowStrafe 
 Is strafing allowed during movement? */
void SetbAllowStrafe(bool Value) {}
/* Function: GetbWantsPlayerState 
 Specifies if this AI wants its own PlayerState. */
bool GetbWantsPlayerState() const {}
/* Function: SetbWantsPlayerState 
 Specifies if this AI wants its own PlayerState. */
void SetbWantsPlayerState(bool Value) {}
/* Function: GetbSetControlRotationFromPawnOrientation 
 Copy Pawn rotation to ControlRotation, if there is no focus point. */
bool GetbSetControlRotationFromPawnOrientation() const {}
/* Function: SetbSetControlRotationFromPawnOrientation 
 Copy Pawn rotation to ControlRotation, if there is no focus point. */
void SetbSetControlRotationFromPawnOrientation(bool Value) {}
/* Function: SetActionsComp 
  */
void SetActionsComp(UDEPRECATED_PawnActionsComponent Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AAIController AAIController::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AAIController::StaticClass() {}
}
