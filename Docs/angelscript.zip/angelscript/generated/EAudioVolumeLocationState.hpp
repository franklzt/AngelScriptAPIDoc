/* Class: EAudioVolumeLocationState 
  */ 
 class EAudioVolumeLocationState
{
public:
}
/* Enum: EAudioVolumeLocationState 
 
    InsideTheVolume - Enum
    OutsideTheVolume - Enum
    EAudioVolumeLocationState_MAX - Enum */ 
 enum EAudioVolumeLocationState { 
InsideTheVolume,
OutsideTheVolume,
EAudioVolumeLocationState_MAX, 
}