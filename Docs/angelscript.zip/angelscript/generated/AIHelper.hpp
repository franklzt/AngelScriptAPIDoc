/* Class: AIHelper 
  */ 
 class AIHelper
{
public:
// Group: AI

/* Function: IsValidAILocation 
  */
static bool AIHelper::IsValidAILocation(FVector Location) {}
/* Function: GetBlackboard 
  */
static UBlackboardComponent AIHelper::GetBlackboard(AActor Target) {}
/* Function: GetCurrentPath 
 Returns a NEW UOBJECT that is a COPY of navigation path given controller is currently using.
    The result being a copy means you won't be able to influence agent's pathfollowing
    by manipulating received path.
    Please use GetCurrentPathPoints if you only need the array of path points. */
static UNavigationPath AIHelper::GetCurrentPath(AController Controller) {}
/* Function: GetCurrentPathIndex 
 Return the path index the given controller is currently at. Returns INDEX_NONE if no path. */
static int AIHelper::GetCurrentPathIndex(const AController Controller) {}
/* Function: GetCurrentPathPoints 
 Returns an array of navigation path points given controller is currently using. */
static const TArray<FVector> AIHelper::GetCurrentPathPoints(AController Controller) {}
/* Function: GetNextNavLinkIndex 
 Return the path index of the next nav link for the current path of the given controller. Returns INDEX_NONE if no path or no incoming nav link. */
static int AIHelper::GetNextNavLinkIndex(const AController Controller) {}
/* Function: IsValidAIDirection 
  */
static bool AIHelper::IsValidAIDirection(FVector DirectionVector) {}
/* Function: GetAIController 
 The way it works exactly is if the actor passed in is a pawn, then the function retrieves
    pawn's controller cast to AIController. Otherwise the function returns actor cast to AIController. */
static AAIController AIHelper::GetAIController(AActor ControlledActor) {}
/* Function: IsValidAIRotation 
  */
static bool AIHelper::IsValidAIRotation(FRotator Rotation) {}
/* Function: SendAIMessage 
  */
static void AIHelper::SendAIMessage(APawn Target, FName Message, UObject MessageSource, bool bSuccess = true) {}
/* Function: SpawnAIFromClass 
 Spawns AI agent of a given class. The PawnClass needs to have AIController
set for the function to spawn a controller as well.

Parameters:
    BehaviorTree - if set, and the function has successfully spawned and AI controller, this BehaviorTree asset will be assigned to the AI controller, and run.
    Owner - lets you spawn the AI in a sublevel rather than in the persistent level (which is the default behavior). */
static APawn AIHelper::SpawnAIFromClass(TSubclassOf<APawn> PawnClass, UBehaviorTree BehaviorTree, FVector Location, FRotator Rotation = FRotator ( ), bool bNoCollisionFail = false, AActor Owner = nullptr) {}
// Group: AI|Navigation

/* Function: SimpleMoveToLocation 
  */
static void AIHelper::SimpleMoveToLocation(AController Controller, FVector Goal) {}
/* Function: SimpleMoveToActor 
  */
static void AIHelper::SimpleMoveToActor(AController Controller, const AActor Goal) {}
// Group: Animation

/* Function: UnlockAIResourcesWithAnimation 
 unlocks indicated AI resources of animated pawn. Will unlock only animation-locked resources */
static void AIHelper::UnlockAIResourcesWithAnimation(UAnimInstance AnimInstance, bool bUnlockMovement, bool UnlockAILogic) {}
/* Function: LockAIResourcesWithAnimation 
 locks indicated AI resources of animated pawn */
static void AIHelper::LockAIResourcesWithAnimation(UAnimInstance AnimInstance, bool bLockMovement, bool LockAILogic) {}
}
