/* Class: AControlRigShapeActor 
 An actor used to represent a rig control */ 
 class AControlRigShapeActor : public AActor
{
public:
// Group: ControlRig|Shape

/* Variable: GlobalTransform 
  */
FTransform GlobalTransform;
/* Variable: bSelected 
 Whether this control is selected */
bool bSelected;
/* Variable: bHovered 
 Whether this control is hovered */
bool bHovered;
// Group: StaticMesh

/* Variable: StaticMeshComponent 
 this is visual representation of the transform */
UStaticMeshComponent StaticMeshComponent;
// Group: ControlRig|Shape

/* Function: SetGlobalTransform 
 this returns root component transform based on attach
when there is no attach, it is based on 0 */
void SetGlobalTransform(FTransform InTransform) {}
/* Function: GetGlobalTransform 
  */
FTransform GetGlobalTransform() const {}
// Group: Functions

/* Function: SetHovered 
 Set the control to be hovered */
void SetHovered(bool bInHovered) {}
/* Function: IsSelectedInEditor 
 Get whether the control is selected/unselected */
bool IsSelectedInEditor() const {}
/* Function: OnEnabledChanged 
 Event called when the enabled state of this control has changed */
void OnEnabledChanged(bool bIsEnabled) {}
/* Function: OnHoveredChanged 
 Event called when the hovered state of this control has changed */
void OnHoveredChanged(bool bIsSelected) {}
/* Function: OnManipulatingChanged 
 Event called when the manipulating state of this control has changed */
void OnManipulatingChanged(bool bIsManipulating) {}
/* Function: OnSelectionChanged 
 Event called when the selection state of this control has changed */
void OnSelectionChanged(bool bIsSelected) {}
/* Function: OnTransformChanged 
 Event called when the transform of this control has changed */
void OnTransformChanged(FTransform NewTransform) {}
/* Function: SetEnabled 
 Set the control to be enabled/disabled */
void SetEnabled(bool bInEnabled) {}
/* Function: IsEnabled 
 Get whether the control is enabled/disabled */
bool IsEnabled() const {}
/* Function: IsHovered 
 Get whether the control is hovered */
bool IsHovered() const {}
/* Function: SetSelectable 
 Set the control to be selected/unselected */
void SetSelectable(bool bInSelectable) {}
/* Function: SetSelected 
 Set the control to be selected/unselected */
void SetSelected(bool bInSelected) {}
/* Function: GetbSelected 
 Whether this control is selected */
bool GetbSelected() const {}
/* Function: SetbSelected 
 Whether this control is selected */
void SetbSelected(bool bInSelected) {}
/* Function: GetbHovered 
 Whether this control is hovered */
bool GetbHovered() const {}
/* Function: SetbHovered 
 Whether this control is hovered */
void SetbHovered(bool bInHovered) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AControlRigShapeActor AControlRigShapeActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AControlRigShapeActor::StaticClass() {}
}
