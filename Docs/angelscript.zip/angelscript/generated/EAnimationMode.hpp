/* Class: EAnimationMode 
  */ 
 class EAnimationMode
{
public:
}
/* Enum: EAnimationMode 
 
    AnimationBlueprint - Enum
    AnimationSingleNode - Enum
    AnimationCustomMode - Enum
    EAnimationMode_MAX - Enum */ 
 enum EAnimationMode { 
AnimationBlueprint,
AnimationSingleNode,
AnimationCustomMode,
EAnimationMode_MAX, 
}