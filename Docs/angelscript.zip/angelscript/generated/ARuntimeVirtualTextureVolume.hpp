/* Class: ARuntimeVirtualTextureVolume 
 Actor used to place a URuntimeVirtualTexture in the world. */ 
 class ARuntimeVirtualTextureVolume : public AActor
{
public:
// Group: VirtualTexture

/* Variable: VirtualTextureComponent 
 Component that owns the runtime virtual texture. */
URuntimeVirtualTextureComponent VirtualTextureComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ARuntimeVirtualTextureVolume ARuntimeVirtualTextureVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ARuntimeVirtualTextureVolume::StaticClass() {}
}
