/* Class: ATextRenderActor 
  */ 
 class ATextRenderActor : public AActor
{
public:
// Group: TextRenderActor

/* Variable: TextRender 
 Component to render a text in 3d with a font */
UTextRenderComponent TextRender;
// Group: Static Functions

/* Function: Spawn 
  */
static ATextRenderActor ATextRenderActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATextRenderActor::StaticClass() {}
}
