/* Class: ABrushShape 
 A brush that acts as a template for geometry mode modifiers like "Lathe". */ 
 class ABrushShape : public ABrush
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ABrushShape ABrushShape::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ABrushShape::StaticClass() {}
}
