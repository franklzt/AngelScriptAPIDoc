/* Class: ANavigationData 
 Represents abstract Navigation Data (sub-classed as NavMesh, NavGraph, etc)
Used as a common interface for all navigation types handled by NavigationSystem */ 
 class ANavigationData : public AActor
{
public:
// Group: Runtime

/* Variable: ObservedPathsTickInterval 
 all observed paths will be processed every ObservedPathsTickInterval seconds */
float32 ObservedPathsTickInterval;
/* Variable: RuntimeGeneration 
 Navigation data runtime generation options */
ERuntimeGenerationType RuntimeGeneration;
// Group: Functions

/* Function: SetbForceRebuildOnLoad 
 By default navigation will skip the first update after being successfully loaded
setting bForceRebuildOnLoad to false can override this behavior */
void SetbForceRebuildOnLoad(bool Value) {}
/* Function: SetbAutoDestroyWhenNoNavigation 
 Should this instance auto-destroy when there's no navigation system on
    world when it gets created/loaded */
void SetbAutoDestroyWhenNoNavigation(bool Value) {}
/* Function: SetbCanBeMainNavData 
 If set, navigation data can act as default one in navigation system's queries */
void SetbCanBeMainNavData(bool Value) {}
/* Function: SetbEnableDrawing 
 if set to true then this navigation data will be drawing itself when requested as part of "show navigation" */
void SetbEnableDrawing(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANavigationData ANavigationData::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavigationData::StaticClass() {}
}
