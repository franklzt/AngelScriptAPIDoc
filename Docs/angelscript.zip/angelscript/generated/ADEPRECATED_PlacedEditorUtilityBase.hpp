/* Class: ADEPRECATED_PlacedEditorUtilityBase 
  */ 
 class ADEPRECATED_PlacedEditorUtilityBase : public AActor
{
public:
// Group: Config

/* Variable: HelpText 
  */
FString HelpText;
// Group: Development|Editor

/* Variable: SelectionSet 
 Returns the current selection set in the editor.  Note that for non-editor builds, this will return an empty array */
const TArray<AActor> SelectionSet;
// Group: Development|Editor

/* Function: SelectNothing 
 Selects nothing in the editor (another way to clear the selection) */
void SelectNothing() {}
/* Function: GetActorReference 
 Attempts to find the actor specified by PathToActor in the current editor world

Parameters:
    PathToActor - The path to the actor (e.g. PersistentLevel.PlayerStart)

Returns:
    A reference to the actor, or none if it wasn't found */
AActor GetActorReference(FString PathToActor) {}
/* Function: GetLevelViewportCameraInfo 
 Gets information about the camera position for the primary level editor viewport.  In non-editor builds, these will be zeroed

Parameters:
    CameraLocation - (out) Current location of the level editing viewport camera, or zero if none found
    CameraRotation - (out) Current rotation of the level editing viewport camera, or zero if none found

Returns:
    Whether or not we were able to get a camera for a level editing viewport */
bool GetLevelViewportCameraInfo(FVector& CameraLocation, FRotator& CameraRotation) {}
/* Function: GetSelectionSet 
 Returns the current selection set in the editor.  Note that for non-editor builds, this will return an empty array */
TArray<AActor> GetSelectionSet() {}
/* Function: ClearActorSelectionSet 
 Remove all actors from the selection set */
void ClearActorSelectionSet() {}
/* Function: SetActorSelectionState 
 Set the selection state for the selected actor */
void SetActorSelectionState(AActor Actor, bool bShouldBeSelected) {}
/* Function: SetLevelViewportCameraInfo 
 Sets information about the camera position for the primary level editor viewport.

Parameters:
    CameraLocation - Location the camera will be moved to.
    CameraRotation - Rotation the camera will be set to. */
void SetLevelViewportCameraInfo(FVector CameraLocation, FRotator CameraRotation) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ADEPRECATED_PlacedEditorUtilityBase ADEPRECATED_PlacedEditorUtilityBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADEPRECATED_PlacedEditorUtilityBase::StaticClass() {}
}
