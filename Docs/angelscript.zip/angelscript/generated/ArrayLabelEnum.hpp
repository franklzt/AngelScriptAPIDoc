/* Class: ArrayLabelEnum 
  */ 
 class ArrayLabelEnum
{
public:
}
/* Enum: ArrayLabelEnum 
 
    ArrayIndex0 - Enum
    ArrayIndex1 - Enum
    ArrayIndex2 - Enum
    ArrayIndex3 - Enum
    ArrayIndex4 - Enum
    ArrayIndex5 - Enum
    ArrayIndex_MAX - Enum
    ArrayLabelEnum_MAX - Enum */ 
 enum ArrayLabelEnum { 
ArrayIndex0,
ArrayIndex1,
ArrayIndex2,
ArrayIndex3,
ArrayIndex4,
ArrayIndex5,
ArrayIndex_MAX,
ArrayLabelEnum_MAX, 
}