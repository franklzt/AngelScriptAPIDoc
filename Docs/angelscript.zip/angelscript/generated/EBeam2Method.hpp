/* Class: EBeam2Method 
  */ 
 class EBeam2Method
{
public:
}
/* Enum: EBeam2Method 
 
    PEB2M_Distance - Enum
    PEB2M_Target - Enum
    PEB2M_Branch - Enum
    PEB2M_MAX - Enum */ 
 enum EBeam2Method { 
PEB2M_Distance,
PEB2M_Target,
PEB2M_Branch,
PEB2M_MAX, 
}