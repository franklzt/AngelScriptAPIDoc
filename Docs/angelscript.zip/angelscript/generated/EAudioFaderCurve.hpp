/* Class: EAudioFaderCurve 
  */ 
 class EAudioFaderCurve
{
public:
}
/* Enum: EAudioFaderCurve 
 
    Linear - Enum
    Logarithmic - Enum
    SCurve - Enum
    Sin - Enum
    Count - Enum
    EAudioFaderCurve_MAX - Enum */ 
 enum EAudioFaderCurve { 
Linear,
Logarithmic,
SCurve,
Sin,
Count,
EAudioFaderCurve_MAX, 
}