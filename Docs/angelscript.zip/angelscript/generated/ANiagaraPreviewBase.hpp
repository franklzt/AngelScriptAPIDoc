/* Class: ANiagaraPreviewBase 
 Base actor for preview actors used in UNiagaraPreviewAxis. */ 
 class ANiagaraPreviewBase : public AActor
{
public:
// Group: Niagara|Preview

/* Function: SetSystem 
 AActor Interface End */
void SetSystem(UNiagaraSystem InSystem) {}
/* Function: SetLabelText 
  */
void SetLabelText(FText InXAxisText, FText InYAxisText) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANiagaraPreviewBase ANiagaraPreviewBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANiagaraPreviewBase::StaticClass() {}
}
