/* Class: EAssetTypeActivationOpenedMethod 
  */ 
 class EAssetTypeActivationOpenedMethod
{
public:
}
/* Enum: EAssetTypeActivationOpenedMethod 
 
    Edit - Enum
    View - Enum
    EAssetTypeActivationOpenedMethod_MAX - Enum */ 
 enum EAssetTypeActivationOpenedMethod { 
Edit,
View,
EAssetTypeActivationOpenedMethod_MAX, 
}