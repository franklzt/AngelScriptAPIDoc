/* Class: ConstraintsScripting 
  */ 
 class ConstraintsScripting
{
public:
// Group: Editor Scripting | Sequencer Tools | Control Rig | Constraints

/* Function: CreateFromType 
 Create Constraint based on the specified type.

Parameters:
    InWorld - World to create the constraint
    InType - The type of constraint

Returns:
    return The constraint object */
static UTickableTransformConstraint ConstraintsScripting::CreateFromType(UWorld InWorld, ETransformConstraintType InType) {}
/* Function: CreateTransformableComponentHandle 
 Create the transformable handle that deals with getting and setting transforms on this scene component

Parameters:
    InSceneComponent - World to create the constraint
    InSocketName - Optional name of the socket to get the transform

Returns:
    returns the handle for this scene component */
static UTransformableComponentHandle ConstraintsScripting::CreateTransformableComponentHandle(UWorld InWorld, USceneComponent InSceneComponent, FName InSocketName) {}
/* Function: CreateTransformableHandle 
 Create the transformable handle that deals with getting and setting transforms on this object

Parameters:
    InObject - World to create the constraint
    InAttachmentName - Optional name of the attachment to get the transform. Not that this can represent a scene component's socket name or a control rig control for example.

Returns:
    returns the handle for this scene component */
static UTransformableHandle ConstraintsScripting::CreateTransformableHandle(UWorld InWorld, UObject InObject, FName InAttachmentName = NAME_None) {}
/* Function: GetConstraintsArray 
 Get a copy of the constraints in the current world

Parameters:
    InWorld - World we are in

Returns:
    Copy of the constraints in the level */
static TArray<UTickableConstraint> ConstraintsScripting::GetConstraintsArray(UWorld InWorld) {}
/* Function: RemoveConstraint 
 Remove constraint at specified index

Parameters:
    InWorld - World to remove the constraint
    InIndex - Index to remove from

Returns:
    return If constraint removed correctly */
static bool ConstraintsScripting::RemoveConstraint(UWorld InWorld, int InIndex) {}
/* Function: RemoveThisConstraint 
 Remove specified constraint

Parameters:
    InWorld - World to remove the constraint
    InTickableConstraint - Constraint to remove

Returns:
    return If constraint removed correctly */
static bool ConstraintsScripting::RemoveThisConstraint(UWorld InWorld, UTickableConstraint InTickableConstraint) {}
/* Function: AddConstraint 
  */
static bool ConstraintsScripting::AddConstraint(UWorld InWorld, UTransformableHandle InParentHandle, UTransformableHandle InChildHandle, UTickableTransformConstraint InConstraint, bool bMaintainOffset) {}
}
