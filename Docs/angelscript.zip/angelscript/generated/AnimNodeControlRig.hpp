/* Class: AnimNodeControlRig 
  */ 
 class AnimNodeControlRig
{
public:
// Group: Animation|ControlRig

/* Function: ConvertToControlRigPure 
 Get a control rig context from an anim node context (pure) */
static void AnimNodeControlRig::ConvertToControlRigPure(FAnimNodeReference Node, FControlRigReference& ControlRig, bool& Result) {}
/* Function: SetControlRigClass 
 Set the control rig class on the node */
static FControlRigReference AnimNodeControlRig::SetControlRigClass(FControlRigReference Node, TSubclassOf<UControlRig> ControlRigClass) {}
/* Function: ConvertToControlRig 
 Get a control rig context from an anim node context */
static FControlRigReference AnimNodeControlRig::ConvertToControlRig(FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result) {}
}
