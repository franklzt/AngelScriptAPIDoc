/* Class: AndroidPermission 
  */ 
 class AndroidPermission
{
public:
// Group: AndroidPermission

/* Function: CheckPermission 
 check if the permission is already granted */
static bool AndroidPermission::CheckPermission(FString permission) {}
/* Function: AcquirePermissions 
 try to acquire permissions and return a singleton callback proxy object containing OnPermissionsGranted delegate */
static UAndroidPermissionCallbackProxy AndroidPermission::AcquirePermissions(TArray<FString> permissions) {}
}
