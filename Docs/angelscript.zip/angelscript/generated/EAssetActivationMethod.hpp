/* Class: EAssetActivationMethod 
  */ 
 class EAssetActivationMethod
{
public:
}
/* Enum: EAssetActivationMethod 
 
    DoubleClicked - Enum
    Opened - Enum
    Previewed - Enum
    EAssetActivationMethod_MAX - Enum */ 
 enum EAssetActivationMethod { 
DoubleClicked,
Opened,
Previewed,
EAssetActivationMethod_MAX, 
}