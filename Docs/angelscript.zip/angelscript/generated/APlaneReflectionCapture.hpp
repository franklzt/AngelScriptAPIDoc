/* Class: APlaneReflectionCapture 
  */ 
 class APlaneReflectionCapture : public AReflectionCapture
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static APlaneReflectionCapture APlaneReflectionCapture::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APlaneReflectionCapture::StaticClass() {}
}
