/* Class: EAudioParameterType 
  */ 
 class EAudioParameterType
{
public:
}
/* Enum: EAudioParameterType 
 
    None - Enum
    Boolean - Enum
    Integer - Enum
    Float - Enum
    String - Enum
    Object - Enum
    NoneArray - Enum
    BooleanArray - Enum
    IntegerArray - Enum
    FloatArray - Enum
    StringArray - Enum
    ObjectArray - Enum
    Trigger - Enum
    COUNT - Enum
    EAudioParameterType_MAX - Enum */ 
 enum EAudioParameterType { 
None,
Boolean,
Integer,
Float,
String,
Object,
NoneArray,
BooleanArray,
IntegerArray,
FloatArray,
StringArray,
ObjectArray,
Trigger,
COUNT,
EAudioParameterType_MAX, 
}