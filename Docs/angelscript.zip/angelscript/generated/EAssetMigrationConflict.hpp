/* Class: EAssetMigrationConflict 
  */ 
 class EAssetMigrationConflict
{
public:
}
/* Enum: EAssetMigrationConflict 
 
    Skip - Enum
    Overwrite - Enum
    Cancel - Enum
    EAssetMigrationConflict_MAX - Enum */ 
 enum EAssetMigrationConflict { 
Skip,
Overwrite,
Cancel,
EAssetMigrationConflict_MAX, 
}