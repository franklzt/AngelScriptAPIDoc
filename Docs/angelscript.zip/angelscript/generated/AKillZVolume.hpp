/* Class: AKillZVolume 
 KillZVolume is a volume used to determine when actors should be killed. Killing logic is overridden in FellOutOfWorld

@see FellOutOfWorld */ 
 class AKillZVolume : public APhysicsVolume
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AKillZVolume AKillZVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AKillZVolume::StaticClass() {}
}
