/* Class: ALevelSequenceMediaController 
 Replicated actor class that is responsible for instigating various cinematic assets (Media, Audio, Level Sequences) in a synchronized fasion */ 
 class ALevelSequenceMediaController : public AActor
{
public:
// Group: Synchronization

/* Variable: MediaComponent 
 Media component that contains the media player to synchronize with */
UMediaComponent MediaComponent;
/* Variable: Sequence 
 Pointer to the sequence actor to use for playback */
ALevelSequenceActor Sequence;
/* Variable: ServerStartTimeSeconds 
 Replicated time at which the server started the sequence (taken from AGameStateBase::GetServerWorldTimeSeconds) */
float32 ServerStartTimeSeconds;
// Group: Synchronization

/* Function: GetSequence 
 Access this actor's Level Sequence Actor */
ALevelSequenceActor GetSequence() const {}
/* Function: Play 
  */
void Play() {}
/* Function: SynchronizeToServer 
 Forcibly synchronize the sequence to the server's position if it has diverged by more than the specified threshold */
void SynchronizeToServer(float32 DesyncThresholdSeconds = 2.000000) {}
/* Function: GetMediaComponent 
 Access this actor's media component */
UMediaComponent GetMediaComponent() const {}
// Group: Functions

/* Function: SetMediaComponent 
 Media component that contains the media player to synchronize with */
void SetMediaComponent(UMediaComponent Value) {}
/* Function: SetSequence 
 Pointer to the sequence actor to use for playback */
void SetSequence(ALevelSequenceActor Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALevelSequenceMediaController ALevelSequenceMediaController::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALevelSequenceMediaController::StaticClass() {}
}
