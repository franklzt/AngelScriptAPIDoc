/* Class: EArithmeticKeyOperation 
  */ 
 class EArithmeticKeyOperation
{
public:
}
/* Enum: EArithmeticKeyOperation 
 
    Equal - Enum
    NotEqual - Enum
    Less - Enum
    LessOrEqual - Enum
    Greater - Enum
    GreaterOrEqual - Enum
    EArithmeticKeyOperation_MAX - Enum */ 
 enum EArithmeticKeyOperation { 
Equal,
NotEqual,
Less,
LessOrEqual,
Greater,
GreaterOrEqual,
EArithmeticKeyOperation_MAX, 
}