/* Class: EAttributeEditorToolActions 
  */ 
 class EAttributeEditorToolActions
{
public:
}
/* Enum: EAttributeEditorToolActions 
 
    NoAction - Enum
    ClearNormals - Enum
    DiscardTangents - Enum
    ClearAllUVs - Enum
    ClearSelectedUVs - Enum
    AddUVSet - Enum
    DeleteSelectedUVSet - Enum
    DuplicateSelectedUVSet - Enum
    AddAttribute - Enum
    AddWeightMapLayer - Enum
    AddPolyGroupLayer - Enum
    DeleteAttribute - Enum
    ClearAttribute - Enum
    CopyAttributeFromTo - Enum
    EnableLightmapUVs - Enum
    DisableLightmapUVs - Enum
    ResetLightmapUVChannels - Enum
    EAttributeEditorToolActions_MAX - Enum */ 
 enum EAttributeEditorToolActions { 
NoAction,
ClearNormals,
DiscardTangents,
ClearAllUVs,
ClearSelectedUVs,
AddUVSet,
DeleteSelectedUVSet,
DuplicateSelectedUVSet,
AddAttribute,
AddWeightMapLayer,
AddPolyGroupLayer,
DeleteAttribute,
ClearAttribute,
CopyAttributeFromTo,
EnableLightmapUVs,
DisableLightmapUVs,
ResetLightmapUVChannels,
EAttributeEditorToolActions_MAX, 
}