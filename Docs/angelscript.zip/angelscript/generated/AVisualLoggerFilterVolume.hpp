/* Class: AVisualLoggerFilterVolume 
 A volume to be placed in the level while browsing visual logger output. */ 
 class AVisualLoggerFilterVolume : public AVolume
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AVisualLoggerFilterVolume AVisualLoggerFilterVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVisualLoggerFilterVolume::StaticClass() {}
}
