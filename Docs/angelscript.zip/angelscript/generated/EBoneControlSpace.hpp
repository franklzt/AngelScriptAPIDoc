/* Class: EBoneControlSpace 
  */ 
 class EBoneControlSpace
{
public:
}
/* Enum: EBoneControlSpace 
 
    BCS_WorldSpace - Enum
    BCS_ComponentSpace - Enum
    BCS_ParentBoneSpace - Enum
    BCS_BoneSpace - Enum
    BCS_MAX - Enum */ 
 enum EBoneControlSpace { 
BCS_WorldSpace,
BCS_ComponentSpace,
BCS_ParentBoneSpace,
BCS_BoneSpace,
BCS_MAX, 
}