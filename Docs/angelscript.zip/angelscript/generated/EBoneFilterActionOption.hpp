/* Class: EBoneFilterActionOption 
  */ 
 class EBoneFilterActionOption
{
public:
}
/* Enum: EBoneFilterActionOption 
 
    Remove - Enum
    Keep - Enum
    Invalid - Enum
    EBoneFilterActionOption_MAX - Enum */ 
 enum EBoneFilterActionOption { 
Remove,
Keep,
Invalid,
EBoneFilterActionOption_MAX, 
}