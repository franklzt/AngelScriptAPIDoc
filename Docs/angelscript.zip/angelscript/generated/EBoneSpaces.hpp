/* Class: EBoneSpaces 
  */ 
 class EBoneSpaces
{
public:
}
/* Enum: EBoneSpaces 
 
    WorldSpace - Enum
    ComponentSpace - Enum
    EBoneSpaces_MAX - Enum */ 
 enum EBoneSpaces { 
WorldSpace,
ComponentSpace,
EBoneSpaces_MAX, 
}