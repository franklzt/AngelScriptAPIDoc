/* Class: APaperFlipbookActor 
 An instance of a UPaperFlipbook in a level.

This actor is created when you drag a flipbook asset from the content browser into the level, and
it is just a thin wrapper around a UPaperFlipbookComponent that actually references the asset. */ 
 class APaperFlipbookActor : public AActor
{
public:
// Group: Sprite

/* Variable: RenderComponent 
  */
UPaperFlipbookComponent RenderComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static APaperFlipbookActor APaperFlipbookActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APaperFlipbookActor::StaticClass() {}
}
