/* Class: EAppMsgCategory 
  */ 
 class EAppMsgCategory
{
public:
}
/* Enum: EAppMsgCategory 
 
    Warning - Enum
    Error - Enum
    Success - Enum
    Info - Enum
    EAppMsgCategory_MAX - Enum */ 
 enum EAppMsgCategory { 
Warning,
Error,
Success,
Info,
EAppMsgCategory_MAX, 
}