/* Class: APartyBeaconHost 
 A beacon host used for taking reservations for an existing game session */ 
 class APartyBeaconHost : public AOnlineBeaconHostObject
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static APartyBeaconHost APartyBeaconHost::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APartyBeaconHost::StaticClass() {}
}
