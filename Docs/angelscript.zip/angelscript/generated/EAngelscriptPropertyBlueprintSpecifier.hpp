/* Class: EAngelscriptPropertyBlueprintSpecifier 
  */ 
 class EAngelscriptPropertyBlueprintSpecifier
{
public:
}
/* Enum: EAngelscriptPropertyBlueprintSpecifier 
 
    BlueprintReadWrite - Enum
    BlueprintReadOnly - Enum
    BlueprintHidden - Enum
    EAngelscriptPropertyBlueprintSpecifier_MAX - Enum */ 
 enum EAngelscriptPropertyBlueprintSpecifier { 
BlueprintReadWrite,
BlueprintReadOnly,
BlueprintHidden,
EAngelscriptPropertyBlueprintSpecifier_MAX, 
}