/* Class: AGeometryCollectionISMPoolActor 
  */ 
 class AGeometryCollectionISMPoolActor : public AActor
{
public:
// Group: ISMPoolActor

/* Variable: ISMPoolDebugDrawComp 
  */
UGeometryCollectionISMPoolDebugDrawComponent ISMPoolDebugDrawComp;
/* Variable: ISMPoolComp 
  */
UGeometryCollectionISMPoolComponent ISMPoolComp;
// Group: Static Functions

/* Function: Spawn 
  */
static AGeometryCollectionISMPoolActor AGeometryCollectionISMPoolActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGeometryCollectionISMPoolActor::StaticClass() {}
}
