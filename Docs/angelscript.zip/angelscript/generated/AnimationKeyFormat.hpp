/* Class: AnimationKeyFormat 
  */ 
 class AnimationKeyFormat
{
public:
}
/* Enum: AnimationKeyFormat 
 
    AKF_ConstantKeyLerp - Enum
    AKF_VariableKeyLerp - Enum
    AKF_PerTrackCompression - Enum
    AKF_MAX - Enum */ 
 enum AnimationKeyFormat { 
AKF_ConstantKeyLerp,
AKF_VariableKeyLerp,
AKF_PerTrackCompression,
AKF_MAX, 
}