/* Class: CameraLensEffectInterfaceClassSupport 
  */ 
 class CameraLensEffectInterfaceClassSupport
{
public:
// Group: Lens Effect

/* Function: IsInterfaceClassValid 
 Check whether or not the interface class is valid */
static void CameraLensEffectInterfaceClassSupport::IsInterfaceClassValid(FCameraLensInterfaceClassSupport CameraLens, EInterfaceValidResult& Result) {}
/* Function: SetInterfaceClass 
 Set the represented class of the passed in variable. Note: Check the tooltips on the individual pins.
You cannot bypass the validation by connecting a wires to this node!!

Parameters:
    Class - MUST implement CameraLensEffectInterface - when connecting variables to the input, take care that the input class does in fact implement the interface.
    Var - The wrapper (for validation purposes) of the lens effect class. */
static void CameraLensEffectInterfaceClassSupport::SetInterfaceClass(TSubclassOf<AActor> Class, FCameraLensInterfaceClassSupport& Var, EInterfaceValidResult& Result) {}
/* Function: GetInterfaceClass 
 Returns the class represented by this lens effect wrapper... */
static TSubclassOf<AActor> CameraLensEffectInterfaceClassSupport::GetInterfaceClass(FCameraLensInterfaceClassSupport CameraLens) {}
}
