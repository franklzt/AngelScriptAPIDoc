/* Class: Beam2SourceTargetTangentMethod 
  */ 
 class Beam2SourceTargetTangentMethod
{
public:
}
/* Enum: Beam2SourceTargetTangentMethod 
 
    PEB2STTM_Direct - Enum
    PEB2STTM_UserSet - Enum
    PEB2STTM_Distribution - Enum
    PEB2STTM_Emitter - Enum
    PEB2STTM_MAX - Enum */ 
 enum Beam2SourceTargetTangentMethod { 
PEB2STTM_Direct,
PEB2STTM_UserSet,
PEB2STTM_Distribution,
PEB2STTM_Emitter,
PEB2STTM_MAX, 
}