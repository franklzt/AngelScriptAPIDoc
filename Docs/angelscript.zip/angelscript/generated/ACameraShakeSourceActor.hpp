/* Class: ACameraShakeSourceActor 
  */ 
 class ACameraShakeSourceActor : public AActor
{
public:
// Group: CameraShakeSourceActor

/* Variable: CameraShakeSourceComponent 
  */
UCameraShakeSourceComponent CameraShakeSourceComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ACameraShakeSourceActor ACameraShakeSourceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACameraShakeSourceActor::StaticClass() {}
}
