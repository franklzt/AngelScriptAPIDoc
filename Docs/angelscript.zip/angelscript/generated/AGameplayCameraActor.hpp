/* Class: AGameplayCameraActor 
 An actor that can run a camera asset. */ 
 class AGameplayCameraActor : public AActor
{
public:
// Group: Camera

/* Variable: CameraComponent 
  */
UGameplayCameraComponent CameraComponent;
// Group: Camera

/* Function: GetCameraComponent 
 Gets the camera component. */
UGameplayCameraComponent GetCameraComponent() const {}
// Group: Functions

/* Function: SetCameraComponent 
  */
void SetCameraComponent(UGameplayCameraComponent Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AGameplayCameraActor AGameplayCameraActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameplayCameraActor::StaticClass() {}
}
