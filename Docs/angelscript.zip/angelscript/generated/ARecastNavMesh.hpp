/* Class: ARecastNavMesh 
  */ 
 class ARecastNavMesh : public ANavigationData
{
public:
// Group: Display

/* Variable: TileGenerationDebug 
  */
FRecastNavMeshTileGenerationDebug TileGenerationDebug;
/* Variable: DrawOffset 
 vertical offset added to navmesh's debug representation for better readability */
float32 DrawOffset;
// Group: Generation

/* Variable: TileSizeUU 
 size of single tile, expressed in uu */
float32 TileSizeUU;
/* Variable: NavMeshResolutionParams 
 Resolution params
If using multiple resolutions, it's recommended to chose the highest resolution first and
set it according to the highest desired precision and then the other resolutions. */
FNavMeshResolutionParam NavMeshResolutionParams;
/* Variable: AgentRadius 
 Radius of smallest agent to traverse this navmesh */
float32 AgentRadius;
/* Variable: TilePoolSize 
 maximum number of tiles NavMesh can hold */
int TilePoolSize;
/* Variable: AgentHeight 
 Size of the tallest agent that will path with this navmesh. */
float32 AgentHeight;
/* Variable: AgentMaxSlope 
 The maximum slope (angle) that the agent can move on. */
float32 AgentMaxSlope;
/* Variable: MinRegionArea 
 The minimum dimension of area. Areas smaller than this will be discarded */
float32 MinRegionArea;
/* Variable: MergeRegionSize 
 The size limit of regions to be merged with bigger regions (watershed partitioning only) */
float32 MergeRegionSize;
/* Variable: MaxSimplificationError 
 How much navigable shapes can get simplified - the higher the value the more freedom */
float32 MaxSimplificationError;
/* Variable: SimplificationElevationRatio 
 When simplifying contours, how much is the vertical error taken into account when comparing with MaxSimplificationError.
Use 0 to deactivate (Recast behavior), use 1 as a typical value. */
float32 SimplificationElevationRatio;
/* Variable: MaxSimultaneousTileGenerationJobsCount 
 Sets the limit for number of asynchronous tile generators running at one time, also used for some synchronous tasks */
int MaxSimultaneousTileGenerationJobsCount;
/* Variable: TileNumberHardLimit 
 Absolute hard limit to number of navmesh tiles. Be very, very careful while modifying it while
    having big maps with navmesh. A single, empty tile takes 176 bytes and empty tiles are
    allocated up front (subject to change, but that's where it's at now)
    @note TileNumberHardLimit is always rounded up to the closest power of 2 */
int TileNumberHardLimit;
/* Variable: NavMeshOriginOffset 
 Use this if you don't want your tiles to start at (0,0,0) */
FVector NavMeshOriginOffset;
/* Variable: LedgeSlopeFilterMode 
 filtering methode used for filtering ledge slopes */
ENavigationLedgeSlopeFilterMode LedgeSlopeFilterMode;
/* Variable: RegionPartitioning 
 partitioning method for creating navmesh polys */
ERecastPartitioning RegionPartitioning;
/* Variable: LayerPartitioning 
 partitioning method for creating tile layers */
ERecastPartitioning LayerPartitioning;
/* Variable: RegionChunkSplits 
 number of chunk splits (along single axis) used for region's partitioning: ChunkyMonotone */
int RegionChunkSplits;
/* Variable: LayerChunkSplits 
 number of chunk splits (along single axis) used for layer's partitioning: ChunkyMonotone */
int LayerChunkSplits;
/* Variable: InvokerTilePriorityBumpIncrease 
 Priority increase steps for tiles that are withing near distance. */
uint8 InvokerTilePriorityBumpIncrease;
/* Variable: InvokerTilePriorityBumpDistanceThresholdInTileUnits 
 If >= 1, when sorting pending tiles by priority, tiles near invokers (within the distance threshold) will have their priority increased. */
uint InvokerTilePriorityBumpDistanceThresholdInTileUnits;
/* Variable: NavLinkJumpDownConfig 
 Experimental configuration to generate vertical links. */
FNavLinkGenerationJumpDownConfig NavLinkJumpDownConfig;
// Group: Query

/* Variable: HeuristicScale 
 Euclidean distance heuristic scale used while pathfinding */
float32 HeuristicScale;
/* Variable: VerticalDeviationFromGroundCompensation 
 Value added to each search height to compensate for error between navmesh polys and walkable geometry */
float32 VerticalDeviationFromGroundCompensation;
// Group: TimeSlicing

/* Variable: TimeSliceLongDurationDebug 
 If a single time sliced section of navmesh regen code exceeds this duration then it will trigger debug logging */
float TimeSliceLongDurationDebug;
/* Variable: TimeSliceFilterLedgeSpansMaxYProcess 
 The maximum number of y coords to process when time slicing filter ledge spans during navmesh regeneration. */
int TimeSliceFilterLedgeSpansMaxYProcess;
// Group: NavMesh

/* Function: ReplaceAreaInTileBounds 
 

Returns:
    true if any polygon/link has been touched */
bool ReplaceAreaInTileBounds(FBox Bounds, TSubclassOf<UNavArea> OldArea, TSubclassOf<UNavArea> NewArea, bool ReplaceLinks = true) {}
// Group: Functions

/* Function: SetbDrawPolyEdges 
 Draw edges of every poly (i.e. not only border-edges) */
void SetbDrawPolyEdges(bool Value) {}
/* Function: SetbDrawFilledPolys 
 if disabled skips filling drawn navmesh polygons */
void SetbDrawFilledPolys(bool Value) {}
/* Function: SetbDrawNavMeshEdges 
 Draw border-edges */
void SetbDrawNavMeshEdges(bool Value) {}
/* Function: SetbDrawTileBounds 
 Draw the tile boundaries */
void SetbDrawTileBounds(bool Value) {}
/* Function: SetbDrawTileResolutions 
 Draw the tile resolutions */
void SetbDrawTileResolutions(bool Value) {}
/* Function: SetbDrawPathCollidingGeometry 
 Draw input geometry passed to the navmesh generator.  Recommend disabling other geometry rendering via viewport showflags in editor. */
void SetbDrawPathCollidingGeometry(bool Value) {}
/* Function: SetbDrawTriangleEdges 
 Draw edges of every navmesh's triangle */
void SetbDrawTriangleEdges(bool Value) {}
/* Function: SetbDrawTileLabels 
  */
void SetbDrawTileLabels(bool Value) {}
/* Function: SetbDrawTileBuildTimes 
  */
void SetbDrawTileBuildTimes(bool Value) {}
/* Function: SetbDrawTileBuildTimesHeatMap 
  */
void SetbDrawTileBuildTimesHeatMap(bool Value) {}
/* Function: SetbDrawPolygonLabels 
 Draw a label for every poly that indicates its poly and tile indices */
void SetbDrawPolygonLabels(bool Value) {}
/* Function: SetbDrawDefaultPolygonCost 
 Draw a label for every poly that indicates its default and fixed costs */
void SetbDrawDefaultPolygonCost(bool Value) {}
/* Function: SetbDrawPolygonFlags 
 Draw a label for every poly that indicates its poly and area flags */
void SetbDrawPolygonFlags(bool Value) {}
/* Function: SetbDrawLabelsOnPathNodes 
  */
void SetbDrawLabelsOnPathNodes(bool Value) {}
/* Function: SetbDrawNavLinks 
 Draw valid links (both ends are valid). */
void SetbDrawNavLinks(bool Value) {}
/* Function: SetbDrawFailedNavLinks 
 Draw failed links and valid links. */
void SetbDrawFailedNavLinks(bool Value) {}
/* Function: SetbDrawClusters 
 Draw navmesh's clusters and cluster links. (Requires WITH_NAVMESH_CLUSTER_LINKS=1) */
void SetbDrawClusters(bool Value) {}
/* Function: SetbDrawOctree 
 Draw octree used to store navigation relevant actors */
void SetbDrawOctree(bool Value) {}
/* Function: SetbDrawOctreeDetails 
 Draw octree used to store navigation relevant actors with the elements bounds */
void SetbDrawOctreeDetails(bool Value) {}
/* Function: SetbDrawMarkedForbiddenPolys 
  */
void SetbDrawMarkedForbiddenPolys(bool Value) {}
/* Function: SetbFixedTilePoolSize 
 if true, the NavMesh will allocate fixed size pool for tiles, should be enabled to support streaming */
void SetbFixedTilePoolSize(bool Value) {}
/* Function: SetbSortNavigationAreasByCost 
 Controls whether Navigation Areas will be sorted by cost before application
    to navmesh during navmesh generation. This is relevant when there are
    areas overlapping and we want to have area cost express area relevancy
    as well. Setting it to true will result in having area sorted by cost,
    but it will also increase navmesh generation cost a bit */
void SetbSortNavigationAreasByCost(bool Value) {}
/* Function: SetbIsWorldPartitioned 
 In a world partitioned map, is this navmesh using world partitioning */
void SetbIsWorldPartitioned(bool Value) {}
/* Function: SetbGenerateNavLinks 
 Experimental: if set, navlinks will be automatically generated.
See: FNavLinkGenerationJumpDownConfig */
void SetbGenerateNavLinks(bool Value) {}
/* Function: SetbPerformVoxelFiltering 
 controls whether voxel filtering will be applied (via FRecastTileGenerator::ApplyVoxelFilter).
    Results in generated navmesh better fitting navigation bounds, but hits (a bit) generation performance */
void SetbPerformVoxelFiltering(bool Value) {}
/* Function: SetbMarkLowHeightAreas 
 mark areas with insufficient free height above instead of cutting them out (accessible only for area modifiers using replace mode) */
void SetbMarkLowHeightAreas(bool Value) {}
/* Function: SetbUseExtraTopCellWhenMarkingAreas 
 Expand the top of the area nav modifier's bounds by one cell height when applying to the navmesh.
              If unset, navmesh on top of surfaces might not be marked by marking bounds flush with top surfaces (since navmesh is generated slightly above collision, depending on cell height). */
void SetbUseExtraTopCellWhenMarkingAreas(bool Value) {}
/* Function: SetbFilterLowSpanSequences 
 if set, only single low height span will be allowed under valid one */
void SetbFilterLowSpanSequences(bool Value) {}
/* Function: SetbFilterLowSpanFromTileCache 
 if set, only low height spans with corresponding area modifier will be stored in tile cache (reduces memory, can't modify without full tile rebuild) */
void SetbFilterLowSpanFromTileCache(bool Value) {}
/* Function: SetbDoFullyAsyncNavDataGathering 
 if set, navmesh data gathering will never happen on the game thread and will only be done on background threads */
void SetbDoFullyAsyncNavDataGathering(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ARecastNavMesh ARecastNavMesh::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ARecastNavMesh::StaticClass() {}
}
