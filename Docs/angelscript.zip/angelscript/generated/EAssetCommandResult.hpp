/* Class: EAssetCommandResult 
  */ 
 class EAssetCommandResult
{
public:
}
/* Enum: EAssetCommandResult 
 
    Handled - Enum
    Unhandled - Enum
    EAssetCommandResult_MAX - Enum */ 
 enum EAssetCommandResult { 
Handled,
Unhandled,
EAssetCommandResult_MAX, 
}