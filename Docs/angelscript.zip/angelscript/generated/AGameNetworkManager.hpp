/* Class: AGameNetworkManager 
 Handles game-specific networking management (cheat detection, bandwidth management, etc.). */ 
 class AGameNetworkManager : public AInfo
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AGameNetworkManager AGameNetworkManager::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameNetworkManager::StaticClass() {}
}
