/* Class: EBoneModificationMode 
  */ 
 class EBoneModificationMode
{
public:
}
/* Enum: EBoneModificationMode 
 
    BMM_Ignore - Enum
    BMM_Replace - Enum
    BMM_Additive - Enum
    BMM_MAX - Enum */ 
 enum EBoneModificationMode { 
BMM_Ignore,
BMM_Replace,
BMM_Additive,
BMM_MAX, 
}