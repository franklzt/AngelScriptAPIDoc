/* Class: AGameMode 
 GameMode is a subclass of GameModeBase that behaves like a multiplayer match-based game.
It has default behavior for picking spawn points and match state.
If you want a simpler base, inherit from GameModeBase instead. */ 
 class AGameMode : public AGameModeBase
{
public:
// Group: GameMode

/* Variable: MinRespawnDelay 
 Minimum time before player can respawn after dying. */
float32 MinRespawnDelay;
/* Variable: NumTravellingPlayers 
 Number of players that are still traveling from a previous map */
int NumTravellingPlayers;
/* Variable: InactivePlayerStateLifeSpan 
 Time a playerstate will stick around in an inactive state after a player logout */
float32 InactivePlayerStateLifeSpan;
/* Variable: MaxInactivePlayers 
 The maximum number of inactive players before we kick the oldest ones out */
int MaxInactivePlayers;
/* Variable: bDelayedStart 
 Whether the game should immediately start when the first player logs in. Affects the default behavior of ReadyToStartMatch */
bool bDelayedStart;
/* Variable: NumBots 
 number of non-human players (AI controlled but participating as a player). */
int NumBots;
// Group: Variables

/* Variable: MatchState 
 What match state we are currently in */
const FName MatchState;
// Group: AI

/* Function: Say 
 Exec command to broadcast a string to all players */
void Say(FString Msg) {}
// Group: Game

/* Function: GetMatchState 
 Returns the current match state, this is an accessor to protect the state machine flow */
FName GetMatchState() const {}
/* Function: IsMatchInProgress 
 Returns true if the match state is InProgress or other gameplay state */
bool IsMatchInProgress() const {}
/* Function: OnSetMatchState 
 Implementable event to respond to match state changes */
void OnSetMatchState(FName NewState) {}
/* Function: ReadyToEndMatch 
 Returns true if ready to End Match. Games should override this */
bool ReadyToEndMatch() {}
/* Function: ReadyToStartMatch 
 Returns true if ready to Start Match. Games should override this */
bool ReadyToStartMatch() {}
/* Function: AbortMatch 
 Report that a match has failed due to unrecoverable error */
void AbortMatch() {}
/* Function: EndMatch 
 Transition from InProgress to WaitingPostMatch. You can call this manually, will also get called if ReadyToEndMatch returns true */
void EndMatch() {}
/* Function: RestartGame 
 Restart the game, by default travel to the current map */
void RestartGame() {}
/* Function: StartMatch 
 Transition from WaitingToStart to InProgress. You can call this manually, will also get called if ReadyToStartMatch returns true */
void StartMatch() {}
// Group: Functions

/* Function: SetbDelayedStart 
 Whether the game should immediately start when the first player logs in. Affects the default behavior of ReadyToStartMatch */
void SetbDelayedStart(bool Value) {}
/* Function: GetbDelayedStart 
 Whether the game should immediately start when the first player logs in. Affects the default behavior of ReadyToStartMatch */
bool GetbDelayedStart() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AGameMode AGameMode::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameMode::StaticClass() {}
}
