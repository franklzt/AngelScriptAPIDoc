/* Class: EBoneTransformResolution 
  */ 
 class EBoneTransformResolution
{
public:
}
/* Enum: EBoneTransformResolution 
 
    KeepParent - Enum
    KeepChild - Enum
    Combine - Enum
    EBoneTransformResolution_MAX - Enum */ 
 enum EBoneTransformResolution { 
KeepParent,
KeepChild,
Combine,
EBoneTransformResolution_MAX, 
}