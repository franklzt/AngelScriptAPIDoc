/* Class: AConcertClientVRPresenceActor 
 A ConcertClientVRPresenceActor is a child of AConcertClientPresenceActor that is used to represent users in VR */ 
 class AConcertClientVRPresenceActor : public AConcertClientPresenceActor
{
public:
// Group: Laser

/* Variable: LaserThickness 
  */
float32 LaserThickness;
// Group: Static Functions

/* Function: Spawn 
  */
static AConcertClientVRPresenceActor AConcertClientVRPresenceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AConcertClientVRPresenceActor::StaticClass() {}
}
