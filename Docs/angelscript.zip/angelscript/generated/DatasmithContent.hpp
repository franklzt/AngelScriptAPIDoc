/* Class: DatasmithContent 
  */ 
 class DatasmithContent
{
public:
// Group: Datasmith User Data

/* Function: GetDatasmithUserDataValueForKey 
 Get the value of the given key for the Datasmith User Data of the given object.

Parameters:
    Object - The Object from which to retrieve the Datasmith User Data.
    Key - The key to find in the Datasmith User Data.

Returns:
    The string value associated with the given key */
static FString DatasmithContent::GetDatasmithUserDataValueForKey(UObject Object, FName Key, bool bPartialMatchKey = false) {}
/* Function: GetDatasmithUserData 
 Get the Datasmith User Data of a given object

Parameters:
    Object - The Object from which to retrieve the Datasmith User Data.

Returns:
    The Datasmith User Data if it exists; nullptr, otherwise */
static UDatasmithAssetUserData DatasmithContent::GetDatasmithUserData(UObject Object) {}
/* Function: GetDatasmithUserDataKeysAndValuesForValue 
 Get the keys and values for which the associated value contains the string to match for the Datasmith User Data of the given object.

Parameters:
    Object - The Object from which to retrieve the Datasmith User Data.
    StringToMatch - The string to match in the values.
    OutKeys - Output array of keys for which the associated values contain the string to match.
    OutValues - Output array of values associated to the keys. */
static void DatasmithContent::GetDatasmithUserDataKeysAndValuesForValue(UObject Object, FString StringToMatch, TArray<FName>& OutKeys, TArray<FString>& OutValues) {}
/* Function: GetDatasmithUserDataValuesForKey 
 Get the values of the given key for the Datasmith User Data of the given object.

Parameters:
    Object - The Object from which to retrieve the Datasmith User Data.
    Key - The key to find in the Datasmith User Data.
    bPartialMatchKey - If true, check for contains, rather than exact match.

Returns:
    The string value associated with the given key */
static TArray<FString> DatasmithContent::GetDatasmithUserDataValuesForKey(UObject Object, FName Key, bool bPartialMatchKey = false) {}
// Group: Editor Scripting | Datasmith User Data

/* Function: GetAllObjectsAndValuesForKey 
 Find all loaded objects of the given type that have a Datasmith User Data that contains the given key and their associated values.
This is a slow operation, so editor only.

Parameters:
    Key - The key to find in the Datasmith User Data.
    ObjectClass - Class of the object on which to filter, if specificed; otherwise there's no filtering
    OutObjects - Output array of objects for which the Datasmith User Data match the given key.
    OutValues - Output array of values associated with each object in OutObjects. */
static void DatasmithContent::GetAllObjectsAndValuesForKey(FName Key, TSubclassOf<UObject> ObjectClass, TArray<UObject>& OutObjects, TArray<FString>& OutValues) {}
/* Function: GetAllDatasmithUserData 
 Find all Datasmith User Data of loaded objects of the given type.
This is a slow operation, so editor only.

Parameters:
    ObjectClass - Class of the object on which to filter, if specificed; otherwise there's no filtering
    OutUserData - Output array of Datasmith User Data. */
static void DatasmithContent::GetAllDatasmithUserData(TSubclassOf<UObject> ObjectClass, TArray<UDatasmithAssetUserData>& OutUserData) {}
}
