/* Class: EAutomationEventType 
  */ 
 class EAutomationEventType
{
public:
}
/* Enum: EAutomationEventType 
 
    Info - Enum
    Warning - Enum
    Error - Enum
    EAutomationEventType_MAX - Enum */ 
 enum EAutomationEventType { 
Info,
Warning,
Error,
EAutomationEventType_MAX, 
}