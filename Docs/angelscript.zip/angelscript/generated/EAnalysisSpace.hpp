/* Class: EAnalysisSpace 
  */ 
 class EAnalysisSpace
{
public:
}
/* Enum: EAnalysisSpace 
 
    World - Enum
    Fixed - Enum
    Changing - Enum
    Moving - Enum
    EAnalysisSpace_MAX - Enum */ 
 enum EAnalysisSpace { 
World,
Fixed,
Changing,
Moving,
EAnalysisSpace_MAX, 
}