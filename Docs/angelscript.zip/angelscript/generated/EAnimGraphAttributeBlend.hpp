/* Class: EAnimGraphAttributeBlend 
  */ 
 class EAnimGraphAttributeBlend
{
public:
}
/* Enum: EAnimGraphAttributeBlend 
 
    Blendable - Enum
    NonBlendable - Enum
    EAnimGraphAttributeBlend_MAX - Enum */ 
 enum EAnimGraphAttributeBlend { 
Blendable,
NonBlendable,
EAnimGraphAttributeBlend_MAX, 
}