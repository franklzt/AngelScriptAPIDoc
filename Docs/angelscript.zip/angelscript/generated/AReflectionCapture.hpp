/* Class: AReflectionCapture 
  */ 
 class AReflectionCapture : public AActor
{
public:
// Group: DecalActor

/* Variable: CaptureComponent 
 Reflection capture component. */
UReflectionCaptureComponent CaptureComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AReflectionCapture AReflectionCapture::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AReflectionCapture::StaticClass() {}
}
