/* Class: ACameraRig_Crane 
 A simple rig for simulating crane-like camera movements. */ 
 class ACameraRig_Crane : public AActor
{
public:
// Group: Crane Components

/* Variable: CranePitchControl 
 Component to control Pitch. */
USceneComponent CranePitchControl;
/* Variable: CraneYawControl 
 Component to control Yaw. */
USceneComponent CraneYawControl;
/* Variable: TransformComponent 
 Root component to give the whole actor a transform. */
USceneComponent TransformComponent;
/* Variable: CraneCameraMount 
 Component to define the attach point for cameras. */
USceneComponent CraneCameraMount;
// Group: Crane Controls

/* Variable: CranePitch 
 Controls the pitch of the crane arm. */
float32 CranePitch;
/* Variable: bLockMountPitch 
 Lock the mount pitch so that an attached camera is locked and pitched in the direction of the crane arm */
bool bLockMountPitch;
/* Variable: CraneArmLength 
 Controls the length of the crane arm. */
float32 CraneArmLength;
/* Variable: CraneYaw 
 Controls the yaw of the crane arm. */
float32 CraneYaw;
/* Variable: bLockMountYaw 
 Lock the mount yaw so that an attached camera is locked and oriented in the direction of the crane arm */
bool bLockMountYaw;
// Group: Static Functions

/* Function: Spawn 
  */
static ACameraRig_Crane ACameraRig_Crane::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACameraRig_Crane::StaticClass() {}
}
