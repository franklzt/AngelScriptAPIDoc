/* Class: AProceduralFoliageVolume 
  */ 
 class AProceduralFoliageVolume : public AVolume
{
public:
// Group: ProceduralFoliage

/* Variable: ProceduralComponent 
  */
UProceduralFoliageComponent ProceduralComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AProceduralFoliageVolume AProceduralFoliageVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AProceduralFoliageVolume::StaticClass() {}
}
