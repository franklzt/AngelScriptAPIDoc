/* Class: EAppReturnType 
  */ 
 class EAppReturnType
{
public:
}
/* Enum: EAppReturnType 
 
    No - Enum
    Yes - Enum
    YesAll - Enum
    NoAll - Enum
    Cancel - Enum
    Ok - Enum
    Retry - Enum
    Continue - Enum
    EAppReturnType_MAX - Enum */ 
 enum EAppReturnType { 
No,
Yes,
YesAll,
NoAll,
Cancel,
Ok,
Retry,
Continue,
EAppReturnType_MAX, 
}