/* Class: EAutomationArtifactType 
  */ 
 class EAutomationArtifactType
{
public:
}
/* Enum: EAutomationArtifactType 
 
    None - Enum
    Image - Enum
    Comparison - Enum
    EAutomationArtifactType_MAX - Enum */ 
 enum EAutomationArtifactType { 
None,
Image,
Comparison,
EAutomationArtifactType_MAX, 
}