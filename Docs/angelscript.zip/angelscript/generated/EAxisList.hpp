/* Class: EAxisList 
  */ 
 class EAxisList
{
public:
}
/* Enum: EAxisList 
 
    None - Enum
    X - Enum
    Y - Enum
    Z - Enum
    Screen - Enum
    XY - Enum
    XZ - Enum
    YZ - Enum
    XYZ - Enum
    All - Enum
    ZRotation - Enum
    Rotate2D - Enum
    EAxisList_MAX - Enum */ 
 enum EAxisList { 
None,
X,
Y,
Z,
Screen,
XY,
XZ,
YZ,
XYZ,
All,
ZRotation,
Rotate2D,
EAxisList_MAX, 
}