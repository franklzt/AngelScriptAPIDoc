/* Class: ASceneCapture 
  */ 
 class ASceneCapture : public AActor
{
public:
// Group: Components

/* Variable: SceneComponent 
  */
USceneComponent SceneComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ASceneCapture ASceneCapture::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASceneCapture::StaticClass() {}
}
