/* Class: AInteractiveFoliageActor 
  */ 
 class AInteractiveFoliageActor : public AStaticMeshActor
{
public:
// Group: FoliagePhysics

/* Variable: FoliageTouchImpulseScale 
 Scales forces applied from touch events. */
float32 FoliageTouchImpulseScale;
/* Variable: FoliageStiffness 
 Determines how strong the force that pushes toward the spring's center will be. */
float32 FoliageStiffness;
/* Variable: FoliageStiffnessQuadratic 
 Same as FoliageStiffness, but the strength of this force increases with the square of the distance to the spring's center.
This force is used to prevent the spring from extending past a certain point due to touch and damage forces. */
float32 FoliageStiffnessQuadratic;
/* Variable: FoliageDamping 
 Determines the amount of energy lost by the spring as it oscillates.
This force is similar to air friction. */
float32 FoliageDamping;
/* Variable: MaxDamageImpulse 
 Clamps the magnitude of each damage force applied. */
float32 MaxDamageImpulse;
/* Variable: MaxTouchImpulse 
 Clamps the magnitude of each touch force applied. */
float32 MaxTouchImpulse;
/* Variable: MaxForce 
 Clamps the magnitude of combined forces applied each update. */
float32 MaxForce;
/* Variable: FoliageDamageImpulseScale 
 Scales forces applied from damage events. */
float32 FoliageDamageImpulseScale;
// Group: Static Functions

/* Function: Spawn 
  */
static AInteractiveFoliageActor AInteractiveFoliageActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AInteractiveFoliageActor::StaticClass() {}
}
