/* Class: EAudioUnitsValueType 
  */ 
 class EAudioUnitsValueType
{
public:
}
/* Enum: EAudioUnitsValueType 
 
    Linear - Enum
    Frequency - Enum
    Volume - Enum
    EAudioUnitsValueType_MAX - Enum */ 
 enum EAudioUnitsValueType { 
Linear,
Frequency,
Volume,
EAudioUnitsValueType_MAX, 
}