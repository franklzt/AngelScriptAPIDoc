/* Class: DEPRECATED_EditorSkeletalMesh 
  */ 
 class DEPRECATED_EditorSkeletalMesh
{
public:
// Group: Editor Scripting | SkeletalMesh

/* Function: ImportLOD 
  */
static int DEPRECATED_EditorSkeletalMesh::ImportLOD(USkeletalMesh BaseMesh, int LODIndex, FString SourceFilename) {}
/* Function: GetLodBuildSettings 
  */
static void DEPRECATED_EditorSkeletalMesh::GetLodBuildSettings(const USkeletalMesh SkeletalMesh, int LodIndex, FSkeletalMeshBuildSettings& OutBuildOptions) {}
/* Function: GetLODCount 
  */
static int DEPRECATED_EditorSkeletalMesh::GetLODCount(USkeletalMesh SkeletalMesh) {}
/* Function: GetNumVerts 
  */
static int DEPRECATED_EditorSkeletalMesh::GetNumVerts(USkeletalMesh SkeletalMesh, int LODIndex) {}
/* Function: CreatePhysicsAsset 
 This function creates a PhysicsAsset for the given SkeletalMesh with the same settings as if it were created through FBX import */
static UPhysicsAsset DEPRECATED_EditorSkeletalMesh::CreatePhysicsAsset(USkeletalMesh SkeletalMesh) {}
/* Function: RegenerateLOD 
  */
static bool DEPRECATED_EditorSkeletalMesh::RegenerateLOD(USkeletalMesh SkeletalMesh, int NewLODCount = 0, bool bRegenerateEvenIfImported = false, bool bGenerateBaseLOD = false) {}
/* Function: ReimportAllCustomLODs 
  */
static bool DEPRECATED_EditorSkeletalMesh::ReimportAllCustomLODs(USkeletalMesh SkeletalMesh) {}
/* Function: RenameSocket 
  */
static bool DEPRECATED_EditorSkeletalMesh::RenameSocket(USkeletalMesh SkeletalMesh, FName OldName, FName NewName) {}
/* Function: SetLodBuildSettings 
  */
static void DEPRECATED_EditorSkeletalMesh::SetLodBuildSettings(USkeletalMesh SkeletalMesh, int LodIndex, FSkeletalMeshBuildSettings BuildOptions) {}
}
