/* Class: EAutoChangeMode 
  */ 
 class EAutoChangeMode
{
public:
}
/* Enum: EAutoChangeMode 
 
    AutoKey - Enum
    AutoTrack - Enum
    All - Enum
    None - Enum
    EAutoChangeMode_MAX - Enum */ 
 enum EAutoChangeMode { 
AutoKey,
AutoTrack,
All,
None,
EAutoChangeMode_MAX, 
}