/* Class: ALightmassCharacterIndirectDetailVolume 
  */ 
 class ALightmassCharacterIndirectDetailVolume : public AVolume
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ALightmassCharacterIndirectDetailVolume ALightmassCharacterIndirectDetailVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALightmassCharacterIndirectDetailVolume::StaticClass() {}
}
