/* Class: ADefaultPhysicsVolume 
 DefaultPhysicsVolume determines the physical effects an actor will experience if they are not inside any user specified PhysicsVolume

@see APhysicsVolume */ 
 class ADefaultPhysicsVolume : public APhysicsVolume
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ADefaultPhysicsVolume ADefaultPhysicsVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADefaultPhysicsVolume::StaticClass() {}
}
