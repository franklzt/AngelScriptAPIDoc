/* Class: AAutoRTFMTestAnotherActor 
  */ 
 class AAutoRTFMTestAnotherActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AAutoRTFMTestAnotherActor AAutoRTFMTestAnotherActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AAutoRTFMTestAnotherActor::StaticClass() {}
}
