/* Class: EAbcConversionPreset 
  */ 
 class EAbcConversionPreset
{
public:
}
/* Enum: EAbcConversionPreset 
 
    Maya - Enum
    Max - Enum
    Custom - Enum
    EAbcConversionPreset_MAX - Enum */ 
 enum EAbcConversionPreset { 
Maya,
Max,
Custom,
EAbcConversionPreset_MAX, 
}