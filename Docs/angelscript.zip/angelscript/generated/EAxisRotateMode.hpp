/* Class: EAxisRotateMode 
  */ 
 class EAxisRotateMode
{
public:
}
/* Enum: EAxisRotateMode 
 
    Pull - Enum
    Arc - Enum
    EAxisRotateMode_MAX - Enum */ 
 enum EAxisRotateMode { 
Pull,
Arc,
EAxisRotateMode_MAX, 
}