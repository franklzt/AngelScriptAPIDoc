/* Class: EAnimLayerType 
  */ 
 class EAnimLayerType
{
public:
}
/* Enum: EAnimLayerType 
 
    Base - Enum
    Additive - Enum
    Override - Enum
    EAnimLayerType_MAX - Enum */ 
 enum EAnimLayerType { 
Base,
Additive,
Override,
EAnimLayerType_MAX, 
}