/* Class: EAxisOption 
  */ 
 class EAxisOption
{
public:
}
/* Enum: EAxisOption 
 
    X - Enum
    Y - Enum
    Z - Enum
    X_Neg - Enum
    Y_Neg - Enum
    Z_Neg - Enum
    Custom - Enum
    EAxisOption_MAX - Enum */ 
 enum EAxisOption { 
X,
Y,
Z,
X_Neg,
Y_Neg,
Z_Neg,
Custom,
EAxisOption_MAX, 
}