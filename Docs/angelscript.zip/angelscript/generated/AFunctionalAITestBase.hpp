/* Class: AFunctionalAITestBase 
 AFunctionalAITestBase

Base abstract class defining a Functional AI Test.
You can derive from this base class to create a test with a different type of SpawnSets. */ 
 class AFunctionalAITestBase : public AFunctionalTest
{
public:
// Group: AITest

/* Variable: CurrentSpawnSetName 
  */
FString CurrentSpawnSetName;
/* Variable: SpawnedPawns 
  */
TArray<TObjectPtr<APawn>> SpawnedPawns;
/* Variable: PendingDelayedSpawns 
  */
TArray<FPendingDelayedSpawn> PendingDelayedSpawns;
/* Variable: CurrentSpawnSetIndex 
  */
int CurrentSpawnSetIndex;
/* Variable: bWaitForNavMesh 
 if set, ftest will postpone start until navmesh is fully generated */
bool bWaitForNavMesh;
/* Variable: SpawnLocationRandomizationRange 
  */
float32 SpawnLocationRandomizationRange;
// Group: NavMeshDebug

/* Variable: NavMeshDebugOrigin 
 navmesh debug: log navoctree modifiers around this point */
FVector NavMeshDebugOrigin;
/* Variable: NavMeshDebugExtent 
 navmesh debug: extent around NavMeshDebugOrigin */
FVector NavMeshDebugExtent;
// Group: Variables

/* Variable: OnAllAISPawned 
 Called when a all AI finished spawning */
FFunctionalTestEventSignature OnAllAISPawned;
/* Variable: OnAISpawned 
 Called when a single AI finished spawning */
FFunctionalTestAISpawned OnAISpawned;
// Group: Development

/* Function: IsOneOfSpawnedPawns 
  */
bool IsOneOfSpawnedPawns(AActor Actor) {}
// Group: Functions

/* Function: SetbWaitForNavMesh 
 if set, ftest will postpone start until navmesh is fully generated */
void SetbWaitForNavMesh(bool Value) {}
/* Function: SetbDebugNavMeshOnTimeout 
 if set, ftest will postpone start until navmesh is fully generated */
void SetbDebugNavMeshOnTimeout(bool Value) {}
/* Function: GetbWaitForNavMesh 
 if set, ftest will postpone start until navmesh is fully generated */
bool GetbWaitForNavMesh() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AFunctionalAITestBase AFunctionalAITestBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AFunctionalAITestBase::StaticClass() {}
}
