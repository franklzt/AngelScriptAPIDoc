/* Class: APackedLevelActor 
 APackedLevelActor is the result of packing the source level (WorldAsset base class property) into a single actor. See FPackedLevelActorBuilder.


Other components are unsupported and will result in an incomplete APackedLevelActor. In this case using a regular ALevelInstance is recommended. */ 
 class APackedLevelActor : public ALevelInstance
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static APackedLevelActor APackedLevelActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APackedLevelActor::StaticClass() {}
}
