/* Class: ASkyAtmosphere 
 A placeable actor that represents a planet atmosphere material and simulates sky and light scattering within it.
@see https://docs.unrealengine.com/en-US/Engine/Actors/FogEffects/SkyAtmosphere/index.html */ 
 class ASkyAtmosphere : public AInfo
{
public:
// Group: Atmosphere

/* Variable: SkyAtmosphereComponent 
  */
USkyAtmosphereComponent SkyAtmosphereComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ASkyAtmosphere ASkyAtmosphere::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASkyAtmosphere::StaticClass() {}
}
