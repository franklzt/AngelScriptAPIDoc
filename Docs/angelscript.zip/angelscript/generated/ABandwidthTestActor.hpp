/* Class: ABandwidthTestActor 
 This ABandwidthTestActor class is used to generate an easily controllable amount of bandwidth.
It uses property replication to generate it's traffic via a NetDeltaSerializer struct
Note that the property data is never stored in memory on the simulated clients */ 
 class ABandwidthTestActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ABandwidthTestActor ABandwidthTestActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ABandwidthTestActor::StaticClass() {}
}
