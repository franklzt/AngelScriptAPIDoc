/* Class: AFunctionalTestLevelScript 
  */ 
 class AFunctionalTestLevelScript : public ALevelScriptActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AFunctionalTestLevelScript AFunctionalTestLevelScript::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AFunctionalTestLevelScript::StaticClass() {}
}
