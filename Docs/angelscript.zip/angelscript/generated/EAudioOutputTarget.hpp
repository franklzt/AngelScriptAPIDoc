/* Class: EAudioOutputTarget 
  */ 
 class EAudioOutputTarget
{
public:
}
/* Enum: EAudioOutputTarget 
 
    Speaker - Enum
    Controller - Enum
    ControllerFallbackToSpeaker - Enum
    EAudioOutputTarget_MAX - Enum */ 
 enum EAudioOutputTarget { 
Speaker,
Controller,
ControllerFallbackToSpeaker,
EAudioOutputTarget_MAX, 
}