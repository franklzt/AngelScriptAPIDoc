/* Class: AnimPhysAngularConstraintType 
  */ 
 class AnimPhysAngularConstraintType
{
public:
}
/* Enum: AnimPhysAngularConstraintType 
 
    Angular - Enum
    Cone - Enum
    AnimPhysAngularConstraintType_MAX - Enum */ 
 enum AnimPhysAngularConstraintType { 
Angular,
Cone,
AnimPhysAngularConstraintType_MAX, 
}