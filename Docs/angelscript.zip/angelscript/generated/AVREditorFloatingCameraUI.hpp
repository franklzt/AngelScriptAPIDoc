/* Class: AVREditorFloatingCameraUI 
 Represents an interactive floating UI camera preview panel in the VR Editor */ 
 class AVREditorFloatingCameraUI : public AVREditorFloatingUI
{
public:
// Group: FloatingCameraUI

/* Variable: OffsetFromCamera 
 The offset of this UI from its camera */
FVector OffsetFromCamera;
// Group: Static Functions

/* Function: Spawn 
  */
static AVREditorFloatingCameraUI AVREditorFloatingCameraUI::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVREditorFloatingCameraUI::StaticClass() {}
}
