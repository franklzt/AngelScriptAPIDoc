/* Class: AnimPhysTwistAxis 
  */ 
 class AnimPhysTwistAxis
{
public:
}
/* Enum: AnimPhysTwistAxis 
 
    AxisX - Enum
    AxisY - Enum
    AxisZ - Enum
    AnimPhysTwistAxis_MAX - Enum */ 
 enum AnimPhysTwistAxis { 
AxisX,
AxisY,
AxisZ,
AnimPhysTwistAxis_MAX, 
}