/* Class: EAutoPossessAI 
  */ 
 class EAutoPossessAI
{
public:
}
/* Enum: EAutoPossessAI 
 
    Disabled - Enum
    PlacedInWorld - Enum
    Spawned - Enum
    PlacedInWorldOrSpawned - Enum
    EAutoPossessAI_MAX - Enum */ 
 enum EAutoPossessAI { 
Disabled,
PlacedInWorld,
Spawned,
PlacedInWorldOrSpawned,
EAutoPossessAI_MAX, 
}