/* Class: APaperSpriteActor 
 An instance of a UPaperSprite in a level.

This actor is created when you drag a sprite asset from the content browser into the level, and
it is just a thin wrapper around a UPaperSpriteComponent that actually references the asset. */ 
 class APaperSpriteActor : public AActor
{
public:
// Group: Sprite

/* Variable: RenderComponent 
  */
UPaperSpriteComponent RenderComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static APaperSpriteActor APaperSpriteActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APaperSpriteActor::StaticClass() {}
}
