/* Class: AutomationUtils 
  */ 
 class AutomationUtils
{
public:
// Group: Automation

/* Function: TakeGameplayAutomationScreenshot 
  */
static void AutomationUtils::TakeGameplayAutomationScreenshot(const FString ScreenshotName, float32 MaxGlobalError = 0.020000, float32 MaxLocalError = 0.120000, FString MapNameOverride = "") {}
}
