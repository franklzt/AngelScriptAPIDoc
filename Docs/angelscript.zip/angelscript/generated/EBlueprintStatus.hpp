/* Class: EBlueprintStatus 
  */ 
 class EBlueprintStatus
{
public:
}
/* Enum: EBlueprintStatus 
 
    BS_Unknown - Enum
    BS_Dirty - Enum
    BS_Error - Enum
    BS_UpToDate - Enum
    BS_BeingCreated - Enum
    BS_UpToDateWithWarnings - Enum
    BS_MAX - Enum */ 
 enum EBlueprintStatus { 
BS_Unknown,
BS_Dirty,
BS_Error,
BS_UpToDate,
BS_BeingCreated,
BS_UpToDateWithWarnings,
BS_MAX, 
}