/* Class: APlayerController 
 PlayerControllers are used by human players to control Pawns.

ControlRotation (accessed via GetControlRotation()), determines the aiming
orientation of the controlled Pawn.

In networked games, PlayerControllers exist on the server for every player-controlled pawn,
and also on the controlling client's machine. They do NOT exist on a client's
machine for pawns controlled by remote players elsewhere on the network.

@see https://docs.unrealengine.com/latest/INT/Gameplay/Framework/Controller/PlayerController/ */ 
 class APlayerController : public AController
{
public:
// Group: Cheat Manager

/* Variable: CheatClass 
 Class of my CheatManager.
@see CheatManager for more information about when it will be instantiated. */
TSubclassOf<UCheatManager> CheatClass;
/* Variable: CheatManager 
 Object that manages "cheat" commands.

By default:
      - In Shipping configurations, the manager is always disabled because UE_WITH_CHEAT_MANAGER is 0
  - When playing in the editor, cheats are always enabled
  - In other cases, cheats are enabled by default in single player games but can be forced on with the EnableCheats console command

This behavior can be changed either by overriding APlayerController::EnableCheats or AGameModeBase::AllowCheats. */
UCheatManager CheatManager;
// Group: Game|Feedback

/* Variable: bForceFeedbackEnabled 
  */
bool bForceFeedbackEnabled;
// Group: Game|Player

/* Variable: PlatformUserId 
 Returns the platform user that is assigned to this Player Controller's Local Player.
If there is no local player, then this will return PLATFORMUSERID_NONE */
const FPlatformUserId PlatformUserId;
// Group: HUD

/* Variable: HUD 
 Gets the HUD currently being used by this player controller */
const AHUD HUD;
// Group: Input

/* Variable: bEnableMotionControls 
 Whether or not to consider input from motion sources (tilt, acceleration, etc) */
bool bEnableMotionControls;
/* Variable: OverridePlayerInputClass 
 If set, then this UPlayerInput class will be used instead of the Input Settings' DefaultPlayerInputClass */
TSubclassOf<UPlayerInput> OverridePlayerInputClass;
// Group: MouseInterface

/* Variable: DefaultMouseCursor 
 Type of mouse cursor to show by default */
EMouseCursor DefaultMouseCursor;
/* Variable: CurrentMouseCursor 
 Currently visible mouse cursor */
EMouseCursor CurrentMouseCursor;
/* Variable: ClickEventKeys 
 List of keys that will cause click events to be forwarded, default to left click */
TArray<FKey> ClickEventKeys;
/* Variable: DefaultClickTraceChannel 
 Default trace channel used for determining what world object was clicked on. */
ECollisionChannel DefaultClickTraceChannel;
/* Variable: CurrentClickTraceChannel 
 Trace channel currently being used for determining what world object was clicked on. */
ECollisionChannel CurrentClickTraceChannel;
/* Variable: HitResultTraceDistance 
 Distance to trace when computing click events */
float32 HitResultTraceDistance;
/* Variable: bEnableTouchEvents 
 Whether actor/component touch events should be generated. */
bool bEnableTouchEvents;
/* Variable: bEnableClickEvents 
 Whether actor/component click events should be generated. */
bool bEnableClickEvents;
/* Variable: bShowMouseCursor 
 Whether the mouse cursor should be displayed. */
bool bShowMouseCursor;
/* Variable: bEnableTouchOverEvents 
 Whether actor/component touch over events should be generated. */
bool bEnableTouchOverEvents;
/* Variable: bEnableMouseOverEvents 
 Whether actor/component mouse over events should be generated. */
bool bEnableMouseOverEvents;
// Group: Pawn

/* Variable: FocalLocation 
 Returns the location the PlayerController is focused on.
 If there is a possessed Pawn, returns the Pawn's location.
 If there is a spectator Pawn, returns that Pawn's location.
 Otherwise, returns the PlayerController's spawn location (usually the last known Pawn location after it has died). */
const FVector FocalLocation;
// Group: PlayerController

/* Variable: SmoothTargetViewRotationSpeed 
 Interp speed for blending remote view rotation for smoother client updates */
float32 SmoothTargetViewRotationSpeed;
/* Variable: DeprecatedInputYawScale 
  */
float32 DeprecatedInputYawScale;
/* Variable: PlayerCameraManager 
 Camera manager associated with this Player Controller. */
APlayerCameraManager PlayerCameraManager;
/* Variable: DeprecatedInputPitchScale 
  */
float32 DeprecatedInputPitchScale;
/* Variable: DeprecatedInputRollScale 
  */
float32 DeprecatedInputRollScale;
/* Variable: bPlayerIsWaiting 
 True if PlayerController is currently waiting for the match to start or to respawn. Only valid in Spectating state. */
const bool bPlayerIsWaiting;
/* Variable: bAutoManageActiveCameraTarget 
 True to allow this player controller to manage the camera target for you,
typically by using the possessed pawn as the camera target. Set to false
if you want to manually control the camera target. */
bool bAutoManageActiveCameraTarget;
/* Variable: bShouldPerformFullTickWhenPaused 
 Whether we fully tick when the game is paused, if our tick function is allowed to do so. If false, we do a minimal update during the tick. */
bool bShouldPerformFullTickWhenPaused;
/* Variable: PlayerCameraManagerClass 
 PlayerCamera class should be set for each game, otherwise Engine.PlayerCameraManager is used */
TSubclassOf<APlayerCameraManager> PlayerCameraManagerClass;
// Group: WorldPartition

/* Variable: StreamingSourcePriority 
 PlayerController streaming source priority. */
EStreamingSourcePriority StreamingSourcePriority;
/* Variable: StreamingSourceDebugColor 
 Color used for debugging. */
FColor StreamingSourceDebugColor;
/* Variable: bStreamingSourceShouldActivate 
 Whether the PlayerController streaming source should activate cells after loading. */
bool bStreamingSourceShouldActivate;
/* Variable: bEnableStreamingSource 
 Whether the PlayerController should be used as a World Partiton streaming source. */
bool bEnableStreamingSource;
/* Variable: bStreamingSourceShouldBlockOnSlowStreaming 
 Whether the PlayerController streaming source should block on slow streaming. */
bool bStreamingSourceShouldBlockOnSlowStreaming;
// Group: Variables

/* Variable: PlayerInput 
 Object that manages player input. */
const UPlayerInput PlayerInput;
/* Variable: SpectatorPawn 
 The pawn used when spectating (nullptr if not spectating). */
const ASpectatorPawn SpectatorPawn;
/* Variable: LocalPlayer 
  */
const ULocalPlayer LocalPlayer;
// Group: Game|Audio

/* Function: SetAudioListenerAttenuationOverride 
  */
void SetAudioListenerAttenuationOverride(USceneComponent AttachToComponent, FVector AttenuationLocationOVerride) {}
/* Function: SetAudioListenerOverride 
 Used to override the default positioning of the audio listener

Parameters:
    AttachToComponent - Optional component to attach the audio listener to
    Location - Depending on whether Component is attached this is either an offset from its location or an absolute position
    Rotation - Depending on whether Component is attached this is either an offset from its rotation or an absolute rotation */
void SetAudioListenerOverride(USceneComponent AttachToComponent, FVector Location, FRotator Rotation) {}
/* Function: ClearAudioListenerOverride 
 Clear any overrides that have been applied to audio listener */
void ClearAudioListenerOverride() {}
/* Function: ClearAudioListenerAttenuationOverride 
  */
void ClearAudioListenerAttenuationOverride() {}
// Group: Game|Cinematic

/* Function: SetCinematicMode 
 Server/SP only function for changing whether the player is in cinematic mode.  Updates values of various state variables, then replicates the call to the client
to sync the current cinematic mode.

Parameters:
    bInCinematicMode - specify true if the player is entering cinematic mode; false if the player is leaving cinematic mode.
    bHidePlayer - specify true to hide the player's pawn (only relevant if bInCinematicMode is true)
    bAffectsHUD - specify true if we should show/hide the HUD to match the value of bCinematicMode
    bAffectsMovement - specify true to disable movement in cinematic mode, enable it when leaving
    bAffectsTurning - specify true to disable turning in cinematic mode or enable it when leaving */
void SetCinematicMode(bool bInCinematicMode, bool bHidePlayer, bool bAffectsHUD, bool bAffectsMovement, bool bAffectsTurning) {}
// Group: Game|Feedback

/* Function: SetHapticsByValue 
 Sets the value of the haptics for the specified hand directly, using frequency and amplitude.  NOTE:  If a curve is already
playing for this hand, it will be cancelled in favour of the specified values.

Parameters:
    Frequency - The normalized frequency [0.0, 1.0] to play through the haptics system
    Amplitude - The normalized amplitude [0.0, 1.0] to set the haptic feedback to
    Hand - Which hand to play the effect on */
void SetHapticsByValue(float32 Frequency, float32 Amplitude, EControllerHand Hand) {}
/* Function: ClientStopCameraShakesFromSource 
 Stop camera shake on client. */
void ClientStopCameraShakesFromSource(UCameraShakeSourceComponent SourceComponent, bool bImmediately = true) {}
/* Function: ClientStopForceFeedback 
 Stops a playing force feedback pattern

Parameters:
    ForceFeedbackEffect - If set only patterns from that effect will be stopped
    Tag - If not none only the pattern with this tag will be stopped */
void ClientStopForceFeedback(UForceFeedbackEffect ForceFeedbackEffect, FName Tag) {}
/* Function: PlayDynamicForceFeedback 
 Latent action that controls the playing of force feedback
Begins playing when Start is called.  Calling Update or Stop if the feedback is not active will have no effect.
Completed will execute when Stop is called or the duration ends.
When Update is called the Intensity, Duration, and affect values will be updated with the current inputs

Parameters:
    Intensity - How strong the feedback should be.  Valid values are between 0.0 and 1.0
    Duration - How long the feedback should play for.  If the value is negative it will play until stopped
    bAffectsLeftLarge - Whether the intensity should be applied to the large left servo
    bAffectsLeftSmall - Whether the intensity should be applied to the small left servo
    bAffectsRightLarge - Whether the intensity should be applied to the large right servo
    bAffectsRightSmall - Whether the intensity should be applied to the small right servo */
void PlayDynamicForceFeedback(float32 Intensity, float32 Duration, bool bAffectsLeftLarge, bool bAffectsLeftSmall, bool bAffectsRightLarge, bool bAffectsRightSmall, EDynamicForceFeedbackAction Action, FLatentActionInfo LatentInfo) {}
/* Function: PlayHapticEffect 
 Play a haptic feedback curve on the player's controller

Parameters:
    HapticEffect - The haptic effect to play
    Hand - Which hand to play the effect on
    Scale - Scale between 0.0 and 1.0 on the intensity of playback */
void PlayHapticEffect(UHapticFeedbackEffect_Base HapticEffect, EControllerHand Hand, float32 Scale = 1.000000, bool bLoop = false) {}
/* Function: StopHapticEffect 
 Stops a playing haptic feedback curve

Parameters:
    Hand - Which hand to stop the effect for */
void StopHapticEffect(EControllerHand Hand) {}
/* Function: SetControllerLightColor 
 Sets the light color of the player's controller

Parameters:
    Color - The color for the light to be */
void SetControllerLightColor(FColor Color) {}
/* Function: SetDisableHaptics 
 Allows the player controller to disable all haptic requests from being fired, e.g. in the case of a level loading

Parameters:
    bNewDisabled - If TRUE, the haptics will stop and prevented from being enabled again until set to FALSE */
void SetDisableHaptics(bool bNewDisabled) {}
/* Function: ClientStartCameraShakeFromSource 
 Play Camera Shake localized to a given source

Parameters:
    Shake - Camera shake animation to play
    SourceComponent - The source from which the camera shakes originates */
void ClientStartCameraShakeFromSource(TSubclassOf<UCameraShakeBase> Shake, UCameraShakeSourceComponent SourceComponent) {}
/* Function: ClientClearCameraLensEffects 
 Removes all Camera Lens Effects. */
void ClientClearCameraLensEffects() {}
/* Function: ClientStartCameraShake 
 Play Camera Shake

Parameters:
    Shake - Camera shake animation to play
    Scale - Scalar defining how "intense" to play the anim
    PlaySpace - Which coordinate system to play the shake in (used for CameraAnims within the shake).
    UserPlaySpaceRot - Matrix used when PlaySpace = CAPS_UserDefined */
void ClientStartCameraShake(TSubclassOf<UCameraShakeBase> Shake, float32 Scale = 1.000000, ECameraShakePlaySpace PlaySpace = ECameraShakePlaySpace :: CameraLocal, FRotator UserPlaySpaceRot = FRotator ( )) {}
/* Function: ResetControllerLightColor 
 Resets the light color of the player's controller to default */
void ResetControllerLightColor() {}
/* Function: ClientSpawnGenericCameraLensEffect 
 Spawn a camera lens effect (e.g. blood). */
void ClientSpawnGenericCameraLensEffect(TSubclassOf<AActor> LensEffectEmitterClass) {}
/* Function: ClientPlayForceFeedback 
 Play a force feedback pattern on the player's controller

Parameters:
    ForceFeedbackEffect - The force feedback pattern to play
    Tag - A tag that allows stopping of an effect.  If another effect with this Tag is playing, it will be stopped and replaced
    bLooping - Whether the pattern should be played repeatedly or be a single one shot
    bIgnoreTimeDilation - Whether the pattern should ignore time dilation
    bPlayWhilePaused - Whether the pattern should continue to play while the game is paused */
void ClientPlayForceFeedback(UForceFeedbackEffect ForceFeedbackEffect, FName Tag, bool bLooping, bool bIgnoreTimeDilation, bool bPlayWhilePaused) {}
/* Function: ClientStopCameraShake 
 Stop camera shake on client. */
void ClientStopCameraShake(TSubclassOf<UCameraShakeBase> Shake, bool bImmediately = true) {}
// Group: Game|Player

/* Function: WasInputKeyJustPressed 
 Returns true if the given key/button was up last frame and down this frame. */
bool WasInputKeyJustPressed(FKey Key) const {}
/* Function: SetMouseLocation 
 Positions the mouse cursor in screen space, in pixels. */
void SetMouseLocation(int X, int Y) {}
/* Function: SetMouseCursorWidget 
 Sets the Widget for the Mouse Cursor to display

Parameters:
    Cursor - the cursor to set the widget for
    CursorWidget - the widget to set the cursor to */
void SetMouseCursorWidget(EMouseCursor Cursor, UUserWidget CursorWidget) {}
/* Function: SetViewTargetWithBlend 
 Set the view target blending with variable control

Parameters:
    NewViewTarget - new actor to set as view target
    BlendTime - time taken to blend
    BlendFunc - Cubic, Linear etc functions for blending
    BlendExp - Exponent, used by certain blend functions to control the shape of the curve.
    bLockOutgoing - If true, lock outgoing viewtarget to last frame's camera position for the remainder of the blend. */
void SetViewTargetWithBlend(AActor NewViewTarget, float32 BlendTime = 0.000000, EViewTargetBlendFunction BlendFunc = EViewTargetBlendFunction :: VTBlend_Linear, float32 BlendExp = 0.000000, bool bLockOutgoing = false) {}
/* Function: AddPitchInput 
 Add Pitch (look up) input. This value is multiplied by InputPitchScale.

Parameters:
    Val - Amount to add to Pitch. This value is multiplied by InputPitchScale. */
void AddPitchInput(float32 Val) {}
/* Function: ActivateTouchInterface 
 Activates a new touch interface for this player controller */
void ActivateTouchInterface(UTouchInterface NewTouchInterface) {}
/* Function: WasInputKeyJustReleased 
 Returns true if the given key/button was down last frame and up this frame. */
bool WasInputKeyJustReleased(FKey Key) const {}
/* Function: SetVirtualJoystickVisibility 
 Set the virtual joystick visibility. */
void SetVirtualJoystickVisibility(bool bVisible) {}
/* Function: AddRollInput 
 Add Roll input. This value is multiplied by InputRollScale.

Parameters:
    Val - Amount to add to Roll. This value is multiplied by InputRollScale. */
void AddRollInput(float32 Val) {}
/* Function: ProjectWorldLocationToScreen 
 Convert a World Space 3D position into a 2D Screen Space position.

Returns:
    true if the world coordinate was successfully projected to the screen. */
bool ProjectWorldLocationToScreen(FVector WorldLocation, FVector2D& ScreenLocation, bool bPlayerViewportRelative = false) const {}
/* Function: AddYawInput 
 Add Yaw (turn) input. This value is multiplied by InputYawScale.

Parameters:
    Val - Amount to add to Yaw. This value is multiplied by InputYawScale. */
void AddYawInput(float32 Val) {}
/* Function: CanRestartPlayer 
 Returns true if this controller thinks it's able to restart. Called from GameModeBase::PlayerCanRestart */
bool CanRestartPlayer() {}
/* Function: IsInputKeyDown 
 Returns true if the given key/button is pressed on the input of the controller (if present) */
bool IsInputKeyDown(FKey Key) const {}
/* Function: GetHitResultUnderCursorForObjects 
 Performs a collision query under the mouse cursor, looking for object types */
bool GetHitResultUnderCursorForObjects(TArray<EObjectTypeQuery> ObjectTypes, bool bTraceComplex, FHitResult& HitResult) const {}
/* Function: GetHitResultUnderCursorByChannel 
 Performs a collision query under the mouse cursor, looking on a trace channel */
bool GetHitResultUnderCursorByChannel(ETraceTypeQuery TraceChannel, bool bTraceComplex, FHitResult& HitResult) const {}
/* Function: GetHitResultUnderCursor 
  */
bool GetHitResultUnderCursor(ECollisionChannel TraceChannel, bool bTraceComplex, FHitResult& HitResult) const {}
/* Function: GetPlatformUserId 
 Returns the platform user that is assigned to this Player Controller's Local Player.
If there is no local player, then this will return PLATFORMUSERID_NONE */
FPlatformUserId GetPlatformUserId() const {}
/* Function: GetInputMotionState 
 Retrieves the current motion state of the player's input device */
void GetInputMotionState(FVector& Tilt, FVector& RotationRate, FVector& Gravity, FVector& Acceleration) const {}
/* Function: GetMousePosition 
 Retrieves the X and Y screen coordinates of the mouse cursor. Returns false if there is no associated mouse device */
bool GetMousePosition(float32& LocationX, float32& LocationY) const {}
/* Function: GetInputVectorKeyState 
 Returns the vector value for the given key/button. */
FVector GetInputVectorKeyState(FKey Key) const {}
/* Function: GetInputTouchState 
 Retrieves the X and Y screen coordinates of the specified touch key. Returns false if the touch index is not down */
void GetInputTouchState(ETouchIndex FingerIndex, float32& LocationX, float32& LocationY, bool& bIsCurrentlyPressed) const {}
/* Function: GetInputMouseDelta 
 Retrieves how far the mouse moved this frame. */
void GetInputMouseDelta(float32& DeltaX, float32& DeltaY) const {}
/* Function: GetHitResultUnderFinger 
  */
bool GetHitResultUnderFinger(ETouchIndex FingerIndex, ECollisionChannel TraceChannel, bool bTraceComplex, FHitResult& HitResult) const {}
/* Function: DeprojectScreenPositionToWorld 
 Convert 2D screen position to World Space 3D position and direction. Returns false if unable to determine value. * */
bool DeprojectScreenPositionToWorld(float32 ScreenX, float32 ScreenY, FVector& WorldLocation, FVector& WorldDirection) const {}
/* Function: GetInputAnalogStickState 
 Retrieves the X and Y displacement of the given analog stick. */
void GetInputAnalogStickState(EControllerAnalogStick WhichStick, float32& StickX, float32& StickY) const {}
/* Function: DeprojectMousePositionToWorld 
 Convert current mouse 2D position to World Space 3D position and direction. Returns false if unable to determine value. * */
bool DeprojectMousePositionToWorld(FVector& WorldLocation, FVector& WorldDirection) const {}
/* Function: GetHitResultUnderFingerByChannel 
 Performs a collision query under the finger, looking on a trace channel */
bool GetHitResultUnderFingerByChannel(ETouchIndex FingerIndex, ETraceTypeQuery TraceChannel, bool bTraceComplex, FHitResult& HitResult) const {}
/* Function: GetInputKeyTimeDown 
 Returns how long the given key/button has been down.  Returns 0 if it's up or it just went down this frame. */
float32 GetInputKeyTimeDown(FKey Key) const {}
/* Function: GetHitResultUnderFingerForObjects 
 Performs a collision query under the finger, looking for object types */
bool GetHitResultUnderFingerForObjects(ETouchIndex FingerIndex, TArray<EObjectTypeQuery> ObjectTypes, bool bTraceComplex, FHitResult& HitResult) const {}
/* Function: GetInputAnalogKeyState 
 Returns the analog value for the given key/button.  If analog isn't supported, returns 1 for down and 0 for up. */
float32 GetInputAnalogKeyState(FKey Key) const {}
// Group: HUD

/* Function: ClientSetHUD 
 Set the client's class of HUD and spawns a new instance of it. If there was already a HUD active, it is destroyed. */
void ClientSetHUD(TSubclassOf<AHUD> NewHUDClass) {}
/* Function: GetViewportSize 
 Helper to get the size of the HUD canvas for this player controller.  Returns 0 if there is no HUD */
void GetViewportSize(int& SizeX, int& SizeY) const {}
/* Function: GetHUD 
 Gets the HUD currently being used by this player controller */
AHUD GetHUD() const {}
// Group: Input

/* Function: GetOverridePlayerInputClass 
  */
TSubclassOf<UPlayerInput> GetOverridePlayerInputClass() const {}
/* Function: ResetControllerDeadZones 
 Resets the player's controller deadzones to default */
void ResetControllerDeadZones() {}
/* Function: SetControllerDeadZones 
 Sets the deadzones of the player's controller

Parameters:
    LeftDeadZone - Inner DeadZone for the left analog stick
    RightDeadZone - Inner DeadZone for the right analog stick */
void SetControllerDeadZones(float32 LeftDeadZone, float32 RightDeadZone) {}
// Group: Pawn

/* Function: GetSpectatorPawn 
 Get the Pawn used when spectating. nullptr when not spectating. */
ASpectatorPawn GetSpectatorPawn() const {}
/* Function: GetFocalLocation 
 Returns the location the PlayerController is focused on.
 If there is a possessed Pawn, returns the Pawn's location.
 If there is a spectator Pawn, returns that Pawn's location.
 Otherwise, returns the PlayerController's spawn location (usually the last known Pawn location after it has died). */
FVector GetFocalLocation() const {}
// Group: PlayerController

/* Function: SetDeprecatedInputYawScale 
  */
void SetDeprecatedInputYawScale(float32 NewValue) {}
/* Function: GetDeprecatedInputPitchScale 
  */
float32 GetDeprecatedInputPitchScale() const {}
/* Function: GetDeprecatedInputRollScale 
  */
float32 GetDeprecatedInputRollScale() const {}
/* Function: GetDeprecatedInputYawScale 
  */
float32 GetDeprecatedInputYawScale() const {}
/* Function: ServerSetSpectatorWaiting 
 Indicate that the Spectator is waiting to join/respawn. */
void ServerSetSpectatorWaiting(bool bWaiting) {}
/* Function: ClientSetSpectatorWaiting 
 Indicate that the Spectator is waiting to join/respawn. */
void ClientSetSpectatorWaiting(bool bWaiting) {}
/* Function: SetDeprecatedInputPitchScale 
  */
void SetDeprecatedInputPitchScale(float32 NewValue) {}
/* Function: SetDeprecatedInputRollScale 
  */
void SetDeprecatedInputRollScale(float32 NewValue) {}
// Group: WorldPartition

/* Function: GetStreamingSourceShapes 
 Gets the streaming source priority.
Default implementation returns StreamingSourceShapes but can be overriden in child classes.

Returns:
    the streaming source priority. */
void GetStreamingSourceShapes(TArray<FStreamingSourceShape>& OutShapes) const {}
/* Function: GetStreamingSourcePriority 
 Gets the streaming source priority.
Default implementation returns StreamingSourcePriority but can be overriden in child classes.

Returns:
    the streaming source priority. */
EStreamingSourcePriority GetStreamingSourcePriority() const {}
/* Function: StreamingSourceShouldBlockOnSlowStreaming 
 Whether the PlayerController streaming source should block on slow streaming.
Default implementation returns bStreamingSourceShouldBlockOnSlowStreaming but can be overriden in child classes.

Returns:
    true if it should. */
bool StreamingSourceShouldBlockOnSlowStreaming() const {}
/* Function: GetStreamingSourceLocationAndRotation 
 Gets the streaming source location and rotation.
Default implementation returns APlayerController::GetPlayerViewPoint but can be overriden in child classes. */
void GetStreamingSourceLocationAndRotation(FVector& OutLocation, FRotator& OutRotation) const {}
/* Function: StreamingSourceShouldActivate 
 Whether the PlayerController streaming source should activate cells after loading.
Default implementation returns bStreamingSourceShouldActivate but can be overriden in child classes.

Returns:
    true if it should. */
bool StreamingSourceShouldActivate() const {}
/* Function: IsStreamingSourceEnabled 
 Whether the PlayerController should be used as a World Partiton streaming source.
Default implementation returns bEnableStreamingSource but can be overriden in child classes.

Returns:
    true if it should. */
bool IsStreamingSourceEnabled() const {}
// Group: Functions

/* Function: ClientTeamMessage 
 @todo document */
void ClientTeamMessage(APlayerState SenderPlayerState, FString S, FName Type, float32 MsgLifeTime) {}
/* Function: ClientStartOnlineSession 
 Notify client that the session is starting */
void ClientStartOnlineSession() {}
/* Function: ClientUnmutePlayer 
 Tell the client to unmute a player for this controller

Parameters:
    PlayerId - player id to unmute */
void ClientUnmutePlayer(FUniqueNetIdRepl PlayerId) {}
/* Function: ClientSetViewTarget 
 Set the view target

Parameters:
    A - new actor to set as view target
    TransitionParams - parameters to use for controlling the transition */
void ClientSetViewTarget(AActor A, FViewTargetTransitionParams TransitionParams) {}
/* Function: ClientSetCameraMode 
 Replicated function to set camera style on client */
void ClientSetCameraMode(FName NewCamMode) {}
/* Function: ClientSetForceMipLevelsToBeResident 
 Forces the streaming system to disregard the normal logic for the specified duration and
instead always load all mip-levels for all textures used by the specified material.

Parameters:
    Material - The material whose textures should be forced into memory.
    ForceDuration - Number of seconds to keep all mip-levels in memory, disregarding the normal priority logic.
    CinematicTextureGroups - Bitfield indicating which texture groups that use extra high-resolution mips */
void ClientSetForceMipLevelsToBeResident(UMaterialInterface Material, float32 ForceDuration, int CinematicTextureGroups) {}
/* Function: ClientSetBlockOnAsyncLoading 
 Tells the client to block until all pending level streaming actions are complete.
Happens at the end of the tick primarily used to force update the client ASAP at join time. */
void ClientSetBlockOnAsyncLoading() {}
/* Function: ClientReturnToMainMenuWithTextReason 
 Return the client to the main menu gracefully */
void ClientReturnToMainMenuWithTextReason(FText ReturnReason) {}
/* Function: ClientRetryClientRestart 
 Assign Pawn to player, but avoid calling ClientRestart if we have already accepted this pawn */
void ClientRetryClientRestart(APawn NewPawn) {}
/* Function: ClientTravelInternal 
 Internal clientside implementation of ClientTravel - use ClientTravel to call this

Parameters:
    URL - A string containing the mapname (or IP address) to travel to, along with option key/value pairs
    TravelType - specifies whether the client should append URL options used in previous travels; if true is specified for the bSeamlesss parameter, this value must be TRAVEL_Relative.
    bSeamless - Indicates whether to use seamless travel (requires TravelType of TRAVEL_Relative)
    MapPackageGuid - The GUID of the map package to travel to - this is used to find the file when it has been autodownloaded, so it is only needed for clients */
void ClientTravelInternal(FString URL, ETravelType TravelType, bool bSeamless, FGuid MapPackageGuid) {}
/* Function: ClientSetCinematicMode 
 Called by the server to synchronize cinematic transitions with the client */
void ClientSetCinematicMode(bool bInCinematicMode, bool bAffectsMovement, bool bAffectsTurning, bool bAffectsHUD) {}
/* Function: ClientSetCameraFade 
 Tell client to fade camera

Parameters:
    bEnableFading - true if we should apply FadeColor/FadeAmount to the screen
    FadeColor - Color to fade to
    FadeAlpha - Contains the start fade (X) and end fade (Y) values to apply. A start fade of less than 0 will use the screen's current fade value
    FadeTime - length of time for fade to occur over
    bFadeAudio - true to apply fading of audio alongside the video
    bHoldWhenFinished - True for fade to hold at the ToAlpha until fade is disabled */
void ClientSetCameraFade(bool bEnableFading, FColor FadeColor, FVector2D FadeAlpha, float32 FadeTime, bool bFadeAudio, bool bHoldWhenFinished) {}
/* Function: ClientUnmutePlayers 
 Tell the client to unmute an array of players for this controller

Parameters:
    PlayerIds - player ids to unmute */
void ClientUnmutePlayers(TArray<FUniqueNetIdRepl> PlayerIds) {}
/* Function: ClientRestart 
 Tell client to restart the level */
void ClientRestart(APawn NewPawn) {}
/* Function: ClientReset 
 Tell client to reset the PlayerController */
void ClientReset() {}
/* Function: ClientVoiceHandshakeComplete 
 Tells the client that the server has all the information it needs and that it
is ok to start sending voice packets. The server will already send voice packets
when this function is called, since it is set server side and then forwarded

NOTE: This is done as an RPC instead of variable replication because ordering matters */
void ClientVoiceHandshakeComplete() {}
/* Function: ClientRepObjRef 
 Development RPC for testing object reference replication */
void ClientRepObjRef(UObject Object) {}
/* Function: OnServerStartedVisualLogger 
 Notify from server that Visual Logger is recording, to show that information on client about possible performance issues */
void OnServerStartedVisualLogger(bool bIsLogging) {}
/* Function: ClientRecvServerAckFrameDebug 
  */
void ClientRecvServerAckFrameDebug(uint8 NumBuffered, float32 TargetNumBufferedCmds) {}
/* Function: ClientRecvServerAckFrame 
  */
void ClientRecvServerAckFrame(int LastProcessedInputFrame, int RecvServerFrameNumber, int8 TimeDilation) {}
/* Function: ClientReceiveLocalizedMessage 
 send client localized message id */
void ClientReceiveLocalizedMessage(TSubclassOf<ULocalMessage> Message, int Switch, APlayerState RelatedPlayerState_1, APlayerState RelatedPlayerState_2, UObject OptionalObject) {}
/* Function: ClientPrestreamTextures 
 Forces the streaming system to disregard the normal logic for the specified duration and
instead always load all mip-levels for all textures used by the specified actor.

Parameters:
    ForcedActor - The actor whose textures should be forced into memory.
    ForceDuration - Number of seconds to keep all mip-levels in memory, disregarding the normal priority logic.
    bEnableStreaming - Whether to start (true) or stop (false) streaming
    CinematicTextureGroups - Bitfield indicating which texture groups that use extra high-resolution mips */
void ClientPrestreamTextures(AActor ForcedActor, float32 ForceDuration, bool bEnableStreaming, int CinematicTextureGroups) {}
/* Function: ClientPrepareMapChange 
 Asynchronously loads the given level in preparation for a streaming map transition.
the server sends one function per level name since dynamic arrays can't be replicated

Parameters:
    bFirst - whether this is the first item in the list (so clear the list first)
    bLast - whether this is the last item in the list (so start preparing the change after receiving it) */
void ClientPrepareMapChange(FName LevelName, bool bFirst, bool bLast) {}
/* Function: ServerAcknowledgePossession 
 acknowledge possession of pawn */
void ServerAcknowledgePossession(APawn P) {}
/* Function: ServerBlockPlayer 
 Tell the client to block a player for this controller

Parameters:
    PlayerId - player id to block */
void ServerBlockPlayer(FUniqueNetIdRepl PlayerId) {}
/* Function: ServerCamera 
 change mode of camera */
void ServerCamera(FName NewMode) {}
/* Function: ServerChangeName 
 Change name of server */
void ServerChangeName(FString S) {}
/* Function: ServerCheckClientPossession 
 Tells the server to make sure the possessed pawn is in sync with the client. */
void ServerCheckClientPossession() {}
/* Function: SetPlayer 
  */
void SetPlayer(UPlayer InPlayer) {}
/* Function: ServerCheckClientPossessionReliable 
 Reliable version of ServerCheckClientPossession to be used when there is no likely danger of spamming the network. */
void ServerCheckClientPossessionReliable() {}
/* Function: ServerMutePlayer 
 Tell the server to mute a player for this controller

Parameters:
    PlayerId - player id to mute */
void ServerMutePlayer(FUniqueNetIdRepl PlayerId) {}
/* Function: ServerNotifyLoadedWorld 
 Called to notify the server when the client has loaded a new world via seamless traveling

Parameters:
    WorldPackageName - the name of the world package that was loaded */
void ServerNotifyLoadedWorld(FName WorldPackageName) {}
/* Function: ServerPause 
 Replicate pause request to the server */
void ServerPause() {}
/* Function: ServerRecvClientInputFrame 
  */
void ServerRecvClientInputFrame(int RecvClientInputFrame, TArray<uint8> Data) {}
/* Function: ServerRestartPlayer 
 Attempts to restart this player, generally called from the client upon respawn request. */
void ServerRestartPlayer() {}
/* Function: ServerSetSpectatorLocation 
 When spectating, updates spectator location/rotation and pings the server to make sure spectating should continue. */
void ServerSetSpectatorLocation(FVector NewLoc, FRotator NewRot) {}
/* Function: ClientPlaySoundAtLocation 
 Play sound client-side at the specified location

Parameters:
    Sound - Sound to play
    Location - Location to play the sound at
    VolumeMultiplier - Volume multiplier to apply to the sound
    PitchMultiplier - Pitch multiplier to apply to the sound */
void ClientPlaySoundAtLocation(USoundBase Sound, FVector Location, float32 VolumeMultiplier, float32 PitchMultiplier) {}
/* Function: ServerShortTimeout 
 Notifies the server that the client has ticked gameplay code, and should no longer get the extended "still loading" timeout grace period */
void ServerShortTimeout() {}
/* Function: ServerToggleAILogging 
 Used by UGameplayDebuggingControllerComponent to replicate messages for AI debugging in network games. */
void ServerToggleAILogging() {}
/* Function: ServerUnblockPlayer 
 Tell the client to unblock a player for this controller

Parameters:
    PlayerId - player id to unblock */
void ServerUnblockPlayer(FUniqueNetIdRepl PlayerId) {}
/* Function: ServerUnmutePlayer 
 Tell the server to unmute a player for this controller

Parameters:
    PlayerId - player id to unmute */
void ServerUnmutePlayer(FUniqueNetIdRepl PlayerId) {}
/* Function: ServerUpdateCamera 
 If PlayerCamera.bUseClientSideCameraUpdates is set, client will replicate camera positions to the server. // @TODO - combine pitch/yaw into one int, maybe also send location compressed */
void ServerUpdateCamera(FVector CamLoc, int CamPitchAndYaw) {}
/* Function: ServerVerifyViewTarget 
 Used by client to request server to confirm current viewtarget (server will respond with ClientSetViewTarget() ). */
void ServerVerifyViewTarget() {}
/* Function: ServerViewNextPlayer 
 Move camera to next player on round ended or spectating */
void ServerViewNextPlayer() {}
/* Function: ServerViewPrevPlayer 
 Move camera to previous player on round ended or spectating */
void ServerViewPrevPlayer() {}
/* Function: ServerViewSelf 
 Move camera to current user */
void ServerViewSelf(FViewTargetTransitionParams TransitionParams) {}
/* Function: ClientWasKicked 
 Notify client they were kicked from the server */
void ClientWasKicked(FText KickReason) {}
/* Function: ClientMutePlayer 
 Tell the client to mute a player for this controller

Parameters:
    PlayerId - player id to mute */
void ClientMutePlayer(FUniqueNetIdRepl PlayerId) {}
/* Function: ClientMessage 
 Outputs a message to HUD

Parameters:
    S - message to display
    MsgLifeTime - Optional length of time to display 0 = default time */
void ClientMessage(FString S, FName Type, float32 MsgLifeTime) {}
/* Function: ClientIgnoreMoveInput 
 Calls IgnoreMoveInput on client */
void ClientIgnoreMoveInput(bool bIgnore) {}
/* Function: ClientIgnoreLookInput 
 Calls IgnoreLookInput on client */
void ClientIgnoreLookInput(bool bIgnore) {}
/* Function: ClientGotoState 
 Server uses this to force client into NewState .
Note: ALL STATE NAMES NEED TO BE DEFINED IN name table in UnrealNames.h to be correctly replicated (so they are mapped to the same thing on client and server). */
void ClientGotoState(FName NewState) {}
/* Function: ClientGameEnded 
 Replicated function called by GameHasEnded().

Parameters:
    EndGameFocus - actor to view with camera
    bIsWinner - true if this controller is on winning team */
void ClientGameEnded(AActor EndGameFocus, bool bIsWinner) {}
/* Function: ClientForceGarbageCollection 
 Forces GC at the end of the tick on the client */
void ClientForceGarbageCollection() {}
/* Function: ClientFlushLevelStreaming 
 Tells the client to block until all pending level streaming actions are complete
happens at the end of the tick
primarily used to force update the client ASAP at join time */
void ClientFlushLevelStreaming() {}
/* Function: ClientEndOnlineSession 
 Notify client that the session is about to start */
void ClientEndOnlineSession() {}
/* Function: SetMotionControlsEnabled 
  */
void SetMotionControlsEnabled(bool bEnabled) {}
/* Function: ClientEnableNetworkVoice 
 Tell the client to enable or disable voice chat (not muting)

Parameters:
    bEnable - enable or disable voice chat */
void ClientEnableNetworkVoice(bool bEnable) {}
/* Function: ClientCommitMapChange 
 Actually performs the level transition prepared by PrepareMapChange(). */
void ClientCommitMapChange() {}
/* Function: ClientCapBandwidth 
 Set CurrentNetSpeed to the lower of its current value and Cap. */
void ClientCapBandwidth(int Cap) {}
/* Function: ClientCancelPendingMapChange 
 Tells client to cancel any pending map change. */
void ClientCancelPendingMapChange() {}
/* Function: ClientAddTextureStreamingLoc 
 Adds a location to the texture streaming system for the specified duration. */
void ClientAddTextureStreamingLoc(FVector InLoc, float32 Duration, bool bOverrideLocation) {}
/* Function: ServerExecRPC 
 RPC used by ServerExec. Not intended to be called directly */
void ServerExecRPC(FString Msg) {}
/* Function: ClientPlaySound 
 Play sound client-side (so only the client will hear it)

Parameters:
    Sound - Sound to play
    VolumeMultiplier - Volume multiplier to apply to the sound
    PitchMultiplier - Pitch multiplier to apply to the sound */
void ClientPlaySound(USoundBase Sound, float32 VolumeMultiplier, float32 PitchMultiplier) {}
/* Function: ClientAckTimeDilation 
 Client receives the time dilation value it needs to use to keep its ServerFrame to LocalFrame offset in sync */
void ClientAckTimeDilation(float32 TimeDilation, int ServerStep) {}
/* Function: GetLocalPlayer 
  */
ULocalPlayer GetLocalPlayer() const {}
/* Function: SetbEnableMotionControls 
 Whether or not to consider input from motion sources (tilt, acceleration, etc) */
void SetbEnableMotionControls(bool bEnabled) {}
/* Function: GetPlayerInput 
  */
UPlayerInput GetPlayerInput() {}
/* Function: PopInputComponent 
 Remove an input component so it no longer handles input from this player controller. */
void PopInputComponent(UInputComponent Component) {}
/* Function: PushInputComponent 
 Push an input component to handle input from this player controller. */
void PushInputComponent(UInputComponent Component) {}
/* Function: GetbPlayerIsWaiting 
 True if PlayerController is currently waiting for the match to start or to respawn. Only valid in Spectating state. */
bool GetbPlayerIsWaiting() const {}
/* Function: GetbShowMouseCursor 
 Whether the mouse cursor should be displayed. */
bool GetbShowMouseCursor() const {}
/* Function: SetbShowMouseCursor 
 Whether the mouse cursor should be displayed. */
void SetbShowMouseCursor(bool Value) {}
/* Function: GetbEnableClickEvents 
 Whether actor/component click events should be generated. */
bool GetbEnableClickEvents() const {}
/* Function: SetbEnableClickEvents 
 Whether actor/component click events should be generated. */
void SetbEnableClickEvents(bool Value) {}
/* Function: GetbEnableTouchEvents 
 Whether actor/component touch events should be generated. */
bool GetbEnableTouchEvents() const {}
/* Function: SetbEnableTouchEvents 
 Whether actor/component touch events should be generated. */
void SetbEnableTouchEvents(bool Value) {}
/* Function: GetbEnableMouseOverEvents 
 Whether actor/component mouse over events should be generated. */
bool GetbEnableMouseOverEvents() const {}
/* Function: SetbEnableMouseOverEvents 
 Whether actor/component mouse over events should be generated. */
void SetbEnableMouseOverEvents(bool Value) {}
/* Function: GetbEnableTouchOverEvents 
 Whether actor/component touch over events should be generated. */
bool GetbEnableTouchOverEvents() const {}
/* Function: SetbEnableTouchOverEvents 
 Whether actor/component touch over events should be generated. */
void SetbEnableTouchOverEvents(bool Value) {}
/* Function: GetbForceFeedbackEnabled 
  */
bool GetbForceFeedbackEnabled() const {}
/* Function: SetbForceFeedbackEnabled 
  */
void SetbForceFeedbackEnabled(bool Value) {}
/* Function: GetbEnableMotionControls 
 Whether or not to consider input from motion sources (tilt, acceleration, etc) */
bool GetbEnableMotionControls() const {}
/* Function: GetbEnableStreamingSource 
 Whether the PlayerController should be used as a World Partiton streaming source. */
bool GetbEnableStreamingSource() const {}
/* Function: SetbEnableStreamingSource 
 Whether the PlayerController should be used as a World Partiton streaming source. */
void SetbEnableStreamingSource(bool Value) {}
/* Function: GetbStreamingSourceShouldActivate 
 Whether the PlayerController streaming source should activate cells after loading. */
bool GetbStreamingSourceShouldActivate() const {}
/* Function: SetbStreamingSourceShouldActivate 
 Whether the PlayerController streaming source should activate cells after loading. */
void SetbStreamingSourceShouldActivate(bool Value) {}
/* Function: GetbStreamingSourceShouldBlockOnSlowStreaming 
 Whether the PlayerController streaming source should block on slow streaming. */
bool GetbStreamingSourceShouldBlockOnSlowStreaming() const {}
/* Function: SetbStreamingSourceShouldBlockOnSlowStreaming 
 Whether the PlayerController streaming source should block on slow streaming. */
void SetbStreamingSourceShouldBlockOnSlowStreaming(bool Value) {}
/* Function: SetStreamingSourcePriority 
 PlayerController streaming source priority. */
void SetStreamingSourcePriority(const EStreamingSourcePriority& Value) {}
/* Function: SetStreamingSourceShapes 
 Optional aggregated shape list used to build a custom shape for the streaming source. When empty, fallbacks sphere shape with a radius equal to grid's loading range. */
void SetStreamingSourceShapes(TArray<FStreamingSourceShape> Value) {}
/* Function: GetbShouldPerformFullTickWhenPaused 
 Whether we fully tick when the game is paused, if our tick function is allowed to do so. If false, we do a minimal update during the tick. */
bool GetbShouldPerformFullTickWhenPaused() const {}
/* Function: SetbShouldPerformFullTickWhenPaused 
 Whether we fully tick when the game is paused, if our tick function is allowed to do so. If false, we do a minimal update during the tick. */
void SetbShouldPerformFullTickWhenPaused(bool Value) {}
/* Function: SetOverridePlayerInputClass 
 If set, then this UPlayerInput class will be used instead of the Input Settings' DefaultPlayerInputClass */
void SetOverridePlayerInputClass(TSubclassOf<UPlayerInput> Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static APlayerController APlayerController::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APlayerController::StaticClass() {}
}
