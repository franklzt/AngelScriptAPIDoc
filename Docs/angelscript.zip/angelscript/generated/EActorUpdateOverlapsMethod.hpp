/* Class: EActorUpdateOverlapsMethod 
  */ 
 class EActorUpdateOverlapsMethod
{
public:
}
/* Enum: EActorUpdateOverlapsMethod 
 
    UseConfigDefault - Enum
    AlwaysUpdate - Enum
    OnlyUpdateMovable - Enum
    NeverUpdate - Enum
    EActorUpdateOverlapsMethod_MAX - Enum */ 
 enum EActorUpdateOverlapsMethod { 
UseConfigDefault,
AlwaysUpdate,
OnlyUpdateMovable,
NeverUpdate,
EActorUpdateOverlapsMethod_MAX, 
}