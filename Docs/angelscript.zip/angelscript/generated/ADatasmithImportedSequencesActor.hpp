/* Class: ADatasmithImportedSequencesActor 
  */ 
 class ADatasmithImportedSequencesActor : public AActor
{
public:
// Group: ImportedSequences

/* Variable: ImportedSequences 
  */
TArray<TObjectPtr<ULevelSequence>> ImportedSequences;
// Group: ImportedSequences

/* Function: PlayLevelSequence 
  */
void PlayLevelSequence(ULevelSequence SequenceToPlay) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ADatasmithImportedSequencesActor ADatasmithImportedSequencesActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADatasmithImportedSequencesActor::StaticClass() {}
}
