/* Class: EBaseCreateFromSelectedTargetType 
  */ 
 class EBaseCreateFromSelectedTargetType
{
public:
}
/* Enum: EBaseCreateFromSelectedTargetType 
 
    NewObject - Enum
    FirstInputObject - Enum
    LastInputObject - Enum
    EBaseCreateFromSelectedTargetType_MAX - Enum */ 
 enum EBaseCreateFromSelectedTargetType { 
NewObject,
FirstInputObject,
LastInputObject,
EBaseCreateFromSelectedTargetType_MAX, 
}