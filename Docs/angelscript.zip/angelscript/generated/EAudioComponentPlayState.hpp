/* Class: EAudioComponentPlayState 
  */ 
 class EAudioComponentPlayState
{
public:
}
/* Enum: EAudioComponentPlayState 
 
    Playing - Enum
    Stopped - Enum
    Paused - Enum
    FadingIn - Enum
    FadingOut - Enum
    Count - Enum
    EAudioComponentPlayState_MAX - Enum */ 
 enum EAudioComponentPlayState { 
Playing,
Stopped,
Paused,
FadingIn,
FadingOut,
Count,
EAudioComponentPlayState_MAX, 
}