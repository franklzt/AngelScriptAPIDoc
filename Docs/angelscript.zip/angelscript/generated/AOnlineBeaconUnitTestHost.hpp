/* Class: AOnlineBeaconUnitTestHost 
  */ 
 class AOnlineBeaconUnitTestHost : public AOnlineBeaconHost
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AOnlineBeaconUnitTestHost AOnlineBeaconUnitTestHost::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AOnlineBeaconUnitTestHost::StaticClass() {}
}
