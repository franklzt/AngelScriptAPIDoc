/* Class: ATemplateSequenceActor 
 Actor responsible for controlling a specific template sequence in the world. */ 
 class ATemplateSequenceActor : public AActor
{
public:
// Group: General

/* Variable: TemplateSequence 
  */
FSoftObjectPath TemplateSequence;
/* Variable: BindingOverride 
 The override for the template sequence's root object binding. See SetBinding. */
FTemplateSequenceBindingOverrideData BindingOverride;
// Group: Playback

/* Variable: SequencePlayer 
  */
UTemplateSequencePlayer SequencePlayer;
/* Variable: PlaybackSettings 
  */
FMovieSceneSequencePlaybackSettings PlaybackSettings;
// Group: Sequencer|Player

/* Variable: Sequence 
 Get the template sequence being played by this actor. */
UTemplateSequence Sequence;
// Group: Sequencer|Player

/* Function: SetSequence 
 Set the template sequence being played by this actor. */
void SetSequence(UTemplateSequence InSequence) {}
/* Function: LoadSequence 
 Get the template sequence being played by this actor.

Returns:
    the template sequence, or nullptr if it is not assigned or cannot be loaded */
UTemplateSequence LoadSequence() const {}
/* Function: GetSequence 
 Get the template sequence being played by this actor.

Returns:
    the template sequence, or nullptr if it is not assigned or cannot be loaded */
UTemplateSequence GetSequence() const {}
// Group: Sequencer|Player|Bindings

/* Function: SetBinding 
 Set the actor to play the template sequence onto, by setting up an override for the template
sequence's root object binding. */
void SetBinding(AActor Actor, bool bOverridesDefault = true) {}
// Group: Functions

/* Function: SetSequencePlayer 
  */
void SetSequencePlayer(UTemplateSequencePlayer Value) {}
/* Function: GetSequencePlayer 
 Get the actor's sequence player, or nullptr if it not yet initialized. */
UTemplateSequencePlayer GetSequencePlayer() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ATemplateSequenceActor ATemplateSequenceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATemplateSequenceActor::StaticClass() {}
}
