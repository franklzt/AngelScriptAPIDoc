/* Class: AActor 
 Actor is the base class for an Object that can be placed or spawned in a level.
Actors may contain a collection of ActorComponents, which can be used to control how actors move, how they are rendered, etc.
The other main function of an Actor is the replication of properties and function calls across the network during play.


Actor initialization has multiple steps, here's the order of important virtual functions that get called:
- UObject::PostLoad: For actors statically placed in a level, the normal UObject PostLoad gets called both in the editor and during gameplay.
                     This is not called for newly spawned actors.
- UActorComponent::OnComponentCreated: When an actor is spawned in the editor or during gameplay, this gets called for any native components.
                                       For blueprint-created components, this gets called during construction for that component.
                                       This is not called for components loaded from a level.
- AActor::PreRegisterAllComponents: For statically placed actors and spawned actors that have native root components, this gets called now.
                                    For blueprint actors without a native root component, these registration functions get called later during construction.
- UActorComponent::RegisterComponent: All components are registered in editor and at runtime, this creates their physical/visual representation.
                                      These calls may be distributed over multiple frames, but are always after PreRegisterAllComponents.
                                      This may also get called later on after an UnregisterComponent call removes it from the world.
- AActor::PostRegisterAllComponents: Called for all actors both in the editor and in gameplay, this is the last function that is called in all cases.
- AActor::PostActorCreated: When an actor is created in the editor or during gameplay, this gets called right before construction.
                            This is not called for components loaded from a level.
- AActor::UserConstructionScript: Called for blueprints that implement a construction script.
- AActor::OnConstruction: Called at the end of ExecuteConstruction, which calls the blueprint construction script.
                          This is called after all blueprint-created components are fully created and registered.
                          This is only called during gameplay for spawned actors, and may get rerun in the editor when changing blueprints.
- AActor::PreInitializeComponents: Called before InitializeComponent is called on the actor's components.
                                   This is only called during gameplay and in certain editor preview windows.
- UActorComponent::Activate: This will be called only if the component has bAutoActivate set.
                             It will also got called later on if a component is manually activated.
- UActorComponent::InitializeComponent: This will be called only if the component has bWantsInitializeComponentSet.
                                        This only happens once per gameplay session.
- AActor::PostInitializeComponents: Called after the actor's components have been initialized, only during gameplay and some editor previews.
- AActor::BeginPlay: Called when the level starts ticking, only during actual gameplay.
                     This normally happens right after PostInitializeComponents but can be delayed for networked or child actors.

@see https://docs.unrealengine.com/Programming/UnrealArchitecture/Actors
@see https://docs.unrealengine.com/Programming/UnrealArchitecture/Actors/ActorLifecycle
@see UActorComponent */ 
 class AActor : public UObject
{
public:
// Group: Actor

/* Variable: ActorTimeDilation 
 Get ActorTimeDilation - this can be used for input control or speed control for slomo.
We don't want to scale input globally because input can be used for UI, which do not care for TimeDilation. */
const float32 ActorTimeDilation;
/* Variable: ContentBundleGuid 
 The GUID for this actor's content bundle. */
FGuid ContentBundleGuid;
/* Variable: InitialLifeSpan 
 How long this Actor lives before dying, 0=forever. Note this is the INITIAL value and should not be modified once play has begun. */
float32 InitialLifeSpan;
/* Variable: CustomTimeDilation 
 Allow each actor to run at a different time speed. The DeltaTime for a frame is multiplied by the global TimeDilation (in WorldSettings) and this CustomTimeDilation for this actor's tick. */
float32 CustomTimeDilation;
/* Variable: ActorInstanceGuid 
 The instance GUID for this actor; this guid will be unique for actors from instanced streaming levels.
@see         ActorGuid
@note        This is not guaranteed to be valid during PostLoad, but safe to access from RegisterAllComponents. */
FGuid ActorInstanceGuid;
/* Variable: ParentActor 
 If this Actor was created by a Child Actor Component returns the Actor that owns that Child Actor Component */
const AActor ParentActor;
/* Variable: SpawnCollisionHandlingMethod 
 Controls how to handle spawning this actor in a situation where it's colliding with something else. "Default" means AlwaysSpawn here. */
ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod;
/* Variable: LifeSpan 
 Get the remaining lifespan of this actor. If zero is returned the actor lives forever. */
float32 LifeSpan;
/* Variable: Instigator 
 Pawn responsible for damage and other gameplay events caused by this actor. */
APawn Instigator;
/* Variable: GameTimeSinceCreation 
 The number of seconds (in game time) since this Actor was created, relative to Get Game Time In Seconds. */
const float32 GameTimeSinceCreation;
/* Variable: PivotOffset 
 Local space pivot offset for the actor, only used in the editor */
FVector PivotOffset;
/* Variable: bFindCameraComponentWhenViewTarget 
 If true, this actor should search for an owned camera component to view through when used as a view target. */
bool bFindCameraComponentWhenViewTarget;
/* Variable: Layers 
 Layers the actor belongs to.  This is outside of the editoronly data to allow hiding of LD-specified layers at runtime for profiling. */
TArray<FName> Layers;
/* Variable: bCanBeDamaged 
 Whether this actor can take damage. Must be true for damage events (e.g. ReceiveDamage()) to be called.
@see https://www.unrealengine.com/blog/damage-in-ue4
@see TakeDamage(), ReceiveDamage() */
bool bCanBeDamaged;
/* Variable: ActorGuid 
 The GUID for this actor; this guid will be the same for actors from instanced streaming levels.
@see         ActorInstanceGuid, FActorInstanceGuidMapper
@note        Don't use VisibleAnywhere here to avoid getting the CPF_Edit flag and get this property reset when resetting to defaults.
                     See FActorDetails::AddActorCategory and EditorUtilities::CopySingleProperty for details. */
FGuid ActorGuid;
/* Variable: bAutoDestroyWhenFinished 
 If true then destroy self when "finished", meaning all relevant components report that they are done and no timelines or timers are in flight. */
bool bAutoDestroyWhenFinished;
/* Variable: AttachParentSocketName 
 Walk up the attachment chain from RootComponent until we encounter a different actor, and return the socket name in the component. If we are not attached to a component in a different actor, returns NAME_None */
const FName AttachParentSocketName;
/* Variable: Tags 
 Array of tags that can be used for grouping and categorizing. */
TArray<FName> Tags;
/* Variable: AttachParentActor 
 Walk up the attachment chain from RootComponent until we encounter a different actor, and return it. If we are not attached to a component in a different actor, returns nullptr */
const AActor AttachParentActor;
// Group: Actor|Tick

/* Variable: ActorTickInterval 
 Returns the tick interval of this actor's primary tick function */
float32 ActorTickInterval;
/* Variable: TickableWhenPaused 
 Gets whether this actor can tick when paused. */
bool TickableWhenPaused;
// Group: Collision

/* Variable: UpdateOverlapsMethodDuringLevelStreaming 
 Condition for calling UpdateOverlaps() to initialize overlap state when loaded in during level streaming.
If set to 'UseConfigDefault', the default specified in ini (displayed in 'DefaultUpdateOverlapsMethodDuringLevelStreaming') will be used.
If overlaps are not initialized, this actor and attached components will not have an initial state of what objects are touching it,
and overlap events may only come in once one of those objects update overlaps themselves (for example when moving).
However if an object touching it *does* initialize state, both objects will know about their touching state with each other.
This can be a potentially large performance savings during level loading and streaming, and is safe if the object and others initially
overlapping it do not need the overlap state because they will not trigger overlap notifications.

Note that if 'bGenerateOverlapEventsDuringLevelStreaming' is true, overlaps are always updated in this case, but that flag
determines whether the Begin/End overlap events are triggered.

@see bGenerateOverlapEventsDuringLevelStreaming, DefaultUpdateOverlapsMethodDuringLevelStreaming, GetUpdateOverlapsMethodDuringLevelStreaming() */
EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming;
/* Variable: OnActorBeginOverlap 
 Called when another actor begins to overlap this actor, for example a player walking into a trigger.
For events when objects have a blocking collision, for example a player hitting a wall, see 'Hit' events.
@note Components on both this and the other Actor must have bGenerateOverlapEvents set to true to generate overlap events. */
FActorBeginOverlapSignature OnActorBeginOverlap;
/* Variable: OnActorEndOverlap 
 Called when another actor stops overlapping this actor.
@note Components on both this and the other Actor must have bGenerateOverlapEvents set to true to generate overlap events. */
FActorEndOverlapSignature OnActorEndOverlap;
/* Variable: bGenerateOverlapEventsDuringLevelStreaming 
 If true, this actor will generate overlap Begin/End events when spawned as part of level streaming, which includes initial level load.
You might enable this is in the case where a streaming level loads around an actor and you want Begin/End overlap events to trigger.
@see UpdateOverlapsMethodDuringLevelStreaming */
bool bGenerateOverlapEventsDuringLevelStreaming;
/* Variable: ActorEnableCollision 
 Get current state of collision for the whole actor */
bool ActorEnableCollision;
/* Variable: OnActorHit 
 Called when this Actor hits (or is hit by) something solid. This could happen due to things like Character movement, using Set Location with 'sweep' enabled, or physics simulation.
For events when objects overlap (e.g. walking into a trigger) see the 'Overlap' event.
@note For collisions during physics simulation to generate hit events, 'Simulation Generates Hit Events' must be enabled. */
FActorHitSignature OnActorHit;
// Group: DataLayers

/* Variable: DataLayerAssets 
 There is currently an issue where if we allow property override of DataLayerAssets and it contains Private datalayers
then it will always serialize a diff since those are outered to the instanced level and will get remapped differently between the Override instance and Archetype instance we are comparing against */
TArray<TSoftObjectPtr<UDataLayerAsset>> DataLayerAssets;
// Group: Editor Scripting | Actor Editing

/* Variable: DefaultActorLabel 
 Returns this actor's default label (does not include any numeric suffix).  Actor labels are only available in development builds. */
const FString DefaultActorLabel;
// Group: Game

/* Variable: OnDestroyed 
 Event triggered when the actor has been explicitly destroyed. */
FActorDestroyedSignature OnDestroyed;
/* Variable: InstigatorController 
 Returns the instigator's controller for this actor, or nullptr if there is none. */
const AController InstigatorController;
/* Variable: OnEndPlay 
 Event triggered when the actor is being deleted or removed from a level. */
FActorEndPlaySignature OnEndPlay;
// Group: Game|Damage

/* Variable: OnTakePointDamage 
 Called when the actor is damaged by point damage. */
FTakePointDamageSignature OnTakePointDamage;
/* Variable: OnTakeAnyDamage 
 Called when the actor is damaged in any way. */
FTakeAnyDamageSignature OnTakeAnyDamage;
/* Variable: OnTakeRadialDamage 
 Called when the actor is damaged by radial damage. */
FTakeRadialDamageSignature OnTakeRadialDamage;
// Group: HLOD

/* Variable: bEnableAutoLODGeneration 
 Whether this actor should be considered or not during HLOD generation. */
bool bEnableAutoLODGeneration;
/* Variable: HLODLayer 
 The UHLODLayer in which this actor should be included. */
UHLODLayer HLODLayer;
// Group: Input

/* Variable: AutoReceiveInput 
 Automatically registers this actor to receive input from a player. */
EAutoReceiveInput AutoReceiveInput;
/* Variable: InputPriority 
 The priority of this input component when pushed in to the stack. */
int InputPriority;
// Group: Input|Mouse Input

/* Variable: OnClicked 
 Called when the left mouse button is clicked while the mouse is over this actor and click events are enabled in the player controller. */
FActorOnClickedSignature OnClicked;
/* Variable: OnReleased 
 Called when the left mouse button is released while the mouse is over this actor and click events are enabled in the player controller. */
FActorOnReleasedSignature OnReleased;
/* Variable: OnEndCursorOver 
 Called when the mouse cursor is moved off this actor if mouse over events are enabled in the player controller. */
FActorEndCursorOverSignature OnEndCursorOver;
/* Variable: OnBeginCursorOver 
 Called when the mouse cursor is moved over this actor if mouse over events are enabled in the player controller. */
FActorBeginCursorOverSignature OnBeginCursorOver;
// Group: Input|Touch Input

/* Variable: OnInputTouchEnter 
 Called when a finger is moved over this actor when touch over events are enabled in the player controller. */
FActorBeginTouchOverSignature OnInputTouchEnter;
/* Variable: OnInputTouchBegin 
 Called when a touch input is received over this actor when touch events are enabled in the player controller. */
FActorOnInputTouchBeginSignature OnInputTouchBegin;
/* Variable: OnInputTouchLeave 
 Called when a finger is moved off this actor when touch over events are enabled in the player controller. */
FActorEndTouchOverSignature OnInputTouchLeave;
/* Variable: OnInputTouchEnd 
 Called when a touch input is received over this component when touch events are enabled in the player controller. */
FActorOnInputTouchEndSignature OnInputTouchEnd;
// Group: Level

/* Variable: LevelTransform 
 Return the FTransform of the level this actor is a part of. */
const FTransform LevelTransform;
/* Variable: Level 
 Return the ULevel that this Actor is part of. */
const ULevel Level;
// Group: Networking

/* Variable: LocalRole 
 Returns how much control the local machine has over this actor. */
const ENetRole LocalRole;
/* Variable: RemoteRole 
 Describes how much control the remote machine has over the actor. */
const ENetRole RemoteRole;
// Group: Physics

/* Variable: ResimulationThreshold 
 Get the error threshold in centimeters before this object should enforce a resimulation to trigger. */
const float32 ResimulationThreshold;
// Group: Rendering

/* Variable: bHidden 
 Allows us to only see this Actor in the Editor, and not in the actual game.
@see SetActorHiddenInGame() */
bool bHidden;
/* Variable: SpriteScale 
 The scale to apply to any billboard components in editor builds (happens in any WITH_EDITOR build, including non-cooked games). */
float32 SpriteScale;
// Group: Replication

/* Variable: NetUpdateFrequency 
  */
float32 NetUpdateFrequency;
/* Variable: bAlwaysRelevant 
 Always relevant for network (overrides bOnlyRelevantToOwner). */
bool bAlwaysRelevant;
/* Variable: bNetUseOwnerRelevancy 
 If actor has valid Owner, call Owner's IsNetRelevantFor and GetNetPriority */
bool bNetUseOwnerRelevancy;
/* Variable: bReplicates 
 If true, this actor will replicate to remote machines
@see SetReplicates() */
bool bReplicates;
/* Variable: MinNetUpdateFrequency 
  */
float32 MinNetUpdateFrequency;
/* Variable: NetCullDistanceSquared 
  */
float32 NetCullDistanceSquared;
/* Variable: NetPriority 
 Priority for this actor when checking for replication in a low bandwidth or saturated situation, higher priority means it is more likely to replicate */
float32 NetPriority;
/* Variable: bOnlyRelevantToOwner 
 If true, this actor is only relevant to its owner. If this flag is changed during play, all non-owner channels would need to be explicitly closed. */
bool bOnlyRelevantToOwner;
/* Variable: ReplicatedMovement 
 Used for replication of our RootComponent's position and velocity */
FRepMovement ReplicatedMovement;
/* Variable: NetDormancy 
 Dormancy setting for actor to take itself off of the replication list without being destroyed on clients. */
ENetDormancy NetDormancy;
/* Variable: PhysicsReplicationMode 
 Which mode to replicate physics through for this actor. Only relevant if the actor replicates movement and has a component that simulate physics. */
EPhysicsReplicationMode PhysicsReplicationMode;
/* Variable: bReplicateUsingRegisteredSubObjectList 
 When true the replication system will only replicate the registered subobjects and the replicated actor components list
When false the replication system will instead call the virtual ReplicateSubobjects() function where the subobjects and actor components need to be manually replicated. */
bool bReplicateUsingRegisteredSubObjectList;
// Group: Tick

/* Variable: PrimaryActorTick 
 Primary Actor tick function, which calls TickActor().
Tick functions can be configured to control whether ticking is enabled, at what time during a frame the update occurs, and to set up tick dependencies.
@see https://docs.unrealengine.com/API/Runtime/Engine/Engine/FTickFunction
@see AddTickPrerequisiteActor(), AddTickPrerequisiteComponent() */
FActorTickFunction PrimaryActorTick;
// Group: Transformation

/* Variable: ActorForwardVector 
 Get the forward (X) vector (length 1.0) from this Actor, in world space. */
const FVector ActorForwardVector;
/* Variable: ActorRelativeScale3D 
 Return the actor's relative scale 3d */
FVector ActorRelativeScale3D;
/* Variable: ActorRightVector 
 Get the right (Y) vector (length 1.0) from this Actor, in world space. */
const FVector ActorRightVector;
/* Variable: ActorUpVector 
 Get the up (Z) vector (length 1.0) from this Actor, in world space. */
const FVector ActorUpVector;
/* Variable: RootComponent 
 The component that defines the transform (location, rotation, scale) of this Actor in the world, all other components must be attached to this one somehow */
USceneComponent RootComponent;
/* Variable: Velocity 
 Returns velocity (in cm/s (Unreal Units/second) of the rootcomponent if it is either using physics or has an associated MovementComponent */
const FVector Velocity;
/* Variable: ActorScale3D 
 Returns the Actor's world-space scale. */
FVector ActorScale3D;
// Group: WorldPartition

/* Variable: RuntimeGrid 
 Determine in which partition grid this actor will be placed in the partition (if the world is partitioned).
If None, the decision will be left to the partition. */
FName RuntimeGrid;
// Group: Variables

/* Variable: ActorTransform 
  */
FTransform ActorTransform;
/* Variable: ActorRelativeTransform 
  */
FTransform ActorRelativeTransform;
/* Variable: ActorRotation 
  */
FRotator ActorRotation;
/* Variable: FolderPath 
 The folder path of this actor in the world.
If the actor's level uses the actor folder objects feature, the path is computed using FolderGuid.
If not, it contains the actual path (empty=root, / separated). */
FName FolderPath;
/* Variable: ActorQuat 
  */
FQuat ActorQuat;
/* Variable: ParentComponent 
 The UChildActorComponent that owns this Actor. */
const UChildActorComponent ParentComponent;
/* Variable: ActorLocation 
  */
FVector ActorLocation;
/* Variable: ActorRelativeRotation 
  */
FRotator ActorRelativeRotation;
/* Variable: ActorRelativeLocation 
  */
FVector ActorRelativeLocation;
/* Variable: RayTracingGroupId 
 The RayTracingGroupId this actor and its components belong to. (For components that did not specify any) */
int RayTracingGroupId;
/* Variable: ActorInstigatorController 
  */
const AController ActorInstigatorController;
/* Variable: ActorInstigator 
  */
const APawn ActorInstigator;
/* Variable: GameInstance 
  */
const UGameInstance GameInstance;
/* Variable: ActorNameOrLabel 
  */
const FString ActorNameOrLabel;
/* Variable: Owner 
 Owner of this Actor, used primarily for replication (bNetUseOwnerRelevancy & bOnlyRelevantToOwner) and visibility (PrimitiveComponent bOwnerNoSee and bOnlyOwnerSee)
@see SetOwner(), GetOwner() */
AActor Owner;
// Group: Actor

/* Function: FindComponentByTag 
 Searches components array and returns first encountered component with a given tag. */
UActorComponent FindComponentByTag(TSubclassOf<UActorComponent> ComponentClass, FName Tag) const {}
/* Function: GetComponentsByClass 
 Gets all the components that inherit from the given class.
Currently returns an array of UActorComponent which must be cast to the correct type.
This intended to only be used by blueprints. Use GetComponents() in C++. */
TArray<UActorComponent> GetComponentsByClass(TSubclassOf<UActorComponent> ComponentClass) const {}
/* Function: OnBecomeViewTarget 
 Event called when this Actor becomes the view target for the given PlayerController. */
void OnBecomeViewTarget(APlayerController PC) {}
/* Function: GetOwner 
 Get the owner of this Actor, used primarily for network replication. */
AActor GetOwner() const {}
/* Function: GetAttachParentActor 
 Walk up the attachment chain from RootComponent until we encounter a different actor, and return it. If we are not attached to a component in a different actor, returns nullptr */
AActor GetAttachParentActor() const {}
/* Function: OnEndViewTarget 
 Event called when this Actor is no longer the view target for the given PlayerController. */
void OnEndViewTarget(APlayerController PC) {}
/* Function: OnReset 
 Event called when this Actor is reset to its initial state - used when restarting level without reloading. */
void OnReset() {}
/* Function: GetComponentsByTag 
 Gets all the components that inherit from the given class with a given tag. */
TArray<UActorComponent> GetComponentsByTag(TSubclassOf<UActorComponent> ComponentClass, FName Tag) const {}
/* Function: IsChildActor 
 Returns whether this Actor was spawned by a child actor component */
bool IsChildActor() const {}
/* Function: ActorHasTag 
 See if this actor's Tags array contains the supplied name tag */
bool ActorHasTag(FName Tag) const {}
/* Function: GetComponentByClass 
 Searches components array and returns first encountered component of the specified class */
UActorComponent GetComponentByClass(TSubclassOf<UActorComponent> ComponentClass) const {}
/* Function: SetLifeSpan 
 Set the lifespan of this actor. When it expires the object will be destroyed. If requested lifespan is 0, the timer is cleared and the actor will not be destroyed. */
void SetLifeSpan(float32 InLifespan) {}
/* Function: GetComponentsByInterface 
 Gets all the components that implements the given interface. */
TArray<UActorComponent> GetComponentsByInterface(TSubclassOf<UInterface> Interface) const {}
/* Function: DestroyActor 
 Destroy the actor */
void DestroyActor() {}
/* Function: SetOwner 
 Set the owner of this Actor, used primarily for network replication.

Parameters:
    NewOwner - The Actor who takes over ownership of this Actor */
void SetOwner(AActor NewOwner) {}
/* Function: GetAllChildActors 
 Returns a list of all actors spawned by our Child Actor Components, including children of children.
This does not return the contents of the Children array */
void GetAllChildActors(TArray<AActor>& ChildActors, bool bIncludeDescendants = true) const {}
/* Function: GetAttachParentSocketName 
 Walk up the attachment chain from RootComponent until we encounter a different actor, and return the socket name in the component. If we are not attached to a component in a different actor, returns NAME_None */
FName GetAttachParentSocketName() const {}
/* Function: GetAttachedActors 
 Find all Actors which are attached directly to a component in this actor */
void GetAttachedActors(TArray<AActor>& OutActors, bool bResetArray = true, bool bRecursivelyIncludeAttachedActors = false) const {}
/* Function: GetGameTimeSinceCreation 
 The number of seconds (in game time) since this Actor was created, relative to Get Game Time In Seconds. */
float32 GetGameTimeSinceCreation() const {}
/* Function: GetActorTimeDilation 
 Get ActorTimeDilation - this can be used for input control or speed control for slomo.
We don't want to scale input globally because input can be used for UI, which do not care for TimeDilation. */
float32 GetActorTimeDilation() const {}
/* Function: GetParentComponent 
 If this Actor was created by a Child Actor Component returns that Child Actor Component */
UChildActorComponent GetParentComponent() const {}
/* Function: GetActorEyesViewPoint 
 Returns the point of view of the actor.
Note that this doesn't mean the camera, but the 'eyes' of the actor.
For example, for a Pawn, this would define the eye height location,
and view rotation (which is different from the pawn rotation which has a zeroed pitch component).
A camera first person view will typically use this view point. Most traces (weapon, AI) will be done from this view point.

Parameters:
    OutLocation - location of view point
    OutRotation - view rotation of actor. */
void GetActorEyesViewPoint(FVector& OutLocation, FRotator& OutRotation) const {}
/* Function: GetParentActor 
 If this Actor was created by a Child Actor Component returns the Actor that owns that Child Actor Component */
AActor GetParentActor() const {}
/* Function: GetLifeSpan 
 Get the remaining lifespan of this actor. If zero is returned the actor lives forever. */
float32 GetLifeSpan() const {}
// Group: Actor|Tick

/* Function: GetActorTickInterval 
 Returns the tick interval of this actor's primary tick function */
float32 GetActorTickInterval() const {}
/* Function: SetTickableWhenPaused 
 Sets whether this actor can tick when paused. */
void SetTickableWhenPaused(bool bTickableWhenPaused) {}
/* Function: SetActorTickInterval 
 Sets the tick interval of this actor's primary tick function. Will not enable a disabled tick function. Takes effect on next tick.

Parameters:
    TickInterval - The rate at which this actor should be ticking */
void SetActorTickInterval(float32 TickInterval) {}
/* Function: AddTickPrerequisiteComponent 
 Make this actor tick after PrerequisiteComponent. This only applies to this actor's tick function; dependencies for owned components must be set up separately if desired. */
void AddTickPrerequisiteComponent(UActorComponent PrerequisiteComponent) {}
/* Function: IsActorTickEnabled 
 Returns whether this actor has tick enabled or not */
bool IsActorTickEnabled() const {}
/* Function: RemoveTickPrerequisiteComponent 
 Remove tick dependency on PrerequisiteComponent. */
void RemoveTickPrerequisiteComponent(UActorComponent PrerequisiteComponent) {}
/* Function: GetTickableWhenPaused 
 Gets whether this actor can tick when paused. */
bool GetTickableWhenPaused() {}
/* Function: AddTickPrerequisiteActor 
 Make this actor tick after PrerequisiteActor. This only applies to this actor's tick function; dependencies for owned components must be set up separately if desired. */
void AddTickPrerequisiteActor(AActor PrerequisiteActor) {}
/* Function: SetTickGroup 
 Sets the ticking group for this actor.

Parameters:
    NewTickGroup - the new value to assign */
void SetTickGroup(ETickingGroup NewTickGroup) {}
/* Function: SetActorTickEnabled 
 Set this actor's tick functions to be enabled or disabled. Only has an effect if the function is registered
This only modifies the tick function on actor itself

Parameters:
    bEnabled - Whether it should be enabled or not */
void SetActorTickEnabled(bool bEnabled) {}
/* Function: RemoveTickPrerequisiteActor 
 Remove tick dependency on PrerequisiteActor. */
void RemoveTickPrerequisiteActor(AActor PrerequisiteActor) {}
// Group: AI

/* Function: MakeNoise 
 Trigger a noise caused by a given Pawn, at a given location.
Note that the NoiseInstigator Pawn MUST have a PawnNoiseEmitterComponent for the noise to be detected by a PawnSensingComponent.
Senders of MakeNoise should have an Instigator if they are not pawns, or pass a NoiseInstigator.

Parameters:
    Loudness - The relative loudness of this noise. Usual range is 0 (no noise) to 1 (full volume). If MaxRange is used, this scales the max range, otherwise it affects the hearing range specified by the sensor.
    NoiseInstigator - Pawn responsible for this noise.  Uses the actor's Instigator if NoiseInstigator is null
    NoiseLocation - Position of noise source.  If zero vector, use the actor's location.
    MaxRange - Max range at which the sound may be heard. A value of 0 indicates no max range (though perception may have its own range). Loudness scales the range. (Note: not supported for legacy PawnSensingComponent, only for AIPerception)
    Tag - Identifier for the noise. */
void MakeNoise(float32 Loudness = 1.000000, APawn NoiseInstigator = nullptr, FVector NoiseLocation = FVector ( ), float32 MaxRange = 0.000000, FName Tag = NAME_None) {}
// Group: Collision

/* Function: GetActorBounds 
 Returns the bounding box of all components that make up this Actor (excluding ChildActorComponents).

Parameters:
    bOnlyCollidingComponents - If true, will only return the bounding box for components with collision enabled.
    Origin - Set to the center of the actor in world space
    BoxExtent - Set to half the actor's size in 3d space
    bIncludeFromChildActors - If true then recurse in to ChildActor components */
void GetActorBounds(bool bOnlyCollidingComponents, FVector& Origin, FVector& BoxExtent, bool bIncludeFromChildActors = false) const {}
/* Function: GetActorEnableCollision 
 Get current state of collision for the whole actor */
bool GetActorEnableCollision() const {}
/* Function: SetActorEnableCollision 
 Allows enabling/disabling collision for the whole actor */
void SetActorEnableCollision(bool bNewActorEnableCollision) {}
/* Function: Hit 
 Event when this actor bumps into a blocking object, or blocks another actor that bumps into it.
This could happen due to things like Character movement, using Set Location with 'sweep' enabled, or physics simulation.
For events when objects overlap (e.g. walking into a trigger) see the 'Overlap' event.

Note: For collisions during physics simulation to generate hit events, 'Simulation Generates Hit Events' must be enabled.
Note: When receiving a hit from another object's movement (bSelfMoved is false), the directions of 'Hit.Normal' and 'Hit.ImpactNormal'
will be adjusted to indicate force from the other object against this object.
Note: NormalImpulse will be filled in for physics-simulating bodies, but will be zero for swept-component blocking collisions. */
void Hit(UPrimitiveComponent MyComp, AActor Other, UPrimitiveComponent OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, FHitResult Hit) {}
/* Function: GetOverlappingComponents 
 Returns list of components this actor is overlapping. */
void GetOverlappingComponents(TArray<UPrimitiveComponent>& OverlappingComponents) const {}
/* Function: IsOverlappingActor 
 Check whether any component of this Actor is overlapping any component of another Actor.

Parameters:
    Other - The other Actor to test against

Returns:
    Whether any component of this Actor is overlapping any component of another Actor. */
bool IsOverlappingActor(const AActor Other) const {}
/* Function: ActorBeginOverlap 
 Event when this actor overlaps another actor, for example a player walking into a trigger.
For events when objects have a blocking collision, for example a player hitting a wall, see 'Hit' events.
Note: Components on both this and the other Actor must have bGenerateOverlapEvents set to true to generate overlap events. */
void ActorBeginOverlap(AActor OtherActor) {}
/* Function: ActorEndOverlap 
 Event when an actor no longer overlaps another actor, and they have separated.
Note: Components on both this and the other Actor must have bGenerateOverlapEvents set to true to generate overlap events. */
void ActorEndOverlap(AActor OtherActor) {}
/* Function: GetOverlappingActors 
 Returns list of actors this actor is overlapping (any component overlapping any component). Does not return itself.

Parameters:
    OverlappingActors - [out] Returned list of overlapping actors
    ClassFilter - [optional] If set, only returns actors of this class or subclasses */
void GetOverlappingActors(TArray<AActor>& OverlappingActors, TSubclassOf<AActor> ClassFilter = nullptr) const {}
// Group: Editor Scripting | Actor Editing

/* Function: SetIsTemporarilyHiddenInEditor 
 Explicitly sets whether or not this actor is hidden in the editor for the duration of the current editor session

Parameters:
    bIsHidden - True if the actor is hidden */
void SetIsTemporarilyHiddenInEditor(bool bIsHidden) {}
/* Function: SetFolderPath 
 Assigns a new folder to this actor. Actor folder paths are only available in development builds.

Parameters:
    NewFolderPath - The new folder to assign to the actor. */
void SetFolderPath(FName NewFolderPath) {}
/* Function: GetFolderPath 
 Returns this actor's folder path. Actor folder paths are only available in development builds. */
FName GetFolderPath() const {}
/* Function: GetDefaultActorLabel 
 Returns this actor's default label (does not include any numeric suffix).  Actor labels are only available in development builds. */
FString GetDefaultActorLabel() const {}
/* Function: GetActorLabel 
 Returns this actor's current label.  Actor labels are only available in development builds. */
const FString& GetActorLabel(bool bCreateIfNone = true) const {}
/* Function: IsSelectable 
 Returns true if this actor can EVER be selected in a level in the editor.  Can be overridden by specific actors to make them unselectable. */
bool IsSelectable() const {}
/* Function: IsHiddenEdAtStartup 
 Returns true if the actor is hidden upon editor startup/by default, false if it is not */
bool IsHiddenEdAtStartup() const {}
/* Function: IsHiddenEd 
 Returns true if this actor is hidden in the editor viewports, also checking temporary flags. */
bool IsHiddenEd() const {}
/* Function: IsEditable 
 Returns true if this actor is allowed to be displayed, selected and manipulated by the editor. */
bool IsEditable() const {}
/* Function: IsTemporarilyHiddenInEditor 
 Returns whether or not this actor was explicitly hidden in the editor for the duration of the current editor session

Parameters:
    bIncludeParent - Whether to recurse up child actor hierarchy or not */
bool IsTemporarilyHiddenInEditor(bool bIncludeParent = false) const {}
/* Function: SetActorLabel 
 Assigns a new label to this actor.  Actor labels are only available in development builds.

Parameters:
    NewActorLabel - The new label string to assign to the actor.  If empty, the actor will have a default label.
    bMarkDirty - If true the actor's package will be marked dirty for saving.  Otherwise it will not be.  You should pass false for this parameter if dirtying is not allowed (like during loads) */
void SetActorLabel(FString NewActorLabel, bool bMarkDirty = true) {}
// Group: Game

/* Function: IsActorBeingDestroyed 
 Returns true if this actor is currently being destroyed, some gameplay events may be unsafe */
bool IsActorBeingDestroyed() const {}
/* Function: GetInstigator 
 Returns the instigator for this actor, or nullptr if there is none. */
APawn GetInstigator() const {}
/* Function: GetInstigatorController 
 Returns the instigator's controller for this actor, or nullptr if there is none. */
AController GetInstigatorController() const {}
// Group: Game|Damage

/* Function: RadialDamage 
 Event when this actor takes RADIAL damage */
void RadialDamage(float32 DamageReceived, const UDamageType DamageType, FVector Origin, FHitResult HitInfo, AController InstigatedBy, AActor DamageCauser) {}
/* Function: PointDamage 
 Event when this actor takes POINT damage */
void PointDamage(float32 Damage, const UDamageType DamageType, FVector HitLocation, FVector HitNormal, UPrimitiveComponent HitComponent, FName BoneName, FVector ShotFromDirection, AController InstigatedBy, AActor DamageCauser, FHitResult HitInfo) {}
/* Function: AnyDamage 
 Event when this actor takes ANY damage */
void AnyDamage(float32 Damage, const UDamageType DamageType, AController InstigatedBy, AActor DamageCauser) {}
// Group: Input

/* Function: CreateInputComponent 
 Creates an input component from the input component passed in

Parameters:
    InputComponentToCreate - The UInputComponent to create. */
void CreateInputComponent(TSubclassOf<UInputComponent> InputComponentToCreate) {}
/* Function: DisableInput 
 Removes this actor from the stack of input being handled by a PlayerController.

Parameters:
    PlayerController - The PlayerController whose input events we no longer want to receive. If null, this actor will stop receiving input from all PlayerControllers. */
void DisableInput(APlayerController PlayerController) {}
/* Function: EnableInput 
 Pushes this actor on to the stack of input being handled by a PlayerController.

Parameters:
    PlayerController - The PlayerController whose input events we want to receive. */
void EnableInput(APlayerController PlayerController) {}
// Group: Level

/* Function: GetLevelTransform 
 Return the FTransform of the level this actor is a part of. */
FTransform GetLevelTransform() const {}
/* Function: GetLevel 
 Return the ULevel that this Actor is part of. */
ULevel GetLevel() const {}
// Group: Mouse Input

/* Function: ActorOnReleased 
 Event when this actor is under the mouse when left mouse button is released while using the clickable interface. */
void ActorOnReleased(FKey ButtonReleased) {}
/* Function: ActorEndCursorOver 
 Event when this actor has the mouse moved off of it with the clickable interface. */
void ActorEndCursorOver() {}
/* Function: ActorBeginCursorOver 
 Event when this actor has the mouse moved over it with the clickable interface. */
void ActorBeginCursorOver() {}
/* Function: ActorOnClicked 
 Event when this actor is clicked by the mouse when using the clickable interface. */
void ActorOnClicked(FKey ButtonPressed) {}
// Group: Networking

/* Function: GetLocalRole 
 Returns how much control the local machine has over this actor. */
ENetRole GetLocalRole() const {}
/* Function: GetRemoteRole 
 Returns how much control the remote machine has over this actor. */
ENetRole GetRemoteRole() const {}
/* Function: ForceNetUpdate 
 Force actor to be updated to clients/demo net drivers */
void ForceNetUpdate() {}
/* Function: SetNetDormancy 
 Puts actor in dormant networking state */
void SetNetDormancy(ENetDormancy NewDormancy) {}
/* Function: FlushNetDormancy 
 Forces dormant actor to replicate but doesn't change NetDormancy state (i.e., they will go dormant again if left dormant) */
void FlushNetDormancy() {}
/* Function: HasAuthority 
 Returns whether this actor has network authority */
bool HasAuthority() const {}
/* Function: TearOff 
 Networking - Server - TearOff this actor to stop replication to clients. Will set bTearOff to true. */
void TearOff() {}
/* Function: SetReplicates 
 Set whether this actor replicates to network clients. When this actor is spawned on the server it will be sent to clients as well.
Properties flagged for replication will update on clients if they change on the server.
Internally changes the RemoteRole property and handles the cases where the actor needs to be added to the network actor list.

Parameters:
    bInReplicates - Whether this Actor replicates to network clients. */
void SetReplicates(bool bInReplicates) {}
/* Function: SetReplicateMovement 
 Set whether this actor's movement replicates to network clients.

Parameters:
    bInReplicateMovement - Whether this Actor's movement replicates to clients. */
void SetReplicateMovement(bool bInReplicateMovement) {}
// Group: Physics

/* Function: GetResimulationThreshold 
 Get the error threshold in centimeters before this object should enforce a resimulation to trigger. */
float32 GetResimulationThreshold() const {}
/* Function: CanTriggerResimulation 
 Can this body trigger a resimulation when Physics Prediction is enabled */
bool CanTriggerResimulation() const {}
// Group: RayTracing

/* Function: SetRayTracingGroupId 
 Specify a RayTracingGroupId for this actors. Components with invalid RayTracingGroupId will inherit the actors. */
void SetRayTracingGroupId(int InRaytracingGroupId) {}
/* Function: GetRayTracingGroupId 
 Return the RayTracingGroupId for this actor. */
int GetRayTracingGroupId() const {}
// Group: Rendering

/* Function: SetActorHiddenInGame 
 Sets the actor to be hidden in the game

Parameters:
    bNewHidden - Whether or not to hide the actor and all its components */
void SetActorHiddenInGame(bool bNewHidden) {}
/* Function: PrestreamTextures 
 Calls PrestreamTextures() for all the actor's meshcomponents.

Parameters:
    Seconds - Number of seconds to force all mip-levels to be resident
    bEnableStreaming - Whether to start (true) or stop (false) streaming
    CinematicTextureGroups - Bitfield indicating which texture groups that use extra high-resolution mips */
void PrestreamTextures(float32 Seconds, bool bEnableStreaming, int CinematicTextureGroups = 0) {}
/* Function: WasRecentlyRendered 
 Returns true if this actor has been rendered "recently", with a tolerance in seconds to define what "recent" means.
e.g.: If a tolerance of 0.1 is used, this function will return true only if the actor was rendered in the last 0.1 seconds of game time.

Parameters:
    Tolerance - How many seconds ago the actor last render time can be and still count as having been "recently" rendered.

Returns:
    Whether this actor was recently rendered. */
bool WasRecentlyRendered(float32 Tolerance = 0.200000) const {}
// Group: Replication

/* Function: GetPhysicsReplicationMode 
 Get the physics replication mode of this body, via EPhysicsReplicationMode */
EPhysicsReplicationMode GetPhysicsReplicationMode() {}
/* Function: SetPhysicsReplicationMode 
 Set the physics replication mode of this body, via EPhysicsReplicationMode */
void SetPhysicsReplicationMode(EPhysicsReplicationMode ReplicationMode) {}
// Group: Touch Input

/* Function: ActorOnInputTouchBegin 
 Event when this actor is touched when click events are enabled. */
void ActorOnInputTouchBegin(ETouchIndex FingerIndex) {}
/* Function: ActorOnInputTouchEnd 
 Event when this actor is under the finger when untouched when click events are enabled. */
void ActorOnInputTouchEnd(ETouchIndex FingerIndex) {}
/* Function: ActorOnInputTouchEnter 
 Event when this actor has a finger moved over it with the clickable interface. */
void ActorOnInputTouchEnter(ETouchIndex FingerIndex) {}
/* Function: ActorOnInputTouchLeave 
 Event when this actor has a finger moved off of it with the clickable interface. */
void ActorOnInputTouchLeave(ETouchIndex FingerIndex) {}
// Group: Transformation

/* Function: AttachToActor 
 Attaches the RootComponent of this Actor to the supplied actor, optionally at a named socket.

Parameters:
    ParentActor - Actor to attach this actor's RootComponent to
    SocketName - Socket name to attach to, if any
    LocationRule - How to handle translation when attaching.
    RotationRule - How to handle rotation when attaching.
    ScaleRule - How to handle scale when attaching.
    bWeldSimulatedBodies - Whether to weld together simulated physics bodies.This transfers the shapes in the welded object into the parent (if simulated), which can result in permanent changes that persist even after subsequently detaching.

Returns:
    Whether the attachment was successful or not */
bool AttachToActor(AActor ParentActor, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule, bool bWeldSimulatedBodies) {}
/* Function: GetActorRotation 
 Returns rotation of the RootComponent of this Actor. */
FRotator GetActorRotation() const {}
/* Function: SetActorRelativeTransform 
 Set the actor's RootComponent to the specified relative transform

Parameters:
    NewRelativeTransform - New relative transform of the actor's root component
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the transform without teleporting will not update the transform of simulated child/attached components. */
void SetActorRelativeTransform(FTransform NewRelativeTransform, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: AttachRootComponentToActor 
  */
void AttachRootComponentToActor(AActor InParentActor, FName InSocketName = NAME_None, EAttachLocation AttachLocationType = EAttachLocation :: KeepRelativeOffset, bool bWeldSimulatedBodies = true) {}
/* Function: AttachRootComponentTo 
  */
void AttachRootComponentTo(USceneComponent InParent, FName InSocketName = NAME_None, EAttachLocation AttachLocationType = EAttachLocation :: KeepRelativeOffset, bool bWeldSimulatedBodies = true) {}
/* Function: AddActorWorldTransformKeepScale 
 Adds a delta to the transform of this actor in world space. Scale is unchanged. */
void AddActorWorldTransformKeepScale(FTransform DeltaTransform, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: SetActorLocation 
 Move the Actor to the specified location.

Parameters:
    NewLocation - The new location to move the Actor to.
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    SweepHitResult - The hit result from the move if swept.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the location without teleporting will not update the location of simulated child/attached components.

Returns:
    Whether the location was successfully set (if not swept), or whether movement occurred at all (if swept). */
bool SetActorLocation(FVector NewLocation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: SetActorLocationAndRotation 
 Move the actor instantly to the specified location and rotation.

Parameters:
    NewLocation - The new location to teleport the Actor to.
    NewRotation - The new rotation for the Actor.
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    SweepHitResult - The hit result from the move if swept.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the location without teleporting will not update the location of simulated child/attached components.

Returns:
    Whether the rotation was successfully set. */
bool SetActorLocationAndRotation(FVector NewLocation, FRotator NewRotation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: SetActorRelativeLocation 
 Set the actor's RootComponent to the specified relative location.

Parameters:
    NewRelativeLocation - New relative location of the actor's root component
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the location without teleporting will not update the location of simulated child/attached components. */
void SetActorRelativeLocation(FVector NewRelativeLocation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: DetachFromActor 
 Detaches the RootComponent of this Actor from any SceneComponent it is currently attached to.

Parameters:
    LocationRule - How to handle translation when detaching.
    RotationRule - How to handle rotation when detaching.
    ScaleRule - How to handle scale when detaching. */
void DetachFromActor(EDetachmentRule LocationRule = EDetachmentRule :: KeepRelative, EDetachmentRule RotationRule = EDetachmentRule :: KeepRelative, EDetachmentRule ScaleRule = EDetachmentRule :: KeepRelative) {}
/* Function: GetActorLocation 
 Returns the location of the RootComponent of this Actor */
FVector GetActorLocation() const {}
/* Function: SetActorRotation 
 Set the Actor's rotation instantly to the specified rotation.

Parameters:
    NewRotation - The new rotation for the Actor.
    bTeleportPhysics - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the rotation without teleporting will not update the rotation of simulated child/attached components.

Returns:
    Whether the rotation was successfully set. */
bool SetActorRotation(FRotator NewRotation, bool bTeleportPhysics) {}
/* Function: SetActorTransform 
 Set the Actors transform to the specified one.

Parameters:
    NewTransform - The new transform.
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the transform without teleporting will not update the transform of simulated child/attached components. */
bool SetActorTransform(FTransform NewTransform, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: Teleport 
 Teleport this actor to a new location. If the actor doesn't fit exactly at the location specified, tries to slightly move it out of walls and such.

Parameters:
    DestLocation - The target destination point
    DestRotation - The target rotation at the destination

Returns:
    true if the actor has been successfully moved, or false if it couldn't fit. */
bool Teleport(FVector DestLocation, FRotator DestRotation) {}
/* Function: AddActorWorldTransform 
 Adds a delta to the transform of this actor in world space. Ignores scale and sets it to (1,1,1). */
void AddActorWorldTransform(FTransform DeltaTransform, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: AddActorWorldRotation 
 Adds a delta to the rotation of this actor in world space.

Parameters:
    DeltaRotation - The change in rotation.
    bSweep - Whether to sweep to the target rotation (not currently supported for rotation).
    SweepHitResult - The hit result from the move if swept.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the rotation without teleporting will not update the rotation of simulated child/attached components. */
void AddActorWorldRotation(FRotator DeltaRotation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: AddActorWorldOffset 
 Adds a delta to the location of this actor in world space.

Parameters:
    DeltaLocation - The change in location.
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    SweepHitResult - The hit result from the move if swept.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the location without teleporting will not update the location of simulated child/attached components. */
void AddActorWorldOffset(FVector DeltaLocation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: AddActorLocalTransform 
 Adds a delta to the transform of this component in its local reference frame

Parameters:
    NewTransform - The change in transform in local space.
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the transform without teleporting will not update the transform of simulated child/attached components. */
void AddActorLocalTransform(FTransform NewTransform, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: AddActorLocalRotation 
 Adds a delta to the rotation of this component in its local reference frame

Parameters:
    DeltaRotation - The change in rotation in local space.
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the rotation without teleporting will not update the rotation of simulated child/attached components. */
void AddActorLocalRotation(FRotator DeltaRotation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: AddActorLocalOffset 
 Adds a delta to the location of this component in its local reference frame.

Parameters:
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the location without teleporting will not update the location of simulated child/attached components. */
void AddActorLocalOffset(FVector DeltaLocation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: GetVerticalDistanceTo 
 Returns the distance from this Actor to OtherActor, ignoring XY. */
float32 GetVerticalDistanceTo(const AActor OtherActor) const {}
/* Function: SetActorRelativeRotation 
 Set the actor's RootComponent to the specified relative rotation

Parameters:
    NewRelativeRotation - New relative rotation of the actor's root component
    bSweep - Whether we sweep to the destination location, triggering overlaps along the way and stopping short of the target if blocked by something. Only the root component is swept and checked for blocking collision, child components move without sweeping. If collision is off, this has no effect.
    bTeleport - Whether we teleport the physics state (if physics collision is enabled for this object). If true, physics velocity for this object is unchanged (so ragdoll parts are not affected by change in location). If false, physics velocity is updated based on the change in position (affecting ragdoll parts). If CCD is on and not teleporting, this will affect objects along the entire swept volume. Note that when teleporting, any child/attached components will be teleported too, maintaining their current offset even if they are being simulated. Setting the rotation without teleporting will not update the rotation of simulated child/attached components. */
void SetActorRelativeRotation(FRotator NewRelativeRotation, bool bSweep, FHitResult& SweepHitResult, bool bTeleport) {}
/* Function: GetSquaredHorizontalDistanceTo 
 Returns the squared distance from this Actor to OtherActor, ignoring Z. */
float32 GetSquaredHorizontalDistanceTo(const AActor OtherActor) const {}
/* Function: GetActorUpVector 
 Get the up (Z) vector (length 1.0) from this Actor, in world space. */
FVector GetActorUpVector() const {}
/* Function: AttachToComponent 
 Attaches the RootComponent of this Actor to the supplied component, optionally at a named socket. It is not valid to call this on components that are not Registered.

Parameters:
    Parent - Parent to attach to.
    SocketName - Optional socket to attach to on the parent.
    LocationRule - How to handle translation when attaching.
    RotationRule - How to handle rotation when attaching.
    ScaleRule - How to handle scale when attaching.
    bWeldSimulatedBodies - Whether to weld together simulated physics bodies. This transfers the shapes in the welded object into the parent (if simulated), which can result in permanent changes that persist even after subsequently detaching.

Returns:
    Whether the attachment was successful or not */
bool AttachToComponent(USceneComponent Parent, FName SocketName, EAttachmentRule LocationRule, EAttachmentRule RotationRule, EAttachmentRule ScaleRule, bool bWeldSimulatedBodies) {}
/* Function: GetVelocity 
 Returns velocity (in cm/s (Unreal Units/second) of the rootcomponent if it is either using physics or has an associated MovementComponent */
FVector GetVelocity() const {}
/* Function: GetActorTransform 
 Get the actor-to-world transform.

Returns:
    The transform that transforms from actor space to world space. */
const FTransform& GetActorTransform() const {}
/* Function: DetachRootComponentFromParent 
  */
void DetachRootComponentFromParent(bool bMaintainWorldPosition = true) {}
/* Function: GetActorForwardVector 
 Get the forward (X) vector (length 1.0) from this Actor, in world space. */
FVector GetActorForwardVector() const {}
/* Function: GetActorRelativeScale3D 
 Return the actor's relative scale 3d */
FVector GetActorRelativeScale3D() const {}
/* Function: GetActorRightVector 
 Get the right (Y) vector (length 1.0) from this Actor, in world space. */
FVector GetActorRightVector() const {}
/* Function: GetDotProductTo 
 Returns the dot product from this Actor to OtherActor. Returns -2.0 on failure. Returns 0.0 for coincidental actors. */
float32 GetDotProductTo(const AActor OtherActor) const {}
/* Function: GetSquaredDistanceTo 
 Returns the squared distance from this Actor to OtherActor. */
float32 GetSquaredDistanceTo(const AActor OtherActor) const {}
/* Function: GetActorScale3D 
 Returns the Actor's world-space scale. */
FVector GetActorScale3D() const {}
/* Function: GetDistanceTo 
 Returns the distance from this Actor to OtherActor. */
float32 GetDistanceTo(const AActor OtherActor) const {}
/* Function: SetActorScale3D 
 Set the Actor's world-space scale. */
void SetActorScale3D(FVector NewScale3D) {}
/* Function: SetActorRelativeScale3D 
 Set the actor's RootComponent to the specified relative scale 3d

Parameters:
    NewRelativeScale - New scale to set the actor's RootComponent to */
void SetActorRelativeScale3D(FVector NewRelativeScale) {}
/* Function: GetHorizontalDotProductTo 
 Returns the dot product from this Actor to OtherActor, ignoring Z. Returns -2.0 on failure. Returns 0.0 for coincidental actors. */
float32 GetHorizontalDotProductTo(const AActor OtherActor) const {}
/* Function: GetHorizontalDistanceTo 
 Returns the distance from this Actor to OtherActor, ignoring Z. */
float32 GetHorizontalDistanceTo(const AActor OtherActor) const {}
// Group: TypedElementFramework|Actor

/* Function: AcquireEditorElementHandle 
  */
FScriptTypedElementHandle AcquireEditorElementHandle(bool bAllowCreate = true) const {}
// Group: Functions

/* Function: SetNetUpdateFrequency 
 Set the frequency at which this object will be considered for replication. */
void SetNetUpdateFrequency(float32 Frequency) {}
/* Function: GetNetCullDistanceSquared 
 Get the square of the max distance from the client's viewpoint that this actor is relevant and will be replicated. */
float32 GetNetCullDistanceSquared() const {}
/* Function: Tick 
 Event called every frame, if ticking is enabled */
void Tick(float32 DeltaSeconds) {}
/* Function: GetRootComponent 
 Returns the RootComponent of this Actor */
USceneComponent GetRootComponent() const {}
/* Function: IsActorInitialized 
  */
bool IsActorInitialized() const {}
/* Function: GetNetUpdateFrequency 
 Get the current frequency at which this object will be considered for replication. */
float32 GetNetUpdateFrequency() const {}
/* Function: EndPlay 
 Event to notify blueprints this actor is being deleted or removed from a level. */
void EndPlay(EEndPlayReason EndPlayReason) {}
/* Function: Destroyed 
 Called when the actor has been explicitly destroyed. */
void Destroyed() {}
/* Function: SetMinNetUpdateFrequency 
 Set the frequency to throttle down to when replicated properties are changing infrequently. */
void SetMinNetUpdateFrequency(float32 MinFrequency) {}
/* Function: SetNetCullDistanceSquared 
 Set the square of the max distance from the client's viewpoint that this actor is relevant and will be replicated. */
void SetNetCullDistanceSquared(float32 DistanceSq) {}
/* Function: BeginPlay 
 Event when play begins for this actor. */
void BeginPlay() {}
/* Function: GetMinNetUpdateFrequency 
 Get the frequency to throttle down to when replicated properties are changing infrequently. */
float32 GetMinNetUpdateFrequency() const {}
/* Function: AsyncPhysicsTick 
 Event called every physics tick if bAsyncPhysicsTickEnabled is true */
void AsyncPhysicsTick(float32 DeltaSeconds, float32 SimSeconds) {}
/* Function: GetActorInstigatorController 
  */
AController GetActorInstigatorController() const {}
/* Function: GetActorInstigator 
  */
APawn GetActorInstigator() const {}
/* Function: GetComponentsByClass 
  */
void GetComponentsByClass(UClass ComponentClass, ?& OutComponents) const {}
/* Function: GetComponentsByClass 
  */
void GetComponentsByClass(?& OutComponents) const {}
/* Function: GetGameInstance 
  */
UGameInstance GetGameInstance() const {}
/* Function: GetActorNameOrLabel 
  */
FString GetActorNameOrLabel() const {}
/* Function: IsHidden 
  */
bool IsHidden() const {}
/* Function: ConstructionScript 
 Construction script, the place to spawn components and do other setup.
Note: Name used in CreateBlueprint function */
void ConstructionScript() {}
/* Function: HasActorBegunPlay 
  */
bool HasActorBegunPlay() const {}
/* Function: SetbAutoDestroyWhenFinished 
 If true then destroy self when "finished", meaning all relevant components report that they are done and no timelines or timers are in flight. */
void SetbAutoDestroyWhenFinished(bool bVal) {}
/* Function: SetAutoDestroyWhenFinished 
  */
void SetAutoDestroyWhenFinished(bool bVal) {}
/* Function: AddActorLocalOffset 
  */
void AddActorLocalOffset(FVector DeltaLocation) {}
/* Function: AddActorLocalRotation 
  */
void AddActorLocalRotation(FRotator DeltaRotation) {}
/* Function: AddActorLocalRotation 
  */
void AddActorLocalRotation(FQuat DeltaRotation) {}
/* Function: AddActorLocalTransform 
  */
void AddActorLocalTransform(FTransform DeltaTransform) {}
/* Function: AddActorWorldOffset 
  */
void AddActorWorldOffset(FVector DeltaLocation) {}
/* Function: AddActorWorldRotation 
  */
void AddActorWorldRotation(FRotator DeltaRotation) {}
/* Function: AddActorWorldRotation 
  */
void AddActorWorldRotation(FQuat DeltaRotation) {}
/* Function: AddActorWorldTransform 
  */
void AddActorWorldTransform(FTransform DeltaTransform) {}
/* Function: AttachToActor 
  */
void AttachToActor(AActor ParentActor, FName SocketName = NAME_None, EAttachmentRule AttachmentRule = EAttachmentRule :: SnapToTarget) {}
/* Function: AttachToComponent 
  */
void AttachToComponent(USceneComponent Parent, FName SocketName = NAME_None, EAttachmentRule AttachmentRule = EAttachmentRule :: SnapToTarget) {}
/* Function: GetActorQuat 
  */
FQuat GetActorQuat() const {}
/* Function: GetActorRelativeLocation 
  */
FVector GetActorRelativeLocation() const {}
/* Function: GetActorRelativeRotation 
  */
FRotator GetActorRelativeRotation() const {}
/* Function: GetActorRelativeTransform 
  */
FTransform GetActorRelativeTransform() const {}
/* Function: RerunConstructionScripts 
  */
void RerunConstructionScripts() {}
/* Function: SetActorLocation 
  */
void SetActorLocation(FVector NewLocation) {}
/* Function: SetActorLocationAndRotation 
  */
void SetActorLocationAndRotation(FVector NewLocation, FRotator NewRotation, bool bTeleport = false) {}
/* Function: SetActorLocationAndRotation 
  */
void SetActorLocationAndRotation(FVector NewLocation, FQuat NewRotation, bool bTeleport = false) {}
/* Function: SetActorQuat 
  */
void SetActorQuat(FQuat NewRotation) {}
/* Function: SetActorRelativeLocation 
  */
void SetActorRelativeLocation(FVector NewRelativeLocation) {}
/* Function: SetActorRelativeRotation 
  */
void SetActorRelativeRotation(FRotator NewRelativeRotation) {}
/* Function: SetActorRelativeRotation 
  */
void SetActorRelativeRotation(FQuat NewRelativeRotation) {}
/* Function: SetActorRelativeTransform 
  */
void SetActorRelativeTransform(FTransform NewRelativeTransform) {}
/* Function: SetActorRotation 
  */
void SetActorRotation(FRotator NewRotation) {}
/* Function: SetActorRotation 
  */
void SetActorRotation(FQuat NewRotation) {}
/* Function: SetActorTransform 
  */
void SetActorTransform(FTransform NewTransform) {}
/* Function: SetbRunConstructionScriptOnDrag 
  */
void SetbRunConstructionScriptOnDrag(bool Value) {}
/* Function: GetbOnlyRelevantToOwner 
 If true, this actor is only relevant to its owner. If this flag is changed during play, all non-owner channels would need to be explicitly closed. */
bool GetbOnlyRelevantToOwner() const {}
/* Function: SetbOnlyRelevantToOwner 
 If true, this actor is only relevant to its owner. If this flag is changed during play, all non-owner channels would need to be explicitly closed. */
void SetbOnlyRelevantToOwner(bool Value) {}
/* Function: GetbAlwaysRelevant 
 Always relevant for network (overrides bOnlyRelevantToOwner). */
bool GetbAlwaysRelevant() const {}
/* Function: SetbAlwaysRelevant 
 Always relevant for network (overrides bOnlyRelevantToOwner). */
void SetbAlwaysRelevant(bool Value) {}
/* Function: SetbReplicateMovement 
 If true, replicate movement/location related properties.
Actor must also be set to replicate.
See: SetReplicates()
See: https://docs.unrealengine.com/InteractiveExperiences/Networking/Actors */
void SetbReplicateMovement(bool Value) {}
/* Function: SetbCallPreReplication 
  */
void SetbCallPreReplication(bool Value) {}
/* Function: SetbCallPreReplicationForReplay 
  */
void SetbCallPreReplicationForReplay(bool Value) {}
/* Function: GetbHidden 
 Allows us to only see this Actor in the Editor, and not in the actual game.
See: SetActorHiddenInGame() */
bool GetbHidden() const {}
/* Function: SetbHidden 
 Allows us to only see this Actor in the Editor, and not in the actual game.
See: SetActorHiddenInGame() */
void SetbHidden(bool Value) {}
/* Function: SetbIsMainWorldOnly 
 If checked, this Actor will only get loaded in a main world (persistent level), it will not be loaded through Level Instances. */
void SetbIsMainWorldOnly(bool Value) {}
/* Function: SetbNetLoadOnClient 
 This actor will be loaded on network clients during map load */
void SetbNetLoadOnClient(bool Value) {}
/* Function: GetbNetUseOwnerRelevancy 
 If actor has valid Owner, call Owner's IsNetRelevantFor and GetNetPriority */
bool GetbNetUseOwnerRelevancy() const {}
/* Function: SetbNetUseOwnerRelevancy 
 If actor has valid Owner, call Owner's IsNetRelevantFor and GetNetPriority */
void SetbNetUseOwnerRelevancy(bool Value) {}
/* Function: SetbRelevantForLevelBounds 
 If true, this actor's component's bounds will be included in the level's
bounding box unless the Actor's class has overridden IsLevelBoundsRelevant */
void SetbRelevantForLevelBounds(bool Value) {}
/* Function: SetbReplayRewindable 
 If true, this actor will only be destroyed during scrubbing if the replay is set to a time before the actor existed.
Otherwise, RewindForReplay will be called if we detect the actor needs to be reset.
Note, this Actor must not be destroyed by gamecode, and RollbackViaDeletion may not be used. */
void SetbReplayRewindable(bool Value) {}
/* Function: SetbAllowTickBeforeBeginPlay 
 Whether we allow this Actor to tick before it receives the BeginPlay event.
Normally we don't tick actors until after BeginPlay; this setting allows this behavior to be overridden.
This Actor must be able to tick for this setting to be relevant. */
void SetbAllowTickBeforeBeginPlay(bool Value) {}
/* Function: GetbAutoDestroyWhenFinished 
 If true then destroy self when "finished", meaning all relevant components report that they are done and no timelines or timers are in flight. */
bool GetbAutoDestroyWhenFinished() const {}
/* Function: GetbCanBeDamaged 
 Whether this actor can take damage. Must be true for damage events (e.g. ReceiveDamage()) to be called.
See: https://www.unrealengine.com/blog/damage-in-ue4
See: TakeDamage(), ReceiveDamage() */
bool GetbCanBeDamaged() const {}
/* Function: SetbCanBeDamaged 
 Whether this actor can take damage. Must be true for damage events (e.g. ReceiveDamage()) to be called.
See: https://www.unrealengine.com/blog/damage-in-ue4
See: TakeDamage(), ReceiveDamage() */
void SetbCanBeDamaged(bool Value) {}
/* Function: SetbBlockInput 
 If true, all input on the stack below this actor will not be considered */
void SetbBlockInput(bool Value) {}
/* Function: GetbFindCameraComponentWhenViewTarget 
 If true, this actor should search for an owned camera component to view through when used as a view target. */
bool GetbFindCameraComponentWhenViewTarget() const {}
/* Function: SetbFindCameraComponentWhenViewTarget 
 If true, this actor should search for an owned camera component to view through when used as a view target. */
void SetbFindCameraComponentWhenViewTarget(bool Value) {}
/* Function: GetbGenerateOverlapEventsDuringLevelStreaming 
 If true, this actor will generate overlap Begin/End events when spawned as part of level streaming, which includes initial level load.
You might enable this is in the case where a streaming level loads around an actor and you want Begin/End overlap events to trigger.
See: UpdateOverlapsMethodDuringLevelStreaming */
bool GetbGenerateOverlapEventsDuringLevelStreaming() const {}
/* Function: SetbGenerateOverlapEventsDuringLevelStreaming 
 If true, this actor will generate overlap Begin/End events when spawned as part of level streaming, which includes initial level load.
You might enable this is in the case where a streaming level loads around an actor and you want Begin/End overlap events to trigger.
See: UpdateOverlapsMethodDuringLevelStreaming */
void SetbGenerateOverlapEventsDuringLevelStreaming(bool Value) {}
/* Function: SetbIgnoresOriginShifting 
 Whether this actor should not be affected by world origin shifting. */
void SetbIgnoresOriginShifting(bool Value) {}
/* Function: GetbEnableAutoLODGeneration 
 Whether this actor should be considered or not during HLOD generation. */
bool GetbEnableAutoLODGeneration() const {}
/* Function: SetbEnableAutoLODGeneration 
 Whether this actor should be considered or not during HLOD generation. */
void SetbEnableAutoLODGeneration(bool Value) {}
/* Function: SetbIsEditorOnlyActor 
 Whether this actor is editor-only. Use with care, as if this actor is referenced by anything else that reference will be NULL in cooked builds */
void SetbIsEditorOnlyActor(bool Value) {}
/* Function: GetbReplicates 
 If true, this actor will replicate to remote machines
See: SetReplicates() */
bool GetbReplicates() const {}
/* Function: SetbReplicates 
 If true, this actor will replicate to remote machines
See: SetReplicates() */
void SetbReplicates(bool Value) {}
/* Function: SetbCanBeInCluster 
 If true, this actor can be put inside of a GC Cluster to improve Garbage Collection performance */
void SetbCanBeInCluster(bool Value) {}
/* Function: GetbReplicateUsingRegisteredSubObjectList 
 When true the replication system will only replicate the registered subobjects and the replicated actor components list
When false the replication system will instead call the virtual ReplicateSubobjects() function where the subobjects and actor components need to be manually replicated. */
bool GetbReplicateUsingRegisteredSubObjectList() const {}
/* Function: SetbReplicateUsingRegisteredSubObjectList 
 When true the replication system will only replicate the registered subobjects and the replicated actor components list
When false the replication system will instead call the virtual ReplicateSubobjects() function where the subobjects and actor components need to be manually replicated. */
void SetbReplicateUsingRegisteredSubObjectList(bool Value) {}
/* Function: SetbAsyncPhysicsTickEnabled 
 Whether to use use the async physics tick with this actor. */
void SetbAsyncPhysicsTickEnabled(bool Value) {}
/* Function: GetNetDormancy 
 Dormancy setting for actor to take itself off of the replication list without being destroyed on clients. */
const ENetDormancy& GetNetDormancy() const {}
/* Function: SetInstigator 
 Pawn responsible for damage and other gameplay events caused by this actor. */
void SetInstigator(APawn Value) {}
/* Function: SetRootComponent 
 The component that defines the transform (location, rotation, scale) of this Actor in the world, all other components must be attached to this one somehow */
void SetRootComponent(USceneComponent Value) {}
/* Function: SetbOptimizeBPComponentData 
 Whether to cook additional data to speed up spawn events at runtime for any Blueprint classes based on this Actor. This option may slightly increase memory usage in a cooked build. */
void SetbOptimizeBPComponentData(bool Value) {}
/* Function: SetbIsSpatiallyLoaded 
 Determine if this actor is spatially loaded when placed in a partitioned world.
     If true, this actor will be loaded when in the range of any streaming sources and if (1) in no data layers, or (2) one or more of its data layers are enabled.
     If false, this actor will be loaded if (1) in no data layers, or (2) one or more of its data layers are enabled. */
void SetbIsSpatiallyLoaded(bool Value) {}
/* Function: CreateComponent 
  */
UActorComponent CreateComponent(TSubclassOf<UActorComponent> ComponentClass, FName WithName = NAME_None) {}
/* Function: GetComponent 
  */
UActorComponent GetComponent(TSubclassOf<UActorComponent> ComponentClass, FName WithName = NAME_None) const {}
/* Function: GetOrCreateComponent 
  */
UActorComponent GetOrCreateComponent(TSubclassOf<UActorComponent> ComponentClass, FName WithName = NAME_None) {}
/* Function: GetAllComponents 
  */
void GetAllComponents(UClass ComponentClass, TArray<UActorComponent>& OutComponents) const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AActor AActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AActor::StaticClass() {}
}
