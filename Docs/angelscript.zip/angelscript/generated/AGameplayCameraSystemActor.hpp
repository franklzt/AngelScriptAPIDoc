/* Class: AGameplayCameraSystemActor 
 An actor that hosts a camera system. */ 
 class AGameplayCameraSystemActor : public AActor
{
public:
// Group: Camera

/* Variable: CameraSystemComponent 
  */
UGameplayCameraSystemComponent CameraSystemComponent;
// Group: Camera

/* Function: GetAutoSpawnedCameraSystemActor 
 Get the automatically spawned camera system actor, if it exists.
Returns null if bAutoSpawnCameraSystemActor is disabled in the GameplayCameras
settings, or if no actor has been spawned yet. */
static AGameplayCameraSystemActor AGameplayCameraSystemActor::GetAutoSpawnedCameraSystemActor(APlayerController PlayerController, bool bForceSpawn = false) {}
/* Function: AutoManageActiveViewTarget 
 Automatically sets a camera system actor as the view-target, spawning a unique
instance if needed. Doesn't do anything if bAutoSpawnCameraSystemActor is disabled
in the GameplayCameras settings. */
static void AGameplayCameraSystemActor::AutoManageActiveViewTarget(APlayerController PlayerController) {}
/* Function: GetCameraSystemComponent 
 Gets the camera system component. */
UGameplayCameraSystemComponent GetCameraSystemComponent() const {}
// Group: Functions

/* Function: SetCameraSystemComponent 
  */
void SetCameraSystemComponent(UGameplayCameraSystemComponent Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AGameplayCameraSystemActor AGameplayCameraSystemActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameplayCameraSystemActor::StaticClass() {}
}
