/* Class: ACLVectorFormat 
  */ 
 class ACLVectorFormat
{
public:
}
/* Enum: ACLVectorFormat 
 
    ACLVF_Vector3_96 - Enum
    ACLVF_Vector3_Variable - Enum
    ACLVF_Vector3_MAX - Enum */ 
 enum ACLVectorFormat { 
ACLVF_Vector3_96,
ACLVF_Vector3_Variable,
ACLVF_Vector3_MAX, 
}