/* Class: AEQSTestingPawn 
  */ 
 class AEQSTestingPawn : public ACharacter
{
public:
// Group: EQS

/* Variable: QueryConfig 
  */
TArray<FAIDynamicParam> QueryConfig;
/* Variable: TimeLimitPerStep 
  */
float32 TimeLimitPerStep;
/* Variable: StepToDebugDraw 
  */
int StepToDebugDraw;
/* Variable: HighlightMode 
  */
EEnvQueryHightlightMode HighlightMode;
/* Variable: QueryingMode 
  */
EEnvQueryRunMode QueryingMode;
/* Variable: NavAgentProperties 
  */
FNavAgentProperties NavAgentProperties;
/* Variable: QueryTemplate 
  */
UEnvQuery QueryTemplate;
// Group: Functions

/* Function: SetbDrawFailedItems 
  */
void SetbDrawFailedItems(bool Value) {}
/* Function: SetbReRunQueryOnlyOnFinishedMove 
  */
void SetbReRunQueryOnlyOnFinishedMove(bool Value) {}
/* Function: SetbShouldBeVisibleInGame 
  */
void SetbShouldBeVisibleInGame(bool Value) {}
/* Function: SetbTickDuringGame 
  */
void SetbTickDuringGame(bool Value) {}
/* Function: SetbDrawLabels 
  */
void SetbDrawLabels(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AEQSTestingPawn AEQSTestingPawn::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AEQSTestingPawn::StaticClass() {}
}
