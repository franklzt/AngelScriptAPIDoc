/* Class: EBakeCurvatureClampMode 
  */ 
 class EBakeCurvatureClampMode
{
public:
}
/* Enum: EBakeCurvatureClampMode 
 
    None - Enum
    OnlyPositive - Enum
    OnlyNegative - Enum
    EBakeCurvatureClampMode_MAX - Enum */ 
 enum EBakeCurvatureClampMode { 
None,
OnlyPositive,
OnlyNegative,
EBakeCurvatureClampMode_MAX, 
}