/* Class: ACharacter 
 Characters are Pawns that have a mesh, collision, and built-in movement logic.
They are responsible for all physical interaction between the player or AI and the world, and also implement basic networking and input models.
They are designed for a vertically-oriented player representation that can walk, jump, fly, and swim through the world using CharacterMovementComponent.

@see APawn, UCharacterMovementComponent
@see https://docs.unrealengine.com/latest/INT/Gameplay/Framework/Pawn/Character/ */ 
 class ACharacter : public APawn
{
public:
// Group: Animation

/* Variable: CurrentMontage 
 Return current playing Montage * */
const UAnimMontage CurrentMontage;
// Group: Camera

/* Variable: CrouchedEyeHeight 
 Default crouched eye height */
float32 CrouchedEyeHeight;
// Group: Character

/* Variable: CapsuleComponent 
 The CapsuleComponent being used for movement collision (by CharacterMovement). Always treated as being vertically aligned in simple collision check functions. */
UCapsuleComponent CapsuleComponent;
/* Variable: JumpKeyHoldTime 
 Jump key Held Time.
This is the time that the player has held the jump key, in seconds. */
float32 JumpKeyHoldTime;
/* Variable: JumpForceTimeRemaining 
 Amount of jump force time remaining, if JumpMaxHoldTime > 0. */
float32 JumpForceTimeRemaining;
/* Variable: ProxyJumpForceStartedTime 
 Track last time a jump force started for a proxy. */
float32 ProxyJumpForceStartedTime;
/* Variable: CharacterMovement 
 Movement component used for movement logic in various movement modes (walking, falling, etc), containing relevant settings and functions to control movement. */
UCharacterMovementComponent CharacterMovement;
/* Variable: JumpMaxHoldTime 
 The max time the jump key can be held.
Note that if StopJumping() is not called before the max jump hold time is reached,
then the character will carry on receiving vertical velocity. Therefore it is usually
best to call StopJumping() when jump input has ceased (such as a button up event). */
float32 JumpMaxHoldTime;
/* Variable: JumpMaxCount 
 The max number of jumps the character can perform.
Note that if JumpMaxHoldTime is non zero and StopJumping is not called, the player
may be able to perform and unlimited number of jumps. Therefore it is usually
best to call StopJumping() when jump input has ceased (such as a button up event). */
int JumpMaxCount;
/* Variable: JumpCurrentCount 
 Tracks the current number of jumps performed.
This is incremented in CheckJumpInput, used in CanJump_Implementation, and reset in OnMovementModeChanged.
When providing overrides for these methods, it's recommended to either manually
increment / reset this value, or call the Super:: method. */
int JumpCurrentCount;
/* Variable: JumpCurrentCountPreJump 
 Represents the current number of jumps performed before CheckJumpInput modifies JumpCurrentCount.
This is set in CheckJumpInput and is used in SetMoveFor and PrepMoveFor instead of JumpCurrentCount
since CheckJumpInput can modify JumpCurrentCount.
When providing overrides for these methods, it's recommended to either manually
set this value, or call the Super:: method. */
int JumpCurrentCountPreJump;
/* Variable: Mesh 
 The main skeletal mesh associated with this Character (optional sub-object). */
USkeletalMeshComponent Mesh;
/* Variable: LandedDelegate 
 Called upon landing when falling, to perform actions based on the Hit result.
Note that movement mode is still "Falling" during this event. Current Velocity value is the velocity at the time of landing.
Consider OnMovementModeChanged() as well, as that can be used once the movement mode changes to the new mode (most likely Walking).

@param Hit Result describing the landing that resulted in a valid landing spot.
@see OnMovementModeChanged() */
FLandedSignature LandedDelegate;
/* Variable: MovementModeChangedDelegate 
 Multicast delegate for MovementMode changing. */
FMovementModeChangedSignature MovementModeChangedDelegate;
/* Variable: OnCharacterMovementUpdated 
 Event triggered at the end of a CharacterMovementComponent movement update.
This is the preferred event to use rather than the Tick event when performing custom updates to CharacterMovement properties based on the current state.
This is mainly due to the nature of network updates, where client corrections in position from the server can cause multiple iterations of a movement update,
which allows this event to update as well, while a Tick event would not.

@param       DeltaSeconds            Delta time in seconds for this update
@param       InitialLocation         Location at the start of the update. May be different than the current location if movement occurred.
@param       InitialVelocity         Velocity at the start of the update. May be different than the current velocity. */
FCharacterMovementUpdatedSignature OnCharacterMovementUpdated;
/* Variable: OnReachedJumpApex 
 Broadcast when Character's jump reaches its apex. Needs CharacterMovement->bNotifyApex = true */
FCharacterReachedApexSignature OnReachedJumpApex;
/* Variable: bPressedJump 
 When true, player wants to jump */
const bool bPressedJump;
/* Variable: bIsCrouched 
 Set by character movement to specify that this Character is currently crouched. */
const bool bIsCrouched;
/* Variable: bWasJumping 
 Tracks whether or not the character was already jumping last frame. */
const bool bWasJumping;
// Group: Variables

/* Variable: AnimRootMotionTranslationScale 
 Scale to apply to root motion translation on this Character */
const float32 AnimRootMotionTranslationScale;
/* Variable: BaseTranslationOffset 
 Saved translation offset of mesh. */
const FVector BaseTranslationOffset;
/* Variable: BaseRotationOffset 
 Saved rotation offset of mesh. */
const FRotator BaseRotationOffset;
// Group: Animation

/* Function: PlayAnimMontage 
 Play Animation Montage on the character mesh. Returns the length of the animation montage in seconds, or 0.f if failed to play. * */
float32 PlayAnimMontage(UAnimMontage AnimMontage, float32 InPlayRate = 1.000000, FName StartSectionName = NAME_None) {}
/* Function: GetAnimRootMotionTranslationScale 
 Returns current value of AnimRootMotionScale */
float32 GetAnimRootMotionTranslationScale() const {}
/* Function: HasAnyRootMotion 
 True if we are playing root motion from any source right now (anim root motion, root motion source) */
bool HasAnyRootMotion() const {}
/* Function: StopAnimMontage 
 Stop Animation Montage. If nullptr, it will stop what's currently active. The Blend Out Time is taken from the montage asset that is being stopped. * */
void StopAnimMontage(UAnimMontage AnimMontage = nullptr) {}
/* Function: IsPlayingNetworkedRootMotionMontage 
 True if we are playing Root Motion right now, through a Montage with RootMotionMode == ERootMotionMode::RootMotionFromMontagesOnly.
This means code path for networked root motion is enabled. */
bool IsPlayingNetworkedRootMotionMontage() const {}
/* Function: IsPlayingRootMotion 
 True if we are playing Anim root motion right now */
bool IsPlayingRootMotion() const {}
/* Function: GetCurrentMontage 
 Return current playing Montage * */
UAnimMontage GetCurrentMontage() const {}
// Group: Character

/* Function: CanCrouch 
 

Returns:
    true if this character is currently able to crouch (and is not currently crouched) */
bool CanCrouch() const {}
/* Function: CanJumpInternal 
 Customizable event to check if the character can jump in the current state.
Default implementation returns true if the character is on the ground and not crouching,
has a valid CharacterMovementComponent and CanEverJump() returns true.
Default implementation also allows for 'hold to jump higher' functionality:
As well as returning true when on the ground, it also returns true when GetMaxJumpTime is more
than zero and IsJumping returns true.

Returns:
    Whether the character can jump in the current state. */
bool CanJumpInternal() const {}
/* Function: CanJump 
 Check if the character can jump in the current state.

The default implementation may be overridden or extended by implementing the custom CanJump event in Blueprints.

Returns:
    Whether the character can jump in the current state. */
bool CanJump() const {}
/* Function: Jump 
 Make the character jump on the next update.
If you want your character to jump according to the time that the jump key is held,
then you can set JumpMaxHoldTime to some non-zero value. Make sure in this case to
call StopJumping() when you want the jump's z-velocity to stop being applied (such
as on a button up event), otherwise the character will carry on receiving the
velocity until JumpKeyHoldTime reaches JumpMaxHoldTime. */
void Jump() {}
/* Function: Crouch 
 Request the character to start crouching. The request is processed on the next update of the CharacterMovementComponent.
See: OnStartCrouch
See: IsCrouched
See: CharacterMovement->WantsToCrouch */
void Crouch(bool bClientSimulation = false) {}
/* Function: OnJumped 
 Event fired when the character has just started jumping */
void OnJumped() {}
/* Function: GetBaseRotationOffset 
 Get the saved rotation offset of mesh. This is how much extra rotation is applied from the capsule rotation. */
FRotator GetBaseRotationOffset() const {}
/* Function: GetBaseTranslationOffset 
 Get the saved translation offset of mesh. This is how much extra offset is applied from the center of the capsule. */
FVector GetBaseTranslationOffset() const {}
/* Function: OnWalkingOffLedge 
 Event fired when the Character is walking off a surface and is about to fall because CharacterMovement->CurrentFloor became unwalkable.
If CharacterMovement->MovementMode does not change during this event then the character will automatically start falling afterwards.
Note: Z velocity is zero during walking movement, and will be here as well. Another velocity can be computed here if desired and will be used when starting to fall.

Parameters:
    PreviousFloorImpactNormal - Normal of the previous walkable floor.
    PreviousFloorContactNormal - Normal of the contact with the previous walkable floor.
    PreviousLocation - Previous character location before movement off the ledge. */
void OnWalkingOffLedge(FVector PreviousFloorImpactNormal, FVector PreviousFloorContactNormal, FVector PreviousLocation, float32 TimeDelta) {}
/* Function: IsJumpProvidingForce 
 True if jump is actively providing a force, such as when the jump key is held and the time it has been held is less than JumpMaxHoldTime.
See: CharacterMovement->IsFalling */
bool IsJumpProvidingForce() const {}
/* Function: CacheInitialMeshOffset 
 Cache mesh offset from capsule. This is used as the target for network smoothing interpolation, when the mesh is offset with lagged smoothing.
This is automatically called during initialization; call this at runtime if you intend to change the default mesh offset from the capsule.
See: GetBaseTranslationOffset(), GetBaseRotationOffset() */
void CacheInitialMeshOffset(FVector MeshRelativeLocation, FRotator MeshRelativeRotation) {}
/* Function: LaunchCharacter 
 Set a pending launch velocity on the Character. This velocity will be processed on the next CharacterMovementComponent tick,
and will set it to the "falling" state. Triggers the OnLaunched event.

Parameters:
    LaunchVelocity - is the velocity to impart to the Character
    bXYOverride - if true replace the XY part of the Character's velocity instead of adding to it.
    bZOverride - if true replace the Z component of the Character's velocity instead of adding to it. */
void LaunchCharacter(FVector LaunchVelocity, bool bXYOverride, bool bZOverride) {}
/* Function: UnCrouch 
 Request the character to stop crouching. The request is processed on the next update of the CharacterMovementComponent.
See: OnEndCrouch
See: IsCrouched
See: CharacterMovement->WantsToCrouch */
void UnCrouch(bool bClientSimulation = false) {}
/* Function: StopJumping 
 Stop the character from jumping on the next update.
Call this from an input event (such as a button 'up' event) to cease applying
jump Z-velocity. If this is not called, then jump z-velocity will be applied
until JumpMaxHoldTime is reached. */
void StopJumping() {}
// Group: Functions

/* Function: ClientCheatFly 
  */
void ClientCheatFly() {}
/* Function: UpdateCustomMovement 
 Event for implementing custom character movement mode. Called by CharacterMovement if MovementMode is set to Custom.
Note: C++ code should override UCharacterMovementComponent::PhysCustom() instead.
See: UCharacterMovementComponent::PhysCustom() */
void UpdateCustomMovement(float32 DeltaTime) {}
/* Function: ClientAdjustRootMotionPosition 
  */
void ClientAdjustRootMotionPosition(float32 TimeStamp, float32 ServerMontageTrackPosition, FVector ServerLoc, FVector ServerRotation, float32 ServerVelZ, UPrimitiveComponent ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode) {}
/* Function: ClientCheatGhost 
  */
void ClientCheatGhost() {}
/* Function: OnEndCrouch 
 Event when Character stops crouching.

Parameters:
    HalfHeightAdjust - difference between default collision half-height, and actual crouched capsule half-height.
    ScaledHalfHeightAdjust - difference after component scale is taken in to account. */
void OnEndCrouch(float32 HalfHeightAdjust, float32 ScaledHalfHeightAdjust) {}
/* Function: ClientVeryShortAdjustPosition 
 Bandwidth saving version, when velocity is zeroed */
void ClientVeryShortAdjustPosition(float32 TimeStamp, FVector NewLoc, UPrimitiveComponent NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode) {}
/* Function: OnMovementModeChanged 
 Called from CharacterMovementComponent to notify the character that the movement mode has changed.

Parameters:
    PrevMovementMode - Movement mode before the change
    NewMovementMode - New movement mode
    PrevCustomMode - Custom mode before the change (applicable if PrevMovementMode is Custom)
    NewCustomMode - New custom mode (applicable if NewMovementMode is Custom) */
void OnMovementModeChanged(EMovementMode PrevMovementMode, EMovementMode NewMovementMode, uint8 PrevCustomMode, uint8 NewCustomMode) {}
/* Function: OnLaunched 
 Let blueprint know that we were launched */
void OnLaunched(FVector LaunchVelocity, bool bXYOverride, bool bZOverride) {}
/* Function: ClientCheatWalk 
  */
void ClientCheatWalk() {}
/* Function: ClientAdjustPosition 
  */
void ClientAdjustPosition(float32 TimeStamp, FVector NewLoc, FVector NewVel, UPrimitiveComponent NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode) {}
/* Function: RootMotionDebugClientPrintOnScreen 
  */
void RootMotionDebugClientPrintOnScreen(FString InString) {}
/* Function: ServerMove 
  */
void ServerMove(float32 TimeStamp, FVector InAccel, FVector ClientLoc, uint8 CompressedMoveFlags, uint8 ClientRoll, uint View, UPrimitiveComponent ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) {}
/* Function: ServerMoveDual 
  */
void ServerMoveDual(float32 TimeStamp0, FVector InAccel0, uint8 PendingFlags, uint View0, float32 TimeStamp, FVector InAccel, FVector ClientLoc, uint8 NewFlags, uint8 ClientRoll, uint View, UPrimitiveComponent ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) {}
/* Function: ServerMoveDualHybridRootMotion 
  */
void ServerMoveDualHybridRootMotion(float32 TimeStamp0, FVector InAccel0, uint8 PendingFlags, uint View0, float32 TimeStamp, FVector InAccel, FVector ClientLoc, uint8 NewFlags, uint8 ClientRoll, uint View, UPrimitiveComponent ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) {}
/* Function: ServerMoveDualNoBase 
  */
void ServerMoveDualNoBase(float32 TimeStamp0, FVector InAccel0, uint8 PendingFlags, uint View0, float32 TimeStamp, FVector InAccel, FVector ClientLoc, uint8 NewFlags, uint8 ClientRoll, uint View, uint8 ClientMovementMode) {}
/* Function: ServerMoveNoBase 
  */
void ServerMoveNoBase(float32 TimeStamp, FVector InAccel, FVector ClientLoc, uint8 CompressedMoveFlags, uint8 ClientRoll, uint View, uint8 ClientMovementMode) {}
/* Function: ServerMoveOld 
  */
void ServerMoveOld(float32 OldTimeStamp, FVector OldAccel, uint8 OldMoveFlags) {}
/* Function: ClientAckGoodMove 
  */
void ClientAckGoodMove(float32 TimeStamp) {}
/* Function: OnLanded 
 Called upon landing when falling, to perform actions based on the Hit result.
Note that movement mode is still "Falling" during this event. Current Velocity value is the velocity at the time of landing.
Consider OnMovementModeChanged() as well, as that can be used once the movement mode changes to the new mode (most likely Walking).

Parameters:
    Hit - Result describing the landing that resulted in a valid landing spot. */
void OnLanded(FHitResult Hit) {}
/* Function: OnStartCrouch 
 Event when Character crouches.

Parameters:
    HalfHeightAdjust - difference between default collision half-height, and actual crouched capsule half-height.
    ScaledHalfHeightAdjust - difference after component scale is taken in to account. */
void OnStartCrouch(float32 HalfHeightAdjust, float32 ScaledHalfHeightAdjust) {}
/* Function: GetbIsCrouched 
 Set by character movement to specify that this Character is currently crouched. */
bool GetbIsCrouched() const {}
/* Function: GetbPressedJump 
 When true, player wants to jump */
bool GetbPressedJump() const {}
/* Function: GetbWasJumping 
 Tracks whether or not the character was already jumping last frame. */
bool GetbWasJumping() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ACharacter ACharacter::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACharacter::StaticClass() {}
}
