/* Class: EAudioBusChannels 
  */ 
 class EAudioBusChannels
{
public:
}
/* Enum: EAudioBusChannels 
 
    Mono - Enum
    Stereo - Enum
    Quad - Enum
    FivePointOne - Enum
    SevenPointOne - Enum
    MaxChannelCount - Enum
    EAudioBusChannels_MAX - Enum */ 
 enum EAudioBusChannels { 
Mono,
Stereo,
Quad,
FivePointOne,
SevenPointOne,
MaxChannelCount,
EAudioBusChannels_MAX, 
}