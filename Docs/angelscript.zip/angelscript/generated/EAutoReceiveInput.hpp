/* Class: EAutoReceiveInput 
  */ 
 class EAutoReceiveInput
{
public:
}
/* Enum: EAutoReceiveInput 
 
    Disabled - Enum
    Player0 - Enum
    Player1 - Enum
    Player2 - Enum
    Player3 - Enum
    Player4 - Enum
    Player5 - Enum
    Player6 - Enum
    Player7 - Enum
    EAutoReceiveInput_MAX - Enum */ 
 enum EAutoReceiveInput { 
Disabled,
Player0,
Player1,
Player2,
Player3,
Player4,
Player5,
Player6,
Player7,
EAutoReceiveInput_MAX, 
}