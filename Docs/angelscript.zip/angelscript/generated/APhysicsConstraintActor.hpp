/* Class: APhysicsConstraintActor 
  */ 
 class APhysicsConstraintActor : public ARigidBodyBase
{
public:
// Group: ConstraintActor

/* Variable: ConstraintComp 
  */
UPhysicsConstraintComponent ConstraintComp;
// Group: Static Functions

/* Function: Spawn 
  */
static APhysicsConstraintActor APhysicsConstraintActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APhysicsConstraintActor::StaticClass() {}
}
