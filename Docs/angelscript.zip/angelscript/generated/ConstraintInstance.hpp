/* Class: ConstraintInstance 
  */ 
 class ConstraintInstance
{
public:
// Group: Physics|Constraints

/* Function: GetProjectionParams 
 Gets projection parameters of the constraint

Parameters:
    Accessor - Constraint accessor to query
    bEnableProjection - true to enable projection
    ProjectionLinearAlpha - how much linear projection to apply in [0,1] range
    ProjectionAngularAlpha - how much angular projection to apply in [0,1] range */
static void ConstraintInstance::GetProjectionParams(FConstraintInstanceAccessor& Accessor, bool& bEnableProjection, float32& ProjectionLinearAlpha, float32& ProjectionAngularAlpha) {}
/* Function: GetAngularBreakable 
 Gets Constraint Angular Breakable properties

Parameters:
    Accessor - Constraint accessor to query
    bAngularBreakable - Whether it is possible to break the joint with angular force
    AngularBreakThreshold - Torque needed to break the joint */
static void ConstraintInstance::GetAngularBreakable(FConstraintInstanceAccessor& Accessor, bool& bAngularBreakable, float32& AngularBreakThreshold) {}
/* Function: GetAngularDriveMode 
 Gets the angular drive mode ( SLERP or Twist And Swing)

Parameters:
    Accessor - Constraint accessor to query
    OutDriveMode - The angular drive mode to use. SLERP uses shortest spherical path, but will not work if any angular constraints are locked. Twist and Swing decomposes the path into the different angular degrees of freedom but may experience gimbal lock */
static void ConstraintInstance::GetAngularDriveMode(FConstraintInstanceAccessor& Accessor, EAngularDriveMode& OutDriveMode) {}
/* Function: GetAngularDriveParams 
 Gets the drive params for the angular drive.

Parameters:
    Accessor - Constraint accessor to query
    OutPositionStrength - Positional strength for the drive (stiffness)
    OutVelocityStrength - Velocity strength of the drive (damping)
    OutForceLimit - Max force applied by the drive */
static void ConstraintInstance::GetAngularDriveParams(FConstraintInstanceAccessor& Accessor, float32& OutPositionStrength, float32& OutVelocityStrength, float32& OutForceLimit) {}
/* Function: GetAngularLimits 
 Gets Constraint Angular Motion Ranges

Parameters:
    Accessor - Constraint accessor to query
    Swing1MotionType - Type of swing motion ( first axis )
    Swing1LimitAngle - Size of limit in degrees in [0, 180] range
    Swing2MotionType - Type of swing motion ( second axis )
    Swing2LimitAngle - Size of limit in degrees in [0, 180] range
    TwistMotionType - Type of twist motion
    TwistLimitAngle - Size of limit in degrees in [0, 180] range */
static void ConstraintInstance::GetAngularLimits(FConstraintInstanceAccessor& Accessor, EAngularConstraintMotion& Swing1MotionType, float32& Swing1LimitAngle, EAngularConstraintMotion& Swing2MotionType, float32& Swing2LimitAngle, EAngularConstraintMotion& TwistMotionType, float32& TwistLimitAngle) {}
/* Function: GetAngularOrientationTarget 
 Gets the target orientation for the angular drive.

Parameters:
    Accessor - Constraint accessor to query
    OutPosTarget - Target orientation */
static void ConstraintInstance::GetAngularOrientationTarget(FConstraintInstanceAccessor& Accessor, FRotator& OutPosTarget) {}
/* Function: GetAngularPlasticity 
 Sets Constraint Angular Plasticity properties

Parameters:
    Accessor - Constraint accessor to query
    bAngularPlasticity - Whether it is possible to reset the target angle from the angular displacement
    AngularPlasticityThreshold - Degrees needed to reset the rest state of the joint */
static void ConstraintInstance::GetAngularPlasticity(FConstraintInstanceAccessor& Accessor, bool& bAngularPlasticity, float32& AngularPlasticityThreshold) {}
/* Function: GetAngularSoftSwingLimitParams 
 Gets Constraint Angular Soft Swing Limit parameters

Parameters:
    Accessor - Constraint accessor to query *
    bSoftSwingLimit - True is the swing limit is soft
    SwingLimitStiffness - Stiffness of the soft swing limit. Only used when Soft limit is on ( positive value )
    SwingLimitDamping - Damping of the soft swing limit. Only used when Soft limit is on ( positive value )
    SwingLimitRestitution - Controls the amount of bounce when the constraint is violated. A restitution value of 1 will bounce back with the same velocity the limit was hit. A value of 0 will stop dead.
    SwingLimitContactDistance - Determines how close to the limit we have to get before turning the joint on. Larger value will be more expensive, but will do a better job not violating constraints. A smaller value will be more efficient, but easier to violate. */
static void ConstraintInstance::GetAngularSoftSwingLimitParams(FConstraintInstanceAccessor& Accessor, bool& bSoftSwingLimit, float32& SwingLimitStiffness, float32& SwingLimitDamping, float32& SwingLimitRestitution, float32& SwingLimitContactDistance) {}
/* Function: GetAngularSoftTwistLimitParams 
 Gets Constraint Angular Soft Twist Limit parameters

Parameters:
    Accessor - Constraint accessor to query *
    bSoftTwistLimit - True is the Twist limit is soft
    TwistLimitStiffness - Stiffness of the soft Twist limit. Only used when Soft limit is on ( positive value )
    TwistLimitDamping - Damping of the soft Twist limit. Only used when Soft limit is on ( positive value )
    TwistLimitRestitution - Controls the amount of bounce when the constraint is violated. A restitution value of 1 will bounce back with the same velocity the limit was hit. A value of 0 will stop dead.
    TwistLimitContactDistance - Determines how close to the limit we have to get before turning the joint on. Larger value will be more expensive, but will do a better job not violating constraints. A smaller value will be more efficient, but easier to violate. */
static void ConstraintInstance::GetAngularSoftTwistLimitParams(FConstraintInstanceAccessor& Accessor, bool& bSoftTwistLimit, float32& TwistLimitStiffness, float32& TwistLimitDamping, float32& TwistLimitRestitution, float32& TwistLimitContactDistance) {}
/* Function: GetAngularVelocityDriveSLERP 
 Gets whether the angular velocity slerp drive is enabled or not. Only relevant if the AngularDriveMode is set to SLERP

Parameters:
    Accessor - Constraint accessor to query
    bOutEnableSLERP - Indicates whether the SLERP drive is enabled. Only relevant if the AngularDriveMode is set to SLERP */
static void ConstraintInstance::GetAngularVelocityDriveSLERP(FConstraintInstanceAccessor& Accessor, bool& bOutEnableSLERP) {}
/* Function: GetAngularVelocityDriveTwistAndSwing 
 Gets whether angular velocity twist and swing drive is enabled or not. Only relevant if the AngularDriveMode is set to Twist and Swing

Parameters:
    Accessor - Constraint accessor to query
    bOutEnableTwistDrive - Indicates whether the drive for the twist axis should be enabled. Only relevant if the AngularDriveMode is set to Twist and Swing
    bOutEnableSwingDrive - Indicates whether the drive for the swing axis should be enabled. Only relevant if the AngularDriveMode is set to Twist and Swing */
static void ConstraintInstance::GetAngularVelocityDriveTwistAndSwing(FConstraintInstanceAccessor& Accessor, bool& bOutEnableTwistDrive, bool& bOutEnableSwingDrive) {}
/* Function: GetAngularVelocityTarget 
 Gets the target velocity for the angular drive.

Parameters:
    Accessor - Constraint accessor to query
    OutVelTarget - Target velocity */
static void ConstraintInstance::GetAngularVelocityTarget(FConstraintInstanceAccessor& Accessor, FVector& OutVelTarget) {}
/* Function: GetAttachedBodyNames 
 Gets Attached body names

Parameters:
    Accessor - Constraint accessor to query
    ParentBody - Parent body name of the constraint
    ChildBody - Child body name of the constraint */
static void ConstraintInstance::GetAttachedBodyNames(FConstraintInstanceAccessor& Accessor, FName& ParentBody, FName& ChildBody) {}
/* Function: GetContactTransferScale 
 Gets Constraint Contact Transfer Scale properties

Parameters:
    Accessor - Constraint accessor to query
    ContactTransferScale - Scale for transfer of child energy to parent. */
static void ConstraintInstance::GetContactTransferScale(FConstraintInstanceAccessor& Accessor, float32& ContactTransferScale) {}
/* Function: GetDisableCollsion 
 Gets whether bodies attched to the constraint can collide or not

Parameters:
    Accessor - Constraint accessor to query */
static bool ConstraintInstance::GetDisableCollsion(FConstraintInstanceAccessor& Accessor) {}
/* Function: GetLinearBreakable 
 Gets Constraint Linear Breakable properties

Parameters:
    Accessor - Constraint accessor to query
    bLinearBreakable - Whether it is possible to break the joint with linear force
    LinearBreakThreshold - Force needed to break the joint */
static void ConstraintInstance::GetLinearBreakable(FConstraintInstanceAccessor& Accessor, bool& bLinearBreakable, float32& LinearBreakThreshold) {}
/* Function: GetLinearDriveParams 
 Gets the drive params for the linear drive.

Parameters:
    Accessor - Constraint accessor to query
    OutPositionStrength - Positional strength for the drive (stiffness)
    OutVelocityStrength - Velocity strength of the drive (damping)
    OutForceLimit - Max force applied by the drive */
static void ConstraintInstance::GetLinearDriveParams(FConstraintInstanceAccessor& Accessor, float32& OutPositionStrength, float32& OutVelocityStrength, float32& OutForceLimit) {}
/* Function: GetLinearLimits 
 Gets Constraint Linear Motion Ranges

Parameters:
    Accessor - Constraint accessor to query
    XMotion - Type of motion along the X axis
    YMotion - Type of motion along the Y axis
    ZMotion - Type of motion along the Z axis
    Limit - linear limit applied to all axis */
static void ConstraintInstance::GetLinearLimits(FConstraintInstanceAccessor& Accessor, ELinearConstraintMotion& XMotion, ELinearConstraintMotion& YMotion, ELinearConstraintMotion& ZMotion, float32& Limit) {}
/* Function: GetLinearPlasticity 
 Gets Constraint Linear Plasticity properties

Parameters:
    Accessor - Constraint accessor to query */
static void ConstraintInstance::GetLinearPlasticity(FConstraintInstanceAccessor& Accessor, bool& bLinearPlasticity, float32& LinearPlasticityThreshold, EConstraintPlasticityType& PlasticityType) {}
/* Function: GetLinearPositionDrive 
 Gets whether linear position drive is enabled or not

Parameters:
    Accessor - Constraint accessor to query
    bOutEnableDriveX - Indicates whether the drive for the X-Axis is enabled
    bOutEnableDriveY - Indicates whether the drive for the Y-Axis is enabled
    bOutEnableDriveZ - Indicates whether the drive for the Z-Axis is enabled */
static void ConstraintInstance::GetLinearPositionDrive(FConstraintInstanceAccessor& Accessor, bool& bOutEnableDriveX, bool& bOutEnableDriveY, bool& bOutEnableDriveZ) {}
/* Function: GetLinearPositionTarget 
 Gets the target position for the linear drive.

Parameters:
    Accessor - Constraint accessor to query
    OutPosTarget - Target position */
static void ConstraintInstance::GetLinearPositionTarget(FConstraintInstanceAccessor& Accessor, FVector& OutPosTarget) {}
/* Function: GetLinearSoftLimitParams 
 Gets Constraint Linear Soft Limit parameters

Parameters:
    Accessor - Constraint accessor to query *
    bSoftLinearLimit - True is the Linear limit is soft
    LinearLimitStiffness - Stiffness of the soft Linear limit. Only used when Soft limit is on ( positive value )
    LinearLimitDamping - Damping of the soft Linear limit. Only used when Soft limit is on ( positive value )
    LinearLimitRestitution - Controls the amount of bounce when the constraint is violated. A restitution value of 1 will bounce back with the same velocity the limit was hit. A value of 0 will stop dead.
    LinearLimitContactDistance - Determines how close to the limit we have to get before turning the joint on. Larger value will be more expensive, but will do a better job not violating constraints. A smaller value will be more efficient, but easier to violate. */
static void ConstraintInstance::GetLinearSoftLimitParams(FConstraintInstanceAccessor& Accessor, bool& bSoftLinearLimit, float32& LinearLimitStiffness, float32& LinearLimitDamping, float32& LinearLimitRestitution, float32& LinearLimitContactDistance) {}
/* Function: GetLinearVelocityDrive 
 Gets whether linear velocity drive is enabled or not

Parameters:
    Accessor - Constraint accessor to query
    bOutEnableDriveX - Indicates whether the drive for the X-Axis is enabled
    bOutEnableDriveY - Indicates whether the drive for the Y-Axis is enabled
    bOutEnableDriveZ - Indicates whether the drive for the Z-Axis is enabled */
static void ConstraintInstance::GetLinearVelocityDrive(FConstraintInstanceAccessor& Accessor, bool& bOutEnableDriveX, bool& bOutEnableDriveY, bool& bOutEnableDriveZ) {}
/* Function: GetLinearVelocityTarget 
 Gets the target velocity for the linear drive.

Parameters:
    Accessor - Constraint accessor to query
    OutVelTarget - Target velocity */
static void ConstraintInstance::GetLinearVelocityTarget(FConstraintInstanceAccessor& Accessor, FVector& OutVelTarget) {}
/* Function: GetMassConditioningEnabled 
 @brief Gets whether mass conditioning is enabled for the constraint. */
static bool ConstraintInstance::GetMassConditioningEnabled(FConstraintInstanceAccessor& Accessor) {}
/* Function: GetOrientationDriveSLERP 
 Gets whether the angular orientation slerp drive is enabled or not. Only relevant if the AngularDriveMode is set to SLERP

Parameters:
    Accessor - Constraint accessor to query
    bOutEnableSLERP - Indicates whether the SLERP drive should be enabled. Only relevant if the AngularDriveMode is set to SLERP */
static void ConstraintInstance::GetOrientationDriveSLERP(FConstraintInstanceAccessor& Accessor, bool& bOutEnableSLERP) {}
/* Function: GetOrientationDriveTwistAndSwing 
 Gets whether angular orientation drive are enabled. Only relevant if the AngularDriveMode is set to Twist and Swing

Parameters:
    Accessor - Constraint accessor to query
    bOutEnableTwistDrive - Indicates whether the drive for the twist axis is enabled. Only relevant if the AngularDriveMode is set to Twist and Swing
    bOutEnableSwingDrive - Indicates whether the drive for the swing axis is enabled. Only relevant if the AngularDriveMode is set to Twist and Swing */
static void ConstraintInstance::GetOrientationDriveTwistAndSwing(FConstraintInstanceAccessor& Accessor, bool& bOutEnableTwistDrive, bool& bOutEnableSwingDrive) {}
/* Function: GetParentDominates 
 Gets whether the parent body is not affected by it's child motion

Parameters:
    Accessor - Constraint accessor to query */
static bool ConstraintInstance::GetParentDominates(FConstraintInstanceAccessor& Accessor) {}
/* Function: CopyParams 
 Copies all properties from one constraint to another

Parameters:
    Accessor - Constraint accessor to write to
    SourceAccessor - Constraint accessor to read from
    bKeepPosition - Whether to keep original constraint positions
    bKeepRotation - Whether to keep original constraint rotations */
static void ConstraintInstance::CopyParams(FConstraintInstanceAccessor& Accessor, FConstraintInstanceAccessor& SourceAccessor, bool bKeepPosition = true, bool bKeepRotation = true) {}
/* Function: SetAngularBreakable 
 Sets Constraint Angular Breakable properties

Parameters:
    Accessor - Constraint accessor to change
    bAngularBreakable - Whether it is possible to break the joint with angular force
    AngularBreakThreshold - Torque needed to break the joint */
static void ConstraintInstance::SetAngularBreakable(FConstraintInstanceAccessor& Accessor, bool bAngularBreakable, float32 AngularBreakThreshold) {}
/* Function: SetAngularDriveMode 
 Switches the angular drive mode between SLERP and Twist And Swing

Parameters:
    Accessor - Constraint accessor to change
    DriveMode - The angular drive mode to use. SLERP uses shortest spherical path, but will not work if any angular constraints are locked. Twist and Swing decomposes the path into the different angular degrees of freedom but may experience gimbal lock */
static void ConstraintInstance::SetAngularDriveMode(FConstraintInstanceAccessor& Accessor, EAngularDriveMode DriveMode) {}
/* Function: SetAngularDriveParams 
 Sets the drive params for the angular drive.

Parameters:
    Accessor - Constraint accessor to change
    PositionStrength - Positional strength for the drive (stiffness)
    VelocityStrength - Velocity strength of the drive (damping)
    InForceLimit - Max force applied by the drive */
static void ConstraintInstance::SetAngularDriveParams(FConstraintInstanceAccessor& Accessor, float32 PositionStrength, float32 VelocityStrength, float32 InForceLimit) {}
/* Function: SetAngularLimits 
 Sets COnstraint Angular Motion Ranges

Parameters:
    Accessor - Constraint accessor to change
    Swing1MotionType - Type of swing motion ( first axis )
    Swing1LimitAngle - Size of limit in degrees in [0, 180] range
    Swing2MotionType - Type of swing motion ( second axis )
    Swing2LimitAngle - Size of limit in degrees in [0, 180] range
    TwistMotionType - Type of twist motion
    TwistLimitAngle - Size of limit in degrees in [0, 180] range */
static void ConstraintInstance::SetAngularLimits(FConstraintInstanceAccessor& Accessor, EAngularConstraintMotion Swing1MotionType, float32 Swing1LimitAngle, EAngularConstraintMotion Swing2MotionType, float32 Swing2LimitAngle, EAngularConstraintMotion TwistMotionType, float32 TwistLimitAngle) {}
/* Function: SetAngularOrientationTarget 
 Sets the target orientation for the angular drive.

Parameters:
    Accessor - Constraint accessor to change
    InPosTarget - Target orientation */
static void ConstraintInstance::SetAngularOrientationTarget(FConstraintInstanceAccessor& Accessor, FRotator InPosTarget) {}
/* Function: SetAngularPlasticity 
 Sets Constraint Angular Plasticity properties

Parameters:
    Accessor - Constraint accessor to change
    bAngularPlasticity - Whether it is possible to reset the target angle from the angular displacement
    AngularPlasticityThreshold - Degrees needed to reset the rest state of the joint */
static void ConstraintInstance::SetAngularPlasticity(FConstraintInstanceAccessor& Accessor, bool bAngularPlasticity, float32 AngularPlasticityThreshold) {}
/* Function: SetAngularSoftSwingLimitParams 
 Sets Constraint Angular Soft Swing Limit parameters

Parameters:
    Accessor - Constraint accessor to change *
    bSoftSwingLimit - True is the swing limit is soft
    SwingLimitStiffness - Stiffness of the soft swing limit. Only used when Soft limit is on ( positive value )
    SwingLimitDamping - Damping of the soft swing limit. Only used when Soft limit is on ( positive value )
    SwingLimitRestitution - Controls the amount of bounce when the constraint is violated. A restitution value of 1 will bounce back with the same velocity the limit was hit. A value of 0 will stop dead.
    SwingLimitContactDistance - Determines how close to the limit we have to get before turning the joint on. Larger value will be more expensive, but will do a better job not violating constraints. A smaller value will be more efficient, but easier to violate. */
static void ConstraintInstance::SetAngularSoftSwingLimitParams(FConstraintInstanceAccessor& Accessor, bool bSoftSwingLimit, float32 SwingLimitStiffness, float32 SwingLimitDamping, float32 SwingLimitRestitution, float32 SwingLimitContactDistance) {}
/* Function: SetAngularSoftTwistLimitParams 
 Sets Constraint Angular Soft Twist Limit parameters

Parameters:
    Accessor - Constraint accessor to change *
    bSoftTwistLimit - True is the twist limit is soft
    TwistLimitStiffness - Stiffness of the soft Twist limit. Only used when Soft limit is on ( positive value )
    TwistLimitDamping - Damping of the soft Twist limit. Only used when Soft limit is on ( positive value )
    TwistLimitRestitution - Controls the amount of bounce when the constraint is violated. A restitution value of 1 will bounce back with the same velocity the limit was hit. A value of 0 will stop dead.
    TwistLimitContactDistance - Determines how close to the limit we have to get before turning the joint on. Larger value will be more expensive, but will do a better job not violating constraints. A smaller value will be more efficient, but easier to violate. */
static void ConstraintInstance::SetAngularSoftTwistLimitParams(FConstraintInstanceAccessor& Accessor, bool bSoftTwistLimit, float32 TwistLimitStiffness, float32 TwistLimitDamping, float32 TwistLimitRestitution, float32 TwistLimitContactDistance) {}
/* Function: SetAngularVelocityDriveSLERP 
 Enables/Disables the angular velocity slerp drive. Only relevant if the AngularDriveMode is set to SLERP

Parameters:
    Accessor - Constraint accessor to change
    bEnableSLERP - Indicates whether the SLERP drive should be enabled. Only relevant if the AngularDriveMode is set to SLERP */
static void ConstraintInstance::SetAngularVelocityDriveSLERP(FConstraintInstanceAccessor& Accessor, bool bEnableSLERP) {}
/* Function: SetAngularVelocityDriveTwistAndSwing 
 Enables/Disables angular velocity twist and swing drive. Only relevant if the AngularDriveMode is set to Twist and Swing

Parameters:
    Accessor - Constraint accessor to change
    bEnableTwistDrive - Indicates whether the drive for the twist axis should be enabled. Only relevant if the AngularDriveMode is set to Twist and Swing
    bEnableSwingDrive - Indicates whether the drive for the swing axis should be enabled. Only relevant if the AngularDriveMode is set to Twist and Swing */
static void ConstraintInstance::SetAngularVelocityDriveTwistAndSwing(FConstraintInstanceAccessor& Accessor, bool bEnableTwistDrive, bool bEnableSwingDrive) {}
/* Function: SetAngularVelocityTarget 
 Sets the target velocity for the angular drive.

Parameters:
    Accessor - Constraint accessor to change
    InVelTarget - Target velocity */
static void ConstraintInstance::SetAngularVelocityTarget(FConstraintInstanceAccessor& Accessor, FVector InVelTarget) {}
/* Function: SetContactTransferScale 
 Set Contact Transfer Scale

Parameters:
    Accessor - Constraint accessor to change
    ContactTransferScale - Set Contact Transfer Scale onto joints parent */
static void ConstraintInstance::SetContactTransferScale(FConstraintInstanceAccessor& Accessor, float32 ContactTransferScale) {}
/* Function: SetDisableCollision 
 Sets whether bodies attched to the constraint can collide or not

Parameters:
    Accessor - Constraint accessor to change
    bDisableCollision - true to disable collision between constrained bodies */
static void ConstraintInstance::SetDisableCollision(FConstraintInstanceAccessor& Accessor, bool bDisableCollision) {}
/* Function: SetLinearBreakable 
 Sets the Linear Breakable properties

Parameters:
    Accessor - Constraint accessor to change
    bLinearBreakable - Whether it is possible to break the joint with linear force
    LinearBreakThreshold - Force needed to break the joint */
static void ConstraintInstance::SetLinearBreakable(FConstraintInstanceAccessor& Accessor, bool bLinearBreakable, float32 LinearBreakThreshold) {}
/* Function: SetLinearDriveParams 
 Sets the drive params for the linear drive.

Parameters:
    Accessor - Constraint accessor to change
    PositionStrength - Positional strength for the drive (stiffness)
    VelocityStrength - Velocity strength of the drive (damping)
    InForceLimit - Max force applied by the drive */
static void ConstraintInstance::SetLinearDriveParams(FConstraintInstanceAccessor& Accessor, float32 PositionStrength, float32 VelocityStrength, float32 InForceLimit) {}
/* Function: SetLinearLimits 
 Sets Constraint Linear Motion Ranges

Parameters:
    Accessor - Constraint accessor to change
    XMotion - Type of motion along the X axis
    YMotion - Type of motion along the Y axis
    ZMotion - Type of motion along the Z axis
    Limit - linear limit to apply to all axis */
static void ConstraintInstance::SetLinearLimits(FConstraintInstanceAccessor& Accessor, ELinearConstraintMotion XMotion, ELinearConstraintMotion YMotion, ELinearConstraintMotion ZMotion, float32 Limit) {}
/* Function: SetLinearPlasticity 
 Sets Constraint Linear Plasticity properties

Parameters:
    Accessor - Constraint accessor to change
    bLinearPlasticity - Whether it is possible to reset the target position from the linear displacement
    LinearPlasticityThreshold - Delta from target needed to reset the target joint */
static void ConstraintInstance::SetLinearPlasticity(FConstraintInstanceAccessor& Accessor, bool bLinearPlasticity, float32 LinearPlasticityThreshold, EConstraintPlasticityType PlasticityType) {}
/* Function: SetLinearPositionDrive 
 Enables/Disables linear position drive

Parameters:
    Accessor - Constraint accessor to change
    bEnableDriveX - Indicates whether the drive for the X-Axis should be enabled
    bEnableDriveY - Indicates whether the drive for the Y-Axis should be enabled
    bEnableDriveZ - Indicates whether the drive for the Z-Axis should be enabled */
static void ConstraintInstance::SetLinearPositionDrive(FConstraintInstanceAccessor& Accessor, bool bEnableDriveX, bool bEnableDriveY, bool bEnableDriveZ) {}
/* Function: SetLinearPositionTarget 
 Sets the target position for the linear drive.

Parameters:
    Accessor - Constraint accessor to change
    InPosTarget - Target position */
static void ConstraintInstance::SetLinearPositionTarget(FConstraintInstanceAccessor& Accessor, FVector InPosTarget) {}
/* Function: SetLinearSoftLimitParams 
 Sets Constraint Linear Soft Limit parameters

Parameters:
    Accessor - Constraint accessor to change *
    bSoftLinearLimit - True is the linear limit is soft
    LinearLimitStiffness - Stiffness of the soft linear limit. Only used when Soft limit is on ( positive value )
    LinearLimitDamping - Damping of the soft linear limit. Only used when Soft limit is on ( positive value )
    LinearLimitRestitution - Controls the amount of bounce when the constraint is violated. A restitution value of 1 will bounce back with the same velocity the limit was hit. A value of 0 will stop dead.
    LinearLimitContactDistance - Determines how close to the limit we have to get before turning the joint on. Larger value will be more expensive, but will do a better job not violating constraints. A smaller value will be more efficient, but easier to violate. */
static void ConstraintInstance::SetLinearSoftLimitParams(FConstraintInstanceAccessor& Accessor, bool bSoftLinearLimit, float32 LinearLimitStiffness, float32 LinearLimitDamping, float32 LinearLimitRestitution, float32 LinearLimitContactDistance) {}
/* Function: SetLinearVelocityDrive 
 Enables/Disables linear velocity drive

Parameters:
    Accessor - Constraint accessor to change
    bEnableDriveX - Indicates whether the drive for the X-Axis should be enabled
    bEnableDriveY - Indicates whether the drive for the Y-Axis should be enabled
    bEnableDriveZ - Indicates whether the drive for the Z-Axis should be enabled */
static void ConstraintInstance::SetLinearVelocityDrive(FConstraintInstanceAccessor& Accessor, bool bEnableDriveX, bool bEnableDriveY, bool bEnableDriveZ) {}
/* Function: SetLinearVelocityTarget 
 Sets the target velocity for the linear drive.

Parameters:
    Accessor - Constraint accessor to change
    InVelTarget - Target velocity */
static void ConstraintInstance::SetLinearVelocityTarget(FConstraintInstanceAccessor& Accessor, FVector InVelTarget) {}
/* Function: SetMassConditioningEnabled 
 @brief Enable or disable mass conditioning for the constraint. */
static void ConstraintInstance::SetMassConditioningEnabled(FConstraintInstanceAccessor& Accessor, bool bEnableMassConditioning) {}
/* Function: SetOrientationDriveSLERP 
 Enables/Disables the angular orientation slerp drive. Only relevant if the AngularDriveMode is set to SLERP

Parameters:
    Accessor - Constraint accessor to change
    bEnableSLERP - Indicates whether the SLERP drive should be enabled. Only relevant if the AngularDriveMode is set to SLERP */
static void ConstraintInstance::SetOrientationDriveSLERP(FConstraintInstanceAccessor& Accessor, bool bEnableSLERP) {}
/* Function: SetOrientationDriveTwistAndSwing 
 Enables/Disables angular orientation drive. Only relevant if the AngularDriveMode is set to Twist and Swing

Parameters:
    Accessor - Constraint accessor to change
    bEnableTwistDrive - Indicates whether the drive for the twist axis should be enabled. Only relevant if the AngularDriveMode is set to Twist and Swing
    bEnableSwingDrive - Indicates whether the drive for the swing axis should be enabled. Only relevant if the AngularDriveMode is set to Twist and Swing */
static void ConstraintInstance::SetOrientationDriveTwistAndSwing(FConstraintInstanceAccessor& Accessor, bool bEnableTwistDrive, bool bEnableSwingDrive) {}
/* Function: SetParentDominates 
 Sets whether the parent body is not affected by it's child motion

Parameters:
    Accessor - Constraint accessor to change
    bParentDominates - true to avoid the parent being affected by its child motion */
static void ConstraintInstance::SetParentDominates(FConstraintInstanceAccessor& Accessor, bool bParentDominates) {}
/* Function: SetProjectionParams 
 Sets projection parameters of the constraint

Parameters:
    Accessor - Constraint accessor to change
    bEnableProjection - true to enable projection
    ProjectionLinearAlpha - how much linear projection to apply in [0,1] range
    ProjectionAngularAlpha - how much angular projection to apply in [0,1] range */
static void ConstraintInstance::SetProjectionParams(FConstraintInstanceAccessor& Accessor, bool bEnableProjection, float32 ProjectionLinearAlpha, float32 ProjectionAngularAlpha) {}
}
