/* Class: EAudioRadialSliderLayout 
  */ 
 class EAudioRadialSliderLayout
{
public:
}
/* Enum: EAudioRadialSliderLayout 
 
    Layout_LabelTop - Enum
    Layout_LabelCenter - Enum
    Layout_LabelBottom - Enum
    Layout_MAX - Enum */ 
 enum EAudioRadialSliderLayout { 
Layout_LabelTop,
Layout_LabelCenter,
Layout_LabelBottom,
Layout_MAX, 
}