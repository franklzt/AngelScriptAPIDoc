/* Class: EAudioSpectrumPlotTilt 
  */ 
 class EAudioSpectrumPlotTilt
{
public:
}
/* Enum: EAudioSpectrumPlotTilt 
 
    NoTilt - Enum
    Plus1_5dBPerOctave - Enum
    Plus3dBPerOctave - Enum
    Plus4_5dBPerOctave - Enum
    Plus6dBPerOctave - Enum
    EAudioSpectrumPlotTilt_MAX - Enum */ 
 enum EAudioSpectrumPlotTilt { 
NoTilt,
Plus1_5dBPerOctave,
Plus3dBPerOctave,
Plus4_5dBPerOctave,
Plus6dBPerOctave,
EAudioSpectrumPlotTilt_MAX, 
}