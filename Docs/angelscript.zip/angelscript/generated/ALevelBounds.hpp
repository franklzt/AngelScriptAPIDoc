/* Class: ALevelBounds 
 Defines level bounds
Updates bounding box automatically based on actors transformation changes or holds fixed user defined bounding box
Uses only actors where AActor::IsLevelBoundsRelevant() == true */ 
 class ALevelBounds : public AActor
{
public:
// Group: LevelBounds

/* Variable: bAutoUpdateBounds 
 Whether to automatically update actor bounds based on all relevant actors bounds belonging to the same level */
bool bAutoUpdateBounds;
/* Variable: BoxComponent 
 Bounding box for the level bounds. */
UBoxComponent BoxComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ALevelBounds ALevelBounds::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALevelBounds::StaticClass() {}
}
