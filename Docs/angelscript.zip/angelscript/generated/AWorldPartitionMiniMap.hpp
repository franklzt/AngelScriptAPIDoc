/* Class: AWorldPartitionMiniMap 
 A mini map to preview the world in world partition window. (editor-only) */ 
 class AWorldPartitionMiniMap : public AInfo
{
public:
// Group: WorldPartitionMiniMap

/* Variable: WorldUnitsPerPixel 
 Target world units per pixel for the minimap texture.
May not end up being the final minimap accuracy if the resulting texture resolution is unsupported. */
int WorldUnitsPerPixel;
/* Variable: BuilderCellSize 
 Size of the loading region that will be used when iterating over the whole map during the minimap build process.
A smaller size may help reduce blurriness as it will put less pressure on various graphics pools, at the expanse of an increase in processing time. */
int BuilderCellSize;
/* Variable: CaptureSource 
 Specifies which component of the scene rendering should be output to the minimap texture. */
ESceneCaptureSource CaptureSource;
/* Variable: CaptureWarmupFrames 
 Number of frames to render before each capture in order to warmup various rendering systems (VT/Nanite/etc). */
uint CaptureWarmupFrames;
/* Variable: ExcludedDataLayers 
 Datalayers excluded from MiniMap rendering */
TSet<FActorDataLayer> ExcludedDataLayers;
// Group: Static Functions

/* Function: Spawn 
  */
static AWorldPartitionMiniMap AWorldPartitionMiniMap::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AWorldPartitionMiniMap::StaticClass() {}
}
