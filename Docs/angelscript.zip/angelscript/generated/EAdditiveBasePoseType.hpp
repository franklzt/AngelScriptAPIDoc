/* Class: EAdditiveBasePoseType 
  */ 
 class EAdditiveBasePoseType
{
public:
}
/* Enum: EAdditiveBasePoseType 
 
    ABPT_None - Enum
    ABPT_RefPose - Enum
    ABPT_AnimScaled - Enum
    ABPT_AnimFrame - Enum
    ABPT_LocalAnimFrame - Enum
    ABPT_MAX - Enum */ 
 enum EAdditiveBasePoseType { 
ABPT_None,
ABPT_RefPose,
ABPT_AnimScaled,
ABPT_AnimFrame,
ABPT_LocalAnimFrame,
ABPT_MAX, 
}