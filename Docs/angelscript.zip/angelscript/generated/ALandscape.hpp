/* Class: ALandscape 
  */ 
 class ALandscape : public ALandscapeProxy
{
public:
// Group: Landscape

/* Variable: bCanHaveLayersContent 
  */
bool bCanHaveLayersContent;
// Group: WorldPartition

/* Variable: bAreNewLandscapeActorsSpatiallyLoaded 
 Landscape actor has authority on default streaming behavior for new actors : LandscapeStreamingProxies & LandscapeSplineActors */
bool bAreNewLandscapeActorsSpatiallyLoaded;
// Group: Landscape

/* Function: ForceLayersFullUpdate 
  */
void ForceLayersFullUpdate() {}
// Group: Landscape|Editor

/* Function: GetTargetLayerNames 
 Retrieves the names of valid paint layers on this landscape (editor-only : returns nothing at runtime)

Parameters:
    bInIncludeVisibilityLayer - whether the visibility layer's name should be included in the list or not

Returns:
    the list of paint layer names */
TArray<FName> GetTargetLayerNames(bool bInIncludeVisibilityLayer = false) const {}
// Group: Landscape|Runtime

/* Function: RenderWeightmap 
 Render the final weightmap for the requested layer, in the requested top-down window, as one -atlased- texture in the provided render target 2D
 Can be called at runtime.

Parameters:
    InWorldTransform - World transform of the area where the texture should be rendered
    InExtents - Extents of the area where the texture should be rendered (local to InWorldTransform). If size is zero, then the entire loaded landscape will be exported.
    InWeightmapLayerName - Weightmap layer that is being requested to render
    OutRenderTarget - Render target in which the texture will be rendered. The size/format of the render target will be respected.

Returns:
    false in case of failure (e.g. invalid inputs, incompatible render target format...) */
bool RenderWeightmap(FTransform InWorldTransform, FBox2D InExtents, FName InWeightmapLayerName, UTextureRenderTarget2D OutRenderTarget) {}
/* Function: RenderWeightmaps 
 Render the final weightmaps for the requested layers, in the requested top-down window, as one -atlased- texture in the provided render target (2D or 2DArray)
 Can be called at runtime.

Parameters:
    InWorldTransform - World transform of the area where the texture should be rendered
    InExtents - Extents of the area where the texture should be rendered (local to InWorldTransform). If size is zero, then the entire loaded landscape will be exported.
    InWeightmapLayerNames - List of weightmap layers that are being requested to render
    OutRenderTarget - Render target in which the texture will be rendered. The size/format of the render target will be respected. - If a UTextureRenderTarget2D is passed, the requested layers will be packed in the RGBA channels in order (up to the number of channels available with the render target's format). - If a UTextureRenderTarget2DArray is passed, the requested layers will be packed in the RGBA channels of each slice (up to the number of channels * slices available with the render target's format and number of slices).

Returns:
    false in case of failure (e.g. invalid inputs, incompatible render target format...) */
bool RenderWeightmaps(FTransform InWorldTransform, FBox2D InExtents, TArray<FName> InWeightmapLayerNames, UTextureRenderTarget OutRenderTarget) {}
/* Function: RenderHeightmap 
 Render the final heightmap in the requested top-down window as one -atlased- texture in the provided render target 2D
 Can be called at runtime.

Parameters:
    InWorldTransform - World transform of the area where the texture should be rendered
    InExtents - Extents of the area where the texture should be rendered (local to InWorldTransform). If size is zero, then the entire loaded landscape will be exported.
    OutRenderTarget - Render target in which the texture will be rendered. The size/format of the render target will be respected.

Returns:
    false in case of failure (e.g. invalid inputs, incompatible render target format...) */
bool RenderHeightmap(FTransform InWorldTransform, FBox2D InExtents, UTextureRenderTarget2D OutRenderTarget) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALandscape ALandscape::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALandscape::StaticClass() {}
}
