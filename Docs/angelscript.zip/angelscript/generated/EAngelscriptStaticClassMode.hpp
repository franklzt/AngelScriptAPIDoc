/* Class: EAngelscriptStaticClassMode 
  */ 
 class EAngelscriptStaticClassMode
{
public:
}
/* Enum: EAngelscriptStaticClassMode 
 
    Allowed - Enum
    Deprecated - Enum
    Disallowed - Enum
    EAngelscriptStaticClassMode_MAX - Enum */ 
 enum EAngelscriptStaticClassMode { 
Allowed,
Deprecated,
Disallowed,
EAngelscriptStaticClassMode_MAX, 
}