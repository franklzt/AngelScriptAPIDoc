/* Class: ATargetPoint 
  */ 
 class ATargetPoint : public AActor
{
public:
// Group: Display

/* Variable: ArrowComponent 
  */
UArrowComponent ArrowComponent;
/* Variable: SpriteComponent 
  */
UBillboardComponent SpriteComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ATargetPoint ATargetPoint::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATargetPoint::StaticClass() {}
}
