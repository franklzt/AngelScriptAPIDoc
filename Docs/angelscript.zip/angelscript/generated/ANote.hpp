/* Class: ANote 
  */ 
 class ANote : public AActor
{
public:
// Group: Note

/* Variable: Text 
  */
FString Text;
// Group: Static Functions

/* Function: Spawn 
  */
static ANote ANote::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANote::StaticClass() {}
}
