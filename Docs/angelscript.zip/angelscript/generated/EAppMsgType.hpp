/* Class: EAppMsgType 
  */ 
 class EAppMsgType
{
public:
}
/* Enum: EAppMsgType 
 
    Ok - Enum
    YesNo - Enum
    OkCancel - Enum
    YesNoCancel - Enum
    CancelRetryContinue - Enum
    YesNoYesAllNoAll - Enum
    YesNoYesAllNoAllCancel - Enum
    YesNoYesAll - Enum
    EAppMsgType_MAX - Enum */ 
 enum EAppMsgType { 
Ok,
YesNo,
OkCancel,
YesNoCancel,
CancelRetryContinue,
YesNoYesAllNoAll,
YesNoYesAllNoAllCancel,
YesNoYesAll,
EAppMsgType_MAX, 
}