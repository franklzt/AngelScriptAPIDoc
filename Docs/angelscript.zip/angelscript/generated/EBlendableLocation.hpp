/* Class: EBlendableLocation 
  */ 
 class EBlendableLocation
{
public:
}
/* Enum: EBlendableLocation 
 
    BL_SceneColorBeforeDOF - Enum
    BL_SceneColorAfterDOF - Enum
    BL_TranslucencyAfterDOF - Enum
    BL_SSRInput - Enum
    BL_SceneColorBeforeBloom - Enum
    BL_ReplacingTonemapper - Enum
    BL_SceneColorAfterTonemapping - Enum
    BL_MAX - Enum
    BL_BeforeTranslucency - Enum
    BL_BeforeTonemapping - Enum
    BL_AfterTonemapping - Enum */ 
 enum EBlendableLocation { 
BL_SceneColorBeforeDOF,
BL_SceneColorAfterDOF,
BL_TranslucencyAfterDOF,
BL_SSRInput,
BL_SceneColorBeforeBloom,
BL_ReplacingTonemapper,
BL_SceneColorAfterTonemapping,
BL_MAX,
BL_BeforeTranslucency,
BL_BeforeTonemapping,
BL_AfterTonemapping, 
}