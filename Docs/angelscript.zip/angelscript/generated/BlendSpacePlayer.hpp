/* Class: BlendSpacePlayer 
  */ 
 class BlendSpacePlayer
{
public:
// Group: Blend Space Player

/* Function: GetStartPosition 
 Get the current start position of the blend space player. */
static float32 BlendSpacePlayer::GetStartPosition(FBlendSpacePlayerReference BlendSpacePlayer) {}
/* Function: ConvertToBlendSpacePlayerPure 
 Get a blend space player context from an anim node context (pure). */
static void BlendSpacePlayer::ConvertToBlendSpacePlayerPure(FAnimNodeReference Node, FBlendSpacePlayerReference& BlendSpacePlayer, bool& Result) {}
/* Function: GetBlendSpace 
 Get the current BlendSpace of the blend space player. */
static UBlendSpace BlendSpacePlayer::GetBlendSpace(FBlendSpacePlayerReference BlendSpacePlayer) {}
/* Function: GetLoop 
 Get the current loop of the blend space player. */
static bool BlendSpacePlayer::GetLoop(FBlendSpacePlayerReference BlendSpacePlayer) {}
/* Function: GetPlayRate 
 Get the current play rate of the blend space player. */
static float32 BlendSpacePlayer::GetPlayRate(FBlendSpacePlayerReference BlendSpacePlayer) {}
/* Function: GetPosition 
 Get the current position of the blend space player. */
static FVector BlendSpacePlayer::GetPosition(FBlendSpacePlayerReference BlendSpacePlayer) {}
/* Function: ConvertToBlendSpacePlayer 
 Get a blend space player context from an anim node context. */
static FBlendSpacePlayerReference BlendSpacePlayer::ConvertToBlendSpacePlayer(FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result) {}
/* Function: SetBlendSpace 
 Set the current BlendSpace of the blend space player. */
static FBlendSpacePlayerReference BlendSpacePlayer::SetBlendSpace(FBlendSpacePlayerReference BlendSpacePlayer, UBlendSpace BlendSpace) {}
/* Function: SetLoop 
 Set the loop of the blend space player. */
static FBlendSpacePlayerReference BlendSpacePlayer::SetLoop(FBlendSpacePlayerReference BlendSpacePlayer, bool bLoop) {}
/* Function: SetPlayRate 
 Set the play rate of the blend space player. */
static FBlendSpacePlayerReference BlendSpacePlayer::SetPlayRate(FBlendSpacePlayerReference BlendSpacePlayer, float32 PlayRate) {}
/* Function: SetResetPlayTimeWhenBlendSpaceChanges 
 Set whether the current play time should reset when BlendSpace changes of the blend space player. */
static FBlendSpacePlayerReference BlendSpacePlayer::SetResetPlayTimeWhenBlendSpaceChanges(FBlendSpacePlayerReference BlendSpacePlayer, bool bReset) {}
/* Function: ShouldResetPlayTimeWhenBlendSpaceChanges 
 Get the current value of whether the current play time should reset when BlendSpace changes of the blend space player. */
static bool BlendSpacePlayer::ShouldResetPlayTimeWhenBlendSpaceChanges(FBlendSpacePlayerReference BlendSpacePlayer) {}
/* Function: SnapToPosition 
 Forces the Position to the specified value */
static void BlendSpacePlayer::SnapToPosition(FBlendSpacePlayerReference BlendSpacePlayer, FVector NewPosition) {}
}
