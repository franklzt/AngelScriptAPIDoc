/* Class: EAnimDataModelNotifyType 
  */ 
 class EAnimDataModelNotifyType
{
public:
}
/* Enum: EAnimDataModelNotifyType 
 
    BracketOpened - Enum
    BracketClosed - Enum
    TrackAdded - Enum
    TrackChanged - Enum
    TrackRemoved - Enum
    SequenceLengthChanged - Enum
    FrameRateChanged - Enum
    CurveAdded - Enum
    CurveChanged - Enum
    CurveRemoved - Enum
    CurveFlagsChanged - Enum
    CurveRenamed - Enum
    CurveScaled - Enum
    CurveColorChanged - Enum
    CurveCommentChanged - Enum
    AttributeAdded - Enum
    AttributeRemoved - Enum
    AttributeChanged - Enum
    Populated - Enum
    Reset - Enum
    SkeletonChanged - Enum
    Invalid - Enum
    EAnimDataModelNotifyType_MAX - Enum */ 
 enum EAnimDataModelNotifyType { 
BracketOpened,
BracketClosed,
TrackAdded,
TrackChanged,
TrackRemoved,
SequenceLengthChanged,
FrameRateChanged,
CurveAdded,
CurveChanged,
CurveRemoved,
CurveFlagsChanged,
CurveRenamed,
CurveScaled,
CurveColorChanged,
CurveCommentChanged,
AttributeAdded,
AttributeRemoved,
AttributeChanged,
Populated,
Reset,
SkeletonChanged,
Invalid,
EAnimDataModelNotifyType_MAX, 
}