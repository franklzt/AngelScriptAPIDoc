/* Class: BlendSpace 
  */ 
 class BlendSpace
{
public:
// Group: Blend Space

/* Function: ConvertToBlendSpacePure 
 Get a blend space context from an anim node context (pure). */
static void BlendSpace::ConvertToBlendSpacePure(FAnimNodeReference Node, FBlendSpaceReference& BlendSpace, bool& Result) {}
/* Function: GetFilteredPosition 
 Get the current sample coordinates after going through the filtering. */
static FVector BlendSpace::GetFilteredPosition(FBlendSpaceReference BlendSpace) {}
/* Function: GetPosition 
 Get the current position of the blend space. */
static FVector BlendSpace::GetPosition(FBlendSpaceReference BlendSpace) {}
/* Function: SnapToPosition 
 Forces the Position to the specified value */
static void BlendSpace::SnapToPosition(FBlendSpaceReference BlendSpace, FVector NewPosition) {}
/* Function: ConvertToBlendSpace 
 Get a blend space context from an anim node context. */
static FBlendSpaceReference BlendSpace::ConvertToBlendSpace(FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result) {}
}
