/* Class: AChaosVDSolverInfoActor 
 Actor that contains all relevant data for the current visualized solver frame */ 
 class AChaosVDSolverInfoActor : public AChaosVDDataContainerBaseActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AChaosVDSolverInfoActor AChaosVDSolverInfoActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AChaosVDSolverInfoActor::StaticClass() {}
}
