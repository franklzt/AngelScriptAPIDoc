/* Class: ABrush 
  */ 
 class ABrush : public AActor
{
public:
// Group: Brush

/* Variable: BrushType 
 Type of brush */
EBrushType BrushType;
// Group: BrushBuilder

/* Variable: BrushBuilder 
  */
UBrushBuilder BrushBuilder;
// Group: BrushSettings

/* Variable: ShadedVolumeOpacityValue 
 Value used to set the opacity for the shaded volume, between 0-1 */
float32 ShadedVolumeOpacityValue;
// Group: Collision

/* Variable: BrushComponent 
  */
UBrushComponent BrushComponent;
// Group: Functions

/* Function: SetbDisplayShadedVolume 
 If true, display the brush with a shaded volume */
void SetbDisplayShadedVolume(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ABrush ABrush::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ABrush::StaticClass() {}
}
