/* Class: EAdditiveAnimationType 
  */ 
 class EAdditiveAnimationType
{
public:
}
/* Enum: EAdditiveAnimationType 
 
    AAT_None - Enum
    AAT_LocalSpaceBase - Enum
    AAT_RotationOffsetMeshSpace - Enum
    AAT_MAX - Enum */ 
 enum EAdditiveAnimationType { 
AAT_None,
AAT_LocalSpaceBase,
AAT_RotationOffsetMeshSpace,
AAT_MAX, 
}