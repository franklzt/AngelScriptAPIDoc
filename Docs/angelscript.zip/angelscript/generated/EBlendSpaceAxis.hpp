/* Class: EBlendSpaceAxis 
  */ 
 class EBlendSpaceAxis
{
public:
}
/* Enum: EBlendSpaceAxis 
 
    BSA_None - Enum
    BSA_X - Enum
    BSA_Y - Enum
    BSA_MAX - Enum */ 
 enum EBlendSpaceAxis { 
BSA_None,
BSA_X,
BSA_Y,
BSA_MAX, 
}