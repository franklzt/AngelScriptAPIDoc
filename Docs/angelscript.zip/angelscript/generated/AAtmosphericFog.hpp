/* Class: AAtmosphericFog 
 A placeable fog actor that simulates atmospheric light scattering
@see https://docs.unrealengine.com/latest/INT/Engine/Actors/FogEffects/AtmosphericFog/index.html */ 
 class AAtmosphericFog : public AInfo
{
public:
// Group: Atmosphere

/* Variable: AtmosphericFogComponent 
 Main fog component */
UAtmosphericFogComponent AtmosphericFogComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static AAtmosphericFog AAtmosphericFog::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AAtmosphericFog::StaticClass() {}
}
