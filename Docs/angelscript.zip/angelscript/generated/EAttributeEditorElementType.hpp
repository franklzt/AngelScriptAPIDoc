/* Class: EAttributeEditorElementType 
  */ 
 class EAttributeEditorElementType
{
public:
}
/* Enum: EAttributeEditorElementType 
 
    Vertex - Enum
    VertexInstance - Enum
    Triangle - Enum
    Polygon - Enum
    Edge - Enum
    PolygonGroup - Enum
    EAttributeEditorElementType_MAX - Enum */ 
 enum EAttributeEditorElementType { 
Vertex,
VertexInstance,
Triangle,
Polygon,
Edge,
PolygonGroup,
EAttributeEditorElementType_MAX, 
}