/* Class: Dataflow 
  */ 
 class Dataflow
{
public:
// Group: Dataflow

/* Function: EvaluateTerminalNodeByName 
 Find a specific terminal node by name evaluate it using a specific UObject */
static void Dataflow::EvaluateTerminalNodeByName(UDataflow Dataflow, FName TerminalNodeName, UObject ResultAsset) {}
}
