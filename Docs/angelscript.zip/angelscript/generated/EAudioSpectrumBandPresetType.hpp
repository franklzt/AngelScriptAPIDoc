/* Class: EAudioSpectrumBandPresetType 
  */ 
 class EAudioSpectrumBandPresetType
{
public:
}
/* Enum: EAudioSpectrumBandPresetType 
 
    KickDrum - Enum
    SnareDrum - Enum
    Voice - Enum
    Cymbals - Enum
    EAudioSpectrumBandPresetType_MAX - Enum */ 
 enum EAudioSpectrumBandPresetType { 
KickDrum,
SnareDrum,
Voice,
Cymbals,
EAudioSpectrumBandPresetType_MAX, 
}