/* Class: EAnimCurveType 
  */ 
 class EAnimCurveType
{
public:
}
/* Enum: EAnimCurveType 
 
    AttributeCurve - Enum
    MaterialCurve - Enum
    MorphTargetCurve - Enum
    MaxAnimCurveType - Enum
    EAnimCurveType_MAX - Enum */ 
 enum EAnimCurveType { 
AttributeCurve,
MaterialCurve,
MorphTargetCurve,
MaxAnimCurveType,
EAnimCurveType_MAX, 
}