/* Class: APainCausingVolume 
 Volume that causes damage over time to any Actor that overlaps its collision. */ 
 class APainCausingVolume : public APhysicsVolume
{
public:
// Group: PainCausingVolume

/* Variable: DamageType 
 Type of damage done */
TSubclassOf<UDamageType> DamageType;
/* Variable: PainInterval 
 If pain causing, time between damage applications. */
float32 PainInterval;
/* Variable: bPainCausing 
 Whether volume currently causes damage. */
bool bPainCausing;
/* Variable: bEntryPain 
 if bPainCausing, cause pain when something enters the volume in addition to damage each second */
bool bEntryPain;
/* Variable: DamagePerSec 
 Damage done per second to actors in this volume when bPainCausing=true */
float32 DamagePerSec;
// Group: Functions

/* Function: SetbPainCausing 
 Whether volume currently causes damage. */
void SetbPainCausing(bool Value) {}
/* Function: GetbEntryPain 
 if bPainCausing, cause pain when something enters the volume in addition to damage each second */
bool GetbEntryPain() const {}
/* Function: SetbEntryPain 
 if bPainCausing, cause pain when something enters the volume in addition to damage each second */
void SetbEntryPain(bool Value) {}
/* Function: GetbPainCausing 
 Whether volume currently causes damage. */
bool GetbPainCausing() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static APainCausingVolume APainCausingVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APainCausingVolume::StaticClass() {}
}
