/* Class: EAutoExposureMethod 
  */ 
 class EAutoExposureMethod
{
public:
}
/* Enum: EAutoExposureMethod 
 
    AEM_Histogram - Enum
    AEM_Basic - Enum
    AEM_Manual - Enum
    AEM_MAX - Enum */ 
 enum EAutoExposureMethod { 
AEM_Histogram,
AEM_Basic,
AEM_Manual,
AEM_MAX, 
}