/* Class: AFloatingText 
 Draws 3D text in the world along with targeting line cues */ 
 class AFloatingText : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AFloatingText AFloatingText::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AFloatingText::StaticClass() {}
}
