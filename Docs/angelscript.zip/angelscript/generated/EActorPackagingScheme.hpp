/* Class: EActorPackagingScheme 
  */ 
 class EActorPackagingScheme
{
public:
}
/* Enum: EActorPackagingScheme 
 
    Original - Enum
    Reduced - Enum
    EActorPackagingScheme_MAX - Enum */ 
 enum EActorPackagingScheme { 
Original,
Reduced,
EActorPackagingScheme_MAX, 
}