/* Class: EAlignObjectsAlignToOptions 
  */ 
 class EAlignObjectsAlignToOptions
{
public:
}
/* Enum: EAlignObjectsAlignToOptions 
 
    FirstSelected - Enum
    LastSelected - Enum
    Combined - Enum
    EAlignObjectsAlignToOptions_MAX - Enum */ 
 enum EAlignObjectsAlignToOptions { 
FirstSelected,
LastSelected,
Combined,
EAlignObjectsAlignToOptions_MAX, 
}