/* Class: AGameState 
 GameState is a subclass of GameStateBase that behaves like a multiplayer match-based game.
It is tied to functionality in GameMode. */ 
 class AGameState : public AGameStateBase
{
public:
// Group: GameState

/* Variable: PreviousMatchState 
 Previous map state, used to handle if multiple transitions happen per frame */
FName PreviousMatchState;
/* Variable: ElapsedTime 
 Elapsed game time since match has started. */
int ElapsedTime;
/* Variable: MatchState 
 What match state we are currently in */
FName MatchState;
// Group: Static Functions

/* Function: Spawn 
  */
static AGameState AGameState::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameState::StaticClass() {}
}
