/* Class: AHierarchicalLODVolume 
 An invisible volume used to manually define/create an HLOD cluster. */ 
 class AHierarchicalLODVolume : public AVolume
{
public:
// Group: HLOD Volume

/* Variable: ApplyOnlyToSpecificHLODLevels 
 If set, this volume will only be applied to HLOD levels contained in the array.  If empty, it will apply to ALL HLOD levels */
TArray<int> ApplyOnlyToSpecificHLODLevels;
/* Variable: bIncludeOverlappingActors 
 When set this volume will incorporate actors which bounds overlap with the volume, otherwise only actors which are completely inside of the volume are incorporated */
bool bIncludeOverlappingActors;
// Group: Static Functions

/* Function: Spawn 
  */
static AHierarchicalLODVolume AHierarchicalLODVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AHierarchicalLODVolume::StaticClass() {}
}
