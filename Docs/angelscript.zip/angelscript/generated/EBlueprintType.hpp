/* Class: EBlueprintType 
  */ 
 class EBlueprintType
{
public:
}
/* Enum: EBlueprintType 
 
    BPTYPE_Normal - Enum
    BPTYPE_Const - Enum
    BPTYPE_MacroLibrary - Enum
    BPTYPE_Interface - Enum
    BPTYPE_LevelScript - Enum
    BPTYPE_FunctionLibrary - Enum
    BPTYPE_MAX - Enum */ 
 enum EBlueprintType { 
BPTYPE_Normal,
BPTYPE_Const,
BPTYPE_MacroLibrary,
BPTYPE_Interface,
BPTYPE_LevelScript,
BPTYPE_FunctionLibrary,
BPTYPE_MAX, 
}