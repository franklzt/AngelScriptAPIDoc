/* Class: APlayerStart 
 This class indicates a location where a player can spawn when the game begins.


@see https://docs.unrealengine.com/latest/INT/Engine/Actors/PlayerStart/ */ 
 class APlayerStart : public ANavigationObjectBase
{
public:
// Group: Object

/* Variable: PlayerStartTag 
 Used when searching for which playerstart to use. */
FName PlayerStartTag;
// Group: Static Functions

/* Function: Spawn 
  */
static APlayerStart APlayerStart::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APlayerStart::StaticClass() {}
}
