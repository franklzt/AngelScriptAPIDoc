/* Class: ANavigationGraph 
 currently abstract since it's not full implemented */ 
 class ANavigationGraph : public ANavigationData
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ANavigationGraph ANavigationGraph::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavigationGraph::StaticClass() {}
}
