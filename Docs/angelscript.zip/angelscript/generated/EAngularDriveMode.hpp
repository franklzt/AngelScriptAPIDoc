/* Class: EAngularDriveMode 
  */ 
 class EAngularDriveMode
{
public:
}
/* Enum: EAngularDriveMode 
 
    SLERP - Enum
    TwistAndSwing - Enum
    EAngularDriveMode_MAX - Enum */ 
 enum EAngularDriveMode { 
SLERP,
TwistAndSwing,
EAngularDriveMode_MAX, 
}