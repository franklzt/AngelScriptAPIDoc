/* Class: EBodyCollisionResponse 
  */ 
 class EBodyCollisionResponse
{
public:
}
/* Enum: EBodyCollisionResponse 
 
    BodyCollision_Enabled - Enum
    BodyCollision_Disabled - Enum
    BodyCollision_MAX - Enum */ 
 enum EBodyCollisionResponse { 
BodyCollision_Enabled,
BodyCollision_Disabled,
BodyCollision_MAX, 
}