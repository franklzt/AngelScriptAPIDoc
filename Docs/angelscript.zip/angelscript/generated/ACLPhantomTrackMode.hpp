/* Class: ACLPhantomTrackMode 
  */ 
 class ACLPhantomTrackMode
{
public:
}
/* Enum: ACLPhantomTrackMode 
 
    Ignore - Enum
    Strip - Enum
    Warn - Enum
    ACLPhantomTrackMode_MAX - Enum */ 
 enum ACLPhantomTrackMode { 
Ignore,
Strip,
Warn,
ACLPhantomTrackMode_MAX, 
}