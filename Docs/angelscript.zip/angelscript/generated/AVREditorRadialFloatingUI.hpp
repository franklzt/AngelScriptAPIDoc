/* Class: AVREditorRadialFloatingUI 
 Represents an interactive floating UI panel in the VR Editor */ 
 class AVREditorRadialFloatingUI : public AVREditorBaseActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AVREditorRadialFloatingUI AVREditorRadialFloatingUI::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVREditorRadialFloatingUI::StaticClass() {}
}
