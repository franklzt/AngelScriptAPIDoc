/* Class: EBakeVertexChannel 
  */ 
 class EBakeVertexChannel
{
public:
}
/* Enum: EBakeVertexChannel 
 
    R - Enum
    G - Enum
    B - Enum
    A - Enum
    RGBA - Enum
    EBakeVertexChannel_MAX - Enum */ 
 enum EBakeVertexChannel { 
R,
G,
B,
A,
RGBA,
EBakeVertexChannel_MAX, 
}