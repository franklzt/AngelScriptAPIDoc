/* Class: AGeometryCollectionDebugDrawActor 
  */ 
 class AGeometryCollectionDebugDrawActor : public AActor
{
public:
// Group: Debug Draw

/* Variable: bDebugDrawHierarchy 
 Show debug visualization for the top level node rather than the bottom leaf nodes of a cluster's hierarchy. * Only affects Clustering and Geometry visualization. */
bool bDebugDrawHierarchy;
/* Variable: bDebugDrawClustering 
 Show debug visualization for all clustered children associated to the current rigid body id selection. */
bool bDebugDrawClustering;
/* Variable: HideGeometry 
 Geometry visibility setting. Select the part of the geometry to hide in order to better visualize the debug information. */
EGeometryCollectionDebugDrawActorHideGeometry HideGeometry;
/* Variable: bDebugDrawWholeCollection 
 Show debug visualization for the rest of the geometry collection related to the current rigid body id selection. */
bool bDebugDrawWholeCollection;
// Group: Debug Draw|Clustering

/* Variable: bShowParent 
 Show a link from the selected rigid body's associated cluster nodes to their parent's nodes. */
bool bShowParent;
/* Variable: bShowConnectivityEdges 
 Show the connectivity edges for the selected rigid body's associated cluster nodes. */
bool bShowConnectivityEdges;
/* Variable: bShowLevel 
 Show the hierarchical level for the selected rigid body's associated cluster nodes. */
bool bShowLevel;
/* Variable: bShowTransform 
 Show the transform for the selected rigid body's associated cluster nodes. */
bool bShowTransform;
/* Variable: bShowTransformIndex 
 Show the transform index for the selected rigid body's associated cluster nodes. */
bool bShowTransformIndex;
// Group: Debug Draw|Geometry

/* Variable: bShowGeometryIndex 
 Show the geometry index for the selected rigid body's associated geometries. */
bool bShowGeometryIndex;
/* Variable: bShowBoundingBox 
 Show the bounding box for the selected rigid body's associated geometries. */
bool bShowBoundingBox;
/* Variable: bShowFaces 
 Show the faces for the selected rigid body's associated geometries. */
bool bShowFaces;
/* Variable: bShowVertexNormals 
 Show the vertex normals for the selected rigid body's associated geometries. */
bool bShowVertexNormals;
/* Variable: bShowFaceIndices 
 Show the face indices for the selected rigid body's associated geometries. */
bool bShowFaceIndices;
/* Variable: bShowVertices 
 Show the vertices for the selected rigid body's associated geometries. */
bool bShowVertices;
/* Variable: bShowFaceNormals 
 Show the face normals for the selected rigid body's associated geometries. */
bool bShowFaceNormals;
/* Variable: SingleFaceIndex 
 The index of the single face to visualize. */
int SingleFaceIndex;
/* Variable: bShowGeometryTransform 
 Show the geometry transform for the selected rigid body's associated geometries. */
bool bShowGeometryTransform;
/* Variable: bShowVertexIndices 
 Show the vertex indices for the selected rigid body's associated geometries. */
bool bShowVertexIndices;
/* Variable: bShowSingleFace 
 Enable single face visualization for the selected rigid body's associated geometries. */
bool bShowSingleFace;
// Group: Debug Draw|Rigid Body

/* Variable: bShowRigidBodyVelocity 
 Show the selected rigid body's linear and angular velocity. */
bool bShowRigidBodyVelocity;
/* Variable: bCollisionAtOrigin 
 Show the selected rigid body's collision volume at the origin, in local space. */
bool bCollisionAtOrigin;
/* Variable: bShowRigidBodyCollision 
 Show the selected rigid body's collision volume. */
bool bShowRigidBodyCollision;
/* Variable: bShowRigidBodyId 
 Display the selected rigid body's id. */
bool bShowRigidBodyId;
/* Variable: bShowRigidBodyTransform 
 Show the selected rigid body's transform. */
bool bShowRigidBodyTransform;
/* Variable: bShowRigidBodyInertia 
 Show the selected rigid body's inertia tensor box. */
bool bShowRigidBodyInertia;
/* Variable: bShowRigidBodyForce 
 Show the selected rigid body's applied force and torque. */
bool bShowRigidBodyForce;
/* Variable: bShowRigidBodyInfos 
 Show the selected rigid body's on screen text information. */
bool bShowRigidBodyInfos;
// Group: Debug Draw|Settings

/* Variable: bUseActiveVisualization 
 Adapt visualization depending of the cluster nodes' hierarchical level. */
bool bUseActiveVisualization;
/* Variable: PointThickness 
 Thickness of points when visualizing vertices. */
float32 PointThickness;
/* Variable: LineThickness 
 Thickness of lines when visualizing faces, normals, ...etc. */
float32 LineThickness;
/* Variable: bTextShadow 
 Draw shadows under the displayed text. */
bool bTextShadow;
/* Variable: TextScale 
 Scale of the font used to display text. */
float32 TextScale;
/* Variable: NormalScale 
 Scale factor used for visualizing normals. */
float32 NormalScale;
/* Variable: AxisScale 
 Scale of the axis used for visualizing all transforms. */
float32 AxisScale;
/* Variable: ArrowScale 
 Size of arrows used for visualizing normals, breaking information, ...etc. */
float32 ArrowScale;
/* Variable: RigidBodyIdColor 
 Color used for the visualization of the rigid body ids. */
FColor RigidBodyIdColor;
/* Variable: RigidBodyTransformScale 
 Scale for rigid body transform visualization. */
float32 RigidBodyTransformScale;
/* Variable: RigidBodyCollisionColor 
 Color used for collision primitives visualization. */
FColor RigidBodyCollisionColor;
/* Variable: RigidBodyInertiaColor 
 Color used for the visualization of the rigid body inertia tensor box. */
FColor RigidBodyInertiaColor;
/* Variable: RigidBodyVelocityColor 
 Color used for rigid body velocities visualization. */
FColor RigidBodyVelocityColor;
/* Variable: RigidBodyForceColor 
 Color used for rigid body applied force and torque visualization. */
FColor RigidBodyForceColor;
/* Variable: RigidBodyInfoColor 
 Color used for the visualization of the rigid body infos. */
FColor RigidBodyInfoColor;
/* Variable: TransformIndexColor 
 Color used for the visualization of the transform indices. */
FColor TransformIndexColor;
/* Variable: TransformScale 
 Scale for cluster transform visualization. */
float32 TransformScale;
/* Variable: LevelColor 
 Color used for the visualization of the levels. */
FColor LevelColor;
/* Variable: ParentColor 
 Color used for the visualization of the link from the parents. */
FColor ParentColor;
/* Variable: ConnectivityEdgeThickness 
 Line thickness used for the visualization of the rigid clustering connectivity edges. */
float32 ConnectivityEdgeThickness;
/* Variable: GeometryIndexColor 
 Color used for the visualization of the geometry indices. */
FColor GeometryIndexColor;
/* Variable: GeometryTransformScale 
 Scale for geometry transform visualization. */
float32 GeometryTransformScale;
/* Variable: BoundingBoxColor 
 Color used for the visualization of the bounding boxes. */
FColor BoundingBoxColor;
/* Variable: FaceColor 
 Color used for the visualization of the faces. */
FColor FaceColor;
/* Variable: FaceIndexColor 
 Color used for the visualization of the face indices. */
FColor FaceIndexColor;
/* Variable: FaceNormalColor 
 Color used for the visualization of the face normals. */
FColor FaceNormalColor;
/* Variable: SingleFaceColor 
 Color used for the visualization of the single face. */
FColor SingleFaceColor;
/* Variable: VertexColor 
 Color used for the visualization of the vertices. */
FColor VertexColor;
/* Variable: VertexIndexColor 
 Color used for the visualization of the vertex indices. */
FColor VertexIndexColor;
/* Variable: VertexNormalColor 
 Color used for the visualization of the vertex normals. */
FColor VertexNormalColor;
// Group: Static Functions

/* Function: Spawn 
  */
static AGeometryCollectionDebugDrawActor AGeometryCollectionDebugDrawActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGeometryCollectionDebugDrawActor::StaticClass() {}
}
