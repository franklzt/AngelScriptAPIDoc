/* Class: EBackgroundType 
  */ 
 class EBackgroundType
{
public:
}
/* Enum: EBackgroundType 
 
    SolidColor - Enum
    Checkered - Enum
    EBackgroundType_MAX - Enum */ 
 enum EBackgroundType { 
SolidColor,
Checkered,
EBackgroundType_MAX, 
}