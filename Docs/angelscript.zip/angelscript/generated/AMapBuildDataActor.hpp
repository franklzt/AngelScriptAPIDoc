/* Class: AMapBuildDataActor 
  */ 
 class AMapBuildDataActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AMapBuildDataActor AMapBuildDataActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AMapBuildDataActor::StaticClass() {}
}
