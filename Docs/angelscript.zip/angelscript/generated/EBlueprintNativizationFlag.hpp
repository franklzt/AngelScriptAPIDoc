/* Class: EBlueprintNativizationFlag 
  */ 
 class EBlueprintNativizationFlag
{
public:
}
/* Enum: EBlueprintNativizationFlag 
 
    Disabled - Enum
    Dependency - Enum
    ExplicitlyEnabled - Enum
    EBlueprintNativizationFlag_MAX - Enum */ 
 enum EBlueprintNativizationFlag { 
Disabled,
Dependency,
ExplicitlyEnabled,
EBlueprintNativizationFlag_MAX, 
}