/* Class: EAnimFunctionCallSite 
  */ 
 class EAnimFunctionCallSite
{
public:
}
/* Enum: EAnimFunctionCallSite 
 
    OnInitialize - Enum
    OnUpdate - Enum
    OnBecomeRelevant - Enum
    OnEvaluate - Enum
    OnInitializePostRecursion - Enum
    OnUpdatePostRecursion - Enum
    OnBecomeRelevantPostRecursion - Enum
    OnEvaluatePostRecursion - Enum
    OnStartedBlendingOut - Enum
    OnStartedBlendingIn - Enum
    OnFinishedBlendingOut - Enum
    OnFinishedBlendingIn - Enum
    EAnimFunctionCallSite_MAX - Enum */ 
 enum EAnimFunctionCallSite { 
OnInitialize,
OnUpdate,
OnBecomeRelevant,
OnEvaluate,
OnInitializePostRecursion,
OnUpdatePostRecursion,
OnBecomeRelevantPostRecursion,
OnEvaluatePostRecursion,
OnStartedBlendingOut,
OnStartedBlendingIn,
OnFinishedBlendingOut,
OnFinishedBlendingIn,
EAnimFunctionCallSite_MAX, 
}