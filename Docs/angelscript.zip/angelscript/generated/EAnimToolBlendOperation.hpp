/* Class: EAnimToolBlendOperation 
  */ 
 class EAnimToolBlendOperation
{
public:
}
/* Enum: EAnimToolBlendOperation 
 
    Tween - Enum
    BlendToNeighbor - Enum
    PushPull - Enum
    BlendRelative - Enum
    BlendToEase - Enum
    SmoothRough - Enum
    EAnimToolBlendOperation_MAX - Enum */ 
 enum EAnimToolBlendOperation { 
Tween,
BlendToNeighbor,
PushPull,
BlendRelative,
BlendToEase,
SmoothRough,
EAnimToolBlendOperation_MAX, 
}