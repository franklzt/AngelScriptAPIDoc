/* Class: AVREditorDockableCameraWindow 
 A specialized dockable window for camera viewfinders in VR that applies the correct material */ 
 class AVREditorDockableCameraWindow : public AVREditorDockableWindow
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AVREditorDockableCameraWindow AVREditorDockableCameraWindow::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVREditorDockableCameraWindow::StaticClass() {}
}
