/* Class: AnimPhysLinearConstraintType 
  */ 
 class AnimPhysLinearConstraintType
{
public:
}
/* Enum: AnimPhysLinearConstraintType 
 
    Free - Enum
    Limited - Enum
    AnimPhysLinearConstraintType_MAX - Enum */ 
 enum AnimPhysLinearConstraintType { 
Free,
Limited,
AnimPhysLinearConstraintType_MAX, 
}