/* Class: AndroidFileServerBP 
  */ 
 class AndroidFileServerBP
{
public:
// Group: AndroidFileServer

/* Function: StartFileServer 
 Request startup of Android FileServer */
static bool AndroidFileServerBP::StartFileServer(bool bUSB = true, bool bNetwork = false, int Port = 57099) {}
/* Function: StopFileServer 
 Request termination of Android FileServer */
static bool AndroidFileServerBP::StopFileServer(bool bUSB = true, bool bNetwork = true) {}
/* Function: IsFileServerRunning 
 Check if Android FileServer is running */
static EAFSActiveType AndroidFileServerBP::IsFileServerRunning() {}
}
