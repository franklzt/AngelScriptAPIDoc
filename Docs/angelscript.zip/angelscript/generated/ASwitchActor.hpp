/* Class: ASwitchActor 
 Switch Actor allows quickly toggling the visibility of its child actors so that
only one is visible at a time. It can also be captured with the Variant Manager
to expose this capability as a property capture */ 
 class ASwitchActor : public AActor
{
public:
// Group: SwitchActor

/* Variable: Options 
 Returns the child actors that are available options, in a fixed order that may differ from the one displayed in the world outliner */
const TArray<AActor> Options;
/* Variable: SelectedOption 
 If we have exactly one child actor visible, it will return a pointer to it. Returns nullptr otherwise */
const int SelectedOption;
/* Variable: SceneComponent 
 Exposing our root component like this allows manual Mobility control on the details panel */
USceneComponent SceneComponent;
// Group: SwitchActor

/* Function: GetSelectedOption 
 If we have exactly one child actor visible, it will return a pointer to it. Returns nullptr otherwise */
int GetSelectedOption() const {}
/* Function: SelectOption 
 Select one of the available options by index */
void SelectOption(int OptionIndex) {}
/* Function: GetOptions 
 Returns the child actors that are available options, in a fixed order that may differ from the one displayed in the world outliner */
TArray<AActor> GetOptions() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ASwitchActor ASwitchActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASwitchActor::StaticClass() {}
}
