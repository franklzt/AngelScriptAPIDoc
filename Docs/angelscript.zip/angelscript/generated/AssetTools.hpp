/* Class: AssetTools 
  */ 
 class AssetTools
{
public:
// Group: Static Functions

/* Function: FixupReferencers 
 Fix up references to the specified redirectors.

Parameters:
    bCheckoutDialogPrompt - indicates whether to prompt the user with files checkout dialog or silently attempt to checkout all necessary files. */
static void AssetTools::FixupReferencers(TArray<UObject> Objects, bool bCheckoutDialogPrompt, ERedirectFixupMode FixupMode) {}
/* Function: ImportAssetTasks 
 Imports assets using tasks specified.

Parameters:
    ImportTasks - Tasks that specify how to import each file */
static void AssetTools::ImportAssetTasks(TArray<UAssetImportTask> ImportTasks) {}
/* Function: CreateAsset 
 Creates an asset with the specified name, path, and optional factory

Parameters:
    AssetName - the name of the new asset
    PackagePath - the package that will contain the new asset
    AssetClass - the class of the new asset
    Factory - optional factory that will build the new asset
    CallingContext - optional name of the module or method calling CreateAsset() - this is passed to the factory

Returns:
    the new asset or nullptr if it fails */
static UObject AssetTools::CreateAsset(FString AssetName, FString PackagePath, UClass AssetClass, UFactory Factory = nullptr, FName CallingContext = NAME_None) {}
}
