/* Class: EBlueprintCompileMode 
  */ 
 class EBlueprintCompileMode
{
public:
}
/* Enum: EBlueprintCompileMode 
 
    Default - Enum
    Development - Enum
    FinalRelease - Enum
    EBlueprintCompileMode_MAX - Enum */ 
 enum EBlueprintCompileMode { 
Default,
Development,
FinalRelease,
EBlueprintCompileMode_MAX, 
}