/* Class: BT 
  */ 
 class BT
{
public:
// Group: AI|BehaviorTree

/* Function: GetOwnerComponent 
  */
static UBehaviorTreeComponent BT::GetOwnerComponent(UBTNode NodeOwner) {}
/* Function: ClearBlackboardValueAsVector 
 (DEPRECATED) Use ClearBlackboardValue instead */
static void BT::ClearBlackboardValueAsVector(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsActor 
  */
static AActor BT::GetBlackboardValueAsActor(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsBool 
  */
static bool BT::GetBlackboardValueAsBool(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsClass 
  */
static UClass BT::GetBlackboardValueAsClass(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsEnum 
  */
static uint8 BT::GetBlackboardValueAsEnum(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsFloat 
  */
static float32 BT::GetBlackboardValueAsFloat(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsInt 
  */
static int BT::GetBlackboardValueAsInt(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsName 
  */
static FName BT::GetBlackboardValueAsName(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsObject 
  */
static UObject BT::GetBlackboardValueAsObject(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsRotator 
  */
static FRotator BT::GetBlackboardValueAsRotator(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsString 
  */
static FString BT::GetBlackboardValueAsString(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetBlackboardValueAsVector 
  */
static FVector BT::GetBlackboardValueAsVector(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: ClearBlackboardValue 
 Resets indicated value to "not set" value, based on values type */
static void BT::ClearBlackboardValue(UBTNode NodeOwner, FBlackboardKeySelector Key) {}
/* Function: GetOwnersBlackboard 
  */
static UBlackboardComponent BT::GetOwnersBlackboard(UBTNode NodeOwner) {}
/* Function: SetBlackboardValueAsBool 
  */
static void BT::SetBlackboardValueAsBool(UBTNode NodeOwner, FBlackboardKeySelector Key, bool Value) {}
/* Function: SetBlackboardValueAsClass 
  */
static void BT::SetBlackboardValueAsClass(UBTNode NodeOwner, FBlackboardKeySelector Key, UClass Value) {}
/* Function: SetBlackboardValueAsEnum 
  */
static void BT::SetBlackboardValueAsEnum(UBTNode NodeOwner, FBlackboardKeySelector Key, uint8 Value) {}
/* Function: SetBlackboardValueAsFloat 
  */
static void BT::SetBlackboardValueAsFloat(UBTNode NodeOwner, FBlackboardKeySelector Key, float32 Value) {}
/* Function: SetBlackboardValueAsInt 
  */
static void BT::SetBlackboardValueAsInt(UBTNode NodeOwner, FBlackboardKeySelector Key, int Value) {}
/* Function: SetBlackboardValueAsName 
  */
static void BT::SetBlackboardValueAsName(UBTNode NodeOwner, FBlackboardKeySelector Key, FName Value) {}
/* Function: SetBlackboardValueAsObject 
  */
static void BT::SetBlackboardValueAsObject(UBTNode NodeOwner, FBlackboardKeySelector Key, UObject Value) {}
/* Function: SetBlackboardValueAsRotator 
  */
static void BT::SetBlackboardValueAsRotator(UBTNode NodeOwner, FBlackboardKeySelector Key, FRotator Value) {}
/* Function: SetBlackboardValueAsString 
  */
static void BT::SetBlackboardValueAsString(UBTNode NodeOwner, FBlackboardKeySelector Key, FString Value) {}
/* Function: SetBlackboardValueAsVector 
  */
static void BT::SetBlackboardValueAsVector(UBTNode NodeOwner, FBlackboardKeySelector Key, FVector Value) {}
/* Function: StartUsingExternalEvent 
 Initialize variables marked as "instance memory" and set owning actor for blackboard operations */
static void BT::StartUsingExternalEvent(UBTNode NodeOwner, AActor OwningActor) {}
/* Function: StopUsingExternalEvent 
 Save variables marked as "instance memory" and clear owning actor */
static void BT::StopUsingExternalEvent(UBTNode NodeOwner) {}
}
