/* Class: AFunctionalUIScreenshotTest 
  */ 
 class AFunctionalUIScreenshotTest : public AScreenshotFunctionalTestBase
{
public:
// Group: UI

/* Variable: WidgetLocation 
  */
EWidgetTestAppearLocation WidgetLocation;
/* Variable: bHideDebugCanvas 
  */
bool bHideDebugCanvas;
/* Variable: WidgetClass 
  */
TSubclassOf<UUserWidget> WidgetClass;
// Group: Static Functions

/* Function: Spawn 
  */
static AFunctionalUIScreenshotTest AFunctionalUIScreenshotTest::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AFunctionalUIScreenshotTest::StaticClass() {}
}
