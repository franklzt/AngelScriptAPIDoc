/* Class: AudioMixer 
  */ 
 class AudioMixer
{
public:
// Group: Audio

/* Function: GetCurrentAudioOutputDeviceName 
 Gets information about the currently used audio output device

Parameters:
    OnObtainCurrentDeviceEvent - the event to fire when the audio endpoint devices have been retrieved */
static void AudioMixer::GetCurrentAudioOutputDeviceName(FOnMainAudioOutputDeviceObtained OnObtainCurrentDeviceEvent = FOnMainAudioOutputDeviceObtained ( )) {}
/* Function: SwapAudioOutputDevice 
 Hotswaps to the requested audio output device

Parameters:
    NewDeviceId - the device Id to swap to
    OnCompletedDeviceSwap - the event to fire when the audio endpoint devices have been retrieved */
static void AudioMixer::SwapAudioOutputDevice(FString NewDeviceId, FOnCompletedDeviceSwap OnCompletedDeviceSwap = FOnCompletedDeviceSwap ( )) {}
/* Function: GetAvailableAudioOutputDevices 
 Gets information about all audio output devices available in the system

Parameters:
    OnObtainDevicesEvent - the event to fire when the audio endpoint devices have been retrieved */
static void AudioMixer::GetAvailableAudioOutputDevices(FOnAudioOutputDevicesObtained OnObtainDevicesEvent = FOnAudioOutputDevicesObtained ( )) {}
/* Function: Conv_AudioOutputDeviceInfoToString 
 Returns the device info in a human readable format

Parameters:
    Info - The audio device data to print

Returns:
    The data in a string format */
static FString AudioMixer::Conv_AudioOutputDeviceInfoToString(FAudioOutputDeviceInfo Info) {}
// Group: Audio|Analysis

/* Function: StartAnalyzingOutput 
 Start spectrum analysis of the audio output. By leaving the Submix To Analyze blank, you can analyze the master output of the game. */
static void AudioMixer::StartAnalyzingOutput(USoundSubmix SubmixToAnalyze = nullptr, EFFTSize FFTSize = EFFTSize :: DefaultSize, EFFTPeakInterpolationMethod InterpolationMethod = EFFTPeakInterpolationMethod :: Linear, EFFTWindowType WindowType = EFFTWindowType :: Hann, float32 HopSize = 0.000000, EAudioSpectrumType SpectrumType = EAudioSpectrumType :: MagnitudeSpectrum) {}
/* Function: StopAnalyzingOutput 
 Stop spectrum analysis. */
static void AudioMixer::StopAnalyzingOutput(USoundSubmix SubmixToStopAnalyzing = nullptr) {}
/* Function: MakeFullSpectrumSpectralAnalysisBandSettings 
 Make an array of logarithmically spaced bands.

Parameters:
    InNumBands - The number of bands to used to represent the spectrum.
    InMinimumFrequency - The center frequency of the first band.
    InMaximumFrequency - The center frequency of the last band.
    InAttackTimeMsec - The attack time (in milliseconds) to apply to each band's envelope tracker.
    InReleaseTimeMsec - The release time (in milliseconds) to apply to each band's envelope tracker. */
static TArray<FSoundSubmixSpectralAnalysisBandSettings> AudioMixer::MakeFullSpectrumSpectralAnalysisBandSettings(int InNumBands = 30, float32 InMinimumFrequency = 40.000000, float32 InMaximumFrequency = 16000.000000, int InAttackTimeMsec = 10, int InReleaseTimeMsec = 10) {}
/* Function: MakePresetSpectralAnalysisBandSettings 
 Make an array of bands which span the frequency range of a given EAudioSpectrumBandPresetType.

Parameters:
    InBandPresetType - The type audio content which the bands encompass.
    InNumBands - The number of bands used to represent the spectrum.
    InAttackTimeMsec - The attack time (in milliseconds) to apply to each band's envelope tracker.
    InReleaseTimeMsec - The release time (in milliseconds) to apply to each band's envelope tracker. */
static TArray<FSoundSubmixSpectralAnalysisBandSettings> AudioMixer::MakePresetSpectralAnalysisBandSettings(EAudioSpectrumBandPresetType InBandPresetType, int InNumBands = 10, int InAttackTimeMsec = 10, int InReleaseTimeMsec = 10) {}
/* Function: GetMagnitudeForFrequencies 
 Retrieve the magnitudes for the given frequencies. */
static void AudioMixer::GetMagnitudeForFrequencies(TArray<float32> Frequencies, TArray<float32>& Magnitudes, USoundSubmix SubmixToAnalyze = nullptr) {}
/* Function: GetPhaseForFrequencies 
 Retrieve the phases for the given frequencies. */
static void AudioMixer::GetPhaseForFrequencies(TArray<float32> Frequencies, TArray<float32>& Phases, USoundSubmix SubmixToAnalyze = nullptr) {}
/* Function: MakeMusicalSpectralAnalysisBandSettings 
 Make an array of musically spaced bands with ascending frequency.

Parameters:
    InNumSemitones - The number of semitones to represent.
    InStartingOctave - The octave of the first note in the array.
    InAttackTimeMsec - The attack time (in milliseconds) to apply to each band's envelope tracker.
    InReleaseTimeMsec - The release time (in milliseconds) to apply to each band's envelope tracker. */
static TArray<FSoundSubmixSpectralAnalysisBandSettings> AudioMixer::MakeMusicalSpectralAnalysisBandSettings(int InNumSemitones = 60, EMusicalNoteName InStartingMusicalNote = EMusicalNoteName :: C, int InStartingOctave = 2, int InAttackTimeMsec = 10, int InReleaseTimeMsec = 10) {}
// Group: Audio|Bus

/* Function: IsAudioBusActive 
 Queries if the given audio bus is active (and audio can be mixed to it). */
static bool AudioMixer::IsAudioBusActive(UAudioBus AudioBus) {}
/* Function: RegisterAudioBusToSubmix 
 Registers an audio bus to a submix so the submix output can be routed to the audiobus. */
static void AudioMixer::RegisterAudioBusToSubmix(USoundSubmix SoundSubmix, UAudioBus AudioBus) {}
/* Function: StartAudioBus 
 Starts the given audio bus. */
static void AudioMixer::StartAudioBus(UAudioBus AudioBus) {}
/* Function: StopAudioBus 
 Stops the given audio bus. */
static void AudioMixer::StopAudioBus(UAudioBus AudioBus) {}
/* Function: UnregisterAudioBusFromSubmix 
 Unregisters an audio bus that could have been registered to a submix. */
static void AudioMixer::UnregisterAudioBusFromSubmix(USoundSubmix SoundSubmix, UAudioBus AudioBus) {}
// Group: Audio|Cache

/* Function: PrimeSoundCueForPlayback 
 Begin loading any sounds referenced by a sound cue into the cache so that it can be played immediately. */
static void AudioMixer::PrimeSoundCueForPlayback(USoundCue SoundCue) {}
/* Function: PrimeSoundForPlayback 
 Begin loading a sound into the cache so that it can be played immediately. */
static void AudioMixer::PrimeSoundForPlayback(USoundWave SoundWave, const FOnSoundLoadComplete OnLoadCompletion = FOnSoundLoadComplete ( )) {}
/* Function: TrimAudioCache 
 Trim memory used by the audio cache. Returns the number of megabytes freed. */
static float32 AudioMixer::TrimAudioCache(float32 InMegabytesToFree) {}
// Group: Audio|Effects

/* Function: AddMasterSubmixEffect 
 Adds a submix effect preset to the master submix. */
static void AudioMixer::AddMasterSubmixEffect(USoundEffectSubmixPreset SubmixEffectPreset) {}
/* Function: RemoveSourceEffectFromPresetChain 
 Removes source effect entry from preset chain. Only affects the instance of preset chain. */
static void AudioMixer::RemoveSourceEffectFromPresetChain(USoundEffectSourcePresetChain PresetChain, int EntryIndex) {}
/* Function: ClearSubmixEffects 
 Clears all submix effects on the given submix. */
static void AudioMixer::ClearSubmixEffects(USoundSubmix SoundSubmix) {}
/* Function: RemoveSubmixEffect 
 Removes all instances of a submix effect preset from the given submix. */
static void AudioMixer::RemoveSubmixEffect(USoundSubmix SoundSubmix, USoundEffectSubmixPreset SubmixEffectPreset) {}
/* Function: RemoveSubmixEffectAtIndex 
 Removes the submix effect at the given submix chain index, if there is a submix effect at that index. */
static void AudioMixer::RemoveSubmixEffectAtIndex(USoundSubmix SoundSubmix, int SubmixChainIndex) {}
/* Function: RemoveSubmixEffectPreset 
  */
static void AudioMixer::RemoveSubmixEffectPreset(USoundSubmix SoundSubmix, USoundEffectSubmixPreset SubmixEffectPreset) {}
/* Function: RemoveSubmixEffectPresetAtIndex 
  */
static void AudioMixer::RemoveSubmixEffectPresetAtIndex(USoundSubmix SoundSubmix, int SubmixChainIndex) {}
/* Function: GetNumberOfEntriesInSourceEffectChain 
 Returns the number of effect chain entries in the given source effect chain. */
static int AudioMixer::GetNumberOfEntriesInSourceEffectChain(USoundEffectSourcePresetChain PresetChain) {}
/* Function: ReplaceSubmixEffect 
 Replaces the submix effect at the given submix chain index, adds the effect if there is none at that index. */
static void AudioMixer::ReplaceSubmixEffect(USoundSubmix InSoundSubmix, int SubmixChainIndex, USoundEffectSubmixPreset SubmixEffectPreset) {}
/* Function: ReplaceSoundEffectSubmix 
  */
static void AudioMixer::ReplaceSoundEffectSubmix(USoundSubmix InSoundSubmix, int SubmixChainIndex, USoundEffectSubmixPreset SubmixEffectPreset) {}
/* Function: SetBypassSourceEffectChainEntry 
 Set whether or not to bypass the effect at the source effect chain index. */
static void AudioMixer::SetBypassSourceEffectChainEntry(USoundEffectSourcePresetChain PresetChain, int EntryIndex, bool bBypassed) {}
/* Function: SetSubmixEffectChainOverride 
 Sets a submix effect chain override on the given submix. The effect chain will cross fade from the base effect chain or current override to the new override. */
static void AudioMixer::SetSubmixEffectChainOverride(USoundSubmix SoundSubmix, TArray<USoundEffectSubmixPreset> SubmixEffectPresetChain, float32 FadeTimeSec) {}
/* Function: ClearSubmixEffectChainOverride 
 Clears all submix effect overrides on the given submix and returns it to the default effect chain. */
static void AudioMixer::ClearSubmixEffectChainOverride(USoundSubmix SoundSubmix, float32 FadeTimeSec) {}
/* Function: ClearMasterSubmixEffects 
 Clears all master submix effects. */
static void AudioMixer::ClearMasterSubmixEffects() {}
/* Function: AddSubmixEffect 
 Adds a submix effect preset to the given submix at the end of its submix effect chain. Returns the number of submix effects. */
static int AudioMixer::AddSubmixEffect(USoundSubmix SoundSubmix, USoundEffectSubmixPreset SubmixEffectPreset) {}
/* Function: AddSourceEffectToPresetChain 
 Adds source effect entry to preset chain. Only effects the instance of the preset chain */
static void AudioMixer::AddSourceEffectToPresetChain(USoundEffectSourcePresetChain PresetChain, FSourceEffectChainEntry Entry) {}
/* Function: RemoveMasterSubmixEffect 
 Removes a submix effect preset from the master submix. */
static void AudioMixer::RemoveMasterSubmixEffect(USoundEffectSubmixPreset SubmixEffectPreset) {}
// Group: Audio|Recording

/* Function: StartRecordingOutput 
 Start recording audio. By leaving the Submix To Record field blank, you can record the master output of the game. */
static void AudioMixer::StartRecordingOutput(float32 ExpectedDuration, USoundSubmix SubmixToRecord = nullptr) {}
/* Function: ResumeRecordingOutput 
 Resume recording audio after pausing. By leaving the Submix To Pause field blank, you can record the master output of the game. */
static void AudioMixer::ResumeRecordingOutput(USoundSubmix SubmixToPause = nullptr) {}
/* Function: PauseRecordingOutput 
 Pause recording audio, without finalizing the recording to disk. By leaving the Submix To Record field blank, you can record the master output of the game. */
static void AudioMixer::PauseRecordingOutput(USoundSubmix SubmixToPause = nullptr) {}
/* Function: StopRecordingOutput 
 Stop recording audio. Path can be absolute, or relative (to the /Saved/BouncedWavFiles folder). By leaving the Submix To Record field blank, you can record the master output of the game. */
static USoundWave AudioMixer::StopRecordingOutput(EAudioRecordingExportType ExportType, FString Name, FString Path, USoundSubmix SubmixToRecord = nullptr, USoundWave ExistingSoundWaveToOverwrite = nullptr) {}
}
