/* Class: EAnimNodeDataFlags 
  */ 
 class EAnimNodeDataFlags
{
public:
}
/* Enum: EAnimNodeDataFlags 
 
    None - Enum
    HasInitialUpdateFunction - Enum
    HasBecomeRelevantFunction - Enum
    HasUpdateFunction - Enum
    AllFunctions - Enum
    EAnimNodeDataFlags_MAX - Enum */ 
 enum EAnimNodeDataFlags { 
None,
HasInitialUpdateFunction,
HasBecomeRelevantFunction,
HasUpdateFunction,
AllFunctions,
EAnimNodeDataFlags_MAX, 
}