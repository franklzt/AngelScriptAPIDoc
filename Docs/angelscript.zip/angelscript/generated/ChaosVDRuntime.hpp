/* Class: ChaosVDRuntime 
  */ 
 class ChaosVDRuntime
{
public:
// Group: Chaos Visual Debugger

/* Function: RecordDebugDrawLine 
  */
static void ChaosVDRuntime::RecordDebugDrawLine(FVector InStartLocation, FVector InEndLocation, FName Tag = NAME_None, FLinearColor Color = FLinearColor ( 0.000000 , 0.000000 , 1.000000 , 1.000000 )) {}
/* Function: RecordDebugDrawSphere 
  */
static void ChaosVDRuntime::RecordDebugDrawSphere(FVector InCenter, float32 Radius, FName Tag = NAME_None, FLinearColor Color = FLinearColor ( 0.000000 , 0.000000 , 1.000000 , 1.000000 )) {}
/* Function: RecordDebugDrawVector 
  */
static void ChaosVDRuntime::RecordDebugDrawVector(FVector InStartLocation, FVector InVector, FName Tag = NAME_None, FLinearColor Color = FLinearColor ( 0.000000 , 0.000000 , 1.000000 , 1.000000 )) {}
/* Function: RecordDebugDrawBox 
  */
static void ChaosVDRuntime::RecordDebugDrawBox(FBox InBox, FName Tag = NAME_None, FLinearColor Color = FLinearColor ( 0.000000 , 0.000000 , 1.000000 , 1.000000 )) {}
}
