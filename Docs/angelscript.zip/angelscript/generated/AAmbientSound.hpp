/* Class: AAmbientSound 
 A sound actor that can be placed in a level */ 
 class AAmbientSound : public AActor
{
public:
// Group: Sound

/* Variable: AudioComponent 
 Audio component that handles sound playing */
UAudioComponent AudioComponent;
// Group: Audio

/* Function: FadeIn 
 BEGIN DEPRECATED (use component functions now in level script) */
void FadeIn(float32 FadeInDuration, float32 FadeVolumeLevel = 1.000000) {}
/* Function: FadeOut 
  */
void FadeOut(float32 FadeOutDuration, float32 FadeVolumeLevel) {}
/* Function: Play 
  */
void Play(float32 StartTime = 0.000000) {}
/* Function: Stop 
  */
void Stop() {}
/* Function: AdjustVolume 
  */
void AdjustVolume(float32 AdjustVolumeDuration, float32 AdjustVolumeLevel) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AAmbientSound AAmbientSound::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AAmbientSound::StaticClass() {}
}
