/* Class: EAudioSpectrumPlotFrequencyAxisPixelBucketMode 
  */ 
 class EAudioSpectrumPlotFrequencyAxisPixelBucketMode
{
public:
}
/* Enum: EAudioSpectrumPlotFrequencyAxisPixelBucketMode 
 
    Sample - Enum
    Peak - Enum
    Average - Enum
    EAudioSpectrumPlotFrequencyAxisPixelBucketMode_MAX - Enum */ 
 enum EAudioSpectrumPlotFrequencyAxisPixelBucketMode { 
Sample,
Peak,
Average,
EAudioSpectrumPlotFrequencyAxisPixelBucketMode_MAX, 
}