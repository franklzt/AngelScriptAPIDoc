/* Class: EArraySortOrder 
  */ 
 class EArraySortOrder
{
public:
}
/* Enum: EArraySortOrder 
 
    Ascending - Enum
    Descending - Enum
    EArraySortOrder_MAX - Enum */ 
 enum EArraySortOrder { 
Ascending,
Descending,
EArraySortOrder_MAX, 
}