/* Class: EAttachmentRule 
  */ 
 class EAttachmentRule
{
public:
}
/* Enum: EAttachmentRule 
 
    KeepRelative - Enum
    KeepWorld - Enum
    SnapToTarget - Enum
    EAttachmentRule_MAX - Enum */ 
 enum EAttachmentRule { 
KeepRelative,
KeepWorld,
SnapToTarget,
EAttachmentRule_MAX, 
}