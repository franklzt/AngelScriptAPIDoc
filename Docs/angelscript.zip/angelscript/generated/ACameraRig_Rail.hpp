/* Class: ACameraRig_Rail 
  */ 
 class ACameraRig_Rail : public AActor
{
public:
// Group: Rail Components

/* Variable: RailCameraMount 
 Component to define the attach point for cameras. Moves along the rail. */
USceneComponent RailCameraMount;
/* Variable: TransformComponent 
 Root component to give the whole actor a transform. */
USceneComponent TransformComponent;
/* Variable: RailSplineComponent 
 Spline component to define the rail path. */
USplineComponent RailSplineComponent;
// Group: Rail Controls

/* Variable: PreviewMeshScale 
 Determines the scale of the rail mesh preview */
float32 PreviewMeshScale;
/* Variable: bShowRailVisualization 
 Determines whether or not to show the rail mesh preview. */
bool bShowRailVisualization;
/* Variable: bLockOrientationToRail 
 Determines whether the orientation of the mount should be in the direction of the rail. */
bool bLockOrientationToRail;
/* Variable: CurrentPositionOnRail 
 Defines current position of the mount point along the rail, in terms of normalized distance from the beginning of the rail. */
float32 CurrentPositionOnRail;
// Group: Rail Components

/* Function: GetRailSplineComponent 
 Returns the spline component that defines the rail path */
USplineComponent GetRailSplineComponent() {}
// Group: Functions

/* Function: SetRailSplineComponent 
 Spline component to define the rail path. */
void SetRailSplineComponent(USplineComponent Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ACameraRig_Rail ACameraRig_Rail::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACameraRig_Rail::StaticClass() {}
}
