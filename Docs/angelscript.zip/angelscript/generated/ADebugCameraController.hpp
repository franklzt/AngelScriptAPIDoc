/* Class: ADebugCameraController 
 Camera controller that allows you to fly around a level mostly unrestricted by normal movement rules.

To turn it on, please press Alt+C or both (left and right) analogs on XBox pad,
or use the "ToggleDebugCamera" console command. Check the debug camera bindings
in DefaultPawn.cpp for the camera controls. */ 
 class ADebugCameraController : public APlayerController
{
public:
// Group: Debug Camera

/* Variable: InitialMaxSpeed 
 Initial max speed of the spectator pawn when we start possession. */
float32 InitialMaxSpeed;
/* Variable: InitialAccel 
 Initial acceleration of the spectator pawn when we start possession. */
float32 InitialAccel;
/* Variable: InitialDecel 
 Initial deceleration of the spectator pawn when we start possession. */
float32 InitialDecel;
/* Variable: SpeedScale 
 Allows control over the speed of the spectator pawn. This scales the speed based on the InitialMaxSpeed. Use Set Pawn Movement Speed Scale during runtime */
float32 SpeedScale;
// Group: Variables

/* Variable: SelectedActor 
 Currently selected actor, may be invalid */
const AActor SelectedActor;
// Group: Debug Camera

/* Function: ToggleDisplay 
 Toggles the display of debug info and input commands for the Debug Camera. */
void ToggleDisplay() {}
/* Function: OnActorSelected 
 Called when an actor has been selected with the primary key (e.g. left mouse button).

The selection trace starts from the center of the debug camera's view.

Parameters:
    SelectHitLocation - The exact world-space location where the selection trace hit the New Selected Actor.
    SelectHitNormal - The world-space surface normal of the New Selected Actor at the hit location. */
void OnActorSelected(AActor NewSelectedActor, FVector SelectHitLocation, FVector SelectHitNormal, FHitResult Hit) {}
/* Function: SetPawnMovementSpeedScale 
 Sets the pawn movement speed scale. */
void SetPawnMovementSpeedScale(float32 NewSpeedScale) {}
/* Function: GetSelectedActor 
 Returns the currently selected actor, or null if it is invalid or not set */
AActor GetSelectedActor() const {}
// Group: Functions

/* Function: OnDeactivate 
 Function called on deactivation of debug camera controller.

Parameters:
    RestoredPC - The Player Controller that the player input is being returned to. */
void OnDeactivate(APlayerController RestoredPC) {}
/* Function: OnActivate 
 Function called on activation of debug camera controller.

Parameters:
    OriginalPC - The active player controller before this debug camera controller was possessed by the player. */
void OnActivate(APlayerController OriginalPC) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ADebugCameraController ADebugCameraController::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADebugCameraController::StaticClass() {}
}
