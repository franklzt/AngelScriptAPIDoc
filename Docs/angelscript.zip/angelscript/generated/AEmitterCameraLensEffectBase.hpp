/* Class: AEmitterCameraLensEffectBase 
  */ 
 class AEmitterCameraLensEffectBase : public AEmitter
{
public:
// Group: EmitterCameraLensEffectBase

/* Variable: RelativeTransform 
 Effect-to-camera transform to allow arbitrary placement of the particle system .
Note the X component of the location will be scaled with camera fov to keep the lens effect the same apparent size. */
FTransform RelativeTransform;
/* Variable: BaseFOV 
 This is the assumed FOV for which the effect was authored. The code will make automatic adjustments to make it look the same at different FOVs */
float32 BaseFOV;
/* Variable: EmittersToTreatAsSame 
 If an emitter class in this array is currently playing, do not play this effect.
Useful for preventing multiple similar or expensive camera effects from playing simultaneously. */
TArray<TSubclassOf<AActor>> EmittersToTreatAsSame;
/* Variable: PS_CameraEffect 
 Particle System to use */
UParticleSystem PS_CameraEffect;
// Group: Functions

/* Function: SetbResetWhenRetriggered 
 If bAllowMultipleInstances is true and this effect is retriggered, the particle system will be reset if this is true */
void SetbResetWhenRetriggered(bool Value) {}
/* Function: SetbAllowMultipleInstances 
 true if multiple instances of this emitter can exist simultaneously, false otherwise. */
void SetbAllowMultipleInstances(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AEmitterCameraLensEffectBase AEmitterCameraLensEffectBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AEmitterCameraLensEffectBase::StaticClass() {}
}
