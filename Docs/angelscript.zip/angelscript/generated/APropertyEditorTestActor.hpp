/* Class: APropertyEditorTestActor 
  */ 
 class APropertyEditorTestActor : public AActor
{
public:
// Group: ArraysOfProperties

/* Variable: InstancedUObjectArray 
  */
TArray<TObjectPtr<UPropertyEditorTestInstancedObject>> InstancedUObjectArray;
// Group: Default

/* Variable: GetOptionsValue 
  */
FName GetOptionsValue;
// Group: Defaults Only

/* Variable: DefaultsOnly 
  */
float32 DefaultsOnly;
// Group: Defaults Only|Subcategory

/* Variable: DefaultsOnlySubcategory 
  */
float32 DefaultsOnlySubcategory;
// Group: Instance Only

/* Variable: InstanceOnly 
  */
float32 InstanceOnly;
// Group: Instance Only|Subcategory

/* Variable: InstanceOnlySubcategory 
  */
float32 InstanceOnlySubcategory;
// Group: Map

/* Variable: MultiLineMap 
  */
TMap<int,FText> MultiLineMap;
// Group: Static Functions

/* Function: Spawn 
  */
static APropertyEditorTestActor APropertyEditorTestActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APropertyEditorTestActor::StaticClass() {}
}
