/* Class: AGeometryCollectionRenderLevelSetActor 
 AGeometryCollectionRenderLevelSetActor
An actor representing the collection of data necessary to
render volumes.  This references a ray marching material, which
is used internally by a post process component blendable.  This
is a workflow that can be improved with a deeper implementation
in the future if we decide to.  Note that behavior with multiple
render level set actors isn't currently supported very well,
but could be improved in the future */ 
 class AGeometryCollectionRenderLevelSetActor : public AActor
{
public:
// Group: Rendering

/* Variable: RayMarchMaterial 
 Material that performs ray marching.  Note this must have certain parameters in order
to work correctly */
UMaterial RayMarchMaterial;
/* Variable: SurfaceTolerance 
 Surface tolerance used for rendering.  When surface reconstruction is noisy,
try tweaking this value */
float32 SurfaceTolerance;
/* Variable: Isovalue 
 Isovalue of the level set to use for surface reconstruction.  Generally you want
this to be zero, but it can be useful for exploring the distance values to make
this negative to see the interior structure of the levelset */
float32 Isovalue;
/* Variable: Enabled 
 Enable or disable rendering */
bool Enabled;
/* Variable: RenderVolumeBoundingBox 
 Enable or disable rendering */
bool RenderVolumeBoundingBox;
// Group: Volume

/* Variable: TargetVolumeTexture 
 Volume texture to fill */
UVolumeTexture TargetVolumeTexture;
// Group: Static Functions

/* Function: Spawn 
  */
static AGeometryCollectionRenderLevelSetActor AGeometryCollectionRenderLevelSetActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGeometryCollectionRenderLevelSetActor::StaticClass() {}
}
