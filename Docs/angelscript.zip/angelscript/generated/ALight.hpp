/* Class: ALight 
  */ 
 class ALight : public AActor
{
public:
// Group: Light

/* Variable: LightComponent 
 @todo document */
ULightComponent LightComponent;
// Group: Rendering|Lighting

/* Variable: LightColor 
  */
FLinearColor LightColor;
/* Variable: Brightness 
  */
float32 Brightness;
// Group: Rendering|Lighting

/* Function: SetLightColor 
  */
void SetLightColor(FLinearColor NewLightColor) {}
/* Function: GetLightColor 
  */
FLinearColor GetLightColor() const {}
/* Function: IsEnabled 
  */
bool IsEnabled() const {}
/* Function: SetAffectTranslucentLighting 
  */
void SetAffectTranslucentLighting(bool bNewValue) {}
/* Function: SetBrightness 
  */
void SetBrightness(float32 NewBrightness) {}
/* Function: SetCastShadows 
  */
void SetCastShadows(bool bNewValue) {}
/* Function: SetEnabled 
 BEGIN DEPRECATED (use component functions now in level script) */
void SetEnabled(bool bSetEnabled) {}
/* Function: GetBrightness 
  */
float32 GetBrightness() const {}
/* Function: SetLightFunctionFadeDistance 
  */
void SetLightFunctionFadeDistance(float32 NewLightFunctionFadeDistance) {}
/* Function: SetLightFunctionMaterial 
  */
void SetLightFunctionMaterial(UMaterialInterface NewLightFunctionMaterial) {}
/* Function: SetLightFunctionScale 
  */
void SetLightFunctionScale(FVector NewLightFunctionScale) {}
/* Function: ToggleEnabled 
  */
void ToggleEnabled() {}
// Group: Static Functions

/* Function: Spawn 
  */
static ALight ALight::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ALight::StaticClass() {}
}
