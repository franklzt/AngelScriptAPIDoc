/* Class: AReplicatedLevelSequenceActor 
 A level sequence actor that is set to always be relevant for networking purposes */ 
 class AReplicatedLevelSequenceActor : public ALevelSequenceActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AReplicatedLevelSequenceActor AReplicatedLevelSequenceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AReplicatedLevelSequenceActor::StaticClass() {}
}
