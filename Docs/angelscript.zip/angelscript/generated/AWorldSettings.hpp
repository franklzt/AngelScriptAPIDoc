/* Class: AWorldSettings 
 Actor containing all script accessible world properties. */ 
 class AWorldSettings : public AInfo
{
public:
// Group: AI

/* Variable: bEnableAISystem 
 if set to false AI system will not get created. Use it to disable all AI-related activity on a map */
bool bEnableAISystem;
/* Variable: AISystemClass 
  */
TSoftClassPtr<UAISystemBase> AISystemClass;
// Group: Audio

/* Variable: DefaultReverbSettings 
 Default reverb settings used by audio volumes. */
FReverbSettings DefaultReverbSettings;
/* Variable: DefaultAmbientZoneSettings 
 Default interior settings applied to sounds that have "apply ambient volumes" set to true on their SoundClass. */
FInteriorSettings DefaultAmbientZoneSettings;
/* Variable: DefaultBaseSoundMix 
 Default Base SoundMix. */
USoundMix DefaultBaseSoundMix;
// Group: Broadphase

/* Variable: BroadphaseSettings 
  */
FBroadphaseSettings BroadphaseSettings;
// Group: Foliage

/* Variable: InstancedFoliageGridSize 
 Size of the grid for instanced foliage actors, only used for partitioned worlds */
uint InstancedFoliageGridSize;
/* Variable: bShowInstancedFoliageGrid 
  */
bool bShowInstancedFoliageGrid;
// Group: GameMode

/* Variable: DefaultGameMode 
 The default GameMode to use when starting this map in the game. If this value is NULL, the INI setting for default game type is used. */
TSubclassOf<AGameModeBase> DefaultGameMode;
// Group: HLODSystem

/* Variable: HLODSetupAsset 
 If set overrides the level settings and global project settings */
TSoftClassPtr<UHierarchicalLODSetup> HLODSetupAsset;
/* Variable: OverrideBaseMaterial 
 If set overrides the project-wide base material used for Proxy Materials */
TSoftObjectPtr<UMaterialInterface> OverrideBaseMaterial;
/* Variable: HLODBakingTransform 
 Specify the transform to apply to the source meshes when building HLODs. */
FTransform HLODBakingTransform;
/* Variable: HierarchicalLODSetup 
 Hierarchical LOD Setup */
TArray<FHierarchicalSimplification> HierarchicalLODSetup;
// Group: Landscape

/* Variable: LandscapeSplineMeshesGridSize 
  */
uint LandscapeSplineMeshesGridSize;
// Group: Lightmass

/* Variable: LightmassSettings 
 LIGHTMASS RELATED SETTINGS * */
FLightmassWorldInfoSettings LightmassSettings;
/* Variable: PackedLightAndShadowMapTextureSize 
 Maximum size of textures for packed light and shadow maps */
int PackedLightAndShadowMapTextureSize;
// Group: LightmassVolumeLighting

/* Variable: VolumetricLightmapLoadingRange 
 Range in which volumetric lightmaps will be loaded. */
float32 VolumetricLightmapLoadingRange;
// Group: Nanite

/* Variable: NaniteSettings 
 NANITE SETTINGS * */
FNaniteSettings NaniteSettings;
// Group: Navigation

/* Variable: NavigationDataBuilderLoadingCellSize 
 Loading cell size used when building navigation data iteratively.
The actual cell size used will be rounded using the NavigationDataChunkGridSize.
It's recommended to use a value as high as the hardware memory allows to load. */
uint NavigationDataBuilderLoadingCellSize;
/* Variable: NavigationDataChunkGridSize 
 Size of the grid for navigation data chunk actors */
uint NavigationDataChunkGridSize;
/* Variable: BaseNavmeshDataLayers 
 A list of runtime data layers that should be included in the base navmesh.
Editor data layers and actors outside data layers will be included. */
TArray<TObjectPtr<UDataLayerAsset>> BaseNavmeshDataLayers;
// Group: Physics

/* Variable: DefaultPhysicsVolumeClass 
 level specific default physics volume */
TSubclassOf<ADefaultPhysicsVolume> DefaultPhysicsVolumeClass;
/* Variable: GlobalGravityZ 
 optional level specific gravity override set by level designer */
float32 GlobalGravityZ;
/* Variable: bGlobalGravitySet 
 If set to true we will use GlobalGravityZ instead of project setting DefaultGravityZ */
bool bGlobalGravitySet;
/* Variable: PhysicsCollisionHandlerClass 
 optional level specific collision handler */
TSubclassOf<UPhysicsCollisionHandler> PhysicsCollisionHandlerClass;
// Group: PrecomputedVisibility

/* Variable: VisibilityAggressiveness 
 Determines how aggressive precomputed visibility should be.
More aggressive settings cull more objects but also cause more visibility errors like popping. */
EVisibilityAggressiveness VisibilityAggressiveness;
/* Variable: VisibilityCellSize 
 World space size of precomputed visibility cells in x and y.
Smaller sizes produce more effective occlusion culling at the cost of increased runtime memory usage and lighting build times. */
int VisibilityCellSize;
// Group: Rendering

/* Variable: GlobalDistanceFieldViewDistance 
 Distance from the camera that the global distance field should cover. */
float32 GlobalDistanceFieldViewDistance;
/* Variable: DefaultMaxDistanceFieldOcclusionDistance 
 Max occlusion distance used by mesh distance fields, overridden if there is a movable skylight. */
float32 DefaultMaxDistanceFieldOcclusionDistance;
/* Variable: DynamicIndirectShadowsSelfShadowingIntensity 
 Controls the intensity of self-shadowing from capsule indirect shadows.
These types of shadows use approximate occluder representations, so reducing self-shadowing intensity can hide those artifacts. */
float32 DynamicIndirectShadowsSelfShadowingIntensity;
// Group: Tick

/* Variable: MinUndilatedFrameTime 
 Smallest possible frametime, not considering dilation. Equiv to 1/FastestFPS. */
float32 MinUndilatedFrameTime;
/* Variable: MinGlobalTimeDilation 
 Lowest acceptable global time dilation. */
float32 MinGlobalTimeDilation;
/* Variable: MaxUndilatedFrameTime 
 Largest possible frametime, not considering dilation. Equiv to 1/SlowestFPS. */
float32 MaxUndilatedFrameTime;
/* Variable: MaxGlobalTimeDilation 
 Highest acceptable global time dilation. */
float32 MaxGlobalTimeDilation;
// Group: VR

/* Variable: WorldToMeters 
 scale of 1uu to 1m in real world measurements, for HMD and other physically tracked devices (e.g. 1uu = 1cm would be 100.0) */
float32 WorldToMeters;
// Group: World

/* Variable: KillZDamageType 
 The type of damage inflicted when a actor falls below KillZ */
TSubclassOf<UDamageType> KillZDamageType;
/* Variable: KillZ 
 any actor falling below this level gets destroyed */
float32 KillZ;
/* Variable: bEnableWorldOriginRebasing 
 World origin will shift to a camera position when camera goes far away from current origin */
bool bEnableWorldOriginRebasing;
/* Variable: NavigationSystemConfig 
 Holds parameters for NavigationSystem's creation. Set to Null will result
    in NavigationSystem instance not being created for this world. Note that
    if set NavigationSystemConfigOverride will be used instead. */
UNavigationSystemConfig NavigationSystemConfig;
/* Variable: bEnableWorldBoundsChecks 
 If true, enables CheckStillInWorld checks */
bool bEnableWorldBoundsChecks;
/* Variable: bEnableNavigationSystem 
  */
const bool bEnableNavigationSystem;
/* Variable: DefaultColorScale 
 Default color scale for the level */
FVector DefaultColorScale;
/* Variable: bEnableWorldComposition 
 Enables tools for composing a tiled world.
Level has to be saved and all sub-levels removed before enabling this option. */
bool bEnableWorldComposition;
/* Variable: bUseClientSideLevelStreamingVolumes 
 Enables client-side streaming volumes instead of server-side.
Expected usage scenario: server has all streaming levels always loaded, clients independently stream levels in/out based on streaming volumes. */
bool bUseClientSideLevelStreamingVolumes;
// Group: WorldPartitionSetup

/* Variable: WorldPartition 
  */
UWorldPartition WorldPartition;
// Group: Variables

/* Variable: BookMarks 
  */
UBookMark BookMarks;
// Group: Functions

/* Function: SetbEnableWorldOriginRebasing 
 World origin will shift to a camera position when camera goes far away from current origin */
void SetbEnableWorldOriginRebasing(bool Value) {}
/* Function: SetbPlaceCellsOnlyAlongCameraTracks 
 Whether to place visibility cells only along camera tracks or only above shadow casting surfaces. */
void SetbPlaceCellsOnlyAlongCameraTracks(bool Value) {}
/* Function: GetbEnableWorldBoundsChecks 
 If true, enables CheckStillInWorld checks */
bool GetbEnableWorldBoundsChecks() const {}
/* Function: SetbEnableWorldBoundsChecks 
 If true, enables CheckStillInWorld checks */
void SetbEnableWorldBoundsChecks(bool Value) {}
/* Function: GetbEnableNavigationSystem 
  */
bool GetbEnableNavigationSystem() const {}
/* Function: GetbEnableAISystem 
 if set to false AI system will not get created. Use it to disable all AI-related activity on a map */
bool GetbEnableAISystem() const {}
/* Function: SetbEnableAISystem 
 if set to false AI system will not get created. Use it to disable all AI-related activity on a map */
void SetbEnableAISystem(bool Value) {}
/* Function: GetbEnableWorldComposition 
 Enables tools for composing a tiled world.
Level has to be saved and all sub-levels removed before enabling this option. */
bool GetbEnableWorldComposition() const {}
/* Function: SetbEnableWorldComposition 
 Enables tools for composing a tiled world.
Level has to be saved and all sub-levels removed before enabling this option. */
void SetbEnableWorldComposition(bool Value) {}
/* Function: GetbUseClientSideLevelStreamingVolumes 
 Enables client-side streaming volumes instead of server-side.
Expected usage scenario: server has all streaming levels always loaded, clients independently stream levels in/out based on streaming volumes. */
bool GetbUseClientSideLevelStreamingVolumes() const {}
/* Function: SetbUseClientSideLevelStreamingVolumes 
 Enables client-side streaming volumes instead of server-side.
Expected usage scenario: server has all streaming levels always loaded, clients independently stream levels in/out based on streaming volumes. */
void SetbUseClientSideLevelStreamingVolumes(bool Value) {}
/* Function: GetbEnableWorldOriginRebasing 
 World origin will shift to a camera position when camera goes far away from current origin */
bool GetbEnableWorldOriginRebasing() const {}
/* Function: SetbPrecomputeVisibility 
 Whether to place visibility cells inside Precomputed Visibility Volumes and along camera tracks in this level.
Precomputing visibility reduces rendering thread time at the cost of some runtime memory and somewhat increased lighting build times. */
void SetbPrecomputeVisibility(bool Value) {}
/* Function: GetbGlobalGravitySet 
 If set to true we will use GlobalGravityZ instead of project setting DefaultGravityZ */
bool GetbGlobalGravitySet() const {}
/* Function: SetbGlobalGravitySet 
 If set to true we will use GlobalGravityZ instead of project setting DefaultGravityZ */
void SetbGlobalGravitySet(bool Value) {}
/* Function: SetbMinimizeBSPSections 
 Causes the BSP build to generate as few sections as possible.
This is useful when you need to reduce draw calls but can reduce texture streaming efficiency and effective lightmap resolution.
Note - changes require a rebuild to propagate.  Also, be sure to select all surfaces and make sure they all have the same flags to minimize section count. */
void SetbMinimizeBSPSections(bool Value) {}
/* Function: SetbForceNoPrecomputedLighting 
 Whether to force lightmaps and other precomputed lighting to not be created even when the engine thinks they are needed.
This is useful for improving iteration in levels with fully dynamic lighting and shadowing.
Note that any lighting and shadowing interactions that are usually precomputed will be lost if this is enabled. */
void SetbForceNoPrecomputedLighting(bool Value) {}
/* Function: SetbForceVolumetricLightmapsOnly 
 Force precomputed lighting to only use VolumetricLightmaps. */
void SetbForceVolumetricLightmapsOnly(bool Value) {}
/* Function: SetbOverrideDefaultBroadphaseSettings 
  */
void SetbOverrideDefaultBroadphaseSettings(bool Value) {}
/* Function: SetbGenerateSingleClusterForLevel 
 If set to true, all eligible actors in this level will be added to a single cluster representing the entire level (used for small sublevels) */
void SetbGenerateSingleClusterForLevel(bool Value) {}
/* Function: SetbHideEnableStreamingWarning 
 if set to true, this hide the streaming disabled warning available in the viewport */
void SetbHideEnableStreamingWarning(bool Value) {}
/* Function: SetbReuseAddressAndPort 
 Whether to configure the listening socket to allow reuse of the address and port. If this is true, be sure no other
servers can run on the same port, otherwise this can lead to undefined behavior since packets will go to two servers. */
void SetbReuseAddressAndPort(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AWorldSettings AWorldSettings::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AWorldSettings::StaticClass() {}
}
