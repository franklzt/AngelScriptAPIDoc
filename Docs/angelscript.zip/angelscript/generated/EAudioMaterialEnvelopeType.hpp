/* Class: EAudioMaterialEnvelopeType 
  */ 
 class EAudioMaterialEnvelopeType
{
public:
}
/* Enum: EAudioMaterialEnvelopeType 
 
    AD - Enum
    ADSR - Enum
    EAudioMaterialEnvelopeType_MAX - Enum */ 
 enum EAudioMaterialEnvelopeType { 
AD,
ADSR,
EAudioMaterialEnvelopeType_MAX, 
}