/* Class: BuiltInDynamicBindingResolver 
  */ 
 class BuiltInDynamicBindingResolver
{
public:
// Group: Sequencer|Dynamic Binding

/* Function: ResolveToPlayerPawn 
 Resolve the bound object to the player's pawn */
static FMovieSceneDynamicBindingResolveResult BuiltInDynamicBindingResolver::ResolveToPlayerPawn(int PlayerControllerIndex = 0) {}
}
