/* Class: EAudioOscilloscopeTriggerMode 
  */ 
 class EAudioOscilloscopeTriggerMode
{
public:
}
/* Enum: EAudioOscilloscopeTriggerMode 
 
    None - Enum
    Rising - Enum
    Falling - Enum
    EAudioOscilloscopeTriggerMode_MAX - Enum */ 
 enum EAudioOscilloscopeTriggerMode { 
None,
Rising,
Falling,
EAudioOscilloscopeTriggerMode_MAX, 
}