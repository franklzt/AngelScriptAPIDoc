/* Class: ASkyLight 
  */ 
 class ASkyLight : public AInfo
{
public:
// Group: Light

/* Variable: LightComponent 
 @todo document */
USkyLightComponent LightComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ASkyLight ASkyLight::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASkyLight::StaticClass() {}
}
