/* Class: EBoneRotationSource 
  */ 
 class EBoneRotationSource
{
public:
}
/* Enum: EBoneRotationSource 
 
    BRS_KeepComponentSpaceRotation - Enum
    BRS_KeepLocalSpaceRotation - Enum
    BRS_CopyFromTarget - Enum
    BRS_MAX - Enum */ 
 enum EBoneRotationSource { 
BRS_KeepComponentSpaceRotation,
BRS_KeepLocalSpaceRotation,
BRS_CopyFromTarget,
BRS_MAX, 
}