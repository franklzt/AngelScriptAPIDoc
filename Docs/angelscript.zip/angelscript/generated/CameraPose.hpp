/* Class: CameraPose 
  */ 
 class CameraPose
{
public:
// Group: Camera

/* Function: GetTargetDistance 
 Gets the target distance of the camera pose. */
static float CameraPose::GetTargetDistance(FBlueprintCameraPose CameraPose) {}
/* Function: GetAimRay 
 Gets the aim ray of the camera pose. */
static FRay CameraPose::GetAimRay(FBlueprintCameraPose CameraPose) {}
/* Function: GetEffectiveFieldOfView 
 Gets the effective field of view of the camera pose, possibly computed from focal length. */
static float CameraPose::GetEffectiveFieldOfView(FBlueprintCameraPose CameraPose) {}
/* Function: GetFieldOfView 
 Gets the field of view of the camera pose. */
static float CameraPose::GetFieldOfView(FBlueprintCameraPose CameraPose) {}
/* Function: GetFocalLength 
 Gets the focal length of the camera pose. */
static float CameraPose::GetFocalLength(FBlueprintCameraPose CameraPose) {}
/* Function: GetLocation 
 Gets the location of the camera pose. */
static FVector CameraPose::GetLocation(FBlueprintCameraPose CameraPose) {}
/* Function: GetRotation 
 Gets the rotation of the camera pose. */
static FRotator CameraPose::GetRotation(FBlueprintCameraPose CameraPose) {}
/* Function: GetSensorAspectRatio 
 Gets the effective aspect ratio of the camera pose, computed from the sensor size. */
static float CameraPose::GetSensorAspectRatio(FBlueprintCameraPose CameraPose) {}
/* Function: GetTarget 
 Gets the target of the camera pose. */
static FVector CameraPose::GetTarget(FBlueprintCameraPose CameraPose) {}
/* Function: GetTargetAtDistance 
 Gets the target of the camera pose given a specific target distance. */
static FVector CameraPose::GetTargetAtDistance(FBlueprintCameraPose CameraPose, float TargetDistance) {}
/* Function: GetAimDir 
 Gets the facing direction of the camera pose. */
static FVector CameraPose::GetAimDir(FBlueprintCameraPose CameraPose) {}
/* Function: GetTransform 
 Gets the transform matrix of the camera pose. */
static FTransform CameraPose::GetTransform(FBlueprintCameraPose CameraPose) {}
/* Function: MakeCameraPoseFromCameraComponent 
 Creates a new camera pose given a camera component. */
static FBlueprintCameraPose CameraPose::MakeCameraPoseFromCameraComponent(const UCameraComponent CameraComponent) {}
/* Function: MakeCameraPoseFromCineCameraComponent 
 Creates a new camera pose given a cine-camera component. */
static FBlueprintCameraPose CameraPose::MakeCameraPoseFromCineCameraComponent(const UCineCameraComponent CameraComponent) {}
/* Function: SetFieldOfView 
 Creates a copy of the given camera pose with the given field of view. */
static FBlueprintCameraPose CameraPose::SetFieldOfView(FBlueprintCameraPose CameraPose, float32 FieldOfView) {}
/* Function: SetFocalLength 
 Creates a copy of the given camera pose with the given focal length. */
static FBlueprintCameraPose CameraPose::SetFocalLength(FBlueprintCameraPose CameraPose, float32 FocalLength) {}
/* Function: SetLocation 
 Creates a copy of the given camera pose with the given location. */
static FBlueprintCameraPose CameraPose::SetLocation(FBlueprintCameraPose CameraPose, FVector Location) {}
/* Function: SetRotation 
 Creates a copy of the given camera pose with the given rotation. */
static FBlueprintCameraPose CameraPose::SetRotation(FBlueprintCameraPose CameraPose, FRotator Rotation) {}
/* Function: SetTargetDistance 
 Creates a copy of the given camera pose with the given target distance. */
static FBlueprintCameraPose CameraPose::SetTargetDistance(FBlueprintCameraPose CameraPose, float TargetDistance) {}
/* Function: SetTransform 
 Creates a copy of the given camera pose with the given location and rotation. */
static FBlueprintCameraPose CameraPose::SetTransform(FBlueprintCameraPose CameraPose, FTransform Transform) {}
}
