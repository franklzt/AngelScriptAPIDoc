/* Class: EBakeVertexOutput 
  */ 
 class EBakeVertexOutput
{
public:
}
/* Enum: EBakeVertexOutput 
 
    RGBA - Enum
    PerChannel - Enum
    EBakeVertexOutput_MAX - Enum */ 
 enum EBakeVertexOutput { 
RGBA,
PerChannel,
EBakeVertexOutput_MAX, 
}