/* Class: EAlembicImportType 
  */ 
 class EAlembicImportType
{
public:
}
/* Enum: EAlembicImportType 
 
    StaticMesh - Enum
    GeometryCache - Enum
    Skeletal - Enum
    EAlembicImportType_MAX - Enum */ 
 enum EAlembicImportType { 
StaticMesh,
GeometryCache,
Skeletal,
EAlembicImportType_MAX, 
}