/* Class: ADebugCameraHUD 
 HUD that displays info for the DebugCameraController view. */ 
 class ADebugCameraHUD : public AHUD
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ADebugCameraHUD ADebugCameraHUD::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADebugCameraHUD::StaticClass() {}
}
