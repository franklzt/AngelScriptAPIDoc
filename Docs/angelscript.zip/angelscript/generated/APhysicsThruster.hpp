/* Class: APhysicsThruster 
 Attach one of these on an object using physics simulation and it will apply a force down the negative-X direction
ie. point X in the direction you want the thrust in. */ 
 class APhysicsThruster : public ARigidBodyBase
{
public:
// Group: Physics

/* Variable: ThrusterComponent 
 Thruster component */
UPhysicsThrusterComponent ThrusterComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static APhysicsThruster APhysicsThruster::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APhysicsThruster::StaticClass() {}
}
