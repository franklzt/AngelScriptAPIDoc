/* Class: ACineCameraActor 
 A CineCameraActor is a CameraActor specialized to work like a cinematic camera. */ 
 class ACineCameraActor : public ACameraActor
{
public:
// Group: Camera

/* Variable: CineCameraComponent 
 Returns the CineCameraComponent of this CineCamera */
const UCineCameraComponent CineCameraComponent;
// Group: Current Camera Settings

/* Variable: LookatTrackingSettings 
  */
FCameraLookatTrackingSettings LookatTrackingSettings;
// Group: Camera

/* Function: GetCineCameraComponent 
 Returns the CineCameraComponent of this CineCamera */
UCineCameraComponent GetCineCameraComponent() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ACineCameraActor ACineCameraActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACineCameraActor::StaticClass() {}
}
