/* Class: EAssetRenameResult 
  */ 
 class EAssetRenameResult
{
public:
}
/* Enum: EAssetRenameResult 
 
    Failure - Enum
    Success - Enum
    Pending - Enum
    EAssetRenameResult_MAX - Enum */ 
 enum EAssetRenameResult { 
Failure,
Success,
Pending,
EAssetRenameResult_MAX, 
}