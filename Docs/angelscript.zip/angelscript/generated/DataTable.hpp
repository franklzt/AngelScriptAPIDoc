/* Class: DataTable 
  */ 
 class DataTable
{
public:
// Group: DataTable

/* Function: EvaluateCurveTableRow 
  */
static void DataTable::EvaluateCurveTableRow(UCurveTable CurveTable, FName RowName, float32 InXY, EEvaluateCurveTableResult& OutResult, float32& OutXY, FString ContextString) {}
// Group: Editor Scripting | DataTable

/* Function: RemoveDataTableRow 
 Removes the row with the provided name from a Data Table. */
static void DataTable::RemoveDataTableRow(UDataTable DataTable, FName RowName) {}
}
