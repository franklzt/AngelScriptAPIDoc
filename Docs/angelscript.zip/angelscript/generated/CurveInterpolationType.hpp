/* Class: CurveInterpolationType 
  */ 
 class CurveInterpolationType
{
public:
}
/* Enum: CurveInterpolationType 
 
    AUTOINTERP - Enum
    LINEAR - Enum
    CONSTANT - Enum
    CurveInterpolationType_MAX - Enum */ 
 enum CurveInterpolationType { 
AUTOINTERP,
LINEAR,
CONSTANT,
CurveInterpolationType_MAX, 
}