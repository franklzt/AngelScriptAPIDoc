/* Class: ATriggerSphere 
 A sphere shaped trigger, used to generate overlap events in the level */ 
 class ATriggerSphere : public ATriggerBase
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ATriggerSphere ATriggerSphere::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATriggerSphere::StaticClass() {}
}
