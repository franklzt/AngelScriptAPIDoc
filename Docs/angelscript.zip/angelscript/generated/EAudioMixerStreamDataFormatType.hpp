/* Class: EAudioMixerStreamDataFormatType 
  */ 
 class EAudioMixerStreamDataFormatType
{
public:
}
/* Enum: EAudioMixerStreamDataFormatType 
 
    Unknown - Enum
    Float - Enum
    Int16 - Enum
    Unsupported - Enum
    EAudioMixerStreamDataFormatType_MAX - Enum */ 
 enum EAudioMixerStreamDataFormatType { 
Unknown,
Float,
Int16,
Unsupported,
EAudioMixerStreamDataFormatType_MAX, 
}