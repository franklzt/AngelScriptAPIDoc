/* Class: EAspectRatioAxisConstraint 
  */ 
 class EAspectRatioAxisConstraint
{
public:
}
/* Enum: EAspectRatioAxisConstraint 
 
    AspectRatio_MaintainYFOV - Enum
    AspectRatio_MaintainXFOV - Enum
    AspectRatio_MajorAxisFOV - Enum
    AspectRatio_MAX - Enum */ 
 enum EAspectRatioAxisConstraint { 
AspectRatio_MaintainYFOV,
AspectRatio_MaintainXFOV,
AspectRatio_MajorAxisFOV,
AspectRatio_MAX, 
}