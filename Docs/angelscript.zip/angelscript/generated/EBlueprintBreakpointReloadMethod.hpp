/* Class: EBlueprintBreakpointReloadMethod 
  */ 
 class EBlueprintBreakpointReloadMethod
{
public:
}
/* Enum: EBlueprintBreakpointReloadMethod 
 
    RestoreAll - Enum
    RestoreAllAndDisable - Enum
    DiscardAll - Enum
    EBlueprintBreakpointReloadMethod_MAX - Enum */ 
 enum EBlueprintBreakpointReloadMethod { 
RestoreAll,
RestoreAllAndDisable,
DiscardAll,
EBlueprintBreakpointReloadMethod_MAX, 
}