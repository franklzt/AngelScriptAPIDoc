/* Class: ATriggerCapsule 
 A capsule shaped trigger, used to generate overlap events in the level */ 
 class ATriggerCapsule : public ATriggerBase
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ATriggerCapsule ATriggerCapsule::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATriggerCapsule::StaticClass() {}
}
