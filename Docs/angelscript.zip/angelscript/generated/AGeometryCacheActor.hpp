/* Class: AGeometryCacheActor 
 GeometryCache actor, serves as a place-able actor for GeometryCache objects */ 
 class AGeometryCacheActor : public AActor
{
public:
// Group: GeometryCacheActor

/* Variable: GeometryCacheComponent 
  */
UGeometryCacheComponent GeometryCacheComponent;
// Group: Components|GeometryCache

/* Function: GetGeometryCacheComponent 
 Returns GeometryCacheComponent subobject * */
UGeometryCacheComponent GetGeometryCacheComponent() const {}
// Group: Functions

/* Function: SetGeometryCacheComponent 
  */
void SetGeometryCacheComponent(UGeometryCacheComponent Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static AGeometryCacheActor AGeometryCacheActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGeometryCacheActor::StaticClass() {}
}
