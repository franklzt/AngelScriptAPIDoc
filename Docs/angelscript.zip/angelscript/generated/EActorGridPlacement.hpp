/* Class: EActorGridPlacement 
  */ 
 class EActorGridPlacement
{
public:
}
/* Enum: EActorGridPlacement 
 
    Bounds - Enum
    Location - Enum
    AlwaysLoaded - Enum
    None - Enum
    EActorGridPlacement_MAX - Enum */ 
 enum EActorGridPlacement { 
Bounds,
Location,
AlwaysLoaded,
None,
EActorGridPlacement_MAX, 
}