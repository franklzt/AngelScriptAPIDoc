/* Class: EAnimAlphaInputType 
  */ 
 class EAnimAlphaInputType
{
public:
}
/* Enum: EAnimAlphaInputType 
 
    Float - Enum
    Bool - Enum
    Curve - Enum
    EAnimAlphaInputType_MAX - Enum */ 
 enum EAnimAlphaInputType { 
Float,
Bool,
Curve,
EAnimAlphaInputType_MAX, 
}