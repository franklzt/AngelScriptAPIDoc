/* Class: ANavigationTestingActor 
  */ 
 class ANavigationTestingActor : public AActor
{
public:
// Group: Agent

/* Variable: NavAgentProps 
 @todo document */
FNavAgentProperties NavAgentProps;
/* Variable: QueryingExtent 
  */
FVector QueryingExtent;
// Group: AgentStatus

/* Variable: ProjectedLocation 
  */
FVector ProjectedLocation;
/* Variable: bProjectedLocationValid 
  */
const bool bProjectedLocationValid;
// Group: Debug

/* Variable: ShowStepIndex 
 Show debug steps up to this index. Use -1 to disable. */
int ShowStepIndex;
/* Variable: TextCanvasOffset 
 text canvas offset to apply */
FVector2D TextCanvasOffset;
/* Variable: CostDisplayMode 
 determines which cost will be shown */
ENavCostDisplay CostDisplayMode;
// Group: Navigation

/* Variable: InvokerComponent 
  */
UNavigationInvokerComponent InvokerComponent;
// Group: Pathfinding

/* Variable: CostLimitFactor 
 this multiplier is used to compute a max node cost allowed to the open list
    (cost limit = CostLimitFactor*InitialHeuristicEstimate) */
float32 CostLimitFactor;
/* Variable: MinimumCostLimit 
 minimum cost limit clamping value (in cost units)
    used to allow large deviation in short paths */
float32 MinimumCostLimit;
/* Variable: OffsetFromCornersDistance 
  */
float32 OffsetFromCornersDistance;
/* Variable: OtherActor 
  */
ANavigationTestingActor OtherActor;
// Group: PathfindingStatus

/* Variable: PathfindingSteps 
  */
int PathfindingSteps;
/* Variable: PathCost 
  */
float PathCost;
/* Variable: PathfindingTime 
 Time in micro seconds */
float32 PathfindingTime;
/* Variable: bPathIsPartial 
  */
const bool bPathIsPartial;
/* Variable: bPathExist 
  */
const bool bPathExist;
/* Variable: bPathSearchOutOfNodes 
  */
const bool bPathSearchOutOfNodes;
// Group: Query

/* Variable: QueryTargetActor 
 Actor to use as a target for navigation data queries */
AActor QueryTargetActor;
/* Variable: RadiusUsedToValidateNavData 
 NavData must be ready for all tiles within radius. When using 0, NavData must be ready at the actor location. */
float32 RadiusUsedToValidateNavData;
/* Variable: FilterClass 
 "None" will result in default filter being used. This filter is used by the PathFind and Raycast queries. */
TSubclassOf<UNavigationQueryFilter> FilterClass;
// Group: Functions

/* Function: SetbDrawRaycastToQueryTargetActor 
 If set, a line is drawn to indicate to result of a ray cast on the navigation data between the current actor and the QueryTargetActor location
(red when there is a hit, green when there is no hit and the ray end is on the explored corridor, orange otherwise). */
void SetbDrawRaycastToQueryTargetActor(bool Value) {}
/* Function: GetbProjectedLocationValid 
  */
bool GetbProjectedLocationValid() const {}
/* Function: SetbSearchStart 
 if set, start the search from this actor, else start the search from the other actor */
void SetbSearchStart(bool Value) {}
/* Function: SetbBacktracking 
 Instead of regular pathfinding from source to target location do
    a 'backwards' search that searches from the source, but as if the allowed
    movement direction was coming from the target. Meaningful only for paths
    containing one-direction nav links. */
void SetbBacktracking(bool Value) {}
/* Function: SetbUseHierarchicalPathfinding 
  */
void SetbUseHierarchicalPathfinding(bool Value) {}
/* Function: SetbGatherDetailedInfo 
 if set, all steps of A* algorithm will be accessible for debugging */
void SetbGatherDetailedInfo(bool Value) {}
/* Function: SetbRequireNavigableEndLocation 
 if set, require the end location to be close to the navigation data. The tolerance is controlled by QueryingExtent */
void SetbRequireNavigableEndLocation(bool Value) {}
/* Function: SetbDrawDistanceToWall 
  */
void SetbDrawDistanceToWall(bool Value) {}
/* Function: SetbDrawIfNavDataIsReadyInRadius 
 If set, a cylinder is drawn to indicate if the navigation data is ready (has been generated) for the given radius (green when ready, red otherwise). */
void SetbDrawIfNavDataIsReadyInRadius(bool Value) {}
/* Function: SetbDrawIfNavDataIsReadyToQueryTargetActor 
 If set, a capsule is drawn to indicate if the navigation data is ready (has been generated) for the given radius from the current actor to the query target (green when ready, red otherwise). */
void SetbDrawIfNavDataIsReadyToQueryTargetActor(bool Value) {}
/* Function: SetbActAsNavigationInvoker 
  */
void SetbActAsNavigationInvoker(bool Value) {}
/* Function: SetbShowNodePool 
 show polys from open (orange) and closed (yellow) sets */
void SetbShowNodePool(bool Value) {}
/* Function: SetbShowBestPath 
 show current best path */
void SetbShowBestPath(bool Value) {}
/* Function: SetbShowDiffWithPreviousStep 
 show which nodes were modified in current A* step */
void SetbShowDiffWithPreviousStep(bool Value) {}
/* Function: SetbShouldBeVisibleInGame 
  */
void SetbShouldBeVisibleInGame(bool Value) {}
/* Function: GetbPathExist 
  */
bool GetbPathExist() const {}
/* Function: GetbPathIsPartial 
  */
bool GetbPathIsPartial() const {}
/* Function: GetbPathSearchOutOfNodes 
  */
bool GetbPathSearchOutOfNodes() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANavigationTestingActor ANavigationTestingActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavigationTestingActor::StaticClass() {}
}
