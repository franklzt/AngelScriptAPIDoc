/* Class: BeamModifierType 
  */ 
 class BeamModifierType
{
public:
}
/* Enum: BeamModifierType 
 
    PEB2MT_Source - Enum
    PEB2MT_Target - Enum
    PEB2MT_MAX - Enum */ 
 enum BeamModifierType { 
PEB2MT_Source,
PEB2MT_Target,
PEB2MT_MAX, 
}