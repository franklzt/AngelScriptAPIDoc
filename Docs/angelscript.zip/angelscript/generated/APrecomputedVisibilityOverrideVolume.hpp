/* Class: APrecomputedVisibilityOverrideVolume 
  */ 
 class APrecomputedVisibilityOverrideVolume : public AVolume
{
public:
// Group: PrecomputedVisibilityOverrideVolume

/* Variable: OverrideInvisibleActors 
 Array of actors that will always be considered invisible by Precomputed Visibility when viewed from inside this volume. */
TArray<TObjectPtr<AActor>> OverrideInvisibleActors;
/* Variable: OverrideInvisibleLevels 
 Array of level names whose actors will always be considered invisible by Precomputed Visibility when viewed from inside this volume. */
TArray<FName> OverrideInvisibleLevels;
/* Variable: OverrideVisibleActors 
 Array of actors that will always be considered visible by Precomputed Visibility when viewed from inside this volume. */
TArray<TObjectPtr<AActor>> OverrideVisibleActors;
// Group: Static Functions

/* Function: Spawn 
  */
static APrecomputedVisibilityOverrideVolume APrecomputedVisibilityOverrideVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APrecomputedVisibilityOverrideVolume::StaticClass() {}
}
