/* Class: EAudioColorGradient 
  */ 
 class EAudioColorGradient
{
public:
}
/* Enum: EAudioColorGradient 
 
    BlackToWhite - Enum
    WhiteToBlack - Enum
    EAudioColorGradient_MAX - Enum */ 
 enum EAudioColorGradient { 
BlackToWhite,
WhiteToBlack,
EAudioColorGradient_MAX, 
}