/* Class: ADatasmithAreaLightActor 
  */ 
 class ADatasmithAreaLightActor : public AActor
{
public:
// Group: Light

/* Variable: IESTexture 
  */
UTextureLightProfile IESTexture;
/* Variable: LightType 
  */
EDatasmithAreaLightActorType LightType;
/* Variable: LightShape 
  */
EDatasmithAreaLightActorShape LightShape;
/* Variable: Dimensions 
  */
FVector2D Dimensions;
/* Variable: Intensity 
  */
float32 Intensity;
/* Variable: IntensityUnits 
  */
ELightUnits IntensityUnits;
/* Variable: Color 
  */
FLinearColor Color;
/* Variable: Temperature 
  */
float32 Temperature;
/* Variable: SourceRadius 
  */
float32 SourceRadius;
/* Variable: bUseIESBrightness 
  */
bool bUseIESBrightness;
/* Variable: IESBrightnessScale 
  */
float32 IESBrightnessScale;
/* Variable: Rotation 
  */
FRotator Rotation;
/* Variable: SourceLength 
  */
float32 SourceLength;
/* Variable: AttenuationRadius 
  */
float32 AttenuationRadius;
/* Variable: SpotlightInnerAngle 
  */
float32 SpotlightInnerAngle;
/* Variable: SpotlightOuterAngle 
  */
float32 SpotlightOuterAngle;
// Group: Mobility

/* Variable: Mobility 
  */
EComponentMobility Mobility;
// Group: Static Functions

/* Function: Spawn 
  */
static ADatasmithAreaLightActor ADatasmithAreaLightActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ADatasmithAreaLightActor::StaticClass() {}
}
