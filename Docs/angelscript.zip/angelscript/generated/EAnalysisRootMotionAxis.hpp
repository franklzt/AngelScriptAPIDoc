/* Class: EAnalysisRootMotionAxis 
  */ 
 class EAnalysisRootMotionAxis
{
public:
}
/* Enum: EAnalysisRootMotionAxis 
 
    Speed - Enum
    Direction - Enum
    ForwardSpeed - Enum
    RightwardSpeed - Enum
    UpwardSpeed - Enum
    ForwardSlope - Enum
    RightwardSlope - Enum
    EAnalysisRootMotionAxis_MAX - Enum */ 
 enum EAnalysisRootMotionAxis { 
Speed,
Direction,
ForwardSpeed,
RightwardSpeed,
UpwardSpeed,
ForwardSlope,
RightwardSlope,
EAnalysisRootMotionAxis_MAX, 
}