/* Class: EAttributeEditorAttribType 
  */ 
 class EAttributeEditorAttribType
{
public:
}
/* Enum: EAttributeEditorAttribType 
 
    Int32 - Enum
    Boolean - Enum
    Float - Enum
    Vector2 - Enum
    Vector3 - Enum
    Vector4 - Enum
    String - Enum
    Unknown - Enum
    EAttributeEditorAttribType_MAX - Enum */ 
 enum EAttributeEditorAttribType { 
Int32,
Boolean,
Float,
Vector2,
Vector3,
Vector4,
String,
Unknown,
EAttributeEditorAttribType_MAX, 
}