/* Class: EAudioRecordingMode 
  */ 
 class EAudioRecordingMode
{
public:
}
/* Enum: EAudioRecordingMode 
 
    None - Enum
    AudioTrack - Enum
    EAudioRecordingMode_MAX - Enum */ 
 enum EAudioRecordingMode { 
None,
AudioTrack,
EAudioRecordingMode_MAX, 
}