/* Class: ACLCompressionLevel 
  */ 
 class ACLCompressionLevel
{
public:
}
/* Enum: ACLCompressionLevel 
 
    ACLCL_Lowest - Enum
    ACLCL_Low - Enum
    ACLCL_Medium - Enum
    ACLCL_High - Enum
    ACLCL_Highest - Enum
    ACLCL_Automatic - Enum
    ACLCL_MAX - Enum */ 
 enum ACLCompressionLevel { 
ACLCL_Lowest,
ACLCL_Low,
ACLCL_Medium,
ACLCL_High,
ACLCL_Highest,
ACLCL_Automatic,
ACLCL_MAX, 
}