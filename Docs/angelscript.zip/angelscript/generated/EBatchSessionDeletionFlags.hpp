/* Class: EBatchSessionDeletionFlags 
  */ 
 class EBatchSessionDeletionFlags
{
public:
}
/* Enum: EBatchSessionDeletionFlags 
 
    Strict - Enum
    SkipForbiddenSessions - Enum
    EBatchSessionDeletionFlags_MAX - Enum */ 
 enum EBatchSessionDeletionFlags { 
Strict,
SkipForbiddenSessions,
EBatchSessionDeletionFlags_MAX, 
}