/* Class: APhysicsVolume 
 PhysicsVolume: A bounding volume which affects actor physics.
Each AActor is affected at any time by one PhysicsVolume. */ 
 class APhysicsVolume : public AVolume
{
public:
// Group: CharacterMovement

/* Variable: Priority 
 Determines which PhysicsVolume takes precedence if they overlap (higher number = higher priority). */
int Priority;
/* Variable: FluidFriction 
 This property controls the amount of friction applied by the volume as pawns using CharacterMovement move through it. The higher this value, the harder it will feel to move through */
float32 FluidFriction;
/* Variable: bWaterVolume 
 True if this volume contains a fluid like water */
bool bWaterVolume;
/* Variable: TerminalVelocity 
 Terminal velocity of pawns using CharacterMovement when falling. */
float32 TerminalVelocity;
// Group: Volume

/* Variable: bPhysicsOnContact 
 By default, the origin of an AActor must be inside a PhysicsVolume for it to affect the actor. However if this flag is true, the other actor only has to touch the volume to be affected by it. */
bool bPhysicsOnContact;
// Group: Functions

/* Function: SetbWaterVolume 
 True if this volume contains a fluid like water */
void SetbWaterVolume(bool Value) {}
/* Function: GetbPhysicsOnContact 
 By default, the origin of an AActor must be inside a PhysicsVolume for it to affect the actor. However if this flag is true, the other actor only has to touch the volume to be affected by it. */
bool GetbPhysicsOnContact() const {}
/* Function: SetbPhysicsOnContact 
 By default, the origin of an AActor must be inside a PhysicsVolume for it to affect the actor. However if this flag is true, the other actor only has to touch the volume to be affected by it. */
void SetbPhysicsOnContact(bool Value) {}
/* Function: GetbWaterVolume 
 True if this volume contains a fluid like water */
bool GetbWaterVolume() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static APhysicsVolume APhysicsVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APhysicsVolume::StaticClass() {}
}
