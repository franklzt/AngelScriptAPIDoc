/* Class: EBakeScaleMethod 
  */ 
 class EBakeScaleMethod
{
public:
}
/* Enum: EBakeScaleMethod 
 
    BakeFullScale - Enum
    BakeNonuniformScale - Enum
    DoNotBakeScale - Enum
    EBakeScaleMethod_MAX - Enum */ 
 enum EBakeScaleMethod { 
BakeFullScale,
BakeNonuniformScale,
DoNotBakeScale,
EBakeScaleMethod_MAX, 
}