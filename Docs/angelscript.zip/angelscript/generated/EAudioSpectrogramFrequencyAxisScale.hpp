/* Class: EAudioSpectrogramFrequencyAxisScale 
  */ 
 class EAudioSpectrogramFrequencyAxisScale
{
public:
}
/* Enum: EAudioSpectrogramFrequencyAxisScale 
 
    Linear - Enum
    Logarithmic - Enum
    EAudioSpectrogramFrequencyAxisScale_MAX - Enum */ 
 enum EAudioSpectrogramFrequencyAxisScale { 
Linear,
Logarithmic,
EAudioSpectrogramFrequencyAxisScale_MAX, 
}