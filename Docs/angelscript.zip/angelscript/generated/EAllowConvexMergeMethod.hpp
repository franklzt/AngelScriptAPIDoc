/* Class: EAllowConvexMergeMethod 
  */ 
 class EAllowConvexMergeMethod
{
public:
}
/* Enum: EAllowConvexMergeMethod 
 
    ByProximity - Enum
    Any - Enum
    EAllowConvexMergeMethod_MAX - Enum */ 
 enum EAllowConvexMergeMethod { 
ByProximity,
Any,
EAllowConvexMergeMethod_MAX, 
}