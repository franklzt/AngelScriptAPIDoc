/* Class: EAFSActiveType 
  */ 
 class EAFSActiveType
{
public:
}
/* Enum: EAFSActiveType 
 
    None - Enum
    USBOnly - Enum
    NetworkOnly - Enum
    Combined - Enum
    EAFSActiveType_MAX - Enum */ 
 enum EAFSActiveType { 
None,
USBOnly,
NetworkOnly,
Combined,
EAFSActiveType_MAX, 
}