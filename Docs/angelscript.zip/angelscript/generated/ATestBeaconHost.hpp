/* Class: ATestBeaconHost 
 A beacon host used for taking reservations for an existing game session */ 
 class ATestBeaconHost : public AOnlineBeaconHostObject
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ATestBeaconHost ATestBeaconHost::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATestBeaconHost::StaticClass() {}
}
