/* Class: AVREditorAvatarActor 
 Avatar Actor */ 
 class AVREditorAvatarActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AVREditorAvatarActor AVREditorAvatarActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AVREditorAvatarActor::StaticClass() {}
}
