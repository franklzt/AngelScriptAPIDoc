/* Class: AAutoRTFMTestActor 
  */ 
 class AAutoRTFMTestActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AAutoRTFMTestActor AAutoRTFMTestActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AAutoRTFMTestActor::StaticClass() {}
}
