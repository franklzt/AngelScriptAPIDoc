/* Class: EAnimExecutionContextConversionResult 
  */ 
 class EAnimExecutionContextConversionResult
{
public:
}
/* Enum: EAnimExecutionContextConversionResult 
 
    Succeeded - Enum
    Failed - Enum
    EAnimExecutionContextConversionResult_MAX - Enum */ 
 enum EAnimExecutionContextConversionResult { 
Succeeded,
Failed,
EAnimExecutionContextConversionResult_MAX, 
}