/* Class: EAISenseNotifyType 
  */ 
 class EAISenseNotifyType
{
public:
}
/* Enum: EAISenseNotifyType 
 
    OnEveryPerception - Enum
    OnPerceptionChange - Enum
    EAISenseNotifyType_MAX - Enum */ 
 enum EAISenseNotifyType { 
OnEveryPerception,
OnPerceptionChange,
EAISenseNotifyType_MAX, 
}