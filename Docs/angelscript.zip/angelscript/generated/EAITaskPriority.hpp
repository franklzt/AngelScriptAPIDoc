/* Class: EAITaskPriority 
  */ 
 class EAITaskPriority
{
public:
}
/* Enum: EAITaskPriority 
 
    Lowest - Enum
    Low - Enum
    AutonomousAI - Enum
    High - Enum
    Ultimate - Enum
    EAITaskPriority_MAX - Enum */ 
 enum EAITaskPriority { 
Lowest,
Low,
AutonomousAI,
High,
Ultimate,
EAITaskPriority_MAX, 
}