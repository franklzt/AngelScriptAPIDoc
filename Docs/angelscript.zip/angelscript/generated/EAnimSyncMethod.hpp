/* Class: EAnimSyncMethod 
  */ 
 class EAnimSyncMethod
{
public:
}
/* Enum: EAnimSyncMethod 
 
    DoNotSync - Enum
    SyncGroup - Enum
    Graph - Enum
    EAnimSyncMethod_MAX - Enum */ 
 enum EAnimSyncMethod { 
DoNotSync,
SyncGroup,
Graph,
EAnimSyncMethod_MAX, 
}