/* Class: EAnimNotifyEventType 
  */ 
 class EAnimNotifyEventType
{
public:
}
/* Enum: EAnimNotifyEventType 
 
    Begin - Enum
    End - Enum
    EAnimNotifyEventType_MAX - Enum */ 
 enum EAnimNotifyEventType { 
Begin,
End,
EAnimNotifyEventType_MAX, 
}