/* Class: ACLVisualFidelity 
  */ 
 class ACLVisualFidelity
{
public:
}
/* Enum: ACLVisualFidelity 
 
    Highest - Enum
    Medium - Enum
    Lowest - Enum
    ACLVisualFidelity_MAX - Enum */ 
 enum ACLVisualFidelity { 
Highest,
Medium,
Lowest,
ACLVisualFidelity_MAX, 
}