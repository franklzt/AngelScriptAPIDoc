/* Class: EAnalysisLocomotionAxis 
  */ 
 class EAnalysisLocomotionAxis
{
public:
}
/* Enum: EAnalysisLocomotionAxis 
 
    Speed - Enum
    Direction - Enum
    ForwardSpeed - Enum
    RightwardSpeed - Enum
    UpwardSpeed - Enum
    ForwardSlope - Enum
    RightwardSlope - Enum
    EAnalysisLocomotionAxis_MAX - Enum */ 
 enum EAnalysisLocomotionAxis { 
Speed,
Direction,
ForwardSpeed,
RightwardSpeed,
UpwardSpeed,
ForwardSlope,
RightwardSlope,
EAnalysisLocomotionAxis_MAX, 
}