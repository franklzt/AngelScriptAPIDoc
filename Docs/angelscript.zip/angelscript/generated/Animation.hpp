/* Class: Animation 
  */ 
 class Animation
{
public:
// Group: AnimationBlueprintLibrary|Additive

/* Function: SetAdditiveAnimationType 
 Sets the Additive Animation type for the given Animation Sequence */
static void Animation::SetAdditiveAnimationType(UAnimSequence AnimationSequence, EAdditiveAnimationType AdditiveAnimationType) {}
/* Function: GetAdditiveAnimationType 
 Retrieves the Additive Animation type for the given Animation Sequence */
static void Animation::GetAdditiveAnimationType(const UAnimSequence AnimationSequence, EAdditiveAnimationType& AdditiveAnimationType) {}
/* Function: GetAdditiveBasePoseType 
 Retrieves the Additive Base Pose type for the given Animation Sequence */
static void Animation::GetAdditiveBasePoseType(const UAnimSequence AnimationSequence, EAdditiveBasePoseType& AdditiveBasePoseType) {}
/* Function: SetAdditiveBasePoseType 
 Sets the Additive Base Pose type for the given Animation Sequence */
static void Animation::SetAdditiveBasePoseType(UAnimSequence AnimationSequence, EAdditiveBasePoseType AdditiveBasePoseType) {}
// Group: AnimationBlueprintLibrary|Animation

/* Function: SetRateScale 
 Sets the (Play) Rate Scale for the given Animation Sequence */
static void Animation::SetRateScale(UAnimSequenceBase AnimationSequenceBase, float32 RateScale) {}
/* Function: GetNumKeys 
 Retrieves the number of animation keys for the given Animation Sequence */
static void Animation::GetNumKeys(const UAnimSequenceBase AnimationSequenceBase, int& NumKeys) {}
/* Function: GetNumFrames 
 Retrieves the number of animation frames for the given Animation Sequence */
static void Animation::GetNumFrames(const UAnimSequenceBase AnimationSequenceBase, int& NumFrames) {}
/* Function: GetAnimationCurveNames 
 Retrieves the Names of the individual float curves for the given Animation Sequence */
static void Animation::GetAnimationCurveNames(const UAnimSequenceBase AnimationSequenceBase, ERawCurveTrackTypes CurveType, TArray<FName>& CurveNames) {}
/* Function: GetSequenceLength 
 Retrieves the Length of the given Animation Sequence */
static void Animation::GetSequenceLength(const UAnimSequenceBase AnimationSequenceBase, float32& Length) {}
/* Function: GetAnimationTrackNames 
 Retrieves the Names of the individual ATracks for the given Animation Sequence */
static void Animation::GetAnimationTrackNames(const UAnimSequenceBase AnimationSequenceBase, TArray<FName>& TrackNames) {}
/* Function: ExtractRootTrackTransform 
 Gets the root transform from the raw animation at Time */
static FTransform Animation::ExtractRootTrackTransform(const UAnimSequenceBase AnimationSequenceBase, float32 Time) {}
/* Function: GetRateScale 
 Retrieves the (Play) Rate Scale of the given Animation Sequence */
static void Animation::GetRateScale(const UAnimSequenceBase AnimationSequenceBase, float32& RateScale) {}
// Group: AnimationBlueprintLibrary|AnimationNotifies

/* Function: RemoveAllAnimationNotifyTracks 
 Removes All Animation Notify Tracks from Animation Sequence */
static void Animation::RemoveAllAnimationNotifyTracks(UAnimSequenceBase AnimationSequenceBase) {}
/* Function: GetAnimationNotifyTrackNames 
 Retrieves all Unique Animation Notify Track Names found within the given Animation Sequence */
static void Animation::GetAnimationNotifyTrackNames(const UAnimSequenceBase AnimationSequenceBase, TArray<FName>& TrackNames) {}
/* Function: RemoveAnimationNotifyTrack 
 Removes an Animation Notify Track from Animation Sequence by Name */
static void Animation::RemoveAnimationNotifyTrack(UAnimSequenceBase AnimationSequenceBase, FName NotifyTrackName) {}
/* Function: GetAnimNotifyEventTriggerTime 
 Returns the actual trigger time for a NotifyEvent */
static float32 Animation::GetAnimNotifyEventTriggerTime(FAnimNotifyEvent NotifyEvent) {}
/* Function: AddAnimationNotifyTrack 
 Adds an Animation Notify Track to the Animation Sequence */
static void Animation::AddAnimationNotifyTrack(UAnimSequenceBase AnimationSequenceBase, FName NotifyTrackName, FLinearColor TrackColor = FLinearColor ( 1.000000 , 1.000000 , 1.000000 , 1.000000 )) {}
/* Function: GetAnimNotifyEventDuration 
 Returns the duration for a NotifyEvent, only non-zero for Anim Notify States */
static float32 Animation::GetAnimNotifyEventDuration(FAnimNotifyEvent NotifyEvent) {}
// Group: AnimationBlueprintLibrary|Bones

/* Function: RemoveBoneAnimation 
 Removes an Animation Curve by Name from the given Animation Sequence (Raw Animation Curves [Names] may not be removed from the Skeleton)

Parameters:
    AnimationSequence - : AnimSequence
    BoneName - : Name of bone track user wants to remove
    bIncludeChildren - : true if user wants to include all children of BoneName
    bFinalize - : If you set this to true, it will trigger compression. If you set bFinalize to be false, you'll have to manually trigger Finalize. */
static void Animation::RemoveBoneAnimation(UAnimSequence AnimationSequence, FName BoneName, bool bIncludeChildren = true, bool bFinalize = true) {}
// Group: AnimationBlueprintLibrary|Compression

/* Function: SetCurveCompressionSettings 
 Sets the Curve Compression Settings for the given Animation Sequence */
static void Animation::SetCurveCompressionSettings(UAnimSequence AnimationSequence, UAnimCurveCompressionSettings CompressionSettings) {}
/* Function: GetVariableFrameStrippingSettings 
 Retrieves the Variable Frame Stripping Settings for the given Animation Sequence */
static void Animation::GetVariableFrameStrippingSettings(const UAnimSequence AnimationSequence, UVariableFrameStrippingSettings& VariableFrameStrippingSettings) {}
/* Function: GetCurveCompressionSettings 
 Retrieves the Curve Compression Settings for the given Animation Sequence */
static void Animation::GetCurveCompressionSettings(const UAnimSequence AnimationSequence, UAnimCurveCompressionSettings& CompressionSettings) {}
/* Function: GetBoneCompressionSettings 
 Retrieves the Bone Compression Settings for the given Animation Sequence */
static void Animation::GetBoneCompressionSettings(const UAnimSequence AnimationSequence, UAnimBoneCompressionSettings& CompressionSettings) {}
/* Function: SetBoneCompressionSettings 
 Sets the Bone Compression Settings for the given Animation Sequence */
static void Animation::SetBoneCompressionSettings(UAnimSequence AnimationSequence, UAnimBoneCompressionSettings CompressionSettings) {}
/* Function: SetVariableFrameStrippingSettings 
 Sets the Variable Frame Stripping Settings for the given Animation Sequence */
static void Animation::SetVariableFrameStrippingSettings(UAnimSequence AnimationSequence, UVariableFrameStrippingSettings VariableFrameStrippingSettings) {}
// Group: AnimationBlueprintLibrary|Curves

/* Function: AddVectorCurveKeys 
 Adds a multiple of Vector Keys to the specified Animation Curve inside of the given Animation Sequence */
static void Animation::AddVectorCurveKeys(UAnimSequenceBase AnimationSequenceBase, FName CurveName, TArray<float32> Times, TArray<FVector> Vectors) {}
/* Function: AddTransformationCurveKeys 
 Adds a multiple of Transformation Keys to the specified Animation Curve inside of the given Animation Sequence */
static void Animation::AddTransformationCurveKeys(UAnimSequenceBase AnimationSequenceBase, FName CurveName, TArray<float32> Times, TArray<FTransform> Transforms) {}
/* Function: AddTransformationCurveKey 
 Adds a Transformation Key to the specified Animation Curve inside of the given Animation Sequence */
static void Animation::AddTransformationCurveKey(UAnimSequenceBase AnimationSequenceBase, FName CurveName, float32 Time, FTransform Transform) {}
/* Function: FinalizeBoneAnimation 
  */
static void Animation::FinalizeBoneAnimation(UAnimSequence AnimationSequence) {}
/* Function: AddVectorCurveKey 
 Adds a Vector Key to the specified Animation Curve inside of the given Animation Sequence */
static void Animation::AddVectorCurveKey(UAnimSequenceBase AnimationSequenceBase, FName CurveName, float32 Time, const FVector Vector) {}
/* Function: AddFloatCurveKeys 
 Adds a multiple of Float Keys to the specified Animation Curve inside of the given Animation Sequence */
static void Animation::AddFloatCurveKeys(UAnimSequenceBase AnimationSequenceBase, FName CurveName, TArray<float32> Times, TArray<float32> Values) {}
/* Function: GetVectorKeys 
 Retrieves, a multiple of, Vector Key(s) from the specified Animation Curve inside of the given Animation Sequence */
static void Animation::GetVectorKeys(UAnimSequenceBase AnimationSequenceBase, FName CurveName, TArray<float32>& Times, TArray<FVector>& Values) {}
/* Function: CopyAnimationCurveNamesToSkeleton 
 Ensures that any curve names that do not exist on the NewSkeleton are added to it, in which case the SmartName on the actual curve itself will also be updated */
static void Animation::CopyAnimationCurveNamesToSkeleton(USkeleton OldSkeleton, USkeleton NewSkeleton, UAnimSequenceBase SequenceBase, ERawCurveTrackTypes CurveType) {}
/* Function: DoesCurveExist 
 Checks whether or not the given Curve Name exist on the Skeleton referenced by the given Animation Sequence */
static bool Animation::DoesCurveExist(UAnimSequenceBase AnimationSequenceBase, FName CurveName, ERawCurveTrackTypes CurveType) {}
/* Function: AddFloatCurveKey 
 Adds a Float Key to the specified Animation Curve inside of the given Animation Sequence */
static void Animation::AddFloatCurveKey(UAnimSequenceBase AnimationSequenceBase, FName CurveName, float32 Time, float32 Value) {}
/* Function: AddCurve 
 Adds an Animation Curve by Type and Name to the given Animation Sequence */
static void Animation::AddCurve(UAnimSequenceBase AnimationSequenceBase, FName CurveName, ERawCurveTrackTypes CurveType = ERawCurveTrackTypes :: RCT_Float, bool bMetaDataCurve = false) {}
/* Function: RemoveCurve 
 Removes an Animation Curve by Name from the given Animation Sequence (Raw Animation Curves [Names] may not be removed from the Skeleton) */
static void Animation::RemoveCurve(UAnimSequenceBase AnimationSequenceBase, FName CurveName, bool bRemoveNameFromSkeleton = false) {}
/* Function: GetFloatValueAtTime 
 Retrieves an evaluated float value for a given time from the specified Animation Curve inside of the given Animation Sequence */
static float32 Animation::GetFloatValueAtTime(UAnimSequenceBase AnimationSequenceBase, FName CurveName, float32 Time) {}
/* Function: RemoveAllBoneAnimation 
 Removes all Animation Bone Track Data from the given Animation Sequence */
static void Animation::RemoveAllBoneAnimation(UAnimSequence AnimationSequence) {}
/* Function: GetFloatKeys 
 Retrieves, a multiple of, Float Key(s) from the specified Animation Curve inside of the given Animation Sequence */
static void Animation::GetFloatKeys(UAnimSequenceBase AnimationSequenceBase, FName CurveName, TArray<float32>& Times, TArray<float32>& Values) {}
/* Function: GetTransformationKeys 
 Retrieves, a multiple of, Transformation Key(s) from the specified Animation Curve inside of the given Animation Sequence */
static void Animation::GetTransformationKeys(UAnimSequenceBase AnimationSequenceBase, FName CurveName, TArray<float32>& Times, TArray<FTransform>& Values) {}
/* Function: RemoveAllCurveData 
 Removes all Animation Curve Data from the given Animation Sequence (Raw Animation Curves [Names] may not be removed from the Skeleton) */
static void Animation::RemoveAllCurveData(UAnimSequenceBase AnimationSequenceBase) {}
// Group: AnimationBlueprintLibrary|Helpers

/* Function: EvaluateRootBoneTimecodeSubframeAttributeAtTime 
 Evaluates the subframe timecode attribute (e.g. "TCSubframe") of the root bone and returns the resulting value.

Since the subframe component of FFrameTime is clamped to the range [0.0, 1.0), it cannot accurately represent the use
case where the timecode metadata represents subframe values as whole numbered subframes instead of as a percentage of a
frame the way the engine does. The subframe component of the FQualifiedFrameTime returned by
EvaluateRootBoneTimecodeAttributesAtTime() may not reflect the authored subframe metadata in that case.

This function allows access to the subframe values that were actually authored in the timecode metadata.

Returns:
    : true if the root bone had a subframe timecode attribute that could be evaluated and a value was set, or false otherwise. */
static bool Animation::EvaluateRootBoneTimecodeSubframeAttributeAtTime(const UAnimSequenceBase AnimationSequenceBase, float32 EvalTime, float32& OutSubframe) {}
/* Function: FindBonePathToRoot 
 Finds the Bone Path from the given Bone to the Root Bone */
static void Animation::FindBonePathToRoot(const UAnimSequenceBase AnimationSequenceBase, FName BoneName, TArray<FName>& BonePath) {}
/* Function: GetFrameAtTime 
 Retrieves the Frame Index at the specified Time Value for the given Animation Sequence */
static void Animation::GetFrameAtTime(const UAnimSequenceBase AnimationSequenceBase, float32 Time, int& Frame) {}
/* Function: EvaluateRootBoneTimecodeAttributesAtTime 
 Evaluates timecode attributes (e.g. "TCFrame", "TCSecond", etc.) of the root bone and returns the resulting qualified frame time.

Returns:
    : true if the root bone had timecode attributes that could be evaluated and a qualified frame time was set, or false otherwise. */
static bool Animation::EvaluateRootBoneTimecodeAttributesAtTime(const UAnimSequenceBase AnimationSequenceBase, float32 EvalTime, FQualifiedFrameTime& OutQualifiedFrameTime) {}
/* Function: EvaluateBoneTimecodeAndSlateAttributesAtTime 
 Evaluates timecode attributes (e.g. "TCFrame", "TCSecond", etc.) and TCSlate of the root bone and returns the resulting qualified frame time.

Returns:
    : true if the root bone had timecode attributes that could be evaluated and a qualified frame time was set, or false otherwise. */
static bool Animation::EvaluateBoneTimecodeAndSlateAttributesAtTime(const FName BoneName, const UAnimSequenceBase AnimationSequenceBase, float32 EvalTime, FQualifiedFrameTime& OutQualifiedFrameTime, FString& Slate) {}
/* Function: IsValidAnimNotifyTrackName 
 Checks whether or not the given Track Name is a valid Animation Notify Track in the Animation Sequence */
static bool Animation::IsValidAnimNotifyTrackName(const UAnimSequenceBase AnimationSequenceBase, FName NotifyTrackName) {}
/* Function: IsValidRawAnimationTrackName 
 Checks whether or not the given Animation Track Name is contained within the Animation Sequence */
static bool Animation::IsValidRawAnimationTrackName(const UAnimSequenceBase AnimationSequenceBase, const FName TrackName) {}
/* Function: IsValidAnimationSyncMarkerName 
 Checks whether or not the given Marker Name is a valid Animation Sync Marker Name */
static bool Animation::IsValidAnimationSyncMarkerName(const UAnimSequence AnimationSequence, FName MarkerName) {}
/* Function: IsValidTime 
 Checks whether or not the given Time Value lies within the given Animation Sequence's Length */
static void Animation::IsValidTime(const UAnimSequenceBase AnimationSequenceBase, float32 Time, bool& IsValid) {}
/* Function: GetTimeAtFrame 
 Retrieves the Time Value at the specified Frame Indexfor the given Animation Sequence */
static void Animation::GetTimeAtFrame(const UAnimSequenceBase AnimationSequenceBase, int Frame, float32& Time) {}
// Group: AnimationBlueprintLibrary|Interpolation

/* Function: GetAnimationInterpolationType 
 Retrieves the Animation Interpolation type for the given Animation Sequence */
static void Animation::GetAnimationInterpolationType(const UAnimSequence AnimationSequence, EAnimInterpolationType& InterpolationType) {}
/* Function: SetAnimationInterpolationType 
 Sets the Animation Interpolation type for the given Animation Sequence */
static void Animation::SetAnimationInterpolationType(UAnimSequence AnimationSequence, EAnimInterpolationType InterpolationType) {}
// Group: AnimationBlueprintLibrary|MarkerSyncing

/* Function: RemoveAnimationSyncMarkersByName 
 Removes All Animation Sync Marker found within the Animation Sequence whose name matches MarkerName, and returns the number of removed instances */
static int Animation::RemoveAnimationSyncMarkersByName(UAnimSequence AnimationSequence, FName MarkerName) {}
/* Function: GetAnimationSyncMarkersForTrack 
 Retrieves all Animation Sync Markers for the given Notify Track Name from the given Animation Sequence */
static void Animation::GetAnimationSyncMarkersForTrack(const UAnimSequence AnimationSequence, FName NotifyTrackName, TArray<FAnimSyncMarker>& Markers) {}
/* Function: RemoveAnimationSyncMarkersByTrack 
 Removes All Animation Sync Marker found within the Animation Sequence that belong to the specific Notify Track, and returns the number of removed instances */
static int Animation::RemoveAnimationSyncMarkersByTrack(UAnimSequence AnimationSequence, FName NotifyTrackName) {}
/* Function: GetAnimationSyncMarkers 
 Retrieves all the Animation Sync Markers for the given Animation Sequence */
static void Animation::GetAnimationSyncMarkers(const UAnimSequence AnimationSequence, TArray<FAnimSyncMarker>& Markers) {}
/* Function: RemoveAllAnimationSyncMarkers 
 Removes All Animation Sync Markers found within the Animation Sequence, and returns the number of removed instances */
static void Animation::RemoveAllAnimationSyncMarkers(UAnimSequence AnimationSequence) {}
/* Function: GetUniqueMarkerNames 
 Retrieves all the Unique Names for the Animation Sync Markers contained by the given Animation Sequence */
static void Animation::GetUniqueMarkerNames(const UAnimSequence AnimationSequence, TArray<FName>& MarkerNames) {}
/* Function: AddAnimationSyncMarker 
 Adds an Animation Sync Marker to Notify track in the given Animation with the corresponding Marker Name and Time */
static void Animation::AddAnimationSyncMarker(UAnimSequence AnimationSequence, FName MarkerName, float32 Time, FName NotifyTrackName) {}
// Group: AnimationBlueprintLibrary|MetaData

/* Function: GetMetaData 
 Retrieves all Meta Data Instances from the given Animation Asset */
static void Animation::GetMetaData(const UAnimationAsset AnimationAsset, TArray<UAnimMetaData>& MetaData) {}
/* Function: ContainsMetaDataOfClass 
 Checks whether or not the given Animation Asset contains Meta Data Instance of the specified Meta Data Class */
static bool Animation::ContainsMetaDataOfClass(const UAnimationAsset AnimationAsset, TSubclassOf<UAnimMetaData> MetaDataClass) {}
/* Function: AddMetaData 
 Creates and Adds an instance of the specified MetaData Class to the given Animation Asset */
static void Animation::AddMetaData(UAnimationAsset AnimationAsset, TSubclassOf<UAnimMetaData> MetaDataClass, UAnimMetaData& MetaDataInstance) {}
/* Function: AddMetaDataObject 
 Adds an instance of the specified MetaData Class to the given Animation Asset (requires MetaDataObject's outer to be the Animation Asset) */
static void Animation::AddMetaDataObject(UAnimationAsset AnimationAsset, UAnimMetaData MetaDataObject) {}
/* Function: GetMetaDataOfClass 
 Retrieves all Meta Data Instances from the given Animation Asset */
static void Animation::GetMetaDataOfClass(const UAnimationAsset AnimationAsset, TSubclassOf<UAnimMetaData> MetaDataClass, TArray<UAnimMetaData>& MetaDataOfClass) {}
/* Function: RemoveMetaDataOfClass 
 Removes all Meta Data Instance of the specified Class from the given Animation Asset */
static void Animation::RemoveMetaDataOfClass(UAnimationAsset AnimationAsset, TSubclassOf<UAnimMetaData> MetaDataClass) {}
/* Function: RemoveMetaData 
 Removes the specified Meta Data Instance from the given Animation Asset */
static void Animation::RemoveMetaData(UAnimationAsset AnimationAsset, UAnimMetaData MetaDataObject) {}
/* Function: RemoveAllMetaData 
 Removes all Meta Data from the given Animation Asset */
static void Animation::RemoveAllMetaData(UAnimationAsset AnimationAsset) {}
// Group: AnimationBlueprintLibrary|Montage

/* Function: GetMontageSlotNames 
 Retrieves the Names of the Animation Slots used in the given Montage */
static void Animation::GetMontageSlotNames(const UAnimMontage AnimationMontage, TArray<FName>& SlotNames) {}
// Group: AnimationBlueprintLibrary|NotifyEvents

/* Function: GetAnimationNotifyEventsForTrack 
 Retrieves all Animation Notify Events for the given Notify Track Name from the given Animation Sequence */
static void Animation::GetAnimationNotifyEventsForTrack(const UAnimSequenceBase AnimationSequenceBase, FName NotifyTrackName, TArray<FAnimNotifyEvent>& Events) {}
/* Function: RemoveAnimationNotifyEventsByName 
 Removes Animation Notify Events found by Name within the Animation Sequence, and returns the number of removed name instances */
static int Animation::RemoveAnimationNotifyEventsByName(UAnimSequenceBase AnimationSequenceBase, FName NotifyName) {}
/* Function: GetAnimationNotifyEventNames 
 Retrieves all Unique Animation Notify Events found within the given Animation Sequence */
static void Animation::GetAnimationNotifyEventNames(const UAnimSequenceBase AnimationSequenceBase, TArray<FName>& EventNames) {}
/* Function: ReplaceAnimNotifyStates 
 Replaces animation notifies in the specified Animation Sequence */
static void Animation::ReplaceAnimNotifyStates(UAnimSequenceBase AnimationSequenceBase, TSubclassOf<UAnimNotifyState> OldNotifyClass, TSubclassOf<UAnimNotifyState> NewNotifyClass, FOnNotifyStateReplaced OnNotifyStateReplaced = FOnNotifyStateReplaced ( )) {}
/* Function: AddAnimationNotifyEvent 
 Adds an Animation Notify Event to Notify track in the given Animation with the given Notify creation data */
static const UAnimNotify Animation::AddAnimationNotifyEvent(UAnimSequenceBase AnimationSequenceBase, FName NotifyTrackName, float32 StartTime, TSubclassOf<UAnimNotify> NotifyClass) {}
/* Function: RemoveAnimationNotifyEventsByTrack 
 Removes Animation Notify Events found by Track within the Animation Sequence, and returns the number of removed name instances */
static int Animation::RemoveAnimationNotifyEventsByTrack(UAnimSequenceBase AnimationSequenceBase, FName NotifyTrackName) {}
/* Function: ReplaceAnimNotifies 
 Replaces animation notifies in the specified Animation Sequence */
static void Animation::ReplaceAnimNotifies(UAnimSequenceBase AnimationSequenceBase, TSubclassOf<UAnimNotify> OldNotifyClass, TSubclassOf<UAnimNotify> NewNotifyClass, FOnNotifyReplaced OnNotifyReplaced = FOnNotifyReplaced ( )) {}
/* Function: AddAnimationNotifyEventObject 
 Adds an the specific Animation Notify to the Animation Sequence (requires Notify's outer to be the Animation Sequence) */
static void Animation::AddAnimationNotifyEventObject(UAnimSequenceBase AnimationSequenceBase, float32 StartTime, const UAnimNotify Notify, FName NotifyTrackName) {}
/* Function: AddAnimationNotifyStateEvent 
 Adds an Animation Notify State Event to Notify track in the given Animation with the given Notify State creation data */
static const UAnimNotifyState Animation::AddAnimationNotifyStateEvent(UAnimSequenceBase AnimationSequenceBase, FName NotifyTrackName, float32 StartTime, float32 Duration, TSubclassOf<UAnimNotifyState> NotifyStateClass) {}
/* Function: GetAnimationNotifyEvents 
 Retrieves all Animation Notify Events found within the given Animation Sequence */
static void Animation::GetAnimationNotifyEvents(const UAnimSequenceBase AnimationSequenceBase, TArray<FAnimNotifyEvent>& NotifyEvents) {}
/* Function: CopyAnimNotifiesFromSequence 
 Copies animation notifies from Src Animation Sequence to Dest. Creates anim notify tracks as necessary. Returns true on success. */
static void Animation::CopyAnimNotifiesFromSequence(UAnimSequenceBase SourceAnimationSequenceBase, UAnimSequenceBase DestinationAnimationSequenceBase, bool bDeleteExistingNotifies = false) {}
/* Function: AddAnimationNotifyStateEventObject 
 Adds an the specific Animation Notify State to the Animation Sequence (requires Notify State's outer to be the Animation Sequence) */
static void Animation::AddAnimationNotifyStateEventObject(UAnimSequenceBase AnimationSequenceBase, float32 StartTime, float32 Duration, const UAnimNotifyState NotifyState, FName NotifyTrackName) {}
// Group: AnimationBlueprintLibrary|Pose

/* Function: GetBonePoseForFrame 
  */
static void Animation::GetBonePoseForFrame(const UAnimSequenceBase AnimationSequenceBase, FName BoneName, int Frame, bool bExtractRootMotion, FTransform& Pose) {}
/* Function: GetBonePosesForTime 
  */
static void Animation::GetBonePosesForTime(const UAnimSequenceBase AnimationSequenceBase, TArray<FName> BoneNames, float32 Time, bool bExtractRootMotion, TArray<FTransform>& Poses, const USkeletalMesh PreviewMesh = nullptr) {}
/* Function: GetBonePosesForFrame 
  */
static void Animation::GetBonePosesForFrame(const UAnimSequenceBase AnimationSequenceBase, TArray<FName> BoneNames, int Frame, bool bExtractRootMotion, TArray<FTransform>& Poses, const USkeletalMesh PreviewMesh = nullptr) {}
/* Function: GetBonePoseForTime 
  */
static void Animation::GetBonePoseForTime(const UAnimSequenceBase AnimationSequenceBase, FName BoneName, float32 Time, bool bExtractRootMotion, FTransform& Pose) {}
// Group: AnimationBlueprintLibrary|RawTrackData

/* Function: GetRawTrackData 
  */
static void Animation::GetRawTrackData(const UAnimSequenceBase AnimationSequenceBase, const FName TrackName, TArray<FVector>& PositionKeys, TArray<FQuat>& RotationKeys, TArray<FVector>& ScalingKeys) {}
/* Function: GetRawTrackRotationData 
  */
static void Animation::GetRawTrackRotationData(const UAnimSequenceBase AnimationSequenceBase, const FName TrackName, TArray<FQuat>& RotationData) {}
/* Function: GetRawTrackScaleData 
  */
static void Animation::GetRawTrackScaleData(const UAnimSequenceBase AnimationSequenceBase, const FName TrackName, TArray<FVector>& ScaleData) {}
/* Function: GetRawTrackPositionData 
  */
static void Animation::GetRawTrackPositionData(const UAnimSequenceBase AnimationSequenceBase, const FName TrackName, TArray<FVector>& PositionData) {}
// Group: AnimationBlueprintLibrary|RootMotion

/* Function: IsRootMotionEnabled 
 Checks whether or not Root Motion is Enabled for the given Animation Sequence */
static bool Animation::IsRootMotionEnabled(const UAnimSequence AnimationSequence) {}
/* Function: GetRootMotionLockType 
 Retrieves the Root Motion Lock Type for the given Animation Sequence */
static void Animation::GetRootMotionLockType(const UAnimSequence AnimationSequence, ERootMotionRootLock& LockType) {}
/* Function: IsRootMotionLockForced 
 Checks whether or not Root Motion locking is Forced for the given Animation Sequence */
static bool Animation::IsRootMotionLockForced(const UAnimSequence AnimationSequence) {}
/* Function: SetRootMotionLockType 
 Sets the Root Motion Lock Type for the given Animation Sequence */
static void Animation::SetRootMotionLockType(UAnimSequence AnimationSequence, ERootMotionRootLock RootMotionLockType) {}
/* Function: SetRootMotionEnabled 
 Sets whether or not Root Motion is Enabled for the given Animation Sequence */
static void Animation::SetRootMotionEnabled(UAnimSequence AnimationSequence, bool bEnabled) {}
/* Function: SetIsRootMotionLockForced 
 Sets whether or not Root Motion locking is Forced for the given Animation Sequence */
static void Animation::SetIsRootMotionLockForced(UAnimSequence AnimationSequence, bool bForced) {}
// Group: AnimationBlueprintLibrary|Skeleton

/* Function: DoesBoneNameExist 
 Checks whether or not the given Bone Name exist on the Skeleton referenced by the given Animation Sequence */
static void Animation::DoesBoneNameExist(UAnimSequence AnimationSequence, FName BoneName, bool& bExists) {}
// Group: AnimationBlueprintLibrary|VirtualBones

/* Function: RemoveVirtualBone 
 Removes a Virtual Bone with the specified Bone Name from the given Animation Sequence */
static void Animation::RemoveVirtualBone(const UAnimSequence AnimationSequence, FName VirtualBoneName) {}
/* Function: RemoveVirtualBones 
 Removes Virtual Bones with the specified Bone Names from the given Animation Sequence */
static void Animation::RemoveVirtualBones(const UAnimSequence AnimationSequence, TArray<FName> VirtualBoneNames) {}
/* Function: RemoveAllVirtualBones 
 Removes all Virtual Bones from the given Animation Sequence */
static void Animation::RemoveAllVirtualBones(const UAnimSequence AnimationSequence) {}
/* Function: AddVirtualBone 
 Adds a Virtual Bone between the Source and Target Bones to the given Animation Sequence */
static void Animation::AddVirtualBone(const UAnimSequence AnimationSequence, FName SourceBoneName, FName TargetBoneName, FName& VirtualBoneName) {}
}
