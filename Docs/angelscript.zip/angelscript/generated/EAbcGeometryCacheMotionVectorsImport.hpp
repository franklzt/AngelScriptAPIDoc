/* Class: EAbcGeometryCacheMotionVectorsImport 
  */ 
 class EAbcGeometryCacheMotionVectorsImport
{
public:
}
/* Enum: EAbcGeometryCacheMotionVectorsImport 
 
    NoMotionVectors - Enum
    ImportAbcVelocitiesAsMotionVectors - Enum
    CalculateMotionVectorsDuringImport - Enum
    EAbcGeometryCacheMotionVectorsImport_MAX - Enum */ 
 enum EAbcGeometryCacheMotionVectorsImport { 
NoMotionVectors,
ImportAbcVelocitiesAsMotionVectors,
CalculateMotionVectorsDuringImport,
EAbcGeometryCacheMotionVectorsImport_MAX, 
}