/* Class: EBoneAxis 
  */ 
 class EBoneAxis
{
public:
}
/* Enum: EBoneAxis 
 
    BA_X - Enum
    BA_Y - Enum
    BA_Z - Enum
    BA_MAX - Enum */ 
 enum EBoneAxis { 
BA_X,
BA_Y,
BA_Z,
BA_MAX, 
}