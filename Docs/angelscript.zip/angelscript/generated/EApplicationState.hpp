/* Class: EApplicationState 
  */ 
 class EApplicationState
{
public:
}
/* Enum: EApplicationState 
 
    Unknown - Enum
    Inactive - Enum
    Background - Enum
    Active - Enum
    EApplicationState_MAX - Enum */ 
 enum EApplicationState { 
Unknown,
Inactive,
Background,
Active,
EApplicationState_MAX, 
}