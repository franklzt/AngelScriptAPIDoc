/* Class: ACLVisualFidelityChangeResult 
  */ 
 class ACLVisualFidelityChangeResult
{
public:
}
/* Enum: ACLVisualFidelityChangeResult 
 
    Dispatched - Enum
    Completed - Enum
    Failed - Enum
    ACLVisualFidelityChangeResult_MAX - Enum */ 
 enum ACLVisualFidelityChangeResult { 
Dispatched,
Completed,
Failed,
ACLVisualFidelityChangeResult_MAX, 
}