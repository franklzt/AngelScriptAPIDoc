/* Class: ANiagaraLensEffectBase 
 Niagara equivalent of AEmitterCameraLensEffectBase.
This class is supported by APlayerCameraManager (via ICameraLensEffectInterface) as a camera lens effect. */ 
 class ANiagaraLensEffectBase : public ANiagaraActor
{
public:
// Group: Effect Activation

/* Variable: EmittersToTreatAsSame 
 If an effect class in this array is currently playing, do not play this effect.
Useful for preventing multiple similar or expensive camera effects from playing simultaneously. */
TArray<TSubclassOf<AActor>> EmittersToTreatAsSame;
// Group: Positioning And Scale

/* Variable: BaseAuthoredFOV 
 FOVs that differ from this may cause adjustments in positioning.
This is the FOV which the effect was tested with. */
float32 BaseAuthoredFOV;
/* Variable: DesiredRelativeTransform 
 Relative offset from the camera (where X is out from the camera)
Might be changed slightly when the FOV is different than expected. */
FTransform DesiredRelativeTransform;
// Group: Functions

/* Function: SetbResetWhenRetriggered 
 When an instance of this effect is retriggered (because more than one instance is not allowed)
should the particle system be explicitly reset? Activate(bReset = true); */
void SetbResetWhenRetriggered(bool Value) {}
/* Function: SetbAllowMultipleInstances 
 Are multiple instances of the effect allowed?
When disabled, a single instance of the effect may be retriggered! */
void SetbAllowMultipleInstances(bool Value) {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANiagaraLensEffectBase ANiagaraLensEffectBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANiagaraLensEffectBase::StaticClass() {}
}
