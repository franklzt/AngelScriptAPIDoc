/* Class: EBaseCalculationType 
  */ 
 class EBaseCalculationType
{
public:
}
/* Enum: EBaseCalculationType 
 
    None - Enum
    PercentageBased - Enum
    FixedNumber - Enum
    NoCompression - Enum
    EBaseCalculationType_MAX - Enum */ 
 enum EBaseCalculationType { 
None,
PercentageBased,
FixedNumber,
NoCompression,
EBaseCalculationType_MAX, 
}