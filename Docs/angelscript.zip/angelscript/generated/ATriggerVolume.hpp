/* Class: ATriggerVolume 
  */ 
 class ATriggerVolume : public AVolume
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static ATriggerVolume ATriggerVolume::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATriggerVolume::StaticClass() {}
}
