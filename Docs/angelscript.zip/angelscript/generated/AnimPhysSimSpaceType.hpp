/* Class: AnimPhysSimSpaceType 
  */ 
 class AnimPhysSimSpaceType
{
public:
}
/* Enum: AnimPhysSimSpaceType 
 
    Component - Enum
    Actor - Enum
    World - Enum
    RootRelative - Enum
    BoneRelative - Enum
    AnimPhysSimSpaceType_MAX - Enum */ 
 enum AnimPhysSimSpaceType { 
Component,
Actor,
World,
RootRelative,
BoneRelative,
AnimPhysSimSpaceType_MAX, 
}