/* Class: EArchetype 
  */ 
 class EArchetype
{
public:
}
/* Enum: EArchetype 
 
    Asian - Enum
    Black - Enum
    Caucasian - Enum
    Hispanic - Enum
    Alien - Enum
    Other - Enum
    EArchetype_MAX - Enum */ 
 enum EArchetype { 
Asian,
Black,
Caucasian,
Hispanic,
Alien,
Other,
EArchetype_MAX, 
}