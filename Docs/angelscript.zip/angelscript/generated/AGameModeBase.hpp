/* Class: AGameModeBase 
 The GameModeBase defines the game being played. It governs the game rules, scoring, what actors
are allowed to exist in this game type, and who may enter the game.

It is only instanced on the server and will never exist on the client.

A GameModeBase actor is instantiated when the level is initialized for gameplay in
C++ UGameEngine::LoadMap().

The class of this GameMode actor is determined by (in order) either the URL ?game=xxx,
the GameMode Override value set in the World Settings, or the DefaultGameMode entry set
in the game's Project Settings.

@see https://docs.unrealengine.com/latest/INT/Gameplay/Framework/GameMode/index.html */ 
 class AGameModeBase : public AInfo
{
public:
// Group: Classes

/* Variable: ReplaySpectatorPlayerControllerClass 
 The PlayerController class used when spectating a network replay. */
TSubclassOf<APlayerController> ReplaySpectatorPlayerControllerClass;
/* Variable: GameSessionClass 
 Class of GameSession, which handles login approval and online game interface */
TSubclassOf<AGameSession> GameSessionClass;
/* Variable: GameStateClass 
 Class of GameState associated with this GameMode. */
TSubclassOf<AGameStateBase> GameStateClass;
/* Variable: PlayerControllerClass 
 The class of PlayerController to spawn for players logging in. */
TSubclassOf<APlayerController> PlayerControllerClass;
/* Variable: PlayerStateClass 
 A PlayerState of this class will be associated with every player to replicate relevant player information to all clients. */
TSubclassOf<APlayerState> PlayerStateClass;
/* Variable: HUDClass 
 HUD class this game uses. */
TSubclassOf<AHUD> HUDClass;
/* Variable: DefaultPawnClass 
 The default pawn class used by players. */
TSubclassOf<APawn> DefaultPawnClass;
/* Variable: SpectatorClass 
 The pawn class used by the PlayerController for players when spectating. */
TSubclassOf<ASpectatorPawn> SpectatorClass;
/* Variable: ServerStatReplicatorClass 
  */
TSubclassOf<AServerStatReplicator> ServerStatReplicatorClass;
// Group: Game

/* Variable: NumPlayers 
 Returns number of active human players, excluding spectators */
const int NumPlayers;
/* Variable: DefaultPlayerName 
 The default player name assigned to players that join with no name specified. */
FText DefaultPlayerName;
/* Variable: NumSpectators 
 Returns number of human players currently spectating */
const int NumSpectators;
// Group: GameMode

/* Variable: OptionsString 
 Save options string and parse it when needed */
FString OptionsString;
/* Variable: bUseSeamlessTravel 
 Whether the game perform map travels using SeamlessTravel() which loads in the background and doesn't disconnect clients */
bool bUseSeamlessTravel;
/* Variable: bStartPlayersAsSpectators 
 Whether players should immediately spawn when logging in, or stay as spectators until they manually spawn */
bool bStartPlayersAsSpectators;
/* Variable: bPauseable 
 Whether the game is pauseable. */
bool bPauseable;
/* Variable: GameNetDriverReplicationSystem 
 Can be used to request a specific replication system for a GameNetDriver that will replicate this game mode.
Leave to Default to use the game engine's preferred system.
Useful when migrating from one repsystem to another and a game mode does not fully support both repsystem yet. */
EReplicationSystem GameNetDriverReplicationSystem;
// Group: Classes

/* Function: GetDefaultPawnClassForController 
 Returns default pawn class for given controller */
UClass GetDefaultPawnClassForController(AController InController) {}
// Group: Game

/* Function: ChoosePlayerStart 
 Return the 'best' player start for this player to spawn from
Default implementation looks for a random unoccupied spot

Parameters:
    Player - is the controller for whom we are choosing a playerstart

Returns:
    AActor chosen as player start (usually a PlayerStart) */
AActor ChoosePlayerStart(AController Player) {}
/* Function: FindPlayerStart 
 Return the specific player start actor that should be used for the next spawn
This will either use a previously saved startactor, or calls ChoosePlayerStart

Parameters:
    Player - The AController for whom we are choosing a Player Start
    IncomingName - Specifies the tag of a Player Start to use

Returns:
    Actor chosen as player start (usually a PlayerStart) */
AActor FindPlayerStart(AController Player, FString IncomingName) {}
/* Function: ChangeName 
 Sets the name for a controller

Parameters:
    Controller - The controller of the player to change the name of
    NewName - The name to set the player to
    bNameChange - Whether the name is changing or if this is the first time it has been set */
void ChangeName(AController Controller, FString NewName, bool bNameChange) {}
/* Function: MustSpectate 
 Returns true if NewPlayerController may only join the server as a spectator. */
bool MustSpectate(APlayerController NewPlayerController) const {}
/* Function: GetNumPlayers 
 Returns number of active human players, excluding spectators */
int GetNumPlayers() {}
/* Function: GetNumSpectators 
 Returns number of human players currently spectating */
int GetNumSpectators() {}
/* Function: HandleStartingNewPlayer 
 Signals that a player is ready to enter the game, which may start it up */
void HandleStartingNewPlayer(APlayerController NewPlayer) {}
/* Function: HasMatchEnded 
 Returns true if the match can be considered ended */
bool HasMatchEnded() const {}
/* Function: HasMatchStarted 
 Returns true if the match start callbacks have been called */
bool HasMatchStarted() const {}
/* Function: InitializeHUDForPlayer 
 Initialize the AHUD object for a player. Games can override this to do something different */
void InitializeHUDForPlayer(APlayerController NewPlayer) {}
/* Function: InitStartSpot 
 Called from RestartPlayerAtPlayerStart, can be used to initialize the start spawn actor */
void InitStartSpot(AActor StartSpot, AController NewPlayer) {}
/* Function: K2_FindPlayerStart 
 Return the specific player start actor that should be used for the next spawn
This will either use a previously saved startactor, or calls ChoosePlayerStart

Parameters:
    Player - The AController for whom we are choosing a Player Start
    IncomingName - Specifies the tag of a Player Start to use

Returns:
    Actor chosen as player start (usually a PlayerStart) */
AActor K2_FindPlayerStart(AController Player, FString IncomingName = "") {}
/* Function: OnChangeName 
 Overridable event for GameMode blueprint to respond to a change name call

Parameters:
    NewName - The name to set the player to
    bNameChange - Whether the name is changing or if this is the first time it has been set */
void OnChangeName(AController Other, FString NewName, bool bNameChange) {}
/* Function: OnLogout 
 Implementable event when a Controller with a PlayerState leaves the game. */
void OnLogout(AController ExitingController) {}
/* Function: OnRestartPlayer 
 Implementable event called at the end of RestartPlayer */
void OnRestartPlayer(AController NewPlayer) {}
/* Function: OnSwapPlayerControllers 
 Called when a PlayerController is swapped to a new one during seamless travel */
void OnSwapPlayerControllers(APlayerController OldPC, APlayerController NewPC) {}
/* Function: OnPostLogin 
 Notification that a player has successfully logged in, and has been given a player controller */
void OnPostLogin(APlayerController NewPlayer) {}
/* Function: CanSpectate 
 Return whether Viewer is allowed to spectate from the point of view of ViewTarget. */
bool CanSpectate(APlayerController Viewer, APlayerState ViewTarget) {}
/* Function: PlayerCanRestart 
 Returns true if it's valid to call RestartPlayer. By default will call Player->CanRestartPlayer */
bool PlayerCanRestart(APlayerController Player) {}
/* Function: ResetLevel 
 Overridable function called when resetting level. This is used to reset the game state while staying in the same map
Default implementation calls Reset() on all actors except GameMode and Controllers */
void ResetLevel() {}
/* Function: RestartPlayer 
 Tries to spawn the player's pawn, at the location returned by FindPlayerStart */
void RestartPlayer(AController NewPlayer) {}
/* Function: RestartPlayerAtPlayerStart 
 Tries to spawn the player's pawn at the specified actor's location */
void RestartPlayerAtPlayerStart(AController NewPlayer, AActor StartSpot) {}
/* Function: RestartPlayerAtTransform 
 Tries to spawn the player's pawn at a specific location */
void RestartPlayerAtTransform(AController NewPlayer, FTransform SpawnTransform) {}
/* Function: ReturnToMainMenuHost 
 Return to main menu, and disconnect any players */
void ReturnToMainMenuHost() {}
/* Function: ShouldReset 
 Overridable function to determine whether an Actor should have Reset called when the game has Reset called on it.
Default implementation returns true

Parameters:
    ActorToReset - The actor to make a determination for

Returns:
    true if ActorToReset should have Reset() called on it while restarting the game, false if the GameMode will manually reset it or if the actor does not need to be reset */
bool ShouldReset(AActor ActorToReset) {}
/* Function: SpawnDefaultPawnAtTransform 
 Called during RestartPlayer to actually spawn the player's pawn, when using a transform

Parameters:
    NewPlayer - Controller for whom this pawn is spawned
    SpawnTransform - Transform at which to spawn pawn

Returns:
    a pawn of the default pawn class */
APawn SpawnDefaultPawnAtTransform(AController NewPlayer, FTransform SpawnTransform) {}
/* Function: SpawnDefaultPawnFor 
 Called during RestartPlayer to actually spawn the player's pawn, when using a start spot

Parameters:
    NewPlayer - Controller for whom this pawn is spawned
    StartSpot - Actor at which to spawn pawn

Returns:
    a pawn of the default pawn class */
APawn SpawnDefaultPawnFor(AController NewPlayer, AActor StartSpot) {}
/* Function: StartPlay 
 Transitions to calls BeginPlay on actors. */
void StartPlay() {}
// Group: Functions

/* Function: SetbUseSeamlessTravel 
 Whether the game perform map travels using SeamlessTravel() which loads in the background and doesn't disconnect clients */
void SetbUseSeamlessTravel(bool Value) {}
/* Function: GetbStartPlayersAsSpectators 
 Whether players should immediately spawn when logging in, or stay as spectators until they manually spawn */
bool GetbStartPlayersAsSpectators() const {}
/* Function: SetbStartPlayersAsSpectators 
 Whether players should immediately spawn when logging in, or stay as spectators until they manually spawn */
void SetbStartPlayersAsSpectators(bool Value) {}
/* Function: GetbPauseable 
 Whether the game is pauseable. */
bool GetbPauseable() const {}
/* Function: SetbPauseable 
 Whether the game is pauseable. */
void SetbPauseable(bool Value) {}
/* Function: GetbUseSeamlessTravel 
 Whether the game perform map travels using SeamlessTravel() which loads in the background and doesn't disconnect clients */
bool GetbUseSeamlessTravel() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static AGameModeBase AGameModeBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AGameModeBase::StaticClass() {}
}
