/* Class: EAttenuationDistanceModel 
  */ 
 class EAttenuationDistanceModel
{
public:
}
/* Enum: EAttenuationDistanceModel 
 
    Linear - Enum
    Logarithmic - Enum
    Inverse - Enum
    LogReverse - Enum
    NaturalSound - Enum
    Custom - Enum
    EAttenuationDistanceModel_MAX - Enum */ 
 enum EAttenuationDistanceModel { 
Linear,
Logarithmic,
Inverse,
LogReverse,
NaturalSound,
Custom,
EAttenuationDistanceModel_MAX, 
}