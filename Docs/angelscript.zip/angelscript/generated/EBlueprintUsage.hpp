/* Class: EBlueprintUsage 
  */ 
 class EBlueprintUsage
{
public:
}
/* Enum: EBlueprintUsage 
 
    NoProperties - Enum
    DoesNotUseBlueprint - Enum
    UsesBlueprint - Enum
    EBlueprintUsage_MAX - Enum */ 
 enum EBlueprintUsage { 
NoProperties,
DoesNotUseBlueprint,
UsesBlueprint,
EBlueprintUsage_MAX, 
}