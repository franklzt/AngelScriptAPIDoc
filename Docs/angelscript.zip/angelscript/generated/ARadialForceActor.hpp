/* Class: ARadialForceActor 
  */ 
 class ARadialForceActor : public ARigidBodyBase
{
public:
// Group: RadialForceActor

/* Variable: ForceComponent 
 Force component */
URadialForceComponent ForceComponent;
// Group: Physics

/* Function: EnableForce 
  */
void EnableForce() {}
/* Function: FireImpulse 
 BEGIN DEPRECATED (use component functions now in level script) */
void FireImpulse() {}
/* Function: ToggleForce 
  */
void ToggleForce() {}
/* Function: DisableForce 
  */
void DisableForce() {}
// Group: Static Functions

/* Function: Spawn 
  */
static ARadialForceActor ARadialForceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ARadialForceActor::StaticClass() {}
}
