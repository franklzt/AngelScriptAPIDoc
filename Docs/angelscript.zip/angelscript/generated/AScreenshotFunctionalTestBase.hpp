/* Class: AScreenshotFunctionalTestBase 
 Base class for screenshot functional test */ 
 class AScreenshotFunctionalTestBase : public AFunctionalTest
{
public:
// Group: Screenshot

/* Variable: ScreenshotCamera 
  */
UCameraComponent ScreenshotCamera;
/* Variable: ScreenshotOptions 
  */
FAutomationScreenshotOptions ScreenshotOptions;
/* Variable: Notes 
  */
FString Notes;
// Group: Static Functions

/* Function: Spawn 
  */
static AScreenshotFunctionalTestBase AScreenshotFunctionalTestBase::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AScreenshotFunctionalTestBase::StaticClass() {}
}
