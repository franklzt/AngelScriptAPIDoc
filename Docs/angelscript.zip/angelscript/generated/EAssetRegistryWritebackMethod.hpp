/* Class: EAssetRegistryWritebackMethod 
  */ 
 class EAssetRegistryWritebackMethod
{
public:
}
/* Enum: EAssetRegistryWritebackMethod 
 
    Disabled - Enum
    OriginalFile - Enum
    AdjacentFile - Enum
    EAssetRegistryWritebackMethod_MAX - Enum */ 
 enum EAssetRegistryWritebackMethod { 
Disabled,
OriginalFile,
AdjacentFile,
EAssetRegistryWritebackMethod_MAX, 
}