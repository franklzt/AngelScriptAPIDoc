/* Class: ANavSystemConfigOverride 
  */ 
 class ANavSystemConfigOverride : public AActor
{
public:
// Group: Navigation

/* Variable: OverridePolicy 
 If there's already a NavigationSystem instance in the world how should this nav override behave */
ENavSystemOverridePolicy OverridePolicy;
/* Variable: bLoadOnClient 
  */
bool bLoadOnClient;
/* Variable: NavigationSystemConfig 
  */
UNavigationSystemConfig NavigationSystemConfig;
// Group: Functions

/* Function: SetbLoadOnClient 
  */
void SetbLoadOnClient(bool Value) {}
/* Function: GetbLoadOnClient 
  */
bool GetbLoadOnClient() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ANavSystemConfigOverride ANavSystemConfigOverride::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ANavSystemConfigOverride::StaticClass() {}
}
