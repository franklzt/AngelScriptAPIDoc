/* Class: APivotTransformGizmo 
 A transform gizmo on the pivot that allows you to interact with selected objects by moving, scaling and rotating. */ 
 class APivotTransformGizmo : public ABaseTransformGizmo
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static APivotTransformGizmo APivotTransformGizmo::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass APivotTransformGizmo::StaticClass() {}
}
