/* Class: AConcertClientPresenceActor 
 A ConcertClientPresenceActor is a transient actor representing other client presences during a concert client session. */ 
 class AConcertClientPresenceActor : public AActor
{
public:
// Group: Rendering

/* Variable: PresenceMeshComponent 
 The camera mesh component to show visually where the camera is placed */
UStaticMeshComponent PresenceMeshComponent;
/* Variable: PresenceTextComponent 
 The text render component to display the associated client's name */
UTextRenderComponent PresenceTextComponent;
/* Variable: PresenceDeviceType 
 The device type that this presence represent (i.e Oculus, Vive, Desktop) */
FName PresenceDeviceType;
// Group: Static Functions

/* Function: Spawn 
  */
static AConcertClientPresenceActor AConcertClientPresenceActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AConcertClientPresenceActor::StaticClass() {}
}
