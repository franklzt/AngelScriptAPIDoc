/* Class: ATestBeaconClient 
 A beacon client used for making reservations with an existing game session */ 
 class ATestBeaconClient : public AOnlineBeaconClient
{
public:
// Group: Functions

/* Function: ServerPong 
 Send a pong RPC to the host */
void ServerPong() {}
/* Function: ClientPing 
 Send a ping RPC to the client */
void ClientPing() {}
// Group: Static Functions

/* Function: Spawn 
  */
static ATestBeaconClient ATestBeaconClient::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ATestBeaconClient::StaticClass() {}
}
