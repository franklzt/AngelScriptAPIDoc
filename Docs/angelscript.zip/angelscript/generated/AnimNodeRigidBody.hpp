/* Class: AnimNodeRigidBody 
  */ 
 class AnimNodeRigidBody
{
public:
// Group: Animation|Dynamics

/* Function: ConvertToRigidBodyAnimNodePure 
 Get a rigid body anim node context from an anim node context (pure) */
static void AnimNodeRigidBody::ConvertToRigidBodyAnimNodePure(FAnimNodeReference Node, FRigidBodyAnimNodeReference& RigidBodyAnimNode, bool& Result) {}
/* Function: SetOverridePhysicsAsset 
 Set the physics asset on the rigid body anim graph node (RBAN). */
static FRigidBodyAnimNodeReference AnimNodeRigidBody::SetOverridePhysicsAsset(FRigidBodyAnimNodeReference Node, UPhysicsAsset PhysicsAsset) {}
/* Function: ConvertToRigidBodyAnimNode 
 Get a rigid body anim node context from an anim node context */
static FRigidBodyAnimNodeReference AnimNodeRigidBody::ConvertToRigidBodyAnimNode(FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result) {}
}
