/* Class: BlendListBase 
  */ 
 class BlendListBase
{
public:
// Group: Blend List Base

/* Function: ResetNode 
 Reset target blend list node to that the next blend is executed from a blank state */
static void BlendListBase::ResetNode(FBlendListBaseReference BlendListBase) {}
/* Function: ConvertToBlendListBase 
 Get a blend list base context from an anim node context. */
static FBlendListBaseReference BlendListBase::ConvertToBlendListBase(FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result) {}
}
