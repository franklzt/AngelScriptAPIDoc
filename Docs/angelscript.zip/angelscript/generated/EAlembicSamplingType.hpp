/* Class: EAlembicSamplingType 
  */ 
 class EAlembicSamplingType
{
public:
}
/* Enum: EAlembicSamplingType 
 
    PerFrame - Enum
    PerXFrames - Enum
    PerTimeStep - Enum
    EAlembicSamplingType_MAX - Enum */ 
 enum EAlembicSamplingType { 
PerFrame,
PerXFrames,
PerTimeStep,
EAlembicSamplingType_MAX, 
}