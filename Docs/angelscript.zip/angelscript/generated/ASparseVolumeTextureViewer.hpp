/* Class: ASparseVolumeTextureViewer 
 A placeable actor that represents a participating media material around a planet, e.g. clouds. */ 
 class ASparseVolumeTextureViewer : public AInfo
{
public:
// Group: Atmosphere

/* Variable: SparseVolumeTextureViewerComponent 
  */
USparseVolumeTextureViewerComponent SparseVolumeTextureViewerComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ASparseVolumeTextureViewer ASparseVolumeTextureViewer::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ASparseVolumeTextureViewer::StaticClass() {}
}
