/* Class: ACameraActor 
 A CameraActor is a camera viewpoint that can be placed in a level. */ 
 class ACameraActor : public AActor
{
public:
// Group: AutoPlayerActivation

/* Variable: AutoActivatePlayerIndex 
 Returns index of the player for whom we auto-activate, or INDEX_NONE (-1) if disabled. */
const int AutoActivatePlayerIndex;
/* Variable: AutoActivateForPlayer 
 Specifies which player controller, if any, should automatically use this Camera when the controller is active. */
EAutoReceiveInput AutoActivateForPlayer;
// Group: CameraActor

/* Variable: SceneComponent 
  */
USceneComponent SceneComponent;
/* Variable: CameraComponent 
 The camera component for this camera */
UCameraComponent CameraComponent;
// Group: AutoPlayerActivation

/* Function: GetAutoActivatePlayerIndex 
 Returns index of the player for whom we auto-activate, or INDEX_NONE (-1) if disabled. */
int GetAutoActivatePlayerIndex() const {}
// Group: Static Functions

/* Function: Spawn 
  */
static ACameraActor ACameraActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACameraActor::StaticClass() {}
}
