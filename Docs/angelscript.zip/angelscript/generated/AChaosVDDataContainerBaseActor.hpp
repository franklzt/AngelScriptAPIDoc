/* Class: AChaosVDDataContainerBaseActor 
 Base class for any CVD actor that will contain frame related data (either solver frame or game frame) */ 
 class AChaosVDDataContainerBaseActor : public AActor
{
public:
// Group: Static Functions

/* Function: Spawn 
  */
static AChaosVDDataContainerBaseActor AChaosVDDataContainerBaseActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass AChaosVDDataContainerBaseActor::StaticClass() {}
}
