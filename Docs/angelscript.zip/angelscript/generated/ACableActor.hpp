/* Class: ACableActor 
 An actor that renders a simulated cable */ 
 class ACableActor : public AActor
{
public:
// Group: Cable

/* Variable: CableComponent 
 Cable component that performs simulation and rendering */
UCableComponent CableComponent;
// Group: Static Functions

/* Function: Spawn 
  */
static ACableActor ACableActor::Spawn(FVector Location = FVector :: ZeroVector, FRotator Rotation = FRotator :: ZeroRotator, FName Name = NAME_None, ULevel Level = nullptr) {}
/* Function: StaticClass 
  */
static UClass ACableActor::StaticClass() {}
}
