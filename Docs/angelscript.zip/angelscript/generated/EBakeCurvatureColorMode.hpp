/* Class: EBakeCurvatureColorMode 
  */ 
 class EBakeCurvatureColorMode
{
public:
}
/* Enum: EBakeCurvatureColorMode 
 
    Grayscale - Enum
    RedBlue - Enum
    RedGreenBlue - Enum
    EBakeCurvatureColorMode_MAX - Enum */ 
 enum EBakeCurvatureColorMode { 
Grayscale,
RedBlue,
RedGreenBlue,
EBakeCurvatureColorMode_MAX, 
}